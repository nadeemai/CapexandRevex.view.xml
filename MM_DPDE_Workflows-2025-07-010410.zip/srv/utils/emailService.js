const { Client } = require('@microsoft/microsoft-graph-client');
const { ClientSecretCredential } = require('@azure/identity');
const SapCfMailer = require('sap-cf-mailer').default;
 
// const clientId = process.env.MAIL_CLIENTID;
// const clientSecret = process.env.MAIL_CLIENT_SECRET;
// const tenantId = process.env.MAIL_TENANT;
// const mailbox = process.env.MAIL_MAILBOX;
 
// const credential = new ClientSecretCredential(tenantId, clientId, clientSecret);
 
// const client = Client.initWithMiddleware({
//     authProvider: {
//         getAccessToken: async () => (await credential.getToken(["https://graph.microsoft.com/.default"])).token
//     }
// });
 
// async function sendMail({ subject, body, to, cc }) {
//     const recipients = Array.isArray(to) ? to : [to];
//     const ccRecipients = cc ? (Array.isArray(cc) ? cc : [cc]) : [];
 
//     const mail = {
//         message: {
//             subject,
//             body: { contentType: "HTML", content: body },
//             toRecipients: recipients.map(email => ({ emailAddress: { address: email } })),
//             ccRecipients: [],
//         },
//         saveToSentItems: 'false'
//     };
 
//     if (ccRecipients.length > 0) {
//         mail.message.ccRecipients = ccRecipients.map(email => ({ emailAddress: { address: email } }));
//     }
 
//     try {
//         console.log('Sending email to:', recipients.join(', '));
//         if(process.env.NODE_ENV != 'development') {
//             await client.api(`/users/${mailbox}/sendMail`).post(mail);
//              console.log('Email sent successfully');
//         }
//         else{
//             // await client.api(`/users/${mailbox}/sendMail`).post(mail);
//             console.log('Email sent successfully');
//             console.log('mail skipped in develoment mode');
//             console.log(JSON.stringify({recipients,ccRecipients,subject}));
//         }
        
//         return 'Email sent successfully';
//     } catch (error) {
//         console.error('Error sending email:', error.response?.data || error.message);
//         throw error;
//     }
// }

async function sendMail( { subject, body, to, cc, attachments } ) {
  const recipients = Array.isArray(to) ? to : [to];
  const ccRecipients = cc ? (Array.isArray(cc) ? cc : [cc]) : [];
 
  try {
    console.log('Sending email to:', recipients.join(', '));
    console.log('Subject:', subject);
 
     if (process.env.NODE_ENV !== 'development') {
      const transporter = new SapCfMailer("MAIL");
      await transporter.sendMail({
        to: recipients,
        subject,
        html: body,
        cc: ccRecipients,
        attachments
      });
      console.log('Email sent successfully');
    } else {
      console.log('📭 Development mode – email not actually sent');
      console.log(JSON.stringify({ recipients, ccRecipients, subject }, null, 2));
    }
 
    return `Email sent successfully to ${recipients.join(', ')}`;
  } catch (err) {
    console.error(`Error in sendMail: ${err.message || err}`);
    return 'Failed to send email';
  }
}
  
 
module.exports = sendMail;

async function insertAndUpdateProcessLog(tx, reqID, currStage, approver, currentUser, remarks) {
   
    await tx.run(
      INSERT.into(ProcessLogs).entries({
        reqID,
        stage: currStage,
        userName: approver.name,
        userEmail: currentUser,
        status: 'Pending',
        receivedDt: new Date()
      })
    );
  
    await tx.run(
      UPDATE(ProcessLogs)
        .set({ status: 'Approved', remarks: remarks })
        .where({ reqID, status: 'Pending' })
    );
  }
  
 
 