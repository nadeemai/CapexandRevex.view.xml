
const getCurrTimestamp = () => {
    return new Date().toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        timeZone: 'Asia/Kolkata'
    });
}

module.exports = {
    getCurrTimestamp
}
