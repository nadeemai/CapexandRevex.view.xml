async function insertAndUpdateProcessLog(req) {


    // currStage, approver, currentUser, remarks
    const {Requests,ReqFormNB_Details,ProcessLogs}=this.entities;

    const {
      reqID
     
    } = req.data;
    const tx= cds.tx(req);
  
    const RequestsData= await tx.run(
      SELECT.one.from(Requests).where({reqID:reqID})
    );

    const ReqFormNB_Details_Data= await tx.run(
        SELECT.one.from(ReqFormNB_Details).where({reqID})
      );

    const {stage,status}=RequestsData;
    const {approverR1,email}= ReqFormNB_Details_Data;


    // Insert a new pending process log
    await tx.run(
      INSERT.into(ProcessLogs).entries({
        reqID,
        stage: stage,
        userName: approverR1,
        userEmail: email,
        status: status,
        receivedDt: new Date()
      })
    );
  
    // // Update the previous pending log to approved with remarks
    // await tx.run(
    //   UPDATE(ProcessLogs)
    //     .set({ status: 'Approved', remarks: remarks })
    //     .where({ reqID, status: 'Pending' })
    // );
  }

  
  module.exports={
    insertAndUpdateProcessLog
  }