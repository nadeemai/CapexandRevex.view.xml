const cds = require('@sap/cds');

const developmentUser = "50010024@mahindra.com"

async function OnCreateReq(req, res) {
    const db = await cds.connect.to('db');
    const { Request } = db.entities('mm_dpde_schema')
    const tx = cds.transaction(req);
    const requests = req.data;
    const { type } = req.data;
    const subType = req.data.infraDtl?.subType || req.data.newdtl?.subType || '';
    const NABDiv = req.data.newdtl?.NABDiv || '';

    try {
        const seqNum = await getNextSequence(tx, type);
        requests.reqID = generateReqID(type, seqNum);
        requests.refNo = generateRefNo(type, seqNum, subType, NABDiv);
        const now = new Date();
        const currUser = process.env.NODE_ENV == 'development' ? developmentUser : req.user.id;
        requests.createdAt = now;
        requests.createdBy = currUser;
        requests.modifiedAt = now;
        requests.modifiedBy = currUser;
        requests.stage = 'Initiator';
        requests.status = 'Draft';

        await tx.run(INSERT.into(Request).entries(requests));
        return requests;

    } catch (error) {
        console.error("Error in OnCreateReq:", error);
        await tx.rollback();
        throw new Error(500, `Failed to create request: ${error.message}`);
    }
}

async function OnUpdateReq(req) {

    const db = await cds.connect.to('db');
    const { Request } = db.entities('mm_dpde_schema')
    const tx = cds.transaction(req);
    const requests = req.data;
    const { reqID } = req.data;
    const currUser = process.env.NODE_ENV == 'development' ? developmentUser : req.user.id;

    try {
        requests.modifiedAt = new Date();
        requests.modifiedBy = currUser;
        await tx.run(UPDATE(Request).set(req.data).where({ reqID }));
        const CompleteData = await tx.run(
            SELECT.one.from(Request).where({ reqID })
        )
        console.log(CompleteData);

        return CompleteData;
    } catch (error) {
        console.error("Error in OnUpdateReq:", error);
        await tx.rollback();
        throw new Error(500, `Failed to update request: ${error.message}`);
    }
}


async function OnGetReqAP(req) { // used in SSFD : can be used in other also : for approver dashboard
    const db = await cds.connect.to('db');

    const { Request, ProcessLog } = db.entities('mm_dpde_schema');
    const { Approvers } = db.entities('mm_dpde_master');
    const tx = cds.transaction(req);

    const user = process.env.NODE_ENV == 'development' ? developmentUser : req.user.id; // dev
    const currentUserRoles = await tx.run(SELECT.from(Approvers).where({ email: user }));
    const currUser = currentUserRoles[0];
    const userID = currUser.email.split("@")[0];
    // const userRoles = currentUserRoles.map(user => user.role);
    // const userRoles = currentUserRoles.map(user=>user.role).map((role)=>role?.replace('CDMM-HEAD',"CDMM-FDPD HEAD")?.replace('FDPD-HEAD',"CDMM-FDPD HEAD"));
    const userRoles = currentUserRoles.map(user => user.role)
        .map((role) =>
            role
                ?.replace('FDQA-HEAD', 'FDQA & Customer Care-HEAD')
                ?.replace('Customer Care-HEAD', 'FDQA & Customer Care-HEAD')
                ?.replace('Customer Care-PUL', 'Customer Care & QA-PUL')
                ?.replace('QA-PUL', 'Customer Care & QA-PUL')
                ?.replace('CDMM-HEAD', 'CDMM-FDPD HEAD')
                ?.replace('FDPD-HEAD', 'CDMM-FDPD HEAD')
        );
    const requests = await SELECT.from(Request)
        // .where({ 
        //     pendingWith: currUser.email ,
        //     or: { stage: currUser.role}
        //   });
        .where({
            pendingWith: currUser.email,
            or: { stage: { in: userRoles } }

        });
    return requests;
}



async function getNextSequence(tx, reqType) {
    const db = await cds.connect.to('db');


    const { SeqTracker } = db.entities('mm_dpde_schema')
    let tracker = await tx.run(SELECT.one.from(SeqTracker).where({ projectName: reqType }));
    let nextSeq;

    if (!tracker) {
        nextSeq = 1;
        await tx.run(INSERT.into(SeqTracker).entries({ projectName: reqType, lastSeq: nextSeq }));
    } else {
        nextSeq = tracker.lastSeq + 1;
        await tx.run(UPDATE(SeqTracker).set({ lastSeq: nextSeq }).where({ projectName: reqType }));
    }

    return nextSeq;
}

function generateReqID(reqType, seqNum) {
    const prefix =
        reqType === 'SSFD' ? 'REQ-FD' :
            reqType === 'ADPD' ? 'REQ-AP' :
                reqType === 'ISR' ? 'REQ-IS' :
                    reqType === 'NAB' ? 'REQ-CCE' :
                        reqType === 'P24' ? 'REQ-CA' :
                            reqType === 'EXP' ? 'REQ-EXP' :
                                'REQ-XX';

    const seqStr = String(seqNum).padStart(4, '0');
    const seqStr3 = String(seqNum).padStart(3, '0');
    if (prefix === 'REQ-CCE') {
        return `${prefix}-${seqStr3}`
    }
    return `${prefix}-${seqStr}`;
}


// function generateRefNo(reqType, seqNum) {
//     const now = new Date();
//     const currentYear = now.getFullYear();
//     const fyShort = String(currentYear).slice(2);       // e.g., "25" for 2025
//     const fullFY = `FY-${currentYear}`;                 // e.g., "FY-2025"
//     const seqStr = String(seqNum).padStart(3, '0');     // e.g., "001"

// function generateRefNo(reqType, seqNum) {
//     const now = new Date();
//     const currentYear = now.getFullYear();
//     const fyShort = String(currentYear).slice(2);       // e.g., "25" for 2025
//     const fullFY = `FY-${currentYear}`;                 // e.g., "FY-2025"
//     const seqStr = String(seqNum).padStart(3, '0');     // e.g., "001"

//     if (reqType === 'ADPD') {
//         return `SSAP-FY${fyShort}-IT-${seqStr}`;        // e.g., SSAP-FY25-IT-001
//     } else { //for SSFD : but need to be modified if more processes come in picture
//         const fullSeqStr = String(seqNum).padStart(4, '0'); // e.g., "0001"
//         return `${fullFY}-${fullSeqStr}`;                   // e.g., FY-2025-0001
//     }
// }

function getCurrentFinancialYearFormatted() {
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth(); // 0 = Jan, 11 = Dec
    const startYear = month >= 3 ? year : year - 1;
    const endYearShort = (startYear + 1).toString().slice(-2);
    return `${endYearShort}`;
}
function generateRefNo(reqType, seqNum, subType, NABDiv) {
    const now = new Date();

    const currentYear = now.getFullYear();
    const fyShort = String(currentYear).slice(2);           // e.g., "25"
    const fullFY = `FY-${currentYear}`;                   // e.g., "FY-2025"
    const seqStr3 = String(seqNum).padStart(3, '0');        // e.g., "001"
    const seqStr4 = String(seqNum).padStart(4, '0');        // e.g., "0001"
    const seqStr6 = String(seqNum).padStart(6, '0');        // e.g., "000001"

    if (reqType === 'ADPD') {
        return `SSAP-FY${fyShort}-AP-${seqStr3}`;           // e.g., SSAP-FY25-AP-001 
    } else if (reqType === 'SSFD') {
        return `${fullFY}-${seqStr4}`;                      // e.g., FY-2025-0001
    } else if (reqType === 'ISR' && subType === 'FRS') {
        return `FRS-${fyShort}-${seqStr6}`;                 // e.g., FRS-25-000001
    } else if (reqType === 'ISR' && subType === 'CRS') {
        return `CRS-FY${fyShort}-${seqStr6}`;               // e.g., CRS-FY25-000001
    } else if (reqType === 'ISR' && subType === 'SRS') {
        return `SRS-FY${fyShort}-${seqStr6}`;               // e.g., SRS-FY25-000001
    } else if (reqType === 'ISR' && subType === 'WDRS') {
        return `WDRS-FY${fyShort}-${seqStr6}`;              // e.g., WDRS-FY25-000001
    } else if (reqType === 'NAB') {
        const CurrentFY = getCurrentFinancialYearFormatted()
        return `F${CurrentFY}-${NABDiv}-${subType}-${seqStr3}`;   //F25-AD-CR-001
    } else if (reqType === 'P24') {
        return `FY${fyShort}-${seqStr6}`;
    } else if (reqType === 'P25') {
        return `FY${fyShort}-${seqStr6}`;
    } else if (reqType === 'EXP') {
        return `EXP-F${fyShort}-${seqStr6}`;
    }
    else {
        throw new Error(`Unsupported request type: ${reqType}`);
    }
}


// by default get the first user with the email if you want a user with specify role then pass req.data.role
async function getCurrentUser(req) {
    const tx = cds.transaction(req);
    const db = await cds.connect.to('db');
    const { Approvers } = db.entities('mm_dpde_master')
    const role = req.data.role;
    const currUser = process.env.NODE_ENV == 'development' ? developmentUser : req.user.id;
    if (role)
        return await tx.run(SELECT.one.from(Approvers).where({ email: currUser, role }));
    return tx.run(SELECT.one.from(Approvers).where({ email: currUser }));
}

module.exports = {
    OnCreateReq, OnUpdateReq, OnGetReqAP, getCurrentUser
}
