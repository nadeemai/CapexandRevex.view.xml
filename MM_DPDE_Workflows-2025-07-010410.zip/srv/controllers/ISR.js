
// async function OnISRApproval(req) {
//   const db = await cds.connect.to('db');
//   const { Approvers,ProcessGroupTask } = db.entities('mm_dpde_master');
//   const { Request, ReqFormISR, ProcessLog} = db.entities('mm_dpde_schema')
//   const tx = cds.transaction(req);
//   const { reqID, action, remarks } = req.data;
//   const request = await tx.run(SELECT.one.from(Request).where({ reqID: reqID }));
//   const isrData = await tx.run(SELECT.one.from(ReqFormISR).where({ reqID }));
//   const pendingLog = await tx.run(SELECT.one.from(ProcessLog).where({ reqID: reqID, status: 'Pending' }).orderBy('receivedDt desc'));
   
//   //TODO:remove after testing get current user with the specified role
//   // passing the role so that we can get current user with particular role only 
//   req.data.role = action !== 'SUBMIT' ?  pendingLog?.stage  : '';

//   const currentUser = await getCurrentUser(req);
//   // if no current user found
 
//   console.log(action,currentUser, pendingLog);
//   //Check in pending log : currUser email == pedinglog.useer or pendinglog.role=userRole
//   if (action !== 'SUBMIT' && pendingLog) {
//     if(!currentUser){
//       req.reject("Your are not Authorised User");
//     }
//     const { userEmail, stage } = pendingLog;
//     // if user email is there then check email else check role
//     const isAllowed = (userEmail && currentUser.email == userEmail)  || currentUser.role == stage;
//     if (!isAllowed) {
//       req.reject("You are not Authorised to Approve or Sent Back");
//     }
//   }

//   // const date = getCurrTimestamp;
//   const date = getCurrTimestamp();


//   let stage = request.stage;
//   const subType = isrData.subType;

//   if (action === 'SUBMIT') {
//     const reSubmit = await tx.run(SELECT.one.from(ProcessLog).where({ reqID: reqID, status: 'Sent Back' }));
//     console.log(reSubmit);
//     await tx.run(INSERT.into(ProcessLog).entries({
//       reqID,
//       stage: 'Initiator',
//       userName: currentUser?.name ?? req.user.id,
//       userEmail: currentUser?.email ?? req.user.id,
//       status: reSubmit ? 'RESUBMITTED' : 'SUBMITTED',
//       receivedDt: new Date(),
//       remarks
//     })
//     );

//     //Send Mail
//     const email = await getHODEmail(isrData,subType
// , tx);
//     // const hod = isrData.hod;
//     const fullString = isrData.approver;
//     const userName = fullString?.split(' - ')[1];
//     await tx.run(INSERT.into(ProcessLog).entries({
//       // ID:id,
//       reqID,
//       stage: 'HOD',
//       userName: userName,
//       userEmail: email,
//       status: 'Pending',
//       receivedDt: new Date()
//     }));
//     const userID = email.split("@")[0];

//     // await sendSanctionEmail(isrData, request.refNo, 'HOD', email, date);
//    await sendSanctionEmail({
//         isrData: isrData,
//         refNo: request.refNo,
//         stage: 'HOD',
//         emails:email,
//         date,
//     });
//     await tx.run(UPDATE(Request).set({ stage: 'HOD', status: 'Pending', pendingWith: email, pendingWithName: userName }).where({ reqID: reqID }));
//     return { message: `Request ${request.refNo} submitted for Approval successfully.` };
//   }

// //   else if (action === 'APPROVE') {

// //     let nextStage;
// //     let newStatus = 'Pending';
// //     if (stage == 'Final Accounts') {
// //       newStatus = 'Approved'
// //       await tx.run(UPDATE(Request).set({ stage: 'Approved', pendingWith: '', status: 'Approved',pendingWithName:'' }).where({ reqID: reqID }));
// //       await tx.run(
// //         UPDATE(ProcessLog)
// //           .set({ status: 'Approved', remarks: remarks })
// //           .where({ reqID, status: 'Pending' })
// //       );
// //     } else {

// //       nextStage = await getNextStage({
// //         "pId": department,
// //         "subId": isrData.subType || request.subType,
// //         "amount": isrData.budgetRequired,
// //         "stage": stage,
// //         "puDept": isrData.puDept,
// //         "selectedPerson": isrData.selectedApprover,
// //       }, tx);
// //       // check in entity ProcessGroupTask  that  for the nextStage: is a group approver?? if yes then select many from appovers table else one

// //       let approvers = await tx.run(
// //         SELECT.from(Approvers).columns('name', 'email').where({ role: nextStage, department })
// //       );

// //       console.log(approvers);

// //       let groupTask = await tx.run(
// //         SELECT.one.from(ProcessGroupTask).where({ processId: request.type,stage:nextStage })
// //       );

// //       if (approvers?.length==0) {
// //         throw new Error(`Approver email not found`);
// //       }
// //       let isGroupTask= groupTask?.isGroup || false;

// //       // const email = approvers.email;
// //       // const userID = approver.email.split('@')[0];
// //       // await sendSanctionEmail(isrData, request.refNo, nextStage, approver.email, date);
// //       const approversEmail = approvers.map(approver=> approver.email);
// //       await sendSanctionEmail({
// //         isrData: isrData,
// //         refNo: request.refNo,
// //         stage: nextStage,
// //         emails:isGroupTask?approversEmail:approversEmail[0],   //we will send array of approvers email
// //         date,
// //     });
// //     //in case of groupAprover there will be pending with name would be the name,and pending with will be empty 
// //       const pendingWithName = isGroupTask? `${nextStage} Team`: approvers[0].name;
// //       const pendingWith = isGroupTask? '': approvers[0].email;
// //       await tx.run(UPDATE(Request).set({ stage: nextStage, pendingWith: pendingWith ,pendingWithName:pendingWithName}).where({ reqID: reqID }));

// //       await tx.run(
// //         UPDATE(ProcessLog)
// //           .set({ status: 'Approved', remarks: remarks,userEmail:currentUser.email,userName:currentUser.name})
// //           .where({ reqID, status: 'Pending' })
// //       );
// //       //in case of groupAprover there will be role inserted and name amd email would be empty 
// //       await tx.run(INSERT.into(ProcessLog).entries({
// //         reqID,
// //         stage: nextStage,
// //         userName:pendingWithName,
// //         userEmail: pendingWith, //all emails will be shown in case of group 
// //         status: newStatus,
// //         receivedDt: new Date(),
// //       }));
     

// //     }


// //   }

// //   else if (action === 'SENT BACK') {
// //     //send mail to Initiator 

// //     if (stage == 'Final Accounts') {
// //       req.reject('You cannot sent Back');
// //     }

// //     await tx.run(UPDATE(Request).set({ stage: 'Sent Back', status: 'Sent Back', pendingWith: '',pendingWithName:'' }).where({ reqID: reqID }));
// //     await tx.run(
// //       UPDATE(ProcessLog)
// //         .set({ status: 'Sent Back', remarks: remarks })
// //         .where({ reqID, status: 'Pending' })
// //     );
   
// //     const emailLog = await SELECT.one.from(ProcessLog).columns('userEmail').where({
// //       reqID: reqID,
// //       stage: 'Initiator'
// //     });
// //     const email = emailLog.userEmail;

// //     // await sendInitiatorEmail(isrData, request.refNo, email, date);
// //     await sendSanctionEmail({
// //       isrData: isrData,
// //       refNo: request.refNo,
// //       stage: '',
// //       date,
// //       emails:email,
// //       type: 'initiator'
// //     });

// //     return 'Sent back to Initiator';
// //   }

// };

// async function getHODEmail(isrData,subType
// , tx) {

//   const db = await cds.connect.to('db');
//   const { Approvers } = db.entities('mm_dpde_master');

//   try {
//     const fullString = isrData.approver;
//     const department = `ISR_${subType}`;
//     const userID = fullString?.split(' - ')[0];
//     if (!userID) throw new Error(400, 'Invalid approver format.');


//     const approver = await tx.run(SELECT.one.from(Approvers).where({ userID ,department}));
//     if (!approver) throw new Error(404, `No approver found for userID: ${userID}`);

//     const HODEmail = await approver.email;

//     return HODEmail;
//   } catch (error) {
//     console.error("Error fetching approver email:", error);
//     throw new Error(500, `Failed to fetch email: ${error.message}`);
//   }
// }

// async function sendSanctionEmail({
//     isrData,
//     refNo,
//     stage,
//     emails,
//     date,
//     type = 'approver' // or 'initiator'
//   }) {
//     const isInitiator = type === 'initiator';
  
//     const role = isInitiator ? 'IN' : 'AP';
//     const linkLabel = isInitiator ? 'Dashboard' : 'Approval Portal';
//     const subject = isInitiator
//       ? `e-Special Sanction Refno #${refNo} - Sent Back to Initiator`
//       : `e-Special Sanction Refno #${refNo} - ${stage} Approval`;
  
//     const approvalLink = `https://mamdevuat-o55cwsdo.launchpad.cfapps.eu10.hana.ondemand.com/e4109682-d445-4b2b-8667-aed2e5036b4b.comapprovalrouter.commmapprovalhubapprovalhub-0.0.1/index.html?role=${role}`;
  
//     const body = `
//         <p>Dear Sir/ Madam,</p>
//         <p>Please find below eSpecial Sanction Approval Process details</p>
//         <table border="1" cellpadding="8" cellspacing="0" style="border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; font-size: 14px;">
//           <tr>
//             <td style="background-color: red; color: white;">Division</td><td>${isrData.division || ''}</td>
//             <td style="background-color: red; color: white;">PU/Department</td><td>${isrData.puDept || ''}</td>
//             <td style="background-color: red; color: white;">Date</td><td>${date || ''}</td>
//           </tr>
//           <tr>
//             <td style="background-color: red; color: white;">Location</td><td>${isrData.loc || ''}</td>
//             <td style="background-color: red; color: white;">Project Name</td><td>${isrData.projName || ''}</td>
//             <td style="background-color: red; color: white;">Item Required / Description</td><td>${isrData.itemRequiredDesc || ''}</td>
//           </tr>
//           <tr>
//             <td style="background-color: red; color: white;">Budget Required</td><td>${isrData.budgetRequired || ''}</td>
//             <td style="background-color: red; color: white;">IRR (>3Cr)</td><td>${isrData.irr || ''}</td>
//             <td colspan="2"></td>
//           </tr>
//           <tr>
//             <td style="background-color: red; color: white;">Background/Current Scenario</td><td>${isrData.background || ''}</td>
//             <td style="background-color: red; color: white;">Proposal/Justification</td><td>${isrData.justification || ''}</td>
//             <td style="background-color: red; color: white;">Deliverables</td><td>${isrData.deliverables || ''}</td>
//           </tr>
//         </table>
//         <p>
//           <a href="${approvalLink}" style="background-color: #007bff; color: #fff; padding: 10px 15px; text-decoration: none; border-radius: 4px;">
//             ${linkLabel}
//           </a>
//         </p>
//       `;
  
//     await sendMail({ to: emails, subject, body });
//   }

// module.exports = {
//     OnISRApproval
//   }




//new changes approve and submit and mail
 
const cds = require('@sap/cds');
const { getCurrTimestamp } = require("../utils/dateUtils");
const sendMail = require('../utils/emailService');
const { getCurrentUser } = require('./Request');
 
 
async function OnISRApproval(req) {
  const db = await cds.connect.to('db');
  const { Approvers } = db.entities('mm_dpde_master');
  const { Request, ReqFormISR, ReqFormISR_Vehicle_Details, ProcessLog } = db.entities('mm_dpde_schema');
  const tx = cds.transaction(req);
  const { reqID, action, remarks } = req.data;
 
  const request = await tx.run(SELECT.one.from(Request).where({ reqID }));
  const isrData = await tx.run(SELECT.one.from(ReqFormISR).where({ reqID }));
  const isrTabledata = await tx.run(SELECT.from(ReqFormISR_Vehicle_Details).where({ reqID }));
  const pendingLog = await tx.run(SELECT.one.from(ProcessLog).where({ reqID, status: 'Pending' }).orderBy('receivedDt desc'));

  req.data.role = action !== 'SUBMIT' ? pendingLog?.stage : '';
  req.data.department = `ISR_${isrData.subType}`;
 
  const currentUser = await getCurrentUser(req);
  const date = getCurrTimestamp();
  const stage = request.stage;
  const subType = isrData.subType;
 
  if (action !== 'SUBMIT' && pendingLog) {
    if (!currentUser) req.reject("You are not Authorised User");
    const { userEmail, stage } = pendingLog;
    const isAllowed = (userEmail && currentUser.email == userEmail) || currentUser.role == stage;
    if (!isAllowed) req.reject("You are not Authorised to Approve or Sent Back");
  }
 
  if (action === 'SUBMIT') {
    const reSubmit = await tx.run(SELECT.one.from(ProcessLog).where({ reqID, status: 'SEND BACK' }));
    await tx.run(INSERT.into(ProcessLog).entries({
      reqID,
      stage: 'Initiator',
      userName: currentUser?.name ?? req.user.id,
      userEmail: currentUser?.email ?? req.user.id,
      status: reSubmit ? 'RESUBMITTED' : 'SUBMITTED',
      receivedDt: new Date(),
      remarks
    }));
 
    const email = await getHODEmail(isrData, subType, tx);
    const fullString = isrData.approver;
    const userName = fullString?.split(' - ')[1];
    const nextStage = ['FRS', 'WDRS'].includes(subType) ? 'Approver' : 'HOD';
 
    await tx.run(INSERT.into(ProcessLog).entries({
      reqID,
      stage: nextStage,
      userName,
      userEmail: email,
      status: 'Pending',
      receivedDt: new Date()
    }));
 
    await sendInfraEmail({ isrData, refNo: request.refNo, stage: nextStage, emails: email, date, subType });
    await sendInfraEmail({ isrData, refNo: request.refNo, stage: nextStage, emails: currentUser.email, date, type: 'initiator', subType });
 
    await tx.run(UPDATE(Request).set({
      stage: nextStage,
      status: 'Pending',
      pendingWith: email,
      pendingWithName: userName
    }).where({ reqID }));
 
    return { message: `Request ${request.refNo} submitted for Approval successfully.` };
  }
 
  if (action === 'APPROVE') {
    const nextStage = await getNextStage(stage, subType);
 
    await tx.run(UPDATE(ProcessLog).set({
      status: 'Approved',
      remarks,
      userEmail: currentUser.email,
      userName: currentUser.name
    }).where({ reqID, status: 'Pending' }));
 
    //  CHANGES BEGIN: Final approval stage
    if (!nextStage) {
      await tx.run(UPDATE(Request).set({
        stage: 'Completed',
        status: 'Approved',
        pendingWith: '',
        pendingWithName: ''
      }).where({ reqID }));
 
      const emailLog = await SELECT.one.from(ProcessLog).columns('userEmail').where({ reqID, stage: 'Initiator' });
 
      // Send completion email to initiator
      await sendInfraEmail({
        isrData,
        refNo: request.refNo,
        stage: 'Completed',
        emails: emailLog.userEmail,
        date,
        type: 'completed',
        subType
      });
 
      // Send final confirmation email to approver
      await sendInfraEmail({
        isrData,
        refNo: request.refNo,
        stage: 'Completed',
        emails: currentUser.email,
        date,
        type: 'completed',
        subType
      });
 
      // NEW LOGIC: If subType is SRS or CRS and final stage is Stores
      if (['SRS', 'CRS'].includes(subType) && stage === 'Stores') {
       
        let sendStoresIncharge = false;
 
        for (const row of isrTabledata) {
          const issued = Number(row.issuedQty || 0);
          const approved = Number(row.approvedQty || 0);
       
          if (issued < approved) {
            sendStoresIncharge = true;
            break;
          }
  }
 
     
        // Send to Stores In-Charge if needed
        if (sendStoresIncharge) {
          const storesApprover = await tx.run(
            SELECT.one.from(Approvers).where({ role: 'StoresIncharge', department: `ISR_${subType}` })
          );
          if (storesApprover?.email) {
            await sendInfraEmail({
              isrData,
              refNo: request.refNo,
              stage: 'Completed',
              emails: storesApprover.email,
              date,
              type: 'completed',
              subType
            });
          }
        }
 
        // Always notify HOD
        const hodEmail = await getHODEmail(isrData, subType, tx);
        await sendInfraEmail({
          isrData,
          refNo: request.refNo,
          stage: 'Completed',
          emails: hodEmail,
          date,
          type: 'completed',
          subType
        });
      }
      //  CHANGES END
 
      return { message: `Request ${request.refNo} is fully approved and completed.` };
    }
 
    // Proceed to next stage
    const approver = await tx.run(SELECT.one.from(Approvers).where({ role: nextStage, department: `ISR_${subType}` }));
    const nextEmail = approver?.email || '';
    const nextName = approver?.name || `${nextStage} Operator`;
 
    await tx.run(INSERT.into(ProcessLog).entries({
      reqID,
      stage: nextStage,
      userName: nextName,
      userEmail: nextEmail,
      status: 'Pending',
      receivedDt: new Date()
    }));
 
    await tx.run(UPDATE(Request).set({
      stage: nextStage,
      status: 'Pending',
      pendingWith: nextEmail,
      pendingWithName: nextName
    }).where({ reqID }));
 
    await sendInfraEmail({ isrData, refNo: request.refNo, stage: nextStage, emails: nextEmail, date, subType });
    return { message: `Request ${request.refNo} approved and moved to ${nextStage} Operator` };
  }
 
  if (action === 'SEND BACK') {
    await tx.run(UPDATE(Request).set({
      stage: 'SEND BACK',
      status: 'SEND BACK',
      pendingWith: '',
      pendingWithName: ''
    }).where({ reqID }));
 
    await tx.run(UPDATE(ProcessLog).set({
      status: 'SEND BACK',
      remarks
    }).where({ reqID, status: 'Pending' }));
 
    const emailLog = await SELECT.one.from(ProcessLog).columns('userEmail').where({ reqID, stage: 'Initiator' });
 
    await sendInfraEmail({
      isrData,
      refNo: request.refNo,
      stage: '',
      date,
      emails: emailLog.userEmail,
      type: 'initiator',
      subType
    });
 
    return { message: `Request ${request.refNo} sent back to Initiator.` };
  }
}
 
async function getHODEmail(isrData, subType, tx) {
  const { Approvers } = tx.entities('mm_dpde_master');
  const fullString = isrData.approver;
  if (!fullString || !fullString.includes(' - ')) {
    throw new Error('Invalid approver format. Expected "userID - Full Name"');
  }
  const userID = fullString.split(' - ')[0];
  const department = `ISR_${subType}`;
  const approver = await tx.run(SELECT.one.from(Approvers).where({ userID, department }));
  if (!approver || !approver.email) {
    throw new Error(`No approver found for userID: ${userID} in ${department}`);
  }
  return approver.email;
}
 
 
function buildPdfData(infraDtl, history, refNo, date) {
  return {
    refNo,
    date,
    subType: infraDtl.subType,
    requester: infraDtl.initiator || '',
    approver: infraDtl.approver || '',
    department: infraDtl.dept || '',
    costCenter: infraDtl.costCenter || '',
    location: infraDtl.loc || '',
    wbsCode: infraDtl.WBSCode || '',
    typeOfWaste: infraDtl.typeOfWaste || '',
 
    // Line items
    requirementDtl: (infraDtl.requirementDtl || []).map(item => ({
      partDesc: item.partDesc || '',
      partNo: item.partNo || '',
      binNo: item.binNo || '',
      price: item.price || '',
      UOM: item.UOM || '',
      tentativeWt: item.tentativeWt || '',
      weighmentWt: item.weighmentWt || '',
      requestedQty: item.requestedQty || '',
      approvedQty: item.approvedQty || '',
      issuedQty: item.issuedQty || '',
      vehicleNo: item.vehicleNo || '',
      projectNo: item.projectNo || '',
      productDesc: item.productDesc || '',
    })),
 
    // Approval history
    history: (history || []).map(row => ({
      stage: row.stage,
      email: row.userEmail,
      role: row.stage === 'Initiator' ? 'Initiator' : 'Approver',
      status: row.status,
      date: row.receivedDt ? new Date(row.receivedDt).toLocaleString('en-GB') : '',
      remarks: row.remarks || ''
    }))
  };
}
 
 
 
async function sendInfraEmail({ isrData, refNo, stage, emails, date, type = 'approver', subType }) {
  const db = await cds.connect.to('db');
  const { ProcessLog } = db.entities('mm_dpde_schema');
 
  const isInitiator = type === 'initiator';
  const isCompleted = type === 'completed';
  const role = isInitiator ? 'IN' : 'AP';
 
  const linkLabel = isInitiator ? 'Dashboard' : 'Approval Portal';
  const approvalLink = `https://mamdevuat-o55cwsdo.launchpad.cfapps.eu10.hana.ondemand.com/e4109682-d445-4b2b-8667-aed2e5036b4b.comapprovalrouter.commmapprovalhubapprovalhub-0.0.1/index.html?role=${role}`;
 
  const subject = isCompleted
    ? `${getSlipLabel(subType)} for ${refNo} has been Completed by HOD.`
    : isInitiator
      ? `e-Special Infra Refno #${refNo} - Request Submitted for Approval`
      : `${getSlipLabel(subType)} for ${refNo} your Action.`;
 
  let body = `<p><b>${isInitiator ? 'Request Submitted' : isCompleted ? 'Completed by HOD' : 'Approval Required'}</b></p>`;
 
  const history = await cds.run(SELECT.from(ProcessLog).where({ reqID: isrData.reqID }).orderBy('receivedDt ASC'));
 
  const slipLabel = getSlipLabel(subType);
  const highlightNote =
    subType === 'FRS' && isCompleted
      ? `<p style="background-color: yellow; font-weight:bold;">NOTE: FUEL REQUEST PDF-PRINTOUT CAN BE TAKEN FROM FRS PRINTOUT SCREEN</p>`
      : (subType === 'CRS' || subType === 'SRS') && !isInitiator
        ? `<p style="background-color: yellow; font-weight:bold;">Note: Please collect items from stores within 3 days starting from today.</p>`
        : (subType === 'WDRS' && isCompleted)
          ? `<p style="background-color: yellow; font-weight:bold;">WDRS request has been successfully completed. Please process for disposal.</p>`
          : '';
 
  body += `
    <table style="width:100%; font-family: Arial, sans-serif; font-size: 14px;" border="1">
      <tr><td colspan="6" style="background-color:red;color:white;"><b>${slipLabel} Details for the ${slipLabel} Number #${refNo}</b></td></tr>
      <tr><td><b>${slipLabel} Number</b></td><td>${refNo}</td>
          <td><b>Requester</b></td><td>${isrData.initiator}</td>
          <td><b>Approver</b></td><td>${isrData.approver}</td></tr>
      <tr><td><b>Requested Date</b></td><td>${date}</td>
          <td><b>Department Name</b></td><td>${isrData.dept}</td>
          <td><b>Cost Center</b></td><td>${isrData.costCenter || ''}</td></tr>
    </table>
    ${highlightNote}`;
 
  body += `<p><b>Workflow History Details:</b></p>
    <table border="1" cellpadding="6" cellspacing="0" style="border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; font-size: 14px;">
      <tr style="background-color:red;color:white;">
        <th>Stages</th><th>Approver</th><th>Role</th><th>Status</th><th>Approved Date</th><th>Remarks</th>
      </tr>`;
 
  history.forEach(entry => {
    body += `<tr>
      <td>${entry.stage}</td>
      <td>${entry.userEmail}</td>
      <td>${entry.stage === 'Initiator' ? 'Initiator' : 'Approver'}</td>
      <td>${entry.status}</td>
      <td>${['Approved', 'Initiated','SUBMITTED', 'RESUBMITTED'].includes(entry.status) && entry.receivedDt
        ? new Date(entry.receivedDt).toLocaleString('en-GB') : ''}</td>
      <td>${entry.remarks || ''}</td>
    </tr>`;
  });
 
  body += `</table>
    <p><a href="${approvalLink}" style="color:#007bff;">Click here</a> for your action.</p>`;
 
  await sendMail({ to: emails, subject, body });
}
 
function getSlipLabel(subType) {
  switch (subType) {
    case 'FRS': return 'Fuel Requisition slip';
    case 'CRS': return 'Consumable Requisition slip';
    case 'SRS': return 'Stationery Requisition slip';
    case 'WDRS': return 'Waste Disposal Requisition slip';
    default: return 'Infra Requisition slip';
  }
}
 
 
 
 
async function getNextStage(stage, subType) {
  const flowMap = {
    FRS: { Approver: null },
    CRS: { HOD: 'Stores', Stores: null },
    SRS: { HOD: 'Stores', Stores: null },
    WDRS: { Approver: 'ScrapYard', ScrapYard: null }
  };
 
  if (!subType || !stage) throw new Error('Missing subType or stage');
 
  const normalizedStage = stage.replace(/\s/g, '');
  const typeFlow = flowMap[subType];
  if (!typeFlow) throw new Error(`Workflow not defined for subType: ${subType}`);
 
  const nextStage = typeFlow[normalizedStage];
  if (nextStage === undefined) throw new Error(`Invalid stage '${stage}' for subType '${subType}'`);
 
  return nextStage;
}
 
module.exports = {
  OnISRApproval,
  getNextStage,
  sendInfraEmail
};
 
 