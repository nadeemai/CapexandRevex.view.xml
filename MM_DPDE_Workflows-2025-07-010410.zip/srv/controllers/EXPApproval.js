const cds = require('@sap/cds');
const sendMail = require('../utils/emailService');
const { getCurrentUser } = require('./Request');
const { getCurrTimestamp } = require('../utils/dateUtils');

async function OnEXPApproval(req) {
  const db = await cds.connect.to('db');
  const { Approvers } = db.entities('mm_dpde_master');
  const { Request, ReqFormEXP, ProcessLog} = db.entities('mm_dpde_schema')
  const tx = cds.transaction(req);
  const { reqID, action, remarks } = req.data;
  const request = await tx.run(SELECT.one.from(Request).where({ reqID: reqID }));
  const expData = await tx.run(SELECT.one.from(ReqFormEXP).where({ reqID }));
  const pendingLog = await tx.run(SELECT.one.from(ProcessLog).where({ reqID: reqID, status: 'Pending' }).orderBy('receivedDt desc'));
 
  req.data.role = action !== 'SUBMIT' ?  pendingLog?.stage  : '';

  const currentUser = await getCurrentUser(req);

  if (action !== 'SUBMIT' && pendingLog) {
    if(!currentUser){
      req.reject("Your are not Authorised User");
    }
    const { userEmail, stage } = pendingLog;
    // if user email is there then check email else check role
    const isAllowed = (userEmail && currentUser.email == userEmail)  || currentUser.role == stage;
    if (!isAllowed) {
      req.reject("You are not Authorised to Approve or Sent Back");
    }
  }

  // const date = getCurrTimestamp;
  const date = getCurrTimestamp;


  let stage = request.stage;
  const department = request.type;

  if (action === 'SUBMIT') {
   
    await tx.run(INSERT.into(ProcessLog).entries({
      reqID,
      stage: stage,
      userName: currentUser?.name ?? req.user.id,
      userEmail: currentUser?.email ?? req.user.id,
      status: 'SUBMITTED',
      receivedDt: new Date(),
      remarks
    })
    );   

    //Send Mail
    const managerDtl = await tx.run(
      SELECT.one.from(Approvers).columns('name', 'email','userID').where({ userID: expData.manager })
    );
    managerName=managerDtl.name
    managerEmail= managerDtl.email
  
    await tx.run(INSERT.into(ProcessLog).entries({
      // ID:id,
      reqID,
      stage: 'Manager',
      userName:managerName , 
      userEmail: managerEmail,
      status: 'Pending',
      receivedDt: new Date()
    }));

  //  await sendApprovalEmail({
  //       expData: expData,
  //       refNo: request.refNo,
  //       stage: 'Manager',
  //       emails:email,
  //       date,
  //   });
    await tx.run(UPDATE(Request).set({ stage: 'Manager', status: 'Pending', pendingWith: managerEmail, pendingWithName: managerName }).where({ reqID: reqID }));
    return { message: `Request ${request.refNo} submitted for Approval successfully.` };
  }
  else if(action === 'APPROVE'){
    
  }

}

module.exports = {
  OnEXPApproval
};
