const cds = require('@sap/cds');
const { getCurrTimestamp } = require('../utils/dateUtils');
const  sendMail  = require('../utils/emailService');
const { request } = require('express');
 
 
  async function createAllProcessLogs(reqID, tx, entities, userID) {
    const {Requesters, Approvers, Requests, ReqFormAP_Transfer, ReqFormAP_Trans_Details, ReqForm_Recom_Approver, ProcessLogs, ReqFormAP_Invest } = entities;
    // Fetch Request and Transfer data
    const request = await tx.run(SELECT.one.from(Requests).where({ reqID }));
    const transfer = await tx.run(SELECT.one.from(ReqFormAP_Transfer).where({ reqID }));
    const transfer_details = await tx.run(SELECT.from(ReqFormAP_Trans_Details).where({ reqID }));
 
    if (!request || !transfer) throw new Error(`Request or Transfer data not found for reqID ${reqID}`);
    // Initialize logs array
    const logs = [];
 
    // const RequestersNameRow = await tx.run(SELECT.one.from(Requesters)).where({department : 'ADPD', email: req.user.id});
    const RequestersNameRow = await tx.run(SELECT.one.from(Requesters).where({department : 'ADPD', email: userID}));
    // const RequestersNameRow = await tx.run(SELECT.from(Requesters));
    const RequestersName = await RequestersNameRow.name;
    const RequestersId = await RequestersNameRow.requesterTokenNumber;
 
    // ========== 1. Add Initiator log ==========
    logs.push({
      reqID,
      role: 'Initiator',
      stage: 'Initiator',
      status: 'Initiated',
      userEmail: userID,
      userId: RequestersId,
      userName: RequestersName || 'Anonymous',
      receivedDt: new Date(Date.now()),
      completionDt: new Date(Date.now()),
      approverName: transfer.Initiator || 'Unknown',
      approverID: transfer.Initiator,
      remarks: request.remarks
    });
 
    // ========== 2. Add Finance log ==========
    const finIdName = await transfer.finMember;
    const finID = finIdName.split(' - ')[0];
    const approverRow = await tx.run(SELECT.one.from(Approvers).where({ department:'ADPD', role : 'FIN', userID: finID }))
    const finName = await approverRow.name;
    const finEmail = await approverRow.email;
 
    //find finance email and name
    logs.push({
      reqID,
      role: 'Finance',
      stage: 'Finance',
      status: 'Pending',
      userEmail: finEmail,
      userName: finName,
      userId: finID,
      receivedDt: new Date(Date.now()+1)
    });
 
    // ========== 3. Recommended Approvers (TM) ==========
    const recomApprovers = await tx.run(
      SELECT.from(ReqForm_Recom_Approver).where({ reqID })
    );
 
    const recomApproverIDs = recomApprovers.map(r => r.Approvers);
 
    const approversData = await tx.run(
      SELECT.from(Approvers).where({ ID: { in: recomApproverIDs } })
    );
 
    const approverMap = Object.fromEntries(approversData.map(a => [a.ID, a.name]));
    let count=1;
 
    for (const ra of recomApprovers) {

      count++;
 
      //find recommended name and email
      // const recomApproverRow = await tx.run(SELECT.one.from(ReqForm_Recom_Approver).where({ department:'ADPD', email : "" }))
      // const recomApprover = await approverRow.name;
      // const raEmail = await transfer.ra;
      // const approverRow = await tx.run(SELECT.one.from(ReqForm_Recom_Approver).where({ reqID, userID : ra.userId, role:'Recommended' }))
      // const raName = ra.name || 'No Name';
      // const raEmail = ra.email || 'No Name';
 
      //
      logs.push({
        reqID,
        role: ra.Role,
        stage: ra.Role,
        status: "",
        approverID: ra.Approvers,
        userEmail: ra.email,
        userName: ra.name,
        userId: ra.userId,
        receivedDt: new Date(Date.now()+count)
      });
    }
 
    // ========== 4. Approver Block ==========
 
    //find any stage and name also check availability of
    const subType = await transfer.subType;
    let amount = 0;
    if(subType === 'PPBA'){
      const investRow = await tx.run(SELECT.from(ReqFormAP_Invest).where({reqID}));
      for (const row of investRow) {
        const total = parseFloat(row.total);
        amount += isNaN(total) ? 0 : total;
      }    
    }else{
      for (const row of transfer_details) {
        const landed = parseFloat(row.totalLanded);
        const nrt = parseFloat(row.totalNRT);
     
        amount += (isNaN(landed) ? 0 : landed) + (isNaN(nrt) ? 0 : nrt);
      }
    }
    const flowStages = await getApproverBlockStages(subType, amount, reqID, tx);
    const stageApproverIDs = flowStages.map(stage => transfer[stage]).filter(Boolean);
 
    const stageApproversData = await tx.run(
      SELECT.from(Approvers).where({ ID: { in: stageApproverIDs } })
    );
 
    const stageMap = Object.fromEntries(stageApproversData.map(a => [a.ID, a.name]));
 
    for (const stage of flowStages) {
      count++;
      let approverRow, approverName, approverEmail;
      if(stage === 'CPH'|| stage === 'PEH' || stage === 'PPM' || stage === 'PNH' || stage === 'PPH' || stage === 'PFH' || stage === 'SrGM' || stage === 'SrVP'){
        let newStage = stage;
        if(stage === 'Head'){
          newStage = 'projFinHead';
        }
        const userid = await transfer[newStage];
        // const userid = '324844';
        approverRow = await tx.run(SELECT.one.from(Approvers).where({department:'ADPD', userID:userid}));
        approverName = approverRow.name;
        approverEmail = approverRow.email;
      }
      else{
        approverRow = await tx.run(SELECT.one.from(Approvers).where({department:'ADPD', role:stage}));
        approverName = approverRow.name;
        approverEmail = approverRow.email;
      }
       
 
      logs.push({
        reqID,
        role: stage,
        stage,
        status: "",
        userId: approverRow.userID,
        userEmail: approverEmail || 'Unknown',
        userName:  approverName,
        receivedDt: new Date(Date.now()+count)
      });
    }

    count++;
 
    // ========== 5. Finance2 ==========
    //find financeMember name and email
    logs.push({
      reqID,
      role: 'Finance',
      stage: 'Finance',
      status: "",
      userEmail: finEmail,
      userName: finName,
      userId: finID,
      receivedDt: new Date(Date.now()+count)
    });
 
    // ========== 6. Asset Management ==========
 
    //find asset management name and email
    count++;
 
    let amRow = await tx.run(SELECT.one.from(Approvers).where({department:"ADPD", role:'AM'}));
    logs.push({
      reqID,
      role: 'Asset Management',
      stage: 'Asset Management',
      status: "",
      userId: amRow.userID,
      userEmail: amRow.email,
      userName: amRow.name,
      receivedDt: new Date(Date.now()+count)
    });
 
    // ========== 7. CPE ==========
 
    //find cpe name and email

    count++;
 
    cpeRow = await tx.run(SELECT.one.from(Approvers).where({department:"ADPD", role:'CPE'}));
    logs.push({
      reqID,
      role: 'CPE',
      stage: 'CPE',
      status: "",
      userId: cpeRow.userID,
      userEmail: cpeRow.email,
      userName: cpeRow.name,
      receivedDt: new Date(Date.now()+count)
    });
 
    // ========== Final Insertion ==========
    if (logs.length > 0) {
      await tx.run(INSERT.into(ProcessLogs).entries(logs));
    }
  }
 
 
 
  async function getApproverBlockStages(subType, amount, reqID, tx) {
    const {Requesters, Requests, ReqFormAP_Transfer, ReqFormAP_Trans_Details, Approvers, ReqForm_Recom_Approver, ProcessLogs } = cds.entities;
    const amt = Number(amount);
    const reqAPData = await tx. run(SELECT.one.from(ReqFormAP_Transfer).where({reqID}));
    const appendFinal = (baseRoles) => [...baseRoles, ...finalApprovers];

    const finalApprovers = [];
    if (reqAPData.FinalApprover1) {
      finalApprovers.push('FinalApprover1');
      if (reqAPData.FinalApprover2) {
        finalApprovers.push('FinalApprover2');
        if (reqAPData.FinalApprover3) {
          finalApprovers.push('FinalApprover3');
        }
      }
    }

    switch (subType) {
      case 'IIIT': // Interline/Interhead/Intraline
        if (amt <= 10) return ['SrGM'];
        if (amt > 10 && amt <= 50) return ['CPH'];
        if (amt > 50 && amt <= 100) return ['SrVP'];
        // if (amt > 100 && amt <= 500)return ['PFH', 'CPE', 'Head', 'President', 'FinalApprover1', 'FinalApprover2', 'FinalApprover3'];
        if (amt > 100 && amt <= 500)return appendFinal(['PFH', 'CPE', 'Head', 'President']);
        if (amt > 500){
          const natOfExp = reqAPData.natureOfExpense;
          if(natOfExp==='Capex to Capex + Revenue to Revenue' || natOfExp==='Revenue to Revenue'){
            // return ['PFH', 'CPE', 'Head', 'President', 'CFO', 'FinalApprover1', 'FinalApprover2', 'FinalApprover3'];
            return appendFinal(['PFH', 'CPE', 'Head', 'President', 'CFO']);
          }
          else if(natOfExp === 'Revenue to Capex' || natOfExp==='Capex to Revenue'){
            // return ['PFH', 'CPE', 'Head', 'President', 'CFO', 'ED', 'FinalApprover1', 'FinalApprover2', 'FinalApprover3'];
            return appendFinal(['PFH', 'CPE', 'Head', 'President', 'CFO', 'ED']);
          }
          return 'Unregistered Nauture of Expense';
        }
 
      case 'CBU': // Contingency Budget Utilisation
      if (amt <= 10) return ['SrGM'];
      if (amt > 10 && amt <= 50) return ['CPH'];
      if (amt > 50 && amt <= 100) return ['Sr. VP'];
      if (amt > 100 && amt <= 500) return appendFinal(['PFH', 'CPE', 'Head', 'President']);
      if (amt > 500) return appendFinal(['PFH', 'CPE', 'Head', 'President', 'CFO']);
 
      case 'PS': // Parked Savings
      if (amt <= 10) return ['SrVP'];
      if (amt > 10 && amt <= 20) return appendFinal(['PFH', 'CPE', 'Head', 'President']);
      if (amt > 20) return appendFinal(['PFH', 'CPE', 'Head', 'President', 'CFO']);
 
      case 'EXIG': // Exigency
        if (amt <= 500) return appendFinal(['PFH', 'CPE', 'Head', 'President']);
        if (amt > 500 && amt <= 1000) return appendFinal(['PFH', 'CPE', 'Head', 'President', 'CFO']);
        if (amt > 1000) return appendFinal(['PFH', 'CPE', 'Head', 'President', 'CFO', 'ED']);
 
      case 'PPBA': // Pre Project Budget Approvals
        if (amt <= 500) return appendFinal(['PFH', 'CPE', 'Head', 'President', 'CFO']);
        if (amt > 500 && amt <= 2500) return appendFinal(['PFH', 'CPE', 'Head', 'President', 'CFO', 'ED']);
        if (amt > 2500) return appendFinal(['PFH', 'CPE', 'Head', 'President', 'CFO', 'ED']);
 
      case 'BA': // Budget Advancement
        if (amt <= 500) return appendFinal(['PFH', 'CPE', 'Head', 'President']);
        if (amt > 500) return appendFinal(['PFH', 'CPE', 'Head', 'President', 'CFO']);
 
      case 'CO': // Cost Overrun
        if (amt <= 100) return appendFinal(['PFH', 'CPE', 'Head', 'President']);
        if (amt > 100) return appendFinal(['PFH', 'CPE', 'Head', 'President', 'CFO']);
 
      default:
        throw new Error(`Unsupported subtype '${subType}'`);
    }
  }
 
 
 
 
  async function onADPDApproval(req) {
    const {Requesters, Requests, ReqFormAP_Transfer, ReqFormAP_Trans_Details, Approvers, ReqForm_Recom_Approver, ProcessLogs, ReqFormAP_Invest } = this.entities;
    const entities = this.entities;
 
    const { remarks, reqID, action } = req.data;
    const userID = req.user.id;
    const tx = cds.tx(req);
    const request = await tx.run(SELECT.one.from(Requests).where({ reqID }));
    let currStatus = request.stage;
    let nextStage = await tx.run(SELECT.one.from(ProcessLogs).where({reqID, status:''}).orderBy('receivedDt asc'));

    let to;
 
    if (currStatus === 'Initiator' && action === 'SUBMIT') {
 
      await createAllProcessLogs(reqID, tx, entities, userID);
      const finRow = await tx.run(SELECT.one.from(ProcessLogs).where({reqID, stage:'Finance'}).orderBy('receivedDt asc'));
      to = finRow.userEmail;
      await sendADPDMail(reqID,tx,entities,to);
      await tx.run(UPDATE(Requests).set({remarks, stage: 'Finance', status: 'Pending', pendingWith:finRow.userEmail, pendingWithName:finRow.userName }).where({ reqID }));
      return { message: 'Request submitted. Moved to Finance stage.' };
 
    }
    else if(action === 'REJECT'){

      const currLog =await tx.run(SELECT.one.from(ProcessLogs).where({ reqID, status: 'Pending' }));

      //MailSendToRequester
      if(currLog.userEmail !== req.user.id){
        return 'Unauthorised User';
      }
      await tx.run(
        UPDATE(ProcessLogs)
          .set({ status: 'Send Back', completionDt: new Date() , remarks})
          .where({ reqID, status: 'Pending' })
      );
       
      await tx.run(
        UPDATE(Requests)
        .set({
          status: 'Send Back',
          stage: 'Initiator',
          pendingWith: '',
          pendingWithName: '',
        })
        .where({ reqID })
      );

      await tx.run(DELETE(ProcessLogs).where({reqID, status:''}));
      
      const reqRow = await tx.run(SELECT.one.from(Requests).where({reqID}));
      to = reqRow.createdBy;
      await sendADPDMail(reqID,tx,entities,to);
      //MailSendToRequester
      return {
        message: `${currStatus} Send Back, Request forwarded to Initiator`
      };
     
 
    }
    else if(action === 'APPROVE' && nextStage){
      if(nextStage){

        const currLog =await tx.run(SELECT.one.from(ProcessLogs).where({ reqID, status: 'Pending' }));
        if(currLog.userEmail !== req.user.id){
          return 'Unauthorised User';
        }

        const headApprRow = await tx.run(SELECT.one.from(ReqFormAP_Transfer).where({ reqID }));
        const headAppr = headApprRow.onBehalfFlag;

        if (headAppr && currLog.stage === 'Head') {

          await tx.run(
            UPDATE(ProcessLogs).set({
              status: 'Approved',
              completionDt: new Date(),
              remarks
            }).where({ reqID, stage: 'Head', status: 'Pending' })
          ); 

          const logs = await tx.run(
            SELECT.from(ProcessLogs).where({ reqID, status :'' }).orderBy('receivedDt asc')
          );
          

          let indexOfNext;
        
          // const indexOfHead = logs.findIndex(l => l.stage === 'Head');

          if(headApprRow.FinalApprover1){
            indexOfNext = logs.findIndex(l => l.stage === 'FinalApprover1');
          }
          else{
            indexOfNext = logs.findIndex(l => l.stage === 'Finance');
          }
          
          // if (indexOfHead === -1) throw new Error('Head stage not found');

          for (let i = 0; i < indexOfNext; i++) {
            await tx.run(
              UPDATE(ProcessLogs).set({
                status: 'Skipped',
                completionDt: new Date()
              }).where({ reqID, stage: logs[i].stage, status: '' })
            ); 
          }

          const logs2 = await tx.run(
            SELECT.from(ProcessLogs).where({ reqID, status :'' }).orderBy('receivedDt asc')
          );
          await tx.run(
            UPDATE(ProcessLogs).set({
              status: 'Pending',
            }).where({ reqID, stage: logs2[0].stage, status: '' })
          );
        
          // 4. Update Requests table
          await tx.run(
            UPDATE(Requests).set({
              stage: logs2[0].stage,
              pendingWith: logs2[0].userEmail,
              pendingWithName: logs2[0].userName
            }).where({ reqID })
          );
        
          // 5. Send mail
          await sendADPDMail(reqID, tx, entities, logs2[0].userEmail);
        
          return {
            message: `Head approved. Skipped intermediate stages and moved to ${logs2[0].stage}.`
          };
        }
        else if (!nextStage){
          //MailSendToRequester
          const reqRow = await tx.run(SELECT.one.from(Requests).where({reqID}));
          if(reqRow.pendingWith !== req.user.id){
            return 'Unauthorised User';
          }
          await tx.run(
            UPDATE(ProcessLogs)
              .set({ status: 'Approved', completionDt: new Date(Date.now()) , remarks})
              .where({ reqID, status: 'Pending' })
          );
         
          await tx.run(
            UPDATE(Requests)
              .set({ status: 'Approved', stage: '', pendingwith: '', pendingwithName: '' })
              .where({ reqID })
          );

          to = reqRow.createdBy;
          await sendADPDMail(reqID,tx,entities,to);

          return {
            message: `${currStatus} Approved. Request is now fully approved`
          };
        }
        
        

        // if(nextStage.stage = 'Head'){
        //   const headApprRow = await tx.run(SELECT.one.from(ReqFormAP_Transfer).where({reqID}));
        //   const headAppr = headApprRow.onBehalfFlag;

        //   //finad the stages between Head and FinalAppover
          
        //   if(headAppr){
        //     const finalAppr1 = headApprRow.FInalApprover1;
        //     if(finalAppr1){
        //       //skipp the logs between
        //       //move to FinalApprover1
        //     }
        //     else{
        //       //Approve the request
        //     }
        //   }
        //   else{
        //     //Move to president
        //   }
        // }
 
        await tx.run(
          UPDATE(ProcessLogs)
            .set({ status: 'Approved', completionDt: new Date(Date.now()) , remarks})
            .where({ reqID, status: 'Pending' })
        );
        await tx.run(
          UPDATE(ProcessLogs)
            .set({ status: 'Pending', completionDt: new Date(Date.now()) })
            .where({ ID:nextStage.ID })
        );
        

        to = nextStage.email;
        await sendADPDMail(reqID,tx,entities,to);
       
        //MailSendforNextStage
        // let currStage = await tx.run(SELECT.one.from(ProcessLogs).where({reqID, status:''}).orderBy('receivedDt asc'));
        // await tx.run(UPDATE(Requests).set({stage:nextStage.stage, pendingwith:nextStage.email, pendingwithName:nextStage.name}).where({reqID}));
        await tx.run(
          UPDATE(Requests).set({
            stage: nextStage.stage,
            pendingwith: nextStage.email,
            pendingwithName: nextStage.name
          }).where({ reqID })
        );
        return {
          message: `${currStatus} Approved, moved to ${nextStage.stage}`
        };
      }

 
      // return {
      //   message: `${currStatus} Approved, moved to ${nextStage.stage}`
      // };
     
    }

    else if (action === 'APPROVE' && !nextStage){

      const currLog =await tx.run(SELECT.one.from(ProcessLogs).where({ reqID, status: 'Pending' }));

      //MailSendToRequester
      const reqRow = await tx.run(SELECT.one.from(Requests).where({reqID}));
      if(currLog.userEmail !== req.user.id){
        return 'Unauthorised User';
      }
    
      await tx.run(
        UPDATE(ProcessLogs)
          .set({ status: 'Approved', completionDt: new Date(Date.now()) , remarks})
          .where({ reqID, status: 'Pending' })
      );
     
      await tx.run(
        UPDATE(Requests)
          .set({ status: 'Approved', stage: '', pendingWith: '', pendingWithName: '' })
          .where({ reqID })
      );

      to = reqRow.createdBy;
      await sendADPDMail(reqID,tx,entities,to);
      
      return {
        message: `${currStatus} Approved. Request is now fully approved`
      };
    }
  }
 
  async function sendADPDMail(reqID, tx, entities, to) {
    const {
      ReqFormAP_Transfer,
      ReqFormAP_Trans_Details,
      ProcessLogs,
    } = entities;
 
    // 1. Fetch data
    const reqData = await tx.run(SELECT.one.from(ReqFormAP_Transfer).where({ reqID }));
    if (!reqData) throw new Error(`No request found for ID ${reqID}`);
 
    const detailData = await tx.run(SELECT.from(ReqFormAP_Trans_Details).where({ reqID }));
    const logs = await tx.run(SELECT.from(ProcessLogs).where({ reqID }).orderBy('receivedDt asc'));
 
    // 2. Construct Email HTML
    const body = `
      <p>Dear Sir/Madam,</p>
      <p>Kindly check the below approval request raised for <b>${reqID}</b> (${reqData.subType}).</p>
      <p><b>Justification:</b> ${reqData.Justification || 'N/A'}</p>
 
      <h3>Request Details:</h3>
      <table border="1" cellspacing="0" cellpadding="5" style="border-collapse: collapse; width: 100%;">
        <thead style="background-color: #d41c1c; color: white;">
          <tr>
            <th>Project</th><th>Project Desc</th><th>Transfer Type</th><th>Nature of Expense</th>
            <th>Platform</th><th>Total Amount (Lac)</th><th>Click to Open</th>
          </tr>
        </thead>
        <tbody>
          ${detailData.map(row => `
            <tr>
              <td>${reqData.Project}</td>
              <td>${reqData.projectDesc}</td>
              <td>${reqData.transType}</td>
              <td>${reqData.natureOfExpense}</td>
              <td>${reqData.Platform}</td>
              <td>${row.totalLanded}</td>
              <td><a href="YOUR_LINK_HERE/${reqID}">Click here</a></td>
            </tr>
          `).join('')}
        </tbody>
      </table>
 
      <br>
      <h3>Final Approved Values (In Lacs):</h3>
      <table border="1" cellspacing="0" cellpadding="5" style="border-collapse: collapse; width: 100%;">
        <thead style="background-color: #d41c1c; color: white;">
          <tr>
            <th>From WBS</th><th>To WBS</th>
            <th>Capex NRT</th><th>Capex Landed</th>
            <th>Revenue NRT</th><th>Revenue Landed</th>
            <th>Total NRT</th><th>Total Landed</th>
          </tr>
        </thead>
        <tbody>
          ${detailData.map(row => `
            <tr>
              <td>${row.fromWBSCode || ''}</td>
              <td>${row.toWBSCode || ''}</td>
              <td>${row.capexNRT ?? 0}</td>
              <td>${row.capexLanded ?? 0}</td>
              <td>${row.revenueNRT ?? 0}</td>
              <td>${row.revenueLanded ?? 0}</td>
              <td>${row.totalNRT ?? 0}</td>
              <td>${row.totalLanded ?? 0}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
 
      <br>
      <h3>Workflow History:</h3>
      <table border="1" cellspacing="0" cellpadding="5" style="border-collapse: collapse; width: 100%;">
        <thead style="background-color: #d41c1c; color: white;">
          <tr>
            <th>Approver Stage</th><th>Approver</th><th>Role</th><th>Status</th>
            <th>Start Date</th><th>Completion</th><th>Remarks</th>
          </tr>
        </thead>
        <tbody>
          ${logs.map(log => `
            <tr>
              <td>${log.stage}</td>
              <td>${log.userId}:${log.userName}</td>
              <td>${log.role}</td>
              <td>${log.status}</td>
              <td>${log.receivedDt ? new Date(log.receivedDt).toLocaleDateString() : ''}</td>
              <td>${log.completionDt ? new Date(log.completionDt).toLocaleDateString() : ''}</td>
              <td>${log.remarks || ''}</td>
            </tr>
          `).join('')}
        </tbody>
      </table>
    `;
 
    // 3. Send Email
    const subject = `SSAP-${reqID} - ${reqData.Project} (${reqData.subType})`;
    const emails = [reqData.Initiator]; // you can add more like reqData.projFinHead, FinalApprover1 etc.
 
    // await sendMail({ to: emails, subject, body });
    await sendMail({ to:'shivam.shrivastav@sumodigitech.com', subject, body });
  }
 
 
 
  async function onblankApprovers(req){
 
    const {Requesters, Requests, ReqFormAP_Transfer, ReqFormAP_Trans_Details, Approvers, ReqForm_Recom_Approver, ProcessLogs } = this.entities;
 
    const entities = this.entities;
 
    const reqID = req.data.reqID;
    const tx = cds.tx(req);
 
    await sendADPDMail(reqID,tx,entities, to)
 
    // await tx.run(UPDATE(ReqFormAP_Transfer).set({CPH:"",PEH:"",PPM:"",PNH:"",PPH:"",PFH:"",finMember:"",SrGM:"",SrVP:"",FinalApprover1:""}).where({reqID}))
 
  }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
module.exports = { onADPDApproval, onblankApprovers }
 