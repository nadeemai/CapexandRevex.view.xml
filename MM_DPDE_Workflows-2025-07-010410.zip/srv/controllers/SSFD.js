const cds = require('@sap/cds');
const { getCurrTimestamp } = require("../utils/dateUtils.js");
const sendMail = require('../utils/emailService');
const { getCurrentUser } = require('./Request');


async function OnSSFDApproval(req) {
  const db = await cds.connect.to('db');
  const { Approvers,ProcessGroupTask } = db.entities('mm_dpde_master');
  const { Request, ReqFormFD, ProcessLog} = db.entities('mm_dpde_schema')
  const tx = cds.transaction(req);
  const { reqID, action, remarks } = req.data;
  const request = await tx.run(SELECT.one.from(Request).where({ reqID: reqID }));
  const ssfdData = await tx.run(SELECT.one.from(ReqFormFD).where({ reqID }));
  const pendingLog = await tx.run(SELECT.one.from(ProcessLog).where({ reqID: reqID, status: 'Pending' }).orderBy('receivedDt desc'));
   
  //TODO:remove after testing get current user with the specified role
  // passing the role so that we can get current user with particular role only 
  req.data.role = action !== 'SUBMIT' ?  pendingLog?.stage  : '';

  const currentUser = await getCurrentUser(req);
  // if no current user found
 
  console.log(action,currentUser, pendingLog);
  //Check in pending log : currUser email == pedinglog.useer or pendinglog.role=userRole
  if (action !== 'SUBMIT' && pendingLog) {
    if(!currentUser){
      req.reject("Your are not Authorised User");
    }
    const { userEmail, stage } = pendingLog;
    // if user email is there then check email else check role
    const isAllowed = (userEmail && currentUser.email == userEmail)  || currentUser.role == stage;
    if (!isAllowed) {
      req.reject("You are not Authorised to Approve or Sent Back");
    }
  }

  // const date = getCurrTimestamp;
  const date = getCurrTimestamp();


  let stage = request.stage;
  const department = request.type;

  if (action === 'SUBMIT') {
    const reSubmit = await tx.run(SELECT.one.from(ProcessLog).where({ reqID: reqID, status: 'Sent Back' }));
    console.log(reSubmit);
    await tx.run(INSERT.into(ProcessLog).entries({
      reqID,
      stage: 'Initiator',
      userName: currentUser?.name ?? req.user.id,
      userEmail: currentUser?.email ?? req.user.id,
      status: reSubmit ? 'RESUBMITTED' : 'SUBMITTED',
      receivedDt: new Date(),
      remarks
    })
    );   

    //Send Mail
    const email = await getHODEmail(ssfdData, tx);
    // const hod = ssfdData.hod;
    const fullString = ssfdData.hod;
    const userName = fullString?.split(' - ')[1];
    await tx.run(INSERT.into(ProcessLog).entries({
      // ID:id,
      reqID,
      stage: 'HOD',
      userName: userName,
      userEmail: email,
      status: 'Pending',
      receivedDt: new Date()
    }));
    const userID = email.split("@")[0];

    // await sendSanctionEmail(ssfdData, request.refNo, 'HOD', email, date);
   await sendSanctionEmail({
        ssfdData: ssfdData,
        refNo: request.refNo,
        stage: 'HOD',
        emails:email,
        date,
    });
    await tx.run(UPDATE(Request).set({ stage: 'HOD', status: 'Pending', pendingWith: email, pendingWithName: userName }).where({ reqID: reqID }));
    return { message: `Request ${request.refNo} submitted for Approval successfully.` };
  }

  else if (action === 'APPROVE') {

    let nextStage;
    let newStatus = 'Pending';
    if (stage == 'Final Accounts') {
      newStatus = 'Approved'
      await tx.run(UPDATE(Request).set({ stage: 'Approved', pendingWith: '', status: 'Approved',pendingWithName:'' }).where({ reqID: reqID }));
      await tx.run(
        UPDATE(ProcessLog)
          .set({ status: 'Approved', remarks: remarks })
          .where({ reqID, status: 'Pending' })
      );
    } else {

      nextStage = await getNextStage({
        "pId": department,
        "subId": ssfdData.subType || request.subType,
        "amount": ssfdData.budgetRequired,
        "stage": stage,
        "puDept": ssfdData.puDept,
        "selectedPerson": ssfdData.selectedApprover,
      }, tx);

      // check in entity ProcessGroupTask  that  for the nextStage: is a group approver?? if yes then select many from appovers table else one
      let approvers = await tx.run(
        SELECT.from(Approvers).columns('name', 'email').where({ role: nextStage, department })
      );

      console.log(approvers);

      let groupTask = await tx.run(
        SELECT.one.from(ProcessGroupTask).where({ processId: request.type,stage:nextStage })
      );

      if (approvers?.length==0) {
        throw new Error(`Approver email not found`);
      }
      let isGroupTask= groupTask?.isGroup || false;

      // const email = approvers.email;
      // const userID = approver.email.split('@')[0];
      // await sendSanctionEmail(ssfdData, request.refNo, nextStage, approver.email, date);
      const approversEmail = approvers.map(approver=> approver.email);
      await sendSanctionEmail({
        ssfdData: ssfdData,
        refNo: request.refNo,
        stage: nextStage,
        emails:isGroupTask?approversEmail:approversEmail[0],   //we will send array of approvers email
        date,
    });
    //in case of groupAprover there will be pending with name would be the name,and pending with will be empty 
      const pendingWithName = isGroupTask? `${nextStage} Team`: approvers[0].name;
      const pendingWith = isGroupTask? '': approvers[0].email;
      await tx.run(UPDATE(Request).set({ stage: nextStage, pendingWith: pendingWith ,pendingWithName:pendingWithName}).where({ reqID: reqID }));

      await tx.run(
        UPDATE(ProcessLog)
          .set({ status: 'Approved', remarks: remarks,userEmail:currentUser.email,userName:currentUser.name})
          .where({ reqID, status: 'Pending' })
      );
      //in case of groupAprover there will be role inserted and name amd email would be empty 
      await tx.run(INSERT.into(ProcessLog).entries({
        reqID,
        stage: nextStage,
        userName:pendingWithName,
        userEmail: pendingWith, //all emails will be shown in case of group 
        status: newStatus,
        receivedDt: new Date(),
      }));
     

    }


  }

  else if (action === 'SENT BACK') {
    //send mail to Initiator 

    if (stage == 'Final Accounts') {
      req.reject('You cannot sent Back');
    }

    await tx.run(UPDATE(Request).set({ stage: 'Sent Back', status: 'Sent Back', pendingWith: '',pendingWithName:'' }).where({ reqID: reqID }));
    await tx.run(
      UPDATE(ProcessLog)
        .set({ status: 'Sent Back', remarks: remarks })
        .where({ reqID, status: 'Pending' })
    );
   
    const emailLog = await SELECT.one.from(ProcessLog).columns('userEmail').where({
      reqID: reqID,
      stage: 'Initiator'
    });
    const email = emailLog.userEmail;

    // await sendInitiatorEmail(ssfdData, request.refNo, email, date);
    await sendSanctionEmail({
      ssfdData: ssfdData,
      refNo: request.refNo,
      stage: '',
      date,
      emails:email,
      type: 'initiator'
    });

    return 'Sent back to Initiator';
  }

};



async function getHODEmail(ssfdData, tx) {

  const db = await cds.connect.to('db');
  const { Approvers } = db.entities('mm_dpde_master');

  try {
    const fullString = ssfdData.hod;
    const userID = fullString?.split(' - ')[0];
    if (!userID) throw new Error(400, 'Invalid approver format.');


    const approver = await tx.run(SELECT.one.from(Approvers).where({ userID }));
    if (!approver) throw new Error(404, `No approver found for userID: ${userID}`);

    const HODEmail = await approver.email;

    return HODEmail;
  } catch (error) {
    console.error("Error fetching approver email:", error);
    throw new Error(500, `Failed to fetch email: ${error.message}`);
  }
}


async function getNextStage(req, tx) {
  const { stage, pId, subId, amount, puDept, unit = 'lakhs', selectedPerson = 'President' } = req;
  const db = await cds.connect.to('db');
  const { ApprovalDetermination  } = db.entities('mm_dpde_master');
  console.log(unit);

  const normalizedAmount = normalizeAmount(amount, unit);
  console.log(normalizedAmount);

  // Static stages
  if (stage === 'HOD') return 'GM PMO';
  if (stage === 'GM PMO') return 'Accounts';

  if (stage === 'Accounts') {
    if (puDept === 'FD CDMM') return 'VP CDMM';
    if (puDept === 'FD CME') return 'VP CME';
    if (puDept === 'FD PD' || puDept === 'FD-PTD') return 'Sr VP FDPD';
  }

  if (stage === 'VP CDMM' || stage === 'VP CME') return 'Sr VP FDPD';
  if (stage === 'Sr VP FDPD') return 'VP Finance';
  if (stage === 'VP Finance') return 'CEO';

  // Fetch dynamic rules
  const rules = await tx.run(
    SELECT.from(ApprovalDetermination).where({
      processId: pId,
      subProcessId: subId
    })
  );

  rules.sort((a, b) => a.cond_range_min - b.cond_range_min);
  console.log("Rules:", rules);
  console.log("Current Stage:", stage);

  let cumulativeStages = [];
  cumulativeStages.push('CEO'); // Add initial stage

  for (const rule of rules) {
    // Normalize the rule's range min and max values
    const normalizedMin = normalizeAmount(rule.cond_range_min, rule.cond_unit);
    const minPass =
      rule.operator_min === 'GT' ? normalizedAmount > normalizedMin :
        rule.operator_min === 'GE' ? normalizedAmount >= normalizedMin :
          true;

    if (minPass) {
      const stages = rule.approverRole?.split('->')?.map(s => s.trim()) ?? [];
      cumulativeStages.push(...stages);
    }
  }

  if (subId == 'COR' && selectedPerson == 'ED') {
    cumulativeStages.push('AFS CFO');
    cumulativeStages.push('ED');

  }

  const finalChain = cumulativeStages;
  console.log("Final Chain:", finalChain);

  const idx = finalChain.indexOf(stage);
  if (idx >= 0 && idx < finalChain.length - 1) {
    return finalChain[idx + 1];
  } else if (idx === finalChain.length - 1) {
    return 'Final Accounts';
  }

  throw new Error("Invalid stage");
}

// Helper to normalize amounts to rupees (or largest unit)
function normalizeAmount(amount, unit) {
  const unitMultipliers = {
    rupees: 1,
    lakhs: 1e5,
    crores: 1e7,
    millions: 1e6,
    billions: 1e9,
  };

  const multiplier = unitMultipliers[unit?.toLowerCase()] || 1;
  return amount * multiplier;
}

async function OnGetSSFD(req) {
  const db = await cds.connect.to('db');
  const { ReqFormFD } = db.entities('mm_dpde_schema')
  const tx = cds.transaction(req);
  const { reqID } = req.data;
  //Select one from Request where reqid is reqid
  const ssfdData = await tx.run(SELECT.one.from(ReqFormFD).where({ reqID }));

  //calculate the remaining data
  const capBudget = ssfdData.capitalBudget;
  const revBudget = ssfdData.revenueBudget;
  const perCost = ssfdData.personnelCost;

  // Only Capital Budget has 5% contingency
  const capContingency = Number((capBudget * 0.05).toFixed(2));
  const revContingency = 0;
  const perContingency = 0;
  // Totals
  const capTotal = Number((capBudget + capContingency).toFixed(2));
  const revTotal = revBudget;
  const perTotal = perCost;

  const grandBudget = capBudget + revBudget + perCost;
  const grandContingency = capContingency;
  const grandTotal = Number((grandBudget + grandContingency).toFixed(2));

  //bind it in the json
  const budgetSummary = {
    items: [
      {
        nature: 'Capital Budget',
        amount: capBudget,
        contingency: capContingency,
        total: capTotal
      },
      {
        nature: 'Revenue Budget',
        amount: revBudget,
        contingency: revContingency,
        total: revTotal
      },
      {
        nature: 'Personnel Cost',
        amount: perCost,
        contingency: perContingency,
        total: perTotal
      },
      {
        nature: 'Total',
        amount: grandBudget,
        contingency: grandContingency,
        total: grandTotal
      }
    ]
  };

  return budgetSummary;

}





async function sendSanctionEmail({
  ssfdData,
  refNo,
  stage,
  emails,
  date,
  type = 'approver' // or 'initiator'
}) {
  const isInitiator = type === 'initiator';

  const role = isInitiator ? 'IN' : 'AP';
  const linkLabel = isInitiator ? 'Dashboard' : 'Approval Portal';
  const subject = isInitiator
    ? `e-Special Sanction Refno #${refNo} - Sent Back to Initiator`
    : `e-Special Sanction Refno #${refNo} - ${stage} Approval`;

  const approvalLink = `https://mamdevuat-o55cwsdo.launchpad.cfapps.eu10.hana.ondemand.com/e4109682-d445-4b2b-8667-aed2e5036b4b.comapprovalrouter.commmapprovalhubapprovalhub-0.0.1/index.html?role=${role}`;

  const body = `
      <p>Dear Sir/ Madam,</p>
      <p>Please find below eSpecial Sanction Approval Process details</p>
      <table border="1" cellpadding="8" cellspacing="0" style="border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; font-size: 14px;">
        <tr>
          <td style="background-color: red; color: white;">Division</td><td>${ssfdData.division || ''}</td>
          <td style="background-color: red; color: white;">PU/Department</td><td>${ssfdData.puDept || ''}</td>
          <td style="background-color: red; color: white;">Date</td><td>${date || ''}</td>
        </tr>
        <tr>
          <td style="background-color: red; color: white;">Location</td><td>${ssfdData.loc || ''}</td>
          <td style="background-color: red; color: white;">Project Name</td><td>${ssfdData.projName || ''}</td>
          <td style="background-color: red; color: white;">Item Required / Description</td><td>${ssfdData.itemRequiredDesc || ''}</td>
        </tr>
        <tr>
          <td style="background-color: red; color: white;">Budget Required</td><td>${ssfdData.budgetRequired || ''}</td>
          <td style="background-color: red; color: white;">IRR (>3Cr)</td><td>${ssfdData.irr || ''}</td>
          <td colspan="2"></td>
        </tr>
        <tr>
          <td style="background-color: red; color: white;">Background/Current Scenario</td><td>${ssfdData.background || ''}</td>
          <td style="background-color: red; color: white;">Proposal/Justification</td><td>${ssfdData.justification || ''}</td>
          <td style="background-color: red; color: white;">Deliverables</td><td>${ssfdData.deliverables || ''}</td>
        </tr>
      </table>
      <p>
        <a href="${approvalLink}" style="background-color: #007bff; color: #fff; padding: 10px 15px; text-decoration: none; border-radius: 4px;">
          ${linkLabel}
        </a>
      </p>
    `;

  await sendMail({ to: emails, subject, body });
}


module.exports = {
  OnGetSSFD, OnSSFDApproval, getNextStage
}
