const cds = require('@sap/cds');
const { getCurrTimestamp } = require("../utils/dateUtils.js");
const { getCurrentUser } = require('./Request');
const sendMail = require('../utils/emailService');
const fs = require('fs');
const path = require('path');



function validateApprovers(req) {
  const { appR1, appR2, appR3 } = req.data;
  const duplicates = [];

  if (appR1 && appR2 && appR1 === appR2) duplicates.push('R1 & R2');
  if (appR1 && appR3 && appR1 === appR3) duplicates.push('R1 & R3');
  if (appR2 && appR3 && appR2 === appR3) duplicates.push('R2 & R3');

  if (duplicates.length > 0) {
    throw new Error(`Approvers ${duplicates.join(', ')} must be different.`);
  }
  return {
    isDuplicate: Boolean(duplicates.length)
  }
};

async function OnNBApproval(req) {
  try {
    const tx = cds.transaction(req);
    const { reqID, action, remarks } = req.data;

    // Get database entities
    const db = await cds.connect.to('db');
    const { ReqFormNB_Details, Request, ProcessLog } = db.entities('mm_dpde_schema');
    const { Approvers, ProcessGroupTask } = db.entities('mm_dpde_master');


    // Get current request and form details
    const request = await cds.run(SELECT.one.from(Request).where({ reqID }));
    const formDetails = await cds.run(SELECT.one.from(ReqFormNB_Details).where({ reqID }));
    const pendingLog = await cds.run(
      SELECT.one.from(ProcessLog).where({ reqID, status: 'Pending' }).orderBy('receivedDt desc')
    );

 
    if (!request || !formDetails) {
      throw new Error(`Request or form details not found for reqID: ${reqID}`);
    }

    const currentStage = request.stage || 'Initiator';
    if(currentStage=='END'){
      req.reject("This request has been Approved");
    }

    const currentDate = getCurrTimestamp();
    req.data.role = (action !== 'SUBMIT' && currentStage != 'Initiator') ? pendingLog?.stage?.replace('Recommended By ', 'Recommended')?.replace('Approved By', 'ApprovedBy')?.replace('Asset Team Member', 'Asset Team') : '';


    const currentUser = await getCurrentUser(req);
    //console.log(currentUser)
    // if no current user found

    if (currentStage == 'Initiator' && request.createdBy == currentUser.email) {
      currentUser.role = 'Initiator'
    }

    // console.log(action, currentUser, pendingLog);
    //Check in pending log : currUser email == pedinglog.useer or pendinglog.role=userRole
    if (action !== 'SUBMIT' && pendingLog) {
      if (!currentUser) {
        req.reject("Your are not Authorised User");
      }
      const { userEmail, stage } = pendingLog;
      // if user email is there then check email else check role
      const isAllowed = (userEmail && currentUser.email == userEmail) || currentUser.role == stage;
      if (!isAllowed) {
        req.reject("You are not Authorised to Approve or Sent Back");
      }
    }

    // Route to appropriate handler based on action
    switch (action) {
      case 'SUBMIT': // only initator will do
        return await handleSubmit(req, tx, request, formDetails, currentDate);
      case 'REJECT':
        return await handleReject(req, tx, request, formDetails, currentStage, currentDate);
      case 'FORWARD': //handling ASSIGN & FORWARD
        return await handleForward(req, tx, request, formDetails, currentStage, currentDate);
      case 'ASSIGN': //handling ASSIGN & FORWARD
        return await handleForward(req, tx, request, formDetails, currentStage, currentDate);
      case 'APPROVE':
        return await handleApprove(req, tx, request, formDetails, currentStage, currentDate);

      default:
        throw new Error(`Unsupported action: ${action}`);
    }

  } catch (error) {
    console.error('Error in OnNBApproval:', error);
    throw error;
  }
}

async function handleSubmit(req, tx, request, formDetails, currentDate) {
  const { reqID, remarks } = req.data;
  const db = await cds.connect.to('db');
  const { ReqFormNB_Details, Request, ProcessLog } = db.entities('mm_dpde_schema');
  const { Approvers, ProcessGroupTask } = db.entities('mm_dpde_master');

  const isAnonymous = !req.user || req.user.id === 'anonymous';

  // if (request.status !='Draft' &&  request.status !='' ){
  //   throw new Error("Previous request cannot be submitted again");
  // }

  // Log initiator submission
  await tx.run(
    INSERT.into(ProcessLog).entries({
      reqID,
      stage: 'Initiator',
      userName: isAnonymous ? 'Default User' : req.user.name ?? req.user.id,
      userEmail: isAnonymous ? 'default@example.com' : req.user.email ?? req.user.id,
      status:'SUBMITTED',
      receivedDt: currentDate,
      remarks,
      createdAt: new Date(),
    })
  );
  // Get R1 approver details
  const approvers = await getApproverDetails('R1', formDetails, tx);
  await new Promise(resolve => setTimeout(resolve, 1000)); // 1 sec delay

  const r1ApproverName = approvers[0]?.name;
  const r1ApproverEmail = approvers[0]?.email;
  // Update request status
  await tx.run(
    UPDATE(Request).set({
      stage: 'R1',
      status: 'Pending',
      pendingWith: r1ApproverEmail,
      pendingWithName: r1ApproverName
    }).where({ reqID })
  );
  // Create pending log for R1
  await tx.run(
    INSERT.into(ProcessLog).entries({
      reqID,
      stage: 'R1',
      userName: r1ApproverName,
      userEmail: r1ApproverEmail,
      status: 'Pending',
      receivedDt: currentDate,
      createdAt: new Date(),
    })
  );

  // Send email to R1 approver
  sendCapitalBudgetEmail({
    requestData:formDetails,
    refNo:request.refNo,
    emailType: 'APPROVAL',
    email: r1ApproverEmail,
    tx
  });

  return { message: `Request ${request.refNo} submitted for approval successfully.` };
}

// Handler for REJECT action
async function handleReject(req, tx, request, formDetails, currentStage, currentDate) {
  const { reqID, remarks } = req.data;
  const db = await cds.connect.to('db');
  const { ReqFormNB_Details, Request, ProcessLog } = db.entities('mm_dpde_schema');
  const { Approvers, ProcessGroupTask } = db.entities('mm_dpde_master');
  const allModifiers = await getApproverDetails("ALL_MODIFIERS", formDetails, tx, request);

  const allModifiersEmail = allModifiers.map((modifier) => { return modifier.userEmail });
  // TODO:throw error if a particular stage cannot reject

  // Update request to rejected status
  await tx.run(
    UPDATE(Request)
      .set({
        stage: 'Initiator',
        status: 'Rejected',
        pendingWith: '',
        pendingWithName: ''
      })
      .where({ reqID })
  );

  // Update current process log
  await tx.run(
    UPDATE(ProcessLog)
      .set({ status: 'Rejected', completionDt: currentDate, remarks })
      .where({ reqID, status: 'Pending' })
  );

  sendCapitalBudgetEmail({
    requestData:formDetails,
    refNo:request.refNo,
    emailType: 'REJECTED_NOTIFICATION',
    email: allModifiersEmail,
    tx
  });

  return { message: 'Request rejected and sent back to initiator' };
}

async function handleApprove(req, tx, request, formDetails, currentStage, currentDate) {

  const { reqID, remarks } = req.data;  // R1-R6&Approved By values will come from UI for Asset Recommend(Approve)
  const db = await cds.connect.to('db');
  const { ReqFormNB_Details, Request, ProcessLog } = db.entities('mm_dpde_schema');
  const { Approvers, ProcessGroupTask } = db.entities('mm_dpde_master');
  const allModifiers = await getApproverDetails("ALL_MODIFIERS", formDetails, tx, request);

  const allModifiersEmail = allModifiers.map((modifier) => { return modifier.userEmail });

  var nextStage = getNextStage(currentStage);
  if (!nextStage) {
    throw new Error(`No next stage defined for current stage: ${currentStage}`);
  }
  
  if (request.pendingWith == '' && request.pendingWithName.toLowerCase().includes('team')) {
    throw new Error('The request needs to assigned to some of the team member first');
  }

  let isModified = false;
  if (currentStage == 'R1' || currentStage == 'R2' || currentStage == 'R3') {
    // console.log(req.data);
    isModified = await checkForModification(req, tx, request, formDetails, currentStage);
  }

  if (currentStage == 'Initiator' || currentStage == 'Asset Team Member') {
    //  the logic to update wbs
    const { wbsNo } = req.data?.data ?? {};
    if (!wbsNo) {
      throw new Error("WBS number required")
    }

    isModified = await checkForModification(req, tx, request, formDetails, currentStage);
  }

  if (currentStage == 'Asset Team' || currentStage == 'Corporate Team') {
    // save data in asset team
    await handleAssetTeamRecommend(req, tx, request, formDetails, currentDate);
  }

  // update(updated details)the form details again
  formDetails = await tx.run(SELECT.one.from(ReqFormNB_Details).where({ reqID }));
  const newdtl = formDetails;

  // case for auto Approval
  let nextStageInserted = false;

   // Update current process log to approved
  await tx.run(
    UPDATE(ProcessLog)
      .set({ status: 'Approved', completionDt: currentDate, remarks })
      .where({ reqID, status: 'Pending' })
  );

  if (nextStage.toLowerCase().includes('recommended by ')) {
    const SelectedRecommenders = Object.entries(formDetails)
      .filter(([key, value]) => key.startsWith('recomApprover') && value && key.replace('recomApprover', '') >= nextStage.replace('Recommended By ', ''))
      .sort(([a], [b]) => parseInt(a.replace('recomApprover', '')) - parseInt(b.replace('recomApprover', '')))
      .map(([, value]) => value);
    const InitialRecommenders = [newdtl.approverR1, newdtl.approverR2, newdtl.approverR3].filter(Boolean);

    nextStageInserted = false;

   console.log(SelectedRecommenders);
   console.log(InitialRecommenders)

    for (let i = 0; i < SelectedRecommenders.length; i++) {
      const k = nextStage.replace('Recommended By ', '');
      const stage = `Recommended By ${i + Number(k)}`;
      console.log(stage);
     



      let status = 'Auto-approved';
      if ( !InitialRecommenders.includes(SelectedRecommenders[i]) && !nextStageInserted) {
        status = 'Pending'; // first unique recommender becomes active
        nextStageInserted = true;
        const rec = await getApproverDetails(stage, formDetails, tx);

        await tx.run(UPDATE(Request).set({ stage, status }).where({ reqID }));
        // GROUP TASK Start
        let groupTask = await tx.run(
          SELECT.one.from(ProcessGroupTask).where({ processId: request.type, stage: stage })
        );

        if (!rec) {
          throw new Error(`Approver email not found`);
        }
        let isGroupTask = groupTask?.isGroup || false;
        const pendingWithName = isGroupTask ? `${stage} Team` : rec[0].name;
        const pendingWith = isGroupTask ? '' : rec[0].email;

        await tx.run(INSERT.into(ProcessLog).entries({
          reqID,
          stage,
          userName: pendingWithName,
          userEmail: pendingWith,
          status,
          receivedDt: new Date(),
        }));
      }
    }

    if (!nextStageInserted) {
      nextStage = 'Approved By';
    }
  }


  const approvers = await getApproverDetails(nextStage, formDetails, tx, request);
  if ((!approvers || approvers.length === 0)) {
    throw new Error(`No approvers found for stage: ${nextStage}`);
  }

  // Check if this is a group task
  const groupTask = await tx.run(
    SELECT.one.from(ProcessGroupTask).where({
      processId: request.type,
      stage: nextStage
    })
  );

  const isGroupTask = groupTask?.isGroup || false;
  const approverEmails = approvers?.map(app => app.email) ?? [];
  let pendingWithName = '';
  let pendingWith = ''

  const initiator = await getApproverDetails('Initiator', formDetails, tx, request);
  if (nextStage !== 'END') {

    // Determine pending details
    pendingWithName = isGroupTask ? `${nextStage}` : approvers[0].name;
    pendingWith = isGroupTask ? '' : approvers[0].email;

    // Create new pending log for next stage
    if(!nextStageInserted)
      await tx.run(
        INSERT.into(ProcessLog).entries({
          reqID,
          stage: nextStage,
          userName: pendingWithName,
          userEmail: pendingWith,
          status: 'Pending',
          receivedDt: currentDate
        })
    );

    const finalStages = ['Initiator', 'Asset Team Member', 'Corporate Team' ]

    if (!finalStages.includes(nextStage)) {
      sendCapitalBudgetEmail({
        requestData:formDetails,
        refNo:request.refNo,
        emailType: 'NOTIFICATION',
        email: allModifiersEmail,
        tx,
        customAction: 'has been Recommended' + (isModified ? ' With Modification' : '')
      });
    }

    else if (currentStage == 'Approved By') {
      sendCapitalBudgetEmail({
        requestData:formDetails,
        refNo:request.refNo,
        emailType: 'NOTIFICATION',
        email: allModifiersEmail,
        tx,
        customAction: 'has been Approved'
      });
    }


  }
  // Update request stage
  await tx.run(
    UPDATE(Request).set({
      stage: nextStage == 'END' ? "Approved" : nextStage,
      status: nextStage == 'END' ? "Approved" : "Pending",
      pendingWith,
      pendingWithName
    }).where({ reqID })
  );

  // Send approval email
  let emailTarget = isGroupTask ? approverEmails : approverEmails[0];
  let emailType = "APPROVAL";
  let customAction = '';

  if (nextStage == 'Initiator') {
    emailType = 'WBS_CREATION'
  }
  else if (nextStage == 'Asset Team Member') {
    emailType = 'WBS_VERIFICATION';
  } 
  else if (nextStage == 'Corporate Team') {
    emailType = 'CORPORATE'
  }
  //console.log();
  else if (nextStage == 'END'){
    emailType = 'NOTIFICATION';
    const assetTeamMember = await getApproverDetails('Asset Team Member', formDetails, tx, request);
    emailTarget = [emailTarget,assetTeamMember[0].userEmail];
    customAction= 'has Been Completed';
  }

  if (currentStage == 'Asset Team Member' && isModified) {
    sendCapitalBudgetEmail({
      requestData:formDetails,
      refNo:request.refNo,
      emailType: 'NOTIFICATION',
      email: initiator[0].userEmail,
      tx,
      customAction: ' wbsNo revised or modified',
    });
  }



  // await sendApprovalEmail(formDetails, request.refNo:request.refNo, nextStage, emailTarget, tx, currentDate); 
  sendCapitalBudgetEmail({
    requestData:formDetails,
    refNo:request.refNo,
    emailType: emailType,
    email: emailTarget,
    customAction,
    tx
  });
  // APPROVAL mail to email target
  // notification to the modifiers // modifiers will be 
  //  how wwe will get all modifiers fomr proces slogs get the userEMail for all submitted and approved status logs of that request id 

  return { message: `Request approved and moved to ${nextStage}` };
}


async function handleForward(req, tx, request, formDetails, currentStage, currentDate) {
  const { reqID, remarks } = req.data;
  const { assignedTo } = req.data.data;
  const db = await cds.connect.to('db');
  const { ReqFormNB_Details, Request, ProcessLog } = db.entities('mm_dpde_schema');
  const { Approvers, ProcessGroupTask } = db.entities('mm_dpde_master');
  const newdtl = req.data.data;

  const allModifiers = await getApproverDetails("ALL_MODIFIERS", formDetails, tx, request);

  const allModifiersEmail = allModifiers.map((modifier) => { return modifier.userEmail });

  // Check if current stage is a team stage (contains 'Team' or 'Team Member')
  const isTeamStage = currentStage.toLowerCase().includes('team');

  if (!isTeamStage) {
    throw new Error(`Forward action is only allowed for team stages. Current stage: ${currentStage}`);
  }
  if (!assignedTo) {
    throw new Error(`Request must be assgined to someone`);
  }

  // Determine the team type and get appropriate team members
  let teamMembers = [];
  let teamRole = '';


  const stageWords = currentStage.split(' ');
  const teamType = stageWords.find(word => word !== 'Team' && word !== 'Member');
  teamRole = `${teamType}`;

  // if else for team role if team "Assetmanagement" uske behalf pe role change kr dena and db me query krni

  if (teamRole === "Asset") {
    teamRole = "Asset Team"

  }

  if (teamRole === "Corporate") {
    teamRole = "Corporate Team"
  }

  teamMembers = await tx.run(
    SELECT.from(Approvers).columns('name', 'email').where({ role: teamRole })
  );


  if (!teamMembers || teamMembers.length === 0) {
    throw new Error(`No team members found for role: ${teamRole}`);
  }

  // Determine next stage for forwarding
  let nextStage = currentStage;

  const assignDtl = await tx.run(SELECT.one.from(Approvers).columns('name', 'email').where({ userID: assignedTo }));  //assignedTo will get Id from UI
  // Update request with assignment info
  await tx.run(
    UPDATE(Request).set({
      stage: nextStage,
      pendingWith: assignDtl.email, // id se name nikalna
      pendingWithName: assignDtl.name, // id se name nikalna
    }).where({ reqID })
  );

  // Update current process log to show forwarding

  await tx.run(
    UPDATE(ProcessLog)
      .set({
        status: 'Forwarded',
        completionDt: currentDate,
        remarks : `Forwarded:${remarks}`
      })
      .where({ reqID, status: 'Pending' })
  );

  // Create new pending log for the assigned team member

  await tx.run(
    INSERT.into(ProcessLog).entries({
      reqID,
      stage: nextStage,
      userName: assignDtl.name,
      userEmail: assignDtl.email,
      status: 'Pending',
      receivedDt: currentDate,
    })
  );
  // Send forward email to the assigned person and team
  const emailTarget = assignDtl.email;
  sendCapitalBudgetEmail({
    requestData:formDetails,
    refNo:request.refNo,
    emailType: 'APPROVAL',
    email: emailTarget,

    tx
  });


  await tx.run(
    UPDATE(ReqFormNB_Details)
      .set(newdtl)
      .where({ reqID })
  );
  // sendCapitalBudgetEmail({
  //   requestData:formDetails,
  //   refNo:request.refNo,
  //   emailType: 'NOTIFICATION',
  //   email: allModifiersEmail,
  //   customAction: 'has Been Forwarded',
  //   tx
  // });

  return {
    message: `Request forwarded to ${assignDtl.name} in ${nextStage}`,
    stage: nextStage,
    assignedTo: assignedTo
  };
}


async function checkForModification(req, tx, request, formDetails, stage) {
  const { remarks, reqID } = req.data;
  const db = await cds.connect.to('db');
  const { ReqFormNB_Details, Request, ProcessLog } = db.entities('mm_dpde_schema');
  const { Approvers, ProcessGroupTask } = db.entities('mm_dpde_master');


  const olddtl = formDetails
  const changedFields = [];

  const newdtl = req.data.data;

  // Compare each relevant field
  for (const key in newdtl) {
    if (newdtl[key] !== olddtl[key]) {
      changedFields.push({
        field: key,
        oldValue: olddtl[key],
        newValue: newdtl[key],
      });
    }
  }

  // If any changes detected, trigger mail
  if (changedFields.length > 0) {
    await tx.run(
      UPDATE(ReqFormNB_Details)
        .set(newdtl)
        .where({ reqID })
    );
    return true;
  }
  return false;

}

async function handleAssetTeamRecommend(req, tx, request, formDetails, currentDate) {

  const { reqID } = req.data;
  const db = await cds.connect.to('db');
  const { ReqFormNB_Details, Request, ProcessLog } = db.entities('mm_dpde_schema');
  const { Approvers, ProcessGroupTask } = db.entities('mm_dpde_master');
  const data = req.data?.data ?? {};

  const { recomApprover1, approvedBy } = data;

  if (!recomApprover1 || !approvedBy) {
    throw new Error("Approver 1 & approved by is required ")
  }
  //TODO: validate the fields
  const SelectedRecommenders = Object.entries(data)
    .filter(([key, value]) => key.startsWith('recomApprover') && value)
    .sort(([a], [b]) => parseInt(a.replace('recomApprover', '')) - parseInt(b.replace('recomApprover', '')))
    .map(([, value]) => value);
  //console.log(SelectedRecommenders);

  await tx.run(
    UPDATE(ReqFormNB_Details)
      .set(data)
      .where({ reqID })
  );

}

// Helper function to get approver email
async function getApproverEmail(approverString, tx) {
  if (!approverString) return null;

  const userID = approverString.split(' - ')[0];
  const db = await cds.connect.to('db');
  const { ReqFormNB_Details, Request, ProcessLog } = db.entities('mm_dpde_schema');
  const { Approvers, ProcessGroupTask } = db.entities('mm_dpde_master');

  const approver = await tx.run(
    SELECT.one.from(Approvers).columns('email').where({ userID })
  );

  return approver?.email || null;
}

// Helper function to get approver details based on stage
async function getApproverDetails(stage, formDetails, tx, request) {
  const db = await cds.connect.to('db');
  const { Approvers, ProcessGroupTask } = db.entities('mm_dpde_master');
  const { ProcessLog } = db.entities('mm_dpde_schema');
  // pending logs me se asset Team member ki id nikalni h

  let approverID = null;

  // Determine approver based on current stage
  switch (stage) {
    case 'R1':
      approverID = formDetails.approverR1;
      break;
    case 'R2':
      approverID = formDetails.approverR2;
      break;
    case 'R3':
      approverID = formDetails.approverR3;
      break;
    case 'Asset Team Member':
      const emailRow = await tx.run(
        SELECT.one.from(ProcessLog).columns('userEmail').where({ stage: "Asset Team", status: "Approved" }).and('userEmail IS NOT NULL')
          .and("userEmail != ''")
      );
      //  console.log(emailRow, 'email row')
      const email = emailRow?.userEmail;

      const approverRow = await tx.run(
        SELECT.one.from(Approvers).columns('userID').where({ email })
      );
      // console.log('approverrow:', approverRow)
      approverID = approverRow?.userID;
      break;
    case 'Corporate Team Member':
      const emailRows = await tx.run(
        SELECT.one.from(ProcessLog).columns('userEmail').where({ stage: "Corporate Team", status: "Pending" }).and('userEmail IS NOT NULL')
          .and("userEmail != ''")
      );
      //  console.log(emailRow, 'email row')
      const emails = emailRows?.userEmail;

      const approverRows = await tx.run(
        SELECT.one.from(Approvers).columns('userID').where({ emails })
      );
      // console.log('approverrow:', approverRow)
      approverID = approverRows?.userID;
      break;
    case 'Approved By':
      approverID = formDetails[`approvedBy`];;
      break;
    case 'Initiator':
    case 'END':
      const initiator = await tx.run(
        SELECT.one.from(Approvers).columns('userID').where({ email: request[`createdBy`] })
      );
      approverID = initiator?.userID;
      break;
    case 'Corporate Team':
      // For Corporate Team, get all team members
      const corporateTeamMembers = await tx.run(
        SELECT.from(Approvers).columns('name', 'email').where({ role: 'Corporate Team' })
      );
      return corporateTeamMembers;
    case 'Asset Team':
      // For Asset Team, get all team members
      const assetTeamMembers = await tx.run(
        SELECT.from(Approvers).columns('name', 'email').where({ role: 'Asset Team' })
      );
      return assetTeamMembers;
    case 'Recommended By 1':
    case 'Recommended By 2':
    case 'Recommended By 3':
    case 'Recommended By 4':
    case 'Recommended By 5':
    case 'Recommended By 6':
      const index = stage.replace('Recommended By ', '');
      approverID = formDetails[`recomApprover${index}`];
      break;
    case 'ALL_MODIFIERS':
      const modifierEmailRow = await tx.run(
        SELECT.from(ProcessLog)
          .columns('userEmail')
          .where({ status: { '!=': 'Pending' } })
          .and({ userEmail: { '!=': null } })
          .and({ userEmail: { '!=': '' } })
          .and ({reqID: request.reqID})
      );
      // console.log(modifierEmailRow);
      return modifierEmailRow;

    default:
      return null;
  }

  if (approverID) {
    const approver = await tx.run(
      SELECT.one.from(Approvers).columns('name', 'email','userID').where({ userID: approverID })
    );
    return approver ? [approver] : [];
  }

  return [];
}


// Helper function to get next stage in the approval flow
function getNextStage(currentStage) {
  const stageFlow = {
    'R1': 'R2',
    'R2': 'R3',
    'R3': 'Asset Team',
    'Asset Team': 'Recommended By 1',
    'Recommended By 1': 'Recommended By 2',
    'Recommended By 2': 'Recommended By 3',
    'Recommended By 3': 'Recommended By 4',
    'Recommended By 4': 'Recommended By 5',
    'Recommended By 5': 'Recommended By 6',
    'Recommended By 6': 'Approved By',
    'Approved By': 'Initiator',
    'Initiator': 'Asset Team Member',
    'Asset Team Member': 'Corporate Team',
    'Corporate Team': 'END'
  };

  return stageFlow[currentStage] || null;
}

// function getAllModifiersEmail()

const EMAIL_CONFIGS = {
  APPROVAL: {
    action: 'is for your recommendation / approval',
    portalType: 'approval',
    includeContactDetails: false,
  },
  REJECTED_NOTIFICATION: {
    action: 'has been Rejected',
    portalType: 'dashboard',
    includeContactDetails: true,
    isNotification: true,
  },
  NOTIFICATION: {
    action: '', // we will pass custom action,
    portalType: 'dashboard',
    includeContactDetails: false,
    isNotification: true,
  },
  WBS_CREATION: {
    action: 'is for WBS Creation', //TODO : Change value according to PDF 
    portalType: 'dashboard',
    includeContactDetails: false
  },
  WBS_VERIFICATION: {
    action: 'is for WBS Verification', //TODO : Change value according to PDF 
    portalType: 'dashboard',
    includeContactDetails: false
  },
  CORPORATE: { // Fixed typo: CORPORTATE -> CORPORATE & make one more for Budget Release accoriding to PDF 
    action: 'is for Review & Release',
    portalType: 'dashboard',
    includeContactDetails: false
  },
};

const BASE_URL = "https://mamdevuat-o55cwsdo.launchpad.cfapps.eu10.hana.ondemand.com/e4109682-d445-4b2b-8667-aed2e5036b4b.comapprovalrouter.commmapprovalhubapprovalhub-0.0.1/index.html";

const PORTAL_LINKS = {
  approval: `${BASE_URL}?role=AP`,
  dashboard: BASE_URL + '?role=IN'
};

// Email CSS styles
const EMAIL_STYLES = `
  <style>
    .email-container {
      font-family: Arial, sans-serif;
      font-size: 14px;
      max-width: 800px;
      margin: 0 auto;
      padding: 20px;
    }
    
    .email-table {
      border: 1px solid #000;
      border-collapse: collapse;
      width: 100%;
      margin-bottom: 20px;
    }
    
    .email-table td {
      border: 1px solid #000;
      padding: 8px;
    }
    
    .table-header {
      background-color: #dc3545;
      color: white;
      font-weight: bold;
    }
    
    .portal-button {
      background-color: #007bff;
      color: #fff;
      padding: 10px 15px;
      text-decoration: none;
      border-radius: 4px;
      display: inline-block;
      margin-top: 20px;
    }
    
    .portal-button:hover {
      background-color: #0056b3;
      color: #fff;
    }
    
    .section-title {
      color: #333;
      margin-top: 20px;
      margin-bottom: 10px;
    }
    
    .approval-history-header {
      background-color: #dc3545;
      color: white;
      font-weight: bold;
    }
  </style>
`;


const sendCapitalBudgetEmail = async ({
  requestData,
  refNo,
  emailType,
  email,
  tx,
  customAction = null,
  fieldMapping = {}
}) => {
  // Get configuration for the email type
  const config = EMAIL_CONFIGS[emailType];
  if (!config) {
    throw new Error(`Invalid email type: ${emailType}`);
  }
  const r1Data = await cds.run(
    SELECT.one.from('mm_dpde_master.Approvers').where({ userID: requestData.approverR1 })
  );
  
  const r2Data = await cds.run(
    SELECT.one.from('mm_dpde_master.Approvers').where({ userID: requestData.approverR2 })
  );
  
  const r3Data = await cds.run(
    SELECT.one.from('mm_dpde_master.Approvers').where({ userID: requestData.approverR3 })
  );
  
  
  // Default field mapping - can be overridden for specific cases
  const defaultFieldMapping = {
    division: 'NABDiv',
    location: 'NABLoc',
    department: 'dept',
    totalCost: 'totalProjCost',
  };

  // Merge custom field mapping with defaults
  const fields = { ...defaultFieldMapping, ...fieldMapping };

  const getFieldValue = (fieldKey) => {
    const mappedField = fields[fieldKey];
    return requestData[mappedField] || requestData[fieldKey] || '';
  };

  // Generate subject
  const action = customAction || config.action;
  const isNotification = config.isNotification || false; // Fixed variable name

  // Get portal link
  const subject = (isNotification ? `(Notification) ` : '') + `Capital Budget Request - ${getFieldValue('projectDesc')} # ${refNo} ${action}`;

  // Get portal link - Fixed logic
  const portalLink = !isNotification ? PORTAL_LINKS[config.portalType] : PORTAL_LINKS['dashboard'];
  const portalButtonText = config.portalType === 'approval' && !isNotification ? 'Approval Portal' : 'Dashboard';

  // Format date helper
  const formatDate = (dt) => {
    if (!dt) return '';
    const date = new Date(dt);
    return isNaN(date) ? '' : date.toISOString().split('T')[0];
  };


  const approvalHistory = await cds.run(
    SELECT.from('mm_dpde_schema.ProcessLog')
      .where({
        reqID: getFieldValue('reqID'),
        status: { in: ['Approved', 'SUBMITTED', 'Pending'] }
      })
      .orderBy('receivedDt asc')
  );
  

  let approvalHistoryRows = '';
  for (const entry of approvalHistory) {
    approvalHistoryRows += `
      <tr>
        <td class="table-header">${entry.stage || ''}</td>
        <td>${entry.userName || ''}</td>
        <td>${formatDate(entry.receivedDt)}</td>
        <td>${entry.remarks || ''}</td>
      </tr>
    `;
  }

  // Build contact details section if required
  const contactDetailsSection = config.includeContactDetails ? `
    <br>
    <h3 class="section-title">Contact Details</h3>
    <table class="email-table">
      <tr>
        <td class="table-header">Contact Person Name</td>
        <td>${getFieldValue('contactPerson') || 'N/A'}</td>
        <td class="table-header">Contact Number</td>
        <td>${getFieldValue('contactNo') || 'N/A'}</td>
      </tr>
    </table>
  ` : '';

  // Build email body
  const body = `
    <!DOCTYPE html>
    <html lang="en">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>${subject}</title>
      ${EMAIL_STYLES}
    </head>
    <body>
      <div class="email-container">
        <p>Dear Sir/Madam,</p>
        <p>Capital Budget Request No. <strong>${refNo}</strong> ${action}.</p>
       
        <h3 class="section-title">Request Details</h3>
        <table class="email-table">
          <tr>
            <td class="table-header">Division</td>
            <td>${getFieldValue('division')}</td>
            <td class="table-header">Project Name / Item Description</td>
            <td>${getFieldValue('projectDesc')}</td>
          </tr>
          <tr>
            <td class="table-header">Location</td>
            <td>${getFieldValue('location')}</td>
            <td class="table-header">Total project Cost (Lakhs)</td>
            <td>${getFieldValue('totalCost')}</td>
          </tr>
          <tr>
            <td class="table-header">Department</td>
            <td>${getFieldValue('department')}</td>
            <td class="table-header">Seek Approval (Lakhs)</td>
            <td>${getFieldValue('seekApproval')}</td>
          </tr>
          <tr>
            <td class="table-header">Implementation Date</td>
            <td>${formatDate(getFieldValue('implDate'))}</td>
            <td class="table-header">IRR / Payback</td>
            <td>${getFieldValue('irrPayback')}</td>
          </tr>
          <tr>
            <td class="table-header">Contact Person Name</td>
            <td>${getFieldValue('contactPerson')}</td>
            <td class="table-header">Contact Number</td>
            <td>${getFieldValue('contactNo')}</td>
          </tr>
        </table>
  
        ${contactDetailsSection}
  
       <h3 class="section-title">Request Justification</h3>
<table class="email-table" style="table-layout: fixed; width: 100%;">
  <tr>
    <td class="table-header" style="width: 30%;">Objective</td>
    <td style="width: 70%;">${getFieldValue('objective')}</td>
  </tr>
  <tr>
    <td class="table-header" style="width: 30%;">Proposal</td>
    <td style="width: 70%;">${getFieldValue('proposal')}</td>
  </tr>
  <tr>
    <td class="table-header" style="width: 30%;">Deliverables</td>
    <td style="width: 70%;">${getFieldValue('deliverables')}</td>
  </tr>
</table>

  
        <h3 class="section-title">Requisitioners</h3>
<table class="email-table">
  <tr>
    <td class="table-header">Recommended By</td>
    <td>${r1Data.name}</td>
    <td>${r2Data.name}</td>
    <td>${r3Data.name}</td>
  </tr>
</table>

  
        <h3 class="section-title">Approval History</h3>
        <table class="email-table">
          <tr>
            <td class="table-header">Role</td>
            <td class="table-header">Name</td>
            <td class="table-header">Date</td>
            <td class="table-header">Remarks</td>
          </tr>
          ${approvalHistoryRows}
        </table>
  
        <p>
          <a href="${portalLink}" class="portal-button">
            ${portalButtonText}
          </a>
        </p>
      </div>
    </body>
    </html>
  `;
  
  // if(process.env.NODE_ENV !== 'development') {
  //   // Save HTML to file and send mock email
  //   const fileName = emailType;
  //   const filePath = path.join(__dirname, 'email_outputs', fileName);
    
  //   // Create directory if it doesn't exist
  //   const dir = path.dirname(filePath);
  //   if (!fs.existsSync(dir)) {
  //     fs.mkdirSync(dir, { recursive: true });
  //   }
    
  //   // Write HTML file
  //   fs.writeFileSync(filePath, body);
  //   console.log(`✅ HTML file saved: ${filePath}`);
  // }

  // Send mock email
  await sendMail({ to: email, subject, body }, emailType);
  return `Capital Budget Email sent successfully for ${emailType}`;
};

module.exports = {
  validateApprovers,
  OnNBApproval
}