const cds = require('@sap/cds');
const sendMail = require('../utils/emailService');
const { getCurrentUser } = require('./Request');

module.exports = {
  approveRequest
};

function generateCapNumber() {
  const fiscalYear = new Date().getFullYear().toString().slice(-2);
  const randomFive = String(Math.floor(10000 + Math.random() * 90000));
  return `FY${fiscalYear}-CAP-${randomFive}`;
};

function generateInitiatorEmail(form, attachments = [], logs = []) {
  const {
    capNumber,
    projectCode,
    model,
    erNumber,
    projectDescription,
    changeDesc,
    reasonForChange,
    changeCategory,
    costImpactBasic,
    costImpactLanded,
    annualCostImpact,
    aggregate,
    verifiedBy
  } = form;

  const uploadedDocs = attachments.map(doc => `
    <tr>
      <td style="border:1px solid #ddd;padding:8px;">${doc.fileName}</td>
      <td style="border:1px solid #ddd;padding:8px;">${doc.uploadedBy}</td>
      <td style="border:1px solid #ddd;padding:8px;">${new Date(doc.uploadedAt).toLocaleDateString()}</td>
    </tr>
  `).join('');

  const approvalLogs = logs.map(log => `
    <tr>
      <td style="border:1px solid #ddd;padding:8px;">${log.role}</td>
      <td style="border:1px solid #ddd;padding:8px;">${log.status}</td>
      <td style="border:1px solid #ddd;padding:8px;">${log.userID} - ${log.userName}</td>
      <td style="border:1px solid #ddd;padding:8px;">${new Date(log.timestamp).toLocaleDateString()}</td>
      <td style="border:1px solid #ddd;padding:8px;">${log.remarks || ''}</td>
    </tr>
  `).join('');

  return `
    <div style="font-family:Arial,sans-serif;font-size:14px;">
      <p>Dear Sir/Madam,</p>
      <p>Please find below Cost Approval Process details</p>
      
      <table style="border-collapse:collapse;width:100%;margin-bottom:10px;">
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Project Code</td>
          <td style="border:1px solid #ddd;padding:8px;">${projectCode}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Model</td>
          <td style="border:1px solid #ddd;padding:8px;">${model}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">ER Number</td>
          <td style="border:1px solid #ddd;padding:8px;">${erNumber}</td>
        </tr>
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Project Description</td>
          <td style="border:1px solid #ddd;padding:8px;">${projectDescription}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Change Desc</td>
          <td style="border:1px solid #ddd;padding:8px;">${changeDesc}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Reason for change</td>
          <td style="border:1px solid #ddd;padding:8px;">${reasonForChange}</td>
        </tr>
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Change Category</td>
          <td style="border:1px solid #ddd;padding:8px;">${changeCategory}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Cost Impact Basic (In Rs.) Per Tractor</td>
          <td style="border:1px solid #ddd;padding:8px;">${costImpactBasic}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Cost Impact Landed (In Rs.) Per Tractor</td>
          <td style="border:1px solid #ddd;padding:8px;">${costImpactLanded}</td>
        </tr>
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Annual Cost Impact (In Lakhs)</td>
          <td style="border:1px solid #ddd;padding:8px;">${annualCostImpact}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Aggregate</td>
          <td style="border:1px solid #ddd;padding:8px;">${aggregate}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Verified By</td>
          <td style="border:1px solid #ddd;padding:8px;">${verifiedBy}</td>
        </tr>
      </table>

      <h3 style="background:#c00000;color:#fff;padding:8px;">Uploaded Documents</h3>
      <table style="border-collapse:collapse;width:100%;margin-bottom:10px;">
        <tr>
          <th style="background:#c00000;color:#fff;padding:8px;">Document Name</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Uploaded By</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Uploaded On</th>
        </tr>
        ${uploadedDocs || `<tr><td colspan="3" style="border:1px solid #ddd;padding:8px;text-align:center;">No documents uploaded</td></tr>`}
      </table>

      <h3 style="background:#c00000;color:#fff;padding:8px;">Approval History</h3>
      <table style="border-collapse:collapse;width:100%;">
        <tr>
          <th style="background:#c00000;color:#fff;padding:8px;">Approver Role</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Approver Status</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Approved By/Current Holder</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Approved Date</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Comments</th>
        </tr>
        ${approvalLogs || `<tr><td colspan="5" style="border:1px solid #ddd;padding:8px;text-align:center;">No approval records found</td></tr>`}
      </table>

      <p><a href="#">Click Here</a></p>
    </div>
  `;
};


function generatePVELeadEmail(form) {
  const {
    capNumber,
    projectCode,
    model,
    erNumber,
    projectDescription,
    changeDesc,
    reasonForChange,
    changeCategory,
    costImpactBasic,
    costImpactLanded,
    annualCostImpact,
    aggregate,
    verifiedBy
  } = form;

  return `
    <div style="font-family:Arial,sans-serif;font-size:14px;">
      <p>Dear Sir/Madam,</p>
      <p>Please find below Cost Approval Process details</p>
      
      <table style="border-collapse:collapse;width:100%;margin-bottom:10px;">
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Project Code</td>
          <td style="border:1px solid #ddd;padding:8px;">${projectCode}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Model</td>
          <td style="border:1px solid #ddd;padding:8px;">${model}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">ER Number</td>
          <td style="border:1px solid #ddd;padding:8px;">${erNumber}</td>
        </tr>
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Project Description</td>
          <td style="border:1px solid #ddd;padding:8px;">${projectDescription}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Change Desc</td>
          <td style="border:1px solid #ddd;padding:8px;">${changeDesc}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Reason for change</td>
          <td style="border:1px solid #ddd;padding:8px;">${reasonForChange}</td>
        </tr>
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Change Category</td>
          <td style="border:1px solid #ddd;padding:8px;">${changeCategory}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Cost Impact Basic (In Rs.) Per Tractor</td>
          <td style="border:1px solid #ddd;padding:8px;">${costImpactBasic}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Cost Impact Landed (In Rs.) Per Tractor</td>
          <td style="border:1px solid #ddd;padding:8px;">${costImpactLanded}</td>
        </tr>
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Annual Cost Impact (In Lakhs)</td>
          <td style="border:1px solid #ddd;padding:8px;">${annualCostImpact}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Aggregate</td>
          <td style="border:1px solid #ddd;padding:8px;">${aggregate}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Verified By</td>
          <td style="border:1px solid #ddd;padding:8px;">${verifiedBy}</td>
        </tr>
      </table>

      <p><a href="#">Click Here</a></p>
    </div>
  `;
}


function generatePVELeadApprovalEmail(form, attachments = [], logs = []) {
  const {
    capNumber,
    projectCode,
    model,
    erNumber,
    projectDescription,
    changeDesc,
    reasonForChange,
    changeCategory,
    costImpactBasic,
    costImpactLanded,
    annualCostImpact,
    aggregate,
    verifiedBy
  } = form;

  const uploadedDocs = attachments.map(doc => `
    <tr>
      <td style="border:1px solid #ddd;padding:8px;">${doc.fileName}</td>
      <td style="border:1px solid #ddd;padding:8px;">${doc.uploadedBy}</td>
      <td style="border:1px solid #ddd;padding:8px;">${new Date(doc.uploadedAt).toLocaleDateString()}</td>
    </tr>
  `).join('');

  const approvalLogs = logs.map(log => `
    <tr>
      <td style="border:1px solid #ddd;padding:8px;">${log.role}</td>
      <td style="border:1px solid #ddd;padding:8px;">${log.status}</td>
      <td style="border:1px solid #ddd;padding:8px;">${log.userID} - ${log.userName}</td>
      <td style="border:1px solid #ddd;padding:8px;">${new Date(log.timestamp).toLocaleDateString()}</td>
      <td style="border:1px solid #ddd;padding:8px;">${log.remarks || ''}</td>
    </tr>
  `).join('');

  return `
    <div style="font-family:Arial,sans-serif;font-size:14px;">
      <p>Dear Sir/Madam,</p>
      <p>Please find below Cost Approval Process details</p>
      
      <table style="border-collapse:collapse;width:100%;margin-bottom:10px;">
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Project Code</td>
          <td style="border:1px solid #ddd;padding:8px;">${projectCode}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Model</td>
          <td style="border:1px solid #ddd;padding:8px;">${model}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">ER Number</td>
          <td style="border:1px solid #ddd;padding:8px;">${erNumber}</td>
        </tr>
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Project Description</td>
          <td style="border:1px solid #ddd;padding:8px;">${projectDescription}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Change Desc</td>
          <td style="border:1px solid #ddd;padding:8px;">${changeDesc}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Reason for change</td>
          <td style="border:1px solid #ddd;padding:8px;">${reasonForChange}</td>
        </tr>
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Change Category</td>
          <td style="border:1px solid #ddd;padding:8px;">${changeCategory}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Cost Impact Basic (In Rs.) Per Tractor</td>
          <td style="border:1px solid #ddd;padding:8px;">${costImpactBasic}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Cost Impact Landed (In Rs.) Per Tractor</td>
          <td style="border:1px solid #ddd;padding:8px;">${costImpactLanded}</td>
        </tr>
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Annual Cost Impact (In Lakhs)</td>
          <td style="border:1px solid #ddd;padding:8px;">${annualCostImpact}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Aggregate</td>
          <td style="border:1px solid #ddd;padding:8px;">${aggregate}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Verified By</td>
          <td style="border:1px solid #ddd;padding:8px;">${verifiedBy}</td>
        </tr>
      </table>

      <h3 style="background:#c00000;color:#fff;padding:8px;">Uploaded Documents</h3>
      <table style="border-collapse:collapse;width:100%;margin-bottom:10px;">
        <tr>
          <th style="background:#c00000;color:#fff;padding:8px;">Document Name</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Uploaded By</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Uploaded On</th>
        </tr>
        ${uploadedDocs || `<tr><td colspan="3" style="border:1px solid #ddd;padding:8px;text-align:center;">No documents uploaded</td></tr>`}
      </table>

      <h3 style="background:#c00000;color:#fff;padding:8px;">Approval History</h3>
      <table style="border-collapse:collapse;width:100%;">
        <tr>
          <th style="background:#c00000;color:#fff;padding:8px;">Approver Role</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Approver Status</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Approved By/Current Holder</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Approved Date</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Comments</th>
        </tr>
        ${approvalLogs || `<tr><td colspan="5" style="border:1px solid #ddd;padding:8px;text-align:center;">No approval records found</td></tr>`}
      </table>

      <p><a href="#">Click Here</a></p>
    </div>
  `;
}


function generatePVEHeadTaskEmail(form, logs = []) {
  const {
    capNumber,
    projectCode,
    model,
    erNumber,
    projectDescription,
    changeDesc,
    reasonForChange,
    changeCategory,
    costImpactBasic,
    costImpactLanded,
    annualCostImpact,
    aggregate,
    verifiedBy
  } = form;

  const approvalLogs = logs.map(log => `
    <tr>
      <td style="border:1px solid #ddd;padding:8px;">${log.role}</td>
      <td style="border:1px solid #ddd;padding:8px;">${log.status}</td>
      <td style="border:1px solid #ddd;padding:8px;">${log.userID || ''} - ${log.userName}</td>
      <td style="border:1px solid #ddd;padding:8px;">${log.timestamp ? new Date(log.timestamp).toLocaleDateString() : ''}</td>
      <td style="border:1px solid #ddd;padding:8px;">${log.remarks || ''}</td>
    </tr>
  `).join('');

  return `
    <div style="font-family:Arial,sans-serif;font-size:14px;">
      <p>Dear Sir/Madam,</p>
      <p>Please find below Cost Approval Process details</p>
      
      <table style="border-collapse:collapse;width:100%;margin-bottom:10px;">
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Project Code</td>
          <td style="border:1px solid #ddd;padding:8px;">${projectCode}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Model</td>
          <td style="border:1px solid #ddd;padding:8px;">${model}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">ER Number</td>
          <td style="border:1px solid #ddd;padding:8px;">${erNumber}</td>
        </tr>
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Project Description</td>
          <td style="border:1px solid #ddd;padding:8px;">${projectDescription}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Change Desc</td>
          <td style="border:1px solid #ddd;padding:8px;">${changeDesc}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Reason for change</td>
          <td style="border:1px solid #ddd;padding:8px;">${reasonForChange}</td>
        </tr>
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Change Category</td>
          <td style="border:1px solid #ddd;padding:8px;">${changeCategory}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Cost Impact Basic (In Rs.) Per Tractor</td>
          <td style="border:1px solid #ddd;padding:8px;">${costImpactBasic}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Cost Impact Landed (In Rs.) Per Tractor</td>
          <td style="border:1px solid #ddd;padding:8px;">${costImpactLanded}</td>
        </tr>
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Annual Cost Impact (In Lakhs)</td>
          <td style="border:1px solid #ddd;padding:8px;">${annualCostImpact}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Aggregate</td>
          <td style="border:1px solid #ddd;padding:8px;">${aggregate}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Verified By</td>
          <td style="border:1px solid #ddd;padding:8px;">${verifiedBy}</td>
        </tr>
      </table>

      <h3 style="background:#c00000;color:#fff;padding:8px;">Approval History</h3>
      <table style="border-collapse:collapse;width:100%;">
        <tr>
          <th style="background:#c00000;color:#fff;padding:8px;">Approver Role</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Approver Status</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Approved By/Current Holder</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Approved Date</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Comments</th>
        </tr>
        ${approvalLogs || `<tr><td colspan="5" style="border:1px solid #ddd;padding:8px;text-align:center;">No approval records found</td></tr>`}
      </table>

      <p><a href="#">Click Here</a></p>
    </div>
  `;
}


function generatePVEHeadNotificationEmail(form, attachments = [], logs = []) {
  const {
    capNumber,
    projectCode,
    model,
    erNumber,
    projectDescription,
    changeDesc,
    reasonForChange,
    changeCategory,
    costImpactBasic,
    costImpactLanded,
    annualCostImpact,
    aggregate,
    verifiedBy
  } = form;

  const documentRows = attachments.map(doc => `
    <tr>
      <td style="border:1px solid #ddd;padding:8px;">${doc.fileName}</td>
      <td style="border:1px solid #ddd;padding:8px;">${doc.uploadedBy}</td>
      <td style="border:1px solid #ddd;padding:8px;">${doc.uploadedOn ? new Date(doc.uploadedOn).toLocaleDateString() : ''}</td>
    </tr>
  `).join('');

  const approvalLogs = logs.map(log => `
    <tr>
      <td style="border:1px solid #ddd;padding:8px;">${log.role}</td>
      <td style="border:1px solid #ddd;padding:8px;">${log.status}</td>
      <td style="border:1px solid #ddd;padding:8px;">${log.userID || ''} - ${log.userName}</td>
      <td style="border:1px solid #ddd;padding:8px;">${log.timestamp ? new Date(log.timestamp).toLocaleDateString() : ''}</td>
      <td style="border:1px solid #ddd;padding:8px;">${log.remarks || ''}</td>
    </tr>
  `).join('');

  return `
    <div style="font-family:Arial,sans-serif;font-size:14px;">
      <p>Dear Sir/Madam,</p>
      <p>Please find below Cost Approval Process details</p>
      
      <table style="border-collapse:collapse;width:100%;margin-bottom:10px;">
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Project Code</td>
          <td style="border:1px solid #ddd;padding:8px;">${projectCode}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Model</td>
          <td style="border:1px solid #ddd;padding:8px;">${model}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">ER Number</td>
          <td style="border:1px solid #ddd;padding:8px;">${erNumber}</td>
        </tr>
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Project Description</td>
          <td style="border:1px solid #ddd;padding:8px;">${projectDescription}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Change Desc</td>
          <td style="border:1px solid #ddd;padding:8px;">${changeDesc}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Reason for change</td>
          <td style="border:1px solid #ddd;padding:8px;">${reasonForChange}</td>
        </tr>
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Change Category</td>
          <td style="border:1px solid #ddd;padding:8px;">${changeCategory}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Cost Impact Basic (In Rs.) Per Tractor</td>
          <td style="border:1px solid #ddd;padding:8px;">${costImpactBasic}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Cost Impact Landed (In Rs.) Per Tractor</td>
          <td style="border:1px solid #ddd;padding:8px;">${costImpactLanded}</td>
        </tr>
        <tr>
          <td style="background:#c00000;color:#fff;padding:8px;">Annual Cost Impact (In Lakhs)</td>
          <td style="border:1px solid #ddd;padding:8px;">${annualCostImpact}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Aggregate</td>
          <td style="border:1px solid #ddd;padding:8px;">${aggregate}</td>
          <td style="background:#c00000;color:#fff;padding:8px;">Verified By</td>
          <td style="border:1px solid #ddd;padding:8px;">${verifiedBy}</td>
        </tr>
      </table>

      <h3 style="background:#c00000;color:#fff;padding:8px;">Uploaded Documents</h3>
      <table style="border-collapse:collapse;width:100%;margin-bottom:10px;">
        <tr>
          <th style="background:#c00000;color:#fff;padding:8px;">Document Name</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Uploaded By</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Uploaded On</th>
        </tr>
        ${documentRows || `<tr><td colspan="3" style="border:1px solid #ddd;padding:8px;text-align:center;">No documents found</td></tr>`}
      </table>

      <h3 style="background:#c00000;color:#fff;padding:8px;">Approval History</h3>
      <table style="border-collapse:collapse;width:100%;">
        <tr>
          <th style="background:#c00000;color:#fff;padding:8px;">Approver Role</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Approver Status</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Approved By/Current Holder</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Approved Date</th>
          <th style="background:#c00000;color:#fff;padding:8px;">Comments</th>
        </tr>
        ${approvalLogs || `<tr><td colspan="5" style="border:1px solid #ddd;padding:8px;text-align:center;">No approval records found</td></tr>`}
      </table>

      <p><a href="#">Click Here</a></p>
    </div>
  `;
}



function generateCDMMHeadTaskEmail(form) {
  return `
    <p>Dear Sir/Madam,</p>
    <p>Please find below Cost Approval Process details</p>
    <table border="1" style="border-collapse:collapse; width: 100%; text-align: left;">
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Project Code</b></td><td>${form.projectCode}</td>
        <td style="background-color:#D80000; color:white;"><b>Model</b></td><td>${form.model}</td>
        <td style="background-color:#D80000; color:white;"><b>ER Number</b></td><td>${form.erNumber}</td>
      </tr>
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Project Description</b></td><td>${form.projectDesc}</td>
        <td style="background-color:#D80000; color:white;"><b>Change Desc</b></td><td>${form.changeDesc}</td>
        <td style="background-color:#D80000; color:white;"><b>Reason for change</b></td><td>${form.reason}</td>
      </tr>
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Change Category</b></td><td>${form.changeCategory}</td>
        <td style="background-color:#D80000; color:white;"><b>Cost Impact Basic(In Rs.) Per Tractor</b></td><td>${form.basicImpact}</td>
        <td style="background-color:#D80000; color:white;"><b>Cost Impact Landed(In Rs.) Per Tractor</b></td><td>${form.landedImpact}</td>
      </tr>
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Annual Cost Impact(In Lakhs)</b></td><td>${form.annualImpact}</td>
        <td style="background-color:#D80000; color:white;"><b>Aggregate</b></td><td>${form.aggregate}</td>
        <td style="background-color:#D80000; color:white;"><b>Verified By</b></td><td>${form.verifiedBy}</td>
      </tr>
    </table>
    <br/>
    <a href="${form.taskLink}">Click Here</a>
  `;
}


function generateFDPDHeadTaskEmail(form) {
  return `
    <p>Dear Sir/Madam,</p>
    <p>Please find below Cost Approval Process details</p>
    <table border="1" style="border-collapse:collapse; width: 100%; text-align: left;">
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Project Code</b></td><td>${form.projectCode}</td>
        <td style="background-color:#D80000; color:white;"><b>Model</b></td><td>${form.model}</td>
        <td style="background-color:#D80000; color:white;"><b>ER Number</b></td><td>${form.erNumber}</td>
      </tr>
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Project Description</b></td><td>${form.projectDesc}</td>
        <td style="background-color:#D80000; color:white;"><b>Change Desc</b></td><td>${form.changeDesc}</td>
        <td style="background-color:#D80000; color:white;"><b>Reason for change</b></td><td>${form.reason || ''}</td>
      </tr>
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Change Category</b></td><td>${form.changeCategory}</td>
        <td style="background-color:#D80000; color:white;"><b>Cost Impact Basic(In Rs.) Per Tractor</b></td><td>${form.basicImpact}</td>
        <td style="background-color:#D80000; color:white;"><b>Cost Impact Landed(In Rs.) Per Tractor</b></td><td>${form.landedImpact}</td>
      </tr>
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Annual Cost Impact(In Lakhs)</b></td><td>${form.annualImpact}</td>
        <td style="background-color:#D80000; color:white;"><b>Aggregate</b></td><td>${form.aggregate}</td>
        <td style="background-color:#D80000; color:white;"><b>Verified By</b></td><td>${form.verifiedBy}</td>
      </tr>
    </table>
    <br/>
    <a href="${form.taskLink}">Click Here</a>
  `;
}


function generateFDQAHeadTaskEmail(form) {
  return `
    <p>Dear Sir/Madam,</p>
    <p>Please find below Cost Approval Process details</p>
    
    <table border="1" style="border-collapse: collapse; width: 100%; text-align: left;">
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Project Code</b></td><td>${form.projectCode}</td>
        <td style="background-color:#D80000; color:white;"><b>Model</b></td><td>${form.model}</td>
        <td style="background-color:#D80000; color:white;"><b>ER Number</b></td><td>${form.erNumber}</td>
      </tr>
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Project Description</b></td><td>${form.projectDesc}</td>
        <td style="background-color:#D80000; color:white;"><b>Change Desc</b></td><td>${form.changeDesc}</td>
        <td style="background-color:#D80000; color:white;"><b>Reason for change</b></td><td>${form.reason}</td>
      </tr>
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Change Category</b></td><td>${form.changeCategory}</td>
        <td style="background-color:#D80000; color:white;"><b>Cost Impact Basic(In Rs.) Per Tractor</b></td><td>${form.basicImpact}</td>
        <td style="background-color:#D80000; color:white;"><b>Cost Impact Landed(In Rs.) Per Tractor</b></td><td>${form.landedImpact}</td>
      </tr>
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Annual Cost Impact(In Lakhs)</b></td><td>${form.annualImpact}</td>
        <td style="background-color:#D80000; color:white;"><b>Aggregate</b></td><td>${form.aggregate}</td>
        <td style="background-color:#D80000; color:white;"><b>Verified By</b></td><td>${form.verifiedBy}</td>
      </tr>
    </table>
    
    <br/>
    <a href="${form.taskLink}">Click Here</a>
  `;
}




function generateCustomerCareHeadTaskEmail(form) {
  return `
    <p>Dear Sir/Madam,</p>
    <p>Please find below Cost Approval Process details</p>
    
    <table border="1" style="border-collapse: collapse; width: 100%; text-align: left;">
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Project Code</b></td><td>${form.projectCode}</td>
        <td style="background-color:#D80000; color:white;"><b>Model</b></td><td>${form.model}</td>
        <td style="background-color:#D80000; color:white;"><b>ER Number</b></td><td>${form.erNumber}</td>
      </tr>
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Project Description</b></td><td>${form.projectDesc}</td>
        <td style="background-color:#D80000; color:white;"><b>Change Desc</b></td><td>${form.changeDesc}</td>
        <td style="background-color:#D80000; color:white;"><b>Reason for change</b></td><td>${form.reason}</td>
      </tr>
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Change Category</b></td><td>${form.changeCategory}</td>
        <td style="background-color:#D80000; color:white;"><b>Cost Impact Basic(In Rs.) Per Tractor</b></td><td>${form.basicImpact}</td>
        <td style="background-color:#D80000; color:white;"><b>Cost Impact Landed(In Rs.) Per Tractor</b></td><td>${form.landedImpact}</td>
      </tr>
      <tr>
        <td style="background-color:#D80000; color:white;"><b>Annual Cost Impact(In Lakhs)</b></td><td>${form.annualImpact}</td>
        <td style="background-color:#D80000; color:white;"><b>Aggregate</b></td><td>${form.aggregate}</td>
        <td style="background-color:#D80000; color:white;"><b>Verified By</b></td><td>${form.verifiedBy}</td>
      </tr>
    </table>
    
    <br/>
    <a href="${form.taskLink}">Click Here</a>
  `;
}

function generateMFGHeadTaskEmail(form) {
  return `
    <p>Dear Sir/Madam,</p>
    <p>Please find below Cost Approval Process details</p>
    <table border="1" style="border-collapse:collapse; text-align:left;">
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Project Code</b></td>
        <td>${form.projectCode}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Model</b></td>
        <td>${form.model}</td>
        <td style="background-color:#D32F2F;color:white;"><b>ER Number</b></td>
        <td>${form.erNumber}</td>
      </tr>
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Project Description</b></td>
        <td>${form.projectDesc}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Change Desc</b></td>
        <td>${form.changeDesc}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Reason for change</b></td>
        <td>${form.reason}</td>
      </tr>
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Change Category</b></td>
        <td>${form.changeCategory}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Cost Impact Basic(In Rs.) Per Tractor</b></td>
        <td>${form.basicImpact}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Cost Impact Landed(In Rs.) Per Tractor</b></td>
        <td>${form.landedImpact}</td>
      </tr>
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Annual Cost Impact(In Lakhs)</b></td>
        <td>${form.annualImpact}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Aggregate</b></td>
        <td>${form.aggregate}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Verified By</b></td>
        <td>${form.verifiedBy}</td>
      </tr>
    </table>
    <br/>
    <a href="${form.taskLink}">Click Here</a>
  `;
}
function generateFinancePulTaskEmail(form) {
  return `
    <p>Dear Sir/Madam,</p>
    <p>Please find below Cost Approval Process details</p>
    <table border="1" style="border-collapse:collapse; text-align:left;">
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Project Code</b></td>
        <td>${form.projectCode}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Model</b></td>
        <td>${form.model}</td>
        <td style="background-color:#D32F2F;color:white;"><b>ER Number</b></td>
        <td>${form.erNumber}</td>
      </tr>
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Project Description</b></td>
        <td>${form.projectDesc}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Change Desc</b></td>
        <td>${form.changeDesc}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Reason for change</b></td>
        <td>${form.reason}</td>
      </tr>
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Change Category</b></td>
        <td>${form.changeCategory}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Cost Impact Basic(In Rs.) Per Tractor</b></td>
        <td>${form.basicImpact}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Cost Impact Landed(In Rs.) Per Tractor</b></td>
        <td>${form.landedImpact}</td>
      </tr>
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Annual Cost Impact(In Lakhs)</b></td>
        <td>${form.annualImpact}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Aggregate</b></td>
        <td>${form.aggregate}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Verified By</b></td>
        <td>${form.verifiedBy}</td>
      </tr>
    </table>
    <br/>
    <a href="${form.taskLink}">Click Here</a>
  `;
}


function generateFinanceHeadTaskEmail(form) {
  return `
    <p>Dear Sir/Madam,</p>
    <p>Please find below Cost Approval Process details</p>
    <table border="1" style="border-collapse:collapse; text-align:left;">
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Project Code</b></td>
        <td>${form.projectCode}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Model</b></td>
        <td>${form.model}</td>
        <td style="background-color:#D32F2F;color:white;"><b>ER Number</b></td>
        <td>${form.erNumber}</td>
      </tr>
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Project Description</b></td>
        <td>${form.projectDesc}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Change Desc</b></td>
        <td>${form.changeDesc}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Reason for change</b></td>
        <td>${form.reason}</td>
      </tr>
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Change Category</b></td>
        <td>${form.changeCategory}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Cost Impact Basic(In Rs.) Per Tractor</b></td>
        <td>${form.basicImpact}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Cost Impact Landed(In Rs.) Per Tractor</b></td>
        <td>${form.landedImpact}</td>
      </tr>
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Annual Cost Impact(In Lakhs)</b></td>
        <td>${form.annualImpact}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Aggregate</b></td>
        <td>${form.aggregate}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Verified By</b></td>
        <td>${form.verifiedBy}</td>
      </tr>
    </table>
    <br/>
    <a href="${form.taskLink}">Click Here</a>
  `;
}


function generateVPFinanceTaskEmail(form) {
  return `
    <p>Dear Sir/Madam,</p>
    <p>Please find below Cost Approval Process details</p>
    <table border="1" style="border-collapse:collapse; text-align:left;">
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Project Code</b></td>
        <td>${form.projectCode}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Model</b></td>
        <td>${form.model}</td>
        <td style="background-color:#D32F2F;color:white;"><b>ER Number</b></td>
        <td>${form.erNumber}</td>
      </tr>
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Project Description</b></td>
        <td>${form.projectDesc}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Change Desc</b></td>
        <td>${form.changeDesc}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Reason for change</b></td>
        <td>${form.reason}</td>
      </tr>
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Change Category</b></td>
        <td>${form.changeCategory}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Cost Impact Basic(In Rs.) Per Tractor</b></td>
        <td>${form.basicImpact}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Cost Impact Landed(In Rs.) Per Tractor</b></td>
        <td>${form.landedImpact}</td>
      </tr>
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Annual Cost Impact(In Lakhs)</b></td>
        <td>${form.annualImpact}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Aggregate</b></td>
        <td>${form.aggregate}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Verified By</b></td>
        <td>${form.verifiedBy}</td>
      </tr>
    </table>
    <br/>
    <a href="${form.taskLink}">Click Here</a>
  `;
}


function generateRequestCompletionEmail(form, approvalHistory) {
  return `
    <p>Dear Sir/Madam,</p>
    <p>Please find below Cost Approval Process details</p>
    
    <table border="1" style="border-collapse:collapse; text-align:left;">
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Project Code</b></td>
        <td>${form.projectCode}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Model</b></td>
        <td>${form.model}</td>
        <td style="background-color:#D32F2F;color:white;"><b>ER Number</b></td>
        <td>${form.erNumber}</td>
      </tr>
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Project Description</b></td>
        <td>${form.projectDesc}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Change Desc</b></td>
        <td>${form.changeDesc}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Reason for change</b></td>
        <td>${form.reason}</td>
      </tr>
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Change Category</b></td>
        <td>${form.changeCategory}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Cost Impact Basic(In Rs.) Per Tractor</b></td>
        <td>${form.basicImpact}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Cost Impact Landed(In Rs.) Per Tractor</b></td>
        <td>${form.landedImpact}</td>
      </tr>
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Annual Cost Impact(In Lakhs)</b></td>
        <td>${form.annualImpact}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Aggregate</b></td>
        <td>${form.aggregate}</td>
        <td style="background-color:#D32F2F;color:white;"><b>Verified By</b></td>
        <td>${form.verifiedBy}</td>
      </tr>
    </table>

    <br/>
    <h4>Approval History</h4>
    <table border="1" style="border-collapse:collapse; text-align:left;">
      <tr>
        <td style="background-color:#D32F2F;color:white;"><b>Approver Role</b></td>
        <td style="background-color:#D32F2F;color:white;"><b>Approver Status</b></td>
        <td style="background-color:#D32F2F;color:white;"><b>Approved By/Current Holder</b></td>
        <td style="background-color:#D32F2F;color:white;"><b>Approved Date</b></td>
        <td style="background-color:#D32F2F;color:white;"><b>Comments</b></td>
      </tr>
      ${approvalHistory.map(history => `
        <tr>
          <td>${history.role}</td>
          <td>${history.status}</td>
          <td>${history.approvedBy}</td>
          <td>${history.date}</td>
          <td>${history.comments || ''}</td>
        </tr>
      `).join('')}
    </table>

    <br/>
    <a href="${form.taskLink}">Click Here</a>
    <p><b>Note:</b> Please find attached PDF for request details.</p>
  `;
}



async function approveRequest(req) {
  const { reqID, action, remarks } = req.data;
  const db = cds.transaction(req);

  const {
    Request,
    RequestApprovalForm,
    ProcessLog,
    ReqAttachment
  } = db.entities('mm_dpde_schema');

  const {
    ApprovalDetermination,
    Approvers
  } = db.entities('mm_dpde_master');
  const tx = cds.transaction(req);

 
  const requests = await db.run(SELECT.one.from(Request).where({ reqID }));
  const pendingLog = await db.run(SELECT.one.from(ProcessLog).where({ reqID: reqID, status: 'Pending' }).orderBy('receivedDt desc'));
  const currentStage = requests.stage || 'Initiator';
  req.data.role = (action !== 'SUBMIT' && currentStage !== 'Initiator')
  ? pendingLog?.stage
      ?.replace('CDMM-FDPD HEAD', 'CDMM-HEAD')
      ?.replace('CDMM-FDPD HEAD', 'FDPD-HEAD')
      ?.replace('FDQA & Customer Care-HEAD', 'FDQA-HEAD')
      ?.replace('FDQA & Customer Care-HEAD', 'Customer Care-HEAD')
      ?.replace('Customer Care & QA-PUL', 'Customer Care-PUL')
      ?.replace('Customer Care & QA-PUL', 'QA-PUL')
  : '';
  const currentUserObj = await getCurrentUser(req);
  if (!currentUserObj) return { error: true, message: 'Current user not found in Approvers master' };

  const currentUser = currentUserObj.userID;
  const currentEmail = currentUserObj.email;
  const currentUserRole = currentUserObj.role;

  const request = await db.run(SELECT.one.from(Request).where({ reqID }));
  if (!request) return { error: true, message: 'Request not found' };

  const form = await db.run(SELECT.one.from(RequestApprovalForm).where({ reqID }));
  if (!form) return { error: true, message: 'Form data missing' };

  const capNumber = form.capNumber || generateCapNumber();
  if (!form.capNumber) {
    await db.run(UPDATE(RequestApprovalForm).set({ capNumber }).where({ reqID }));
  }



  if (action === 'Save') {
    await db.run(UPDATE(Request).set({
      status: 'Draft',
      refNo: capNumber
    }).where({ reqID }));

    return { error: false, message: `Request ${reqID} saved. CAP No: ${capNumber}` };
  }

  if (action === 'Submit') {

    // if (currentUserRole !== 'Initiator') {
    //   return { error: true, message: 'Only Initiator can submit the request' };
    // }
    await db.run(INSERT.into(ProcessLog).entries({
      reqID,
      stage: 'Initiator',
      userName: currentUser,
      userEmail: currentEmail,
      status: 'Submitted',
      role: 'Initiator',
      receivedDt: new Date(),
      completionDt: null,
      timestamp: new Date().toISOString(),
      remarks: remarks || 'Initial submission'
    }));

    const pveLeadApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'PVE-LEAD' }));
    if (!pveLeadApprover) {
      return { error: true, message: 'PVE-Lead not found in Approvers master.' };
    }

    await db.run(INSERT.into(ProcessLog).entries({
      reqID,
      stage: pveLeadApprover.role,
      userName: pveLeadApprover.name,
      userEmail: pveLeadApprover.email,
      status: 'Pending',
      role: pveLeadApprover.role,
      receivedDt: new Date(),
      completionDt: null,
      timestamp: new Date().toISOString(),
      remarks: remarks || 'Initial submission'
    }));

    await db.run(UPDATE(Request).set({
      status: 'Pending',
      stage: 'PVE-LEAD',
      pendingWith: pveLeadApprover.email,
      pendingWithName: pveLeadApprover.name,
    }).where({ reqID }));

    const attachments = await db.run(SELECT.from(ReqAttachment).where({ reqID }));
    const logs = await db.run(SELECT.from(ProcessLog).where({ reqID }));

    const subjectInitiator = `CAP Notification: ${capNumber} - After process initiation`;
    const emailBody = generateInitiatorEmail(form, attachments, logs);
    const emailBodyPVE = generatePVELeadEmail(form);

    try {
      await sendMail({
        subject: subjectInitiator,
        body: emailBody,
        to: currentEmail,
        cc: 'suraj.mishra@sumodigitech.com'
      });
    } catch (error) {
      console.error(`Failed to send initiator email for ${capNumber}: ${error.message}`);
    }

    try {
      await sendMail({
        subject: `Cost Approval Process: ${capNumber} - PVE-Lead Approval`,
        body: emailBodyPVE,
        to: 'suraj.mishra@sumodigitech.com',
      });
    } catch (error) {
      console.error(`Failed to send PVE-Lead email for ${capNumber}: ${error.message}`);
    }

    return { error: false, message: `Request ${capNumber} submitted.` };
  }

  if (request.stage === 'PVE-LEAD') {

    if (currentUserRole !== 'PVE-LEAD') {
      return { error: true, message: 'Only PVE-LEAD can approve or reject at this stage' };
    }
    if (action === 'Reject' && !remarks) {
      return { error: true, message: 'Remarks are mandatory for rejection.' };
    }

    if (action === 'Reject') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: request.stage,
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: 'PVE-LEAD',
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'No remarks provided'
      }));

      await db.run(UPDATE(Request).set({
        status: 'Rejected',
        stage: 'Initiator',
        pendingWith: form.initiatorEmail || currentEmail,
        pendingWithName: currentUser
      }).where({ reqID }));

      // const emailBodyResubmission = generateInitiatorResubmissionEmail(form, remarks);

      try {
        await sendMail({
          subject: `CAP Notification: ${capNumber} - Request Rejected`,
          // body: emailBodyResubmission,
          to: form.initiatorEmail || currentEmail,
          cc: 'suraj.mishra@sumodigitech.com'
        });
      } catch (error) {
        console.error(`Failed to send resubmission email for ${capNumber}: ${error.message}`);
      }
      return { error: false, message: `Request ${reqID} rejected by PVE-LEAD.` };
    }

    if (action === 'Approve') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: request.stage,
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: 'PVE-LEAD',
        completionDt: null,
        timestamp: new Date().toISOString(),
        remarks: remarks || 'No remarks provided'
      }).where({ reqID, stage: request.stage }));

      const pveHeadApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'PVE-HEAD' }));
      if (!pveHeadApprover) {
        return { error: true, message: 'PVE-Head not found in Approvers master.' };
      }

      await db.run(INSERT.into(ProcessLog).entries({
        reqID,
        stage: 'PVE-HEAD',
        userName: pveHeadApprover.name,
        userEmail: pveHeadApprover.email,
        status: 'Pending',
        role: 'PVE-HEAD',
        receivedDt: new Date(),
        completionDt: null,
        timestamp: new Date().toISOString(),
        remarks: 'Assigned to PVE-HEAD'
      }));

      await db.run(UPDATE(Request).set({
        status: 'Pending',
        stage: 'PVE-HEAD',
        pendingWith: pveHeadApprover.email,
        pendingWithName: pveHeadApprover.name
      }).where({ reqID }));
      
    const attachments = await db.run(SELECT.from(ReqAttachment).where({ reqID }));
    const logs = await db.run(SELECT.from(ProcessLog).where({ reqID }));

      const emailBodyPVELNotification = generatePVELeadApprovalEmail(form, attachments, logs);
      const emailBodyPVEHeadTask = generatePVEHeadTaskEmail(form, logs);

      try {
        await sendMail({
          subject: `CAP Notification: ${capNumber} - After PVE-Lead approval`,
          body: emailBodyPVELNotification,
          to: currentEmail,
          cc: 'suraj.mishra@sumodigitech.com'
        });
      } catch (error) {
        console.error(`Failed to send PVE-Lead notification email for ${capNumber}: ${error.message}`);
      }

      try {
        await sendMail({
          subject: `CAP Notification: ${capNumber} - Assigned to PVE-Head for approval`,
          body: emailBodyPVEHeadTask,
          to: pveHeadApprover.email,
          cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
        });
      } catch (error) {
        console.error(`Failed to send PVE-Head task email for ${capNumber}: ${error.message}`);
      }

      return { error: false, message: `Request ${reqID} approved by PVE-LEAD. Forwarded to PVE-HEAD.` };
    }
  }

  if (request.stage === 'PVE-HEAD') {
    if (currentUserRole !== 'PVE-HEAD') {
      return { error: true, message: 'Only PVE-HEAD can approve or reject at this stage' };
    }
    if (action === 'Reject' && !remarks) {
      return { error: true, message: 'Remarks are mandatory for rejection.' };
    }

    if (action === 'Reject') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: request.stage,
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: 'PVE-HEAD',
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'No remarks provided'
      }));

      await db.run(UPDATE(Request).set({
        status: 'Rejected',
        stage: 'Initiator',
        pendingWith: form.initiatorEmail || currentEmail,
        pendingWithName: currentUser
      }).where({ reqID }));

      // const emailBodyResubmission = generateInitiatorResubmissionEmail(form, remarks);

      try {
        await sendMail({
          subject: `CAP Notification: ${capNumber} - Request Rejected`,
          // body: emailBodyResubmission,
          to: form.initiatorEmail || currentEmail,
          cc: 'suraj.mishra@sumodigitech.com'
        });
      } catch (error) {
        console.error(`Failed to send resubmission email for ${capNumber}: ${error.message}`);
      }
      return { error: false, message: `Request ${reqID} rejected by PVE-HEAD.` };
    }

    if (action === 'Approve') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: request.stage,
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: 'PVE-HEAD',
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'No remarks provided'
      }));

      const impact = form.annualImpact || 0;

      const attachments = await db.run(SELECT.from(ReqAttachment).where({ reqID }));
      const logs = await db.run(SELECT.from(ProcessLog).where({ reqID }));
  
      const emailBodyPVEHeadNotification = generatePVEHeadNotificationEmail(form, attachments, logs);
  
      try {
        await sendMail({
          subject: `CAP Notification: ${capNumber} - After PVE-Head Approval`,
          body: emailBodyPVEHeadNotification,
          to: currentEmail,
          cc: 'suraj.mishra@sumodigitech.com'
        });
      } catch (error) {
        console.error(`Failed to send PVE-Head notification email for ${capNumber}: ${error.message}`);
      }

      if (form.fieldQuality === 'Field Quality' || ['Statutory', 'Product Engineering', 'P24'].includes(form.fieldQuality)) {
        if (impact <= 10) {
          const cdmmPulApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'CDMM-PUL' }));
          if (!cdmmPulApprover) {
            return { error: true, message: 'CDMM-PUL not found in Approvers master.' };
          }

          await db.run(INSERT.into(ProcessLog).entries({
            reqID,
            stage: 'CDMM-PUL',
            userName: cdmmPulApprover.name,
            userEmail: cdmmPulApprover.email,
            status: 'Pending',
            role: 'CDMM-PUL',
            completionDt: null,
            timestamp: new Date().toISOString(),
            remarks: 'Assigned to CDMM-PUL'
          }));

          await db.run(UPDATE(Request).set({
            status: 'Pending',
            stage: 'CDMM-PUL',
            pendingWith: cdmmPulApprover.email,
            pendingWithName: cdmmPulApprover.name
          }).where({ reqID }));

          try {
            await sendMail({
              subject: `CAP Notification: ${capNumber} - After PVE-Head approval, Assigned to CDMM-PUL`,
              to: cdmmPulApprover.email,
              cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
            });
          } catch (error) {
            console.error(`Failed to send CDMM-PUL task email for ${capNumber}: ${error.message}`);
          }

          return { error: false, message: `Request ${reqID} approved by PVE-HEAD. Forwarded to CDMM-PUL.` };
        } else if (impact > 10 && impact <= 50) {
          const cdmmHeadApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'CDMM-HEAD' }));
          const fdpdHeadApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'FDPD-HEAD' }));
          if (!cdmmHeadApprover || !fdpdHeadApprover) {
            return { error: true, message: 'CDMM-HEAD or FDPD-HEAD not found in Approvers master.' };
          }

          await db.run(INSERT.into(ProcessLog).entries([
            {
              reqID,
              stage: 'CDMM-FDPD HEAD',
              userName: cdmmHeadApprover.name,
              userEmail: cdmmHeadApprover.email,
              status: 'Pending',
              role: 'CDMM-HEAD',
              completionDt: null,
              timestamp: new Date().toISOString(),
              remarks: 'Assigned to CDMM-HEAD'
            },
            {
              reqID,
              stage: 'CDMM-FDPD HEAD',
              userName: fdpdHeadApprover.name,
              userEmail: fdpdHeadApprover.email,
              status: 'Pending',
              role: 'FDPD-HEAD',
              completionDt: null,
              timestamp: new Date().toISOString(),
              remarks: 'Assigned to FDPD-HEAD'
            }
          ]));

          await db.run(UPDATE(Request).set({
            status: 'Pending',
            stage: 'CDMM-FDPD HEAD',
            pendingWith: [cdmmHeadApprover.email, fdpdHeadApprover.email].join(','),
            pendingWithName: 'CDMM-HEAD & FDPD-HEAD'
          }).where({ reqID }));

          const emailBodyCDMMHead = generateCDMMHeadTaskEmail(form);
          const emailBodyFDPDHead = generateFDPDHeadTaskEmail(form);

          try {
            await sendMail({
              subject: `Cost Approval Process - ${capNumber} - PTD CDMM HEAD Approval`,
              body: emailBodyCDMMHead,
              to: cdmmHeadApprover.email,
              cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
            });
            
            await sendMail({
              subject: `Cost Approval Process - ${capNumber} - FD PD HEAD Approval`,
              body: emailBodyFDPDHead,
              to: fdpdHeadApprover.email,
              cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
            });
          } catch (error) {
            console.error(`Failed to send CDMM-FDPD HEAD task email for ${capNumber}: ${error.message}`);
          }

          return { error: false, message: `Request ${reqID} approved by PVE-HEAD. Forwarded to CDMM-HEAD & FDPD-HEAD for dual approval.` };
        } else if (impact > 50) {
          const cdmmHeadApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'CDMM-HEAD' }));
          const fdpdHeadApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'FDPD-HEAD' }));
          if (!cdmmHeadApprover || !fdpdHeadApprover) {
            return { error: true, message: 'CDMM-HEAD or FDPD-HEAD not found in Approvers master.' };
          }

          await db.run(INSERT.into(ProcessLog).entries([
            {
              reqID,
              stage: 'CDMM-FDPD HEAD',
              userName: cdmmHeadApprover.name,
              userEmail: cdmmHeadApprover.email,
              status: 'Pending',
              role: 'CDMM-HEAD',
              completionDt: null,
              timestamp: new Date().toISOString(),
              remarks: 'Assigned to CDMM-HEAD'
            },
            {
              reqID,
              stage: 'CDMM-FDPD HEAD',
              userName: fdpdHeadApprover.name,
              userEmail: fdpdHeadApprover.email,
              status: 'Pending',
              role: 'FDPD-HEAD',
              completionDt: null,
              timestamp: new Date().toISOString(),
              remarks: 'Assigned to FDPD-HEAD'
            }
          ]));

          await db.run(UPDATE(Request).set({
            status: 'Pending',
            stage: 'CDMM-FDPD HEAD',
            pendingWith: [cdmmHeadApprover.email, fdpdHeadApprover.email].join(','),
            pendingWithName: 'CDMM-HEAD & FDPD-HEAD'
          }).where({ reqID }));

          
             const emailBodyCDMMHead = generateCDMMHeadTaskEmail(form);
          const emailBodyFDPDHead = generateFDPDHeadTaskEmail(form);

          try {
            await sendMail({
              subject: `Cost Approval Process - ${capNumber} - PTD CDMM HEAD Approval`,
              body: emailBodyCDMMHead,
              to: cdmmHeadApprover.email,
              cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
            });
            
            await sendMail({
              subject: `Cost Approval Process - ${capNumber} - FD PD HEAD Approval`,
              body: emailBodyFDPDHead,
              to: fdpdHeadApprover.email,
              cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
            });
          } catch (error) {
            console.error(`Failed to send CDMM-FDPD HEAD task email for ${capNumber}: ${error.message}`);
          }

          return { error: false, message: `Request ${reqID} approved by PVE-HEAD. Forwarded to CDMM-HEAD & FDPD-HEAD for dual approval.` };
        }
      }
    }
  }

  if (request.stage === 'CDMM-PUL') {
    if (currentUserRole !== 'CDMM-PUL') {
      return { error: true, message: 'Only CDMM-PUL can approve or reject at this stage' };
    }
    if (action === 'Reject' && !remarks) {
      return { error: true, message: 'Remarks are mandatory for rejection.' };
    }

    if (action === 'Reject') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: request.stage,
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: 'CDMM-PUL',
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'No remarks provided'
      }));

      await db.run(UPDATE(Request).set({
        status: 'Rejected',
        stage: 'Initiator',
        pendingWith: form.initiatorEmail || currentEmail,
        pendingWithName: currentUser
      }).where({ reqID }));

      try {
        await sendMail({
          subject: `CAP Notification: ${capNumber} - Request Rejected`,
          to: form.initiatorEmail || currentEmail,
          cc: 'suraj.mishra@sumodigitech.com'
        });
      } catch (error) {
        console.error(`Failed to send resubmission email for ${capNumber}: ${error.message}`);
      }
      return { error: false, message: `Request ${reqID} rejected by CDMM-PUL.` };
    }

    if (action === 'Approve') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: request.stage,
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: 'CDMM-PUL',
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'Approved'
      }));

      if (form.fieldQuality === 'Field Quality') {
        const customerCarePulApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'Customer Care-PUL' }));
        const qaPulApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'QA-PUL' }));
        if (!customerCarePulApprover || !qaPulApprover) {
          return { error: true, message: 'Customer Care-PUL or QA-PUL not found in Approvers master.' };
        }

        await db.run(INSERT.into(ProcessLog).entries([
          {
            reqID,
            stage: 'Customer Care & QA-PUL',
            userName: customerCarePulApprover.name,
            userEmail: customerCarePulApprover.email,
            status: 'Pending',
            role: 'Customer Care-PUL',
            completionDt: null,
            timestamp: new Date().toISOString(),
            remarks: 'Assigned to Customer Care-PUL'
          },
          {
            reqID,
            stage: 'Customer Care & QA-PUL',
            userName: qaPulApprover.name,
            userEmail: qaPulApprover.email,
            status: 'Pending',
            role: 'QA-PUL',
            completionDt: null,
            timestamp: new Date().toISOString(),
            remarks: 'Assigned to QA-PUL'
          }
        ]));

        await db.run(UPDATE(Request).set({
          status: 'Pending',
          stage: 'Customer Care & QA-PUL',
          pendingWith: [customerCarePulApprover.email, qaPulApprover.email].join(','),
          pendingWithName: 'Customer Care-PUL & QA-PUL (Dual Approval)'
        }).where({ reqID }));

        try {
          await sendMail({
            subject: `CAP Notification: ${capNumber} - After CDMM-PUL approval, Assigned to Customer Care-PUL & QA-PUL`,
            to: [customerCarePulApprover.email, qaPulApprover.email].join(','),
            cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
          });
        } catch (error) {
          console.error(`Failed to send Customer Care & QA-PUL task email for ${capNumber}: ${error.message}`);
        }

        return { error: false, message: `Request ${reqID} approved by CDMM-PUL. Forwarded to Customer Care-PUL & QA-PUL for dual approval.` };
      } else if (['Statutory', 'Product Engineering', 'P24'].includes(form.fieldQuality)) {
        const financePulApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'FINANCE & ACCOUNTS-PUL' }));
        if (!financePulApprover) {
          return { error: true, message: 'FINANCE & ACCOUNTS-PUL not found in Approvers master.' };
        }

        await db.run(INSERT.into(ProcessLog).entries({
          reqID,
          stage: 'FINANCE & ACCOUNTS-PUL',
          userName: financePulApprover.name,
          userEmail: financePulApprover.email,
          status: 'Pending',
          role: 'FINANCE & ACCOUNTS-PUL',
          completionDt: null,
          timestamp: new Date().toISOString(),
          remarks: 'Assigned to FINANCE & ACCOUNTS-PUL'
        }));

        await db.run(UPDATE(Request).set({
          status: 'Pending',
          stage: 'FINANCE & ACCOUNTS-PUL',
          pendingWith: financePulApprover.email,
          pendingWithName: financePulApprover.name
        }).where({ reqID }));

        try {
          await sendMail({
            subject: `CAP Notification: ${capNumber} - After CDMM-PUL approval, Assigned to FINANCE & ACCOUNTS-PUL`,
            to: financePulApprover.email,
            cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
          });
        } catch (error) {
          console.error(`Failed to send FINANCE & ACCOUNTS-PUL task email for ${capNumber}: ${error.message}`);
        }

        return { error: false, message: `Request ${reqID} approved by CDMM-PUL. Forwarded to FINANCE & ACCOUNTS-PUL.` };
      }
    }
  }


  if (request.stage === 'Customer Care & QA-PUL') {
    const validRoles = ['Customer Care-PUL', 'QA-PUL'];
    if (!validRoles.includes(currentUserRole)) {
      return { error: true, message: 'Only Customer Care-PUL or QA-PUL can approve or reject at this stage.' };
    }
  
    // Fetch and deduplicate logs for the current stage
    let logs = await db.run(SELECT.from(ProcessLog).where({ reqID, stage: 'Customer Care & QA-PUL' }));
    logs = Object.values(
      logs.reduce((acc, log) => {
        const key = `${log.userEmail}_${log.role}`;
        if (!acc[key] || new Date(log.timestamp) > new Date(acc[key].timestamp)) {
          acc[key] = log;
        }
        return acc;
      }, {})
    );
  
    // Check if there is an existing approval
    const hasApproval = logs.some(log => 
      validRoles.includes(log.role) && log.status === 'Approve'
    );
  
    // Validate rejection action
    if (action === 'Reject' && !remarks) {
      return { error: true, message: 'Remarks are mandatory for rejection.' };
    }
  
    // Handle rejection
    if (action === 'Reject') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: 'Customer Care & QA-PUL',
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: currentUserRole,
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'No remarks provided'
      }).where({ reqID, userEmail: currentEmail }));
  
      await db.run(UPDATE(Request).set({
        status: 'Rejected',
        stage: 'Initiator',
        pendingWith: form.initiatorEmail || currentEmail,
        pendingWithName: currentUser
      }).where({ reqID }));
  
      try {
        await sendMail({
          subject: `CAP Notification: ${capNumber} - Request Rejected`,
          to: form.initiatorEmail || currentEmail,
          cc: 'suraj.mishra@sumodigitech.com'
        });
      } catch (error) {
        console.error(`Failed to send resubmission email for ${capNumber}: ${error.message}`);
      }
  
      return { error: false, message: `Request ${reqID} rejected by ${currentUserRole}.` };
    }
  
    // Handle approval
    if (action === 'Approve') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: 'Customer Care & QA-PUL',
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: currentUserRole,
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'Approved'
      }).where({ reqID, userEmail: currentEmail }));
  
      if (!hasApproval) {
        // First approval, determine next role
        const nextRole = currentUserRole === 'Customer Care-PUL' ? 'QA-PUL' : 'Customer Care-PUL';
        const nextApprover = await db.run(SELECT.one.from(Approvers).where({ role: nextRole }));
        if (!nextApprover) {
          return { error: true, message: `${nextRole} not found in Approvers master.` };
        }
  
        await db.run(
          INSERT.into(ProcessLog).entries({
            reqID,
            stage: 'Customer Care & QA-PUL',
            userName: nextApprover.name,
            userEmail: nextApprover.email,
            status: 'Pending',
            role: nextRole,
            completionDt: null,
            timestamp: new Date().toISOString(),
            remarks: `Assigned to ${nextRole}`
          })
        );
  
        await db.run(UPDATE(Request).set({
          status: 'Pending',
          stage: 'Customer Care & QA-PUL',
          pendingWith: nextApprover.email,
          pendingWithName: nextRole
        }).where({ reqID }));
  
        try {
          await sendMail({
            subject: `CAP Notification: ${capNumber} - ${currentUserRole} Approved, Awaiting ${nextRole}`,
            to: nextApprover.email,
            cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
          });
        } catch (error) {
          console.error(`Failed to send ${nextRole} task email for ${capNumber}: ${error.message}`);
        }
  
        return { error: false, message: `Request ${reqID} approved by ${currentUserRole}. Awaiting approval from ${nextRole}. Remarks: ${remarks}` };
      } else {
        // Both approvals completed, move to next stage
        const nextStage = 'FINANCE & ACCOUNTS-PUL';
        const financePulApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'FINANCE & ACCOUNTS-PUL' }));
        if (!financePulApprover) {
          return { error: true, message: 'FINANCE & ACCOUNTS-PUL not found in Approvers master.' };
        }
  
        await db.run(INSERT.into(ProcessLog).entries({
          reqID,
          stage: nextStage,
          userName: financePulApprover.name,
          userEmail: financePulApprover.email,
          status: 'Pending',
          role: 'FINANCE & ACCOUNTS-PUL',
          completionDt: null,
          timestamp: new Date().toISOString(),
          remarks: `Assigned to ${nextStage}`
        }));
  
        await db.run(UPDATE(Request).set({
          status: 'Pending',
          stage: nextStage,
          pendingWith: financePulApprover.email,
          pendingWithName: financePulApprover.name
        }).where({ reqID }));
  
        try {
          await sendMail({
            subject: `CAP Notification: ${capNumber} - Customer Care-PUL & QA-PUL Dual Approval Completed`,
            to: [form.initiatorEmail, currentEmail].join(','),
            cc: 'suraj.mishra@sumodigitech.com'
          });
          await sendMail({
            subject: `CAP Notification: ${capNumber} - Assigned to ${nextStage}`,
            to: financePulApprover.email,
            cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
          });
        } catch (error) {
          console.error(`Failed to send notification email for ${capNumber}: ${error.message}`);
        }
  
        return { error: false, message: `Request ${reqID} approved by both Customer Care-PUL and QA-PUL. Forwarded to ${nextStage}. Remarks: ${remarks}` };
      }
    }
  }


  if (request.stage === 'CDMM-FDPD HEAD') {
    if (currentUserRole !== 'CDMM-HEAD' && currentUserRole !== 'FDPD-HEAD') {
      return { error: true, message: 'Only CDMM-HEAD or FDPD-HEAD can approve or reject at this stage' };
    }
    let logs = await db.run(SELECT.from(ProcessLog).where({ reqID, stage: 'CDMM-FDPD HEAD' }));
    logs = Object.values(
      logs.reduce((acc, log) => {
        const key = `${log.userEmail}_${log.role}`;
        if (!acc[key] || new Date(log.timestamp) > new Date(acc[key].timestamp)) {
          acc[key] = log;
        }
        return acc;
      }, {})
    );

    
  
    const hasApproval = logs.some(log => 
      (log.role === 'CDMM-HEAD' || log.role === 'FDPD-HEAD') && 
      log.status === 'Approve'
    );
  
    if (action === 'Reject' && !remarks) {
      return { error: true, message: 'Remarks are mandatory for rejection.' };
    }
  
    if (action === 'Reject') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: 'CDMM-FDPD HEAD',
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: currentUserRole,
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'No remarks provided'
      }).where({ reqID, userEmail: currentEmail }));
  
      await db.run(UPDATE(Request).set({
        status: 'Rejected',
        stage: 'Initiator',
        pendingWith: form.initiatorEmail || currentEmail,
        pendingWithName: currentUser
      }).where({ reqID }));
  
      try {
        await sendMail({
          subject: `CAP Notification: ${capNumber} - Request Rejected`,
          to: form.initiatorEmail || currentEmail,
          cc: 'suraj.mishra@sumodigitech.com'
        });
      } catch (error) {
        console.error(`Failed to send resubmission email for ${capNumber}: ${error.message}`);
      }
      return { error: false, message: `Request ${reqID} rejected by ${currentUserRole}.` };
    }
  
    if (action === 'Approve') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: 'CDMM-FDPD HEAD',
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: currentUserRole,
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'Approved'
      }).where({ reqID, userEmail: currentEmail }));
  
      if (!hasApproval) {
        const nextRole = currentUserRole === 'CDMM-HEAD' ? 'FDPD-HEAD' : 'CDMM-HEAD';
        const nextApprover = await db.run(SELECT.one.from(Approvers).where({ role: nextRole }));
        if (!nextApprover) {
          return { error: true, message: `${nextRole} not found in Approvers master.` };
        }

        await db.run(
          INSERT.into(ProcessLog).entries({
            reqID,
            stage: 'CDMM-FDPD HEAD',
            userName: nextApprover.name,
            userEmail: nextApprover.email,
            status: 'Pending',
            role: nextRole,
            completionDt: null,
            timestamp: new Date().toISOString(),
            remarks: `Assigned to ${nextRole}`
          })
        );
  
        await db.run(UPDATE(Request).set({
          status: 'Pending',
          stage: 'CDMM-FDPD HEAD',
          pendingWith: nextApprover.email,
          pendingWithName: nextRole
        }).where({ reqID }));
  
        try {
          await sendMail({
            subject: `CAP Notification: ${capNumber} - ${currentUserRole} Approved, Awaiting ${nextRole}`,
            to: nextApprover.email,
            cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
          });
        } catch (error) {
          console.error(`Failed to send ${nextRole} task email for ${capNumber}: ${error.message}`);
        }
  
        return { error: false, message: `Request ${reqID} approved by ${currentUserRole}. Awaiting approval from ${nextRole}.` };
      } else {
        const impact = form.annualImpact || 0;
        if (form.fieldQuality === 'Field Quality') {
          const fdqaHeadApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'FDQA-HEAD' }));
          const customerCareHeadApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'Customer Care-HEAD' }));
          if (!fdqaHeadApprover || !customerCareHeadApprover) {
            return { error: true, message: 'FDQA-HEAD or Customer Care-HEAD not found in Approvers master.' };
          }
  
          await db.run(INSERT.into(ProcessLog).entries([
            {
              reqID,
              stage: 'FDQA & Customer Care-HEAD',
              userName: fdqaHeadApprover.name,
              userEmail: fdqaHeadApprover.email,
              status: 'Pending',
              role: 'FDQA-HEAD',
              completionDt: null,
              timestamp: new Date().toISOString(),
              remarks: 'Assigned to FDQA-HEAD'
            },
            {
              reqID,
              stage: 'FDQA & Customer Care-HEAD',
              userName: customerCareHeadApprover.name,
              userEmail: customerCareHeadApprover.email,
              status: 'Pending',
              role: 'Customer Care-HEAD',
              completionDt: null,
              timestamp: new Date().toISOString(),
              remarks: 'Assigned to Customer Care-HEAD'
            }
          ]));
  
          await db.run(UPDATE(Request).set({
            status: 'Pending',
            stage: 'FDQA & Customer Care-HEAD',
            pendingWith: [fdqaHeadApprover.email].join(','),
            pendingWithName: 'FDQA-HEAD & Customer Care-HEAD (Dual Approval)'
          }).where({ reqID }));

          const emailBodyFDQA = generateFDQAHeadTaskEmail(form);
          const emailBodyCustomerCare =  generateCustomerCareHeadTaskEmail(form)
  
          try {
            await sendMail({
              subject: `Cost Approval Process: ${capNumber} - FD QA -Head Approval`,
              body: emailBodyFDQA,
              to: [form.email].join(','),
              cc: 'suraj.mishra@sumodigitech.com'
            });
            await sendMail({
              subject: `Cost Approval Process: ${capNumber} - Head Customer Care Approval`,
              body: emailBodyCustomerCare,
              to: [customerCareHeadApprover.email].join(','),
              cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
            });
          } catch (error) {
            console.error(`Failed to send notification email for ${capNumber}: ${error.message}`);
          }
  
          return { error: false, message: `Request ${reqID} approved by both CDMM-HEAD and FDPD-HEAD. Forwarded to FDQA-HEAD & Customer Care-HEAD for dual approval.` };
        } else if (['Statutory', 'Product Engineering','P24'].includes(form.fieldQuality)) {
          const financePulApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'FINANCE & ACCOUNTS-PUL' }));
          if (!financePulApprover) {
            return { error: true, message: 'FINANCE & ACCOUNTS-PUL not found in Approvers master.' };
          }
  
          await db.run(INSERT.into(ProcessLog).entries({
            reqID,
            stage: 'FINANCE & ACCOUNTS-PUL',
            userName: financePulApprover.name,
            userEmail: financePulApprover.email,
            status: 'Pending',
            role: 'FINANCE & ACCOUNTS-PUL',
            completionDt: null,
            timestamp: new Date().toISOString(),
            remarks: 'Assigned to FINANCE & ACCOUNTS-PUL'
          }));
  
          await db.run(UPDATE(Request).set({
            status: 'Pending',
            stage: 'FINANCE & ACCOUNTS-PUL',
            pendingWith: financePulApprover.email,
            pendingWithName: financePulApprover.name
          }).where({ reqID }));
  
          try {
            await sendMail({
              subject: `CAP Notification: ${capNumber} - CDMM-HEAD & FDPD-HEAD Dual Approval Completed`,
              to: [form.initiatorEmail, currentEmail].join(','),
              cc: 'suraj.mishra@sumodigitech.com'
            });
            await sendMail({
              subject: `CAP Notification: ${capNumber} - Assigned to FINANCE & ACCOUNTS-PUL`,
              to: financePulApprover.email,
              cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
            });
          } catch (error) {
            console.error(`Failed to send notification email for ${capNumber}: ${error.message}`);
          }
  
          return { error: false, message: `Request ${reqID} approved by both CDMM-HEAD and FDPD-HEAD. Forwarded to FINANCE & ACCOUNTS-PUL.` };
        }
      }
    }
  }

  if (request.stage === 'FDQA & Customer Care-HEAD') {
    if (currentUserRole !== 'FDQA-HEAD' && currentUserRole !== 'Customer Care-HEAD') {
      return { error: true, message: 'Only FDQA-HEAD or Customer Care-HEAD can approve or reject at this stage' };
    }
  
    let logs = await db.run(SELECT.from(ProcessLog).where({ reqID, stage: 'FDQA & Customer Care-HEAD' }));
    logs = Object.values(
      logs.reduce((acc, log) => {
        const key = `${log.userEmail}_${log.role}`;
        if (!acc[key] || new Date(log.timestamp) > new Date(acc[key].timestamp)) {
          acc[key] = log;
        }
        return acc;
      }, {})
    );
  
    const hasApproval = logs.some(log => 
      (log.role === 'FDQA-HEAD' || log.role === 'Customer Care-HEAD') && 
      log.status === 'Approve'
    );
  
    if (action === 'Reject' && !remarks) {
      return { error: true, message: 'Remarks are mandatory for rejection.' };
    }
  
    if (action === 'Reject') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: 'FDQA & Customer Care-HEAD',
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: currentUserRole,
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'No remarks provided'
      }).where({ reqID, userEmail: currentEmail }));
  
      await db.run(UPDATE(Request).set({
        status: 'Rejected',
        stage: 'Initiator',
        pendingWith: form.initiatorEmail || currentEmail,
        pendingWithName: currentUser
      }).where({ reqID }));
  
      try {
        await sendMail({
          subject: `CAP Notification: ${capNumber} - Request Rejected`,
          to: form.initiatorEmail || currentEmail,
          cc: 'suraj.mishra@sumodigitech.com'
        });
      } catch (error) {
        console.error(`Failed to send resubmission email for ${capNumber}: ${error.message}`);
      }
      return { error: false, message: `Request ${reqID} rejected by ${currentUserRole}.` };
    }
  
    if (action === 'Approve') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: 'FDQA & Customer Care-HEAD',
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: currentUserRole,
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'Approved'
      }).where({ reqID, userEmail: currentEmail }));
  
      if (!hasApproval) {
        const nextRole = currentUserRole === 'FDQA-HEAD' ? 'Customer Care-HEAD' : 'FDQA-HEAD';
        const nextApprover = await db.run(SELECT.one.from(Approvers).where({ role: nextRole }));
        if (!nextApprover) {
          return { error: true, message: `${nextRole} not found in Approvers master.` };
        }
  
        // Insert a Pending ProcessLog entry for the next approver
        await db.run(
          INSERT.into(ProcessLog).entries({
            reqID,
            stage: 'FDQA & Customer Care-HEAD',
            userName: nextApprover.name,
            userEmail: nextApprover.email,
            status: 'Pending',
            role: nextRole,
            completionDt: null,
            timestamp: new Date().toISOString(),
            remarks: `Assigned to ${nextRole}`
          })
        );
  
        await db.run(UPDATE(Request).set({
          status: 'Pending',
          stage: 'FDQA & Customer Care-HEAD',
          pendingWith: nextApprover.email,
          pendingWithName: nextRole
        }).where({ reqID }));
  
        try {
          await sendMail({
            subject: `CAP Notification: ${capNumber} - ${currentUserRole} Approved, Awaiting ${nextRole}`,
            to: nextApprover.email,
            cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
          });
        } catch (error) {
          console.error(`Failed to send ${nextRole} task email for ${capNumber}: ${error.message}`);
        }
  
        return { error: false, message: `Request ${reqID} approved by ${currentUserRole}. Awaiting approval from ${nextRole}.` };
      } else {
        const impact = form.annualImpact || 0;
        if (impact > 10 && impact <= 50) {
          const financePulApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'FINANCE & ACCOUNTS-PUL' }));
          if (!financePulApprover) {
            return { error: true, message: 'FINANCE & ACCOUNTS-PUL not found in Approvers master.' };
          }
  
          await db.run(INSERT.into(ProcessLog).entries({
            reqID,
            stage: 'FINANCE & ACCOUNTS-PUL',
            userName: financePulApprover.name,
            userEmail: financePulApprover.email,
            status: 'Pending',
            role: 'FINANCE & ACCOUNTS-PUL',
            completionDt: null,
            timestamp: new Date().toISOString(),
            remarks: 'Assigned to FINANCE & ACCOUNTS-PUL'
          }));
  
          await db.run(UPDATE(Request).set({
            status: 'Pending',
            stage: 'FINANCE & ACCOUNTS-PUL',
            pendingWith: financePulApprover.email,
            pendingWithName: financePulApprover.name
          }).where({ reqID }));
  
          try {
            await sendMail({
              subject: `CAP Notification: ${capNumber} - FDQA-HEAD & Customer Care-HEAD Dual Approval Completed`,
              to: [form.initiatorEmail, currentEmail].join(','),
              cc: 'suraj.mishra@sumodigitech.com'
            });
            await sendMail({
              subject: `CAP Notification: ${capNumber} - Assigned to FINANCE & ACCOUNTS-PUL`,
              to: financePulApprover.email,
              cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
            });
          } catch (error) {
            console.error(`Failed to send notification email for ${capNumber}: ${error.message}`);
          }
  
          return { error: false, message: `Request ${reqID} approved by both FDQA-HEAD and Customer Care-HEAD. Forwarded to FINANCE & ACCOUNTS-PUL.` };
        } else if (impact > 50) {
          const mfgHeadApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'MFG-HEAD' }));
          if (!mfgHeadApprover) {
            return { error: true, message: 'MFG-HEAD not found in Approvers master.' };
          }
  
          await db.run(INSERT.into(ProcessLog).entries({
            reqID,
            stage: 'MFG-HEAD',
            userName: mfgHeadApprover.name,
            userEmail: mfgHeadApprover.email,
            status: 'Pending',
            role: 'MFG-HEAD',
            completionDt: null,
            timestamp: new Date().toISOString(),
            remarks: 'Assigned to MFG-HEAD'
          }));
  
          await db.run(UPDATE(Request).set({
            status: 'Pending',
            stage: 'MFG-HEAD',
            pendingWith: mfgHeadApprover.email,
            pendingWithName: mfgHeadApprover.name
          }).where({ reqID }));

          const emailMFG = generateMFGHeadTaskEmail(form);
  
          try {
            await sendMail({
              subject: `Cost Approval Process: ${capNumber} - Finance & Account PUL for Approval`,
              body: emailMFG,
              to: [form.initiatorEmail, currentEmail].join(','),
              cc: 'suraj.mishra@sumodigitech.com'
            });
            await sendMail({
              subject: `CAP Notification: ${capNumber} - Assigned to MFG-HEAD`,
              to: mfgHeadApprover.email,
              cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
            });
          } catch (error) {
            console.error(`Failed to send notification email for ${capNumber}: ${error.message}`);
          }
  
          return { error: false, message: `Request ${reqID} approved by both FDQA-HEAD and Customer Care-HEAD. Forwarded to MFG-HEAD.` };
        }
      }
    }
  }


  if (request.stage === 'MFG-HEAD') {
    // if (currentUserRole !== 'MFG-HEAD') {
    //   return { error: true, message: 'Only MFG-HEAD can approve or reject at this stage' };
    // }
    if (action === 'Reject' && !remarks) {
      return { error: true, message: 'Remarks are mandatory for rejection.' };
    }

    if (action === 'Reject') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: request.stage,
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: 'MFG-HEAD',
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'No remarks provided'
      }));

      await db.run(UPDATE(Request).set({
        status: 'Rejected',
        stage: 'Initiator',
        pendingWith: form.initiatorEmail || currentEmail,
        pendingWithName: currentUser
      }).where({ reqID }));

      try {
        await sendMail({
          subject: `CAP Notification: ${capNumber} - Request Rejected`,
          to: form.initiatorEmail || currentEmail,
          cc: 'suraj.mishra@sumodigitech.com'
        });
      } catch (error) {
        console.error(`Failed to send resubmission email for ${capNumber}: ${error.message}`);
      }
      return { error: false, message: `Request ${reqID} rejected by MFG-HEAD.` };
    }

    if (action === 'Approve') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: request.stage,
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: 'MFG-HEAD',
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'Approved'
      }));

      const financePulApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'FINANCE & ACCOUNTS-PUL' }));
      const financeHeadApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'FINANCE & ACCOUNTS-HEAD' }));
      const vpFinanceApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'VP-FINANCE & ACCOUNTS' }));
      if (!financePulApprover || !financeHeadApprover || !vpFinanceApprover) {
        return { error: true, message: 'FINANCE & ACCOUNTS-PUL, FINANCE & ACCOUNTS-HEAD, or VP-FINANCE & ACCOUNTS not found in Approvers master.' };
      }

      await db.run(INSERT.into(ProcessLog).entries([
        {
          reqID,
          stage: 'FINANCE & ACCOUNTS-PUL',
          userName: financePulApprover.name,
          userEmail: financePulApprover.email,
          status: 'Pending',
          role: 'FINANCE & ACCOUNTS-PUL',
          completionDt: null,
          timestamp: new Date().toISOString(),
          remarks: 'Assigned to FINANCE & ACCOUNTS-PUL'
        }
      ]));

      await db.run(UPDATE(Request).set({
        status: 'Pending',
        stage: 'FINANCE & ACCOUNTS-PUL',
        pendingWith: financePulApprover.email,
        pendingWithName: financePulApprover.name
      }).where({ reqID }));


      const emailBodyFinancePul = generateFinancePulTaskEmail(form)

      try {
        await sendMail({
          subject: `Cost Approval Process: ${capNumber} - Finance & Accounts-PUL for Approval`,
          body: emailBodyFinancePul,
          to: financePulApprover.email,
          cc: 'suraj.mishra@sumodigitech.com'
        });
      } catch (error) {
        console.error(`Failed to send MFG-HEAD notification email for ${capNumber}: ${error.message}`);
      }

      try {
        await sendMail({
          subject: `CAP Notification: ${capNumber} - Assigned to FINANCE & ACCOUNTS-PUL for approval`,
          to: financePulApprover.email,
          cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
        });
      } catch (error) {
        console.error(`Failed to send FINANCE & ACCOUNTS-PUL task email for ${capNumber}: ${error.message}`);
      }

      return { error: false, message: `Request ${reqID} approved by MFG-HEAD. Forwarded to FINANCE & ACCOUNTS-PUL.` };
    }
  }

  if (request.stage === 'FINANCE & ACCOUNTS-PUL') {
    if (currentUserRole !== 'FINANCE & ACCOUNTS-PUL') {
      return { error: true, message: 'Only FINANCE & ACCOUNTS-PUL can approve or reject at this stage' };
    }
    if (action === 'Reject' && !remarks) {
      return { error: true, message: 'Remarks are mandatory for rejection.' };
    }

    if (action === 'Reject') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: request.stage,
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: 'FINANCE & ACCOUNTS-PUL',
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'No remarks provided'
      }));

      await db.run(UPDATE(Request).set({
        status: 'Rejected',
        stage: 'Initiator',
        pendingWith: form.initiatorEmail || currentEmail,
        pendingWithName: currentUser
      }).where({ reqID }));

      const attachments = await db.run(SELECT.from(ReqAttachment).where({ reqID }));
      const logs = await db.run(SELECT.from(ProcessLog).where({ reqID }));
      // const emailBodyResubmission = generateInitiatorResubmissionEmail(form, remarks);

      try {
        await sendMail({
          subject: `CAP Notification: ${capNumber} - Request Rejected`,
          // body: emailBodyResubmission,
          to: form.initiatorEmail || currentEmail,
          cc: 'suraj.mishra@sumodigitech.com'
        });
      } catch (error) {
        console.error(`Failed to send resubmission email for ${capNumber}: ${error.message}`);
      }
      return { error: false, message: `Request ${reqID} rejected by FINANCE & ACCOUNTS-PUL.` };
    }

    if (action === 'Approve') {
      const impact = form.annualImpact || 0;
      console.log('Approving FINANCE & ACCOUNTS-PUL', { impact });

      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: request.stage,
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: 'FINANCE & ACCOUNTS-PUL',
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'Approved'
      }).where({ reqID, userEmail: currentEmail }));

      if (impact < 10) {
        await db.run(UPDATE(Request).set({
          status: 'Approved',
          stage: request.stage,
          pendingWith: null,
          pendingWithName: null
        }).where({ reqID }));

        try {
          await sendMail({
            subject: `CAP Notification: ${capNumber} - Request Approved`,
            to: [currentEmail, form.initiatorEmail || currentEmail].join(','),
            cc: 'suraj.mishra@sumodigitech.com'
          });
        } catch (error) {
          console.error(`Failed to send approval notification email for ${capNumber}: ${error.message}`);
        }

        return { error: false, message: `Request ${reqID} approved by FINANCE & ACCOUNTS-PUL. Workflow completed due to costImpact < 10.` };
      } else {
        const financeHeadApprover = await db.run(SELECT.one.from(Approvers).where({ role: 'FINANCE & ACCOUNTS-HEAD' }));
        if (!financeHeadApprover) {
          return { error: true, message: 'FINANCE & ACCOUNTS-HEAD not found in Approvers master.' };
        }

        await db.run(INSERT.into(ProcessLog).entries({
          reqID,
          stage: 'FINANCE & ACCOUNTS-HEAD',
          userName: financeHeadApprover.name,
          userEmail: financeHeadApprover.email,
          status: 'Pending',
          role: 'FINANCE & ACCOUNTS-HEAD',
          completionDt: null,
          timestamp: new Date().toISOString(),
          remarks: 'Assigned to FINANCE & ACCOUNTS-HEAD'
        }));

        await db.run(UPDATE(Request).set({
          status: 'Pending',
          stage: 'FINANCE & ACCOUNTS-HEAD',
          pendingWith: financeHeadApprover.email,
          pendingWithName: financeHeadApprover.name
        }).where({ reqID }));

        const emailBodygenerateFinanceHeadTaskEmail = generateFinanceHeadTaskEmail(form)

        try {
          await sendMail({
            subject: `Cost Approval Process: ${capNumber} - Finance & Account-Head For Approval`,
            body: emailBodygenerateFinanceHeadTaskEmail,
            to: currentEmail,
            cc: 'suraj.mishra@sumodigitech.com'
          });
        } catch (error) {
          console.error(`Failed to send FINANCE & ACCOUNTS-PUL notification email for ${capNumber}: ${error.message}`);
        }

        try {
          await sendMail({
            subject: `CAP Notification: ${capNumber} - Assigned to FINANCE & ACCOUNTS-HEAD for approval`,
            to: financeHeadApprover.email,
            cc: [currentEmail, 'suraj.mishra@sumodigitech.com'].join(',')
          });
        } catch (error) {
          console.error(`Failed to send FINANCE & ACCOUNTS-HEAD task email for ${capNumber}: ${error.message}`);
        }

        return { error: false, message: `Request ${reqID} approved by FINANCE & ACCOUNTS-PUL. Forwarded to FINANCE & ACCOUNTS-HEAD.` };
      }
    }
  }

  if (request.stage === 'FINANCE & ACCOUNTS-HEAD') {

    if (currentUserRole !== 'FINANCE & ACCOUNTS-HEAD') {
      return { error: true, message: 'Only FINANCE & ACCOUNTS-HEAD can approve or reject at this stage' };
    }
    if (action === 'Reject' && !remarks) {
      return { error: true, message: 'Remarks are mandatory for rejection.' };
    }

    const impact = form.annualImpact || 0;
    console.log('Approving FINANCE & ACCOUNTS-HEAD', { impact });

    if (action === 'Reject') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: request.stage,
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: 'FINANCE & ACCOUNTS-HEAD',
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'No remarks provided'
      }));

      await db.run(UPDATE(Request).set({
        status: 'Rejected',
        stage: 'Initiator',
        pendingWith: form.initiatorEmail || currentEmail,
        pendingWithName: currentUser
      }).where({ reqID }));

      const attachments = await db.run(SELECT.from(ReqAttachment).where({ reqID }));
      const logs = await db.run(SELECT.from(ProcessLog).where({ reqID }));
      // const emailBodyResubmission = generateInitiatorResubmissionEmail(form, remarks);

      try {
        await sendMail({
          subject: `CAP Notification: ${capNumber} - Request Rejected`,
          // body: emailBodyResubmission,
          to: form.initiatorEmail || currentEmail,
          cc: 'suraj.mishra@sumodigitech.com'
        });
      } catch (error) {
        console.error(`Failed to send resubmission email for ${capNumber}: ${error.message}`);
      }
      return { error: false, message: `Request ${reqID} rejected by FINANCE & ACCOUNTS-HEAD.` };
    }

    if (action === 'Approve') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: request.stage,
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: 'FINANCE & ACCOUNTS-HEAD',
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'Approved'
      }));

      let nextStage = '';
      let nextApproverRole = '';
      let nextApproverEmail = null;
      let nextApproverName = null;

      if (impact > 50) {
        nextStage = 'VP-FINANCE & ACCOUNTS';
        nextApproverRole = 'VP-FINANCE & ACCOUNTS';
      } else {
        nextStage = 'Completed';
        nextApproverRole = null;
      }

      if (nextStage !== 'Completed') {
        const nextApprover = await db.run(SELECT.one.from(Approvers).where({ role: nextApproverRole }));
        if (!nextApprover) {
          return { error: true, message: `${nextApproverRole} not found in Approvers master.` };
        }
        nextApproverEmail = nextApprover.email;
        nextApproverName = nextApprover.name;

        await db.run(INSERT.into(ProcessLog).entries({
          reqID,
          stage: nextStage,
          userName: nextApproverName,
          userEmail: nextApproverEmail,
          status: 'Pending',
          role: nextApproverRole,
          completionDt: null,
          timestamp: new Date().toISOString(),
          remarks: `Assigned to ${nextApproverRole}`
        }));

        await db.run(UPDATE(Request).set({
          status: 'Pending',
          stage: nextStage,
          pendingWith: nextApproverEmail,
          pendingWithName: nextApproverName
        }).where({ reqID }));

        const emailBodygenerateVPFinanceTaskEmail =  generateVPFinanceTaskEmail(form)


        try {
          await sendMail({
            subject: `Cost Approval Process: ${capNumber} - VP - Finance and Accounts For Approval`,
            body: emailBodygenerateVPFinanceTaskEmail,
            to: nextApproverEmail,
            cc: ['suraj.mishra@sumodigitech.com', currentEmail].join(',')
          });
        } catch (error) {
          console.error(`Failed to send approval notification email for ${capNumber}: ${error.message}`);
        }
        return { error: false, message: `Request ${reqID} approved by FINANCE & ACCOUNTS-HEAD, moving to ${nextStage}.` };
      } else {
        await db.run(UPDATE(Request).set({
          status: 'Approved',
          stage: nextStage,
          pendingWith: null,
          pendingWithName: null
        }).where({ reqID }));


        try {
          await sendMail({
            subject: `Cost Approval Process: ${capNumber} - VP - Finance and Accounts For Approval`,
            body: emailBodygenerateVPFinanceTaskEmail,
            to: form.initiatorEmail || currentEmail,
            cc: ['suraj.mishra@sumodigitech.com', currentEmail].join(',')
          });
        } catch (error) {
          console.error(`Failed to send approval notification email for ${capNumber}: ${error.message}`);
        }

        return { error: false, message: `Request ${reqID} approved by FINANCE & ACCOUNTS-HEAD. Process completed.` };
      }
    }
  }

  if (request.stage === 'VP-FINANCE & ACCOUNTS') {
    if (currentUserRole !== 'VP-FINANCE & ACCOUNTS') {
      return { error: true, message: 'Only VP-FINANCE & ACCOUNTS can approve or reject at this stage' };
    }
    if (action === 'Reject' && !remarks) {
      return { error: true, message: 'Remarks are mandatory for rejection.' };
    }

    if (action === 'Reject') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: request.stage,
        userName: currentUser,
        userEmail: currentEmail,
        status: action,
        role: 'VP-FINANCE & ACCOUNTS',
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'No remarks provided'
      }));

      await db.run(UPDATE(Request).set({
        status: 'Rejected',
        stage: 'Initiator',
        pendingWith: form.initiatorEmail || currentEmail,
        pendingWithName: currentUser
      }).where({ reqID }));

      const attachments = await db.run(SELECT.from(ReqAttachment).where({ reqID }));
      const logs = await db.run(SELECT.from(ProcessLog).where({ reqID }));
      // const emailBodyResubmission = generateInitiatorResubmissionEmail(form, remarks);

      try {
        await sendMail({
          subject: `CAP Notification: ${capNumber} - Request Rejected`,
          // body: emailBodyResubmission,
          to: form.initiatorEmail || currentEmail,
          cc: 'suraj.mishra@sumodigitech.com'
        });
      } catch (error) {
        console.error(`Failed to send resubmission email for ${capNumber}: ${error.message}`);
      }
      return { error: false, message: `Request ${reqID} rejected by VP-FINANCE & ACCOUNTS.` };
    }

    if (action === 'Approve') {
      await db.run(UPDATE(ProcessLog).set({
        reqID,
        stage: request.stage,
        userName: currentUser,
        userEmail: currentEmail,
        status: 'Approved',
        role: 'VP-FINANCE & ACCOUNTS',
        completionDt: new Date(),
        timestamp: new Date().toISOString(),
        remarks: remarks || 'Approved and completed'
      }));

      await db.run(UPDATE(Request).set({
        status: 'Approved',
        stage: 'Completed',
        pendingWith: null,
        pendingWithName: null
      }).where({ reqID }));

      try {
        await sendMail({
          subject: `CAP Notification: ${capNumber} - Request Approved`,
          to: form.initiatorEmail || currentEmail,
          cc: ['suraj.mishra@sumodigitech.com', currentEmail].join(',')
        });
      } catch (error) {
        console.error(`Failed to send approval notification email for ${capNumber}: ${error.message}`);
      }

      return { error: false, message: `Request ${reqID} approved by VP-FINANCE & ACCOUNTS. Process completed.` };
    }
  }
}

