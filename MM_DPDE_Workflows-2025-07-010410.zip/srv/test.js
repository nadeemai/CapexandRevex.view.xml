async function OnNBApproval(req) {
  const { reqID, action, remarks } = req.data;
  const now = new Date();
  const tx = cds.transaction(req);

  const lastLog = await tx.run(SELECT.from('ProcessLog').where({ reqID, status: 'Pending' }).orderBy('receivedDt desc').limit(1));
  const [reqDetails] = await tx.run(SELECT.from('ReqFormNB_Details').where({ reqID }));
  if (!reqDetails) {
    req.error(404, `ReqFormNB_Details entry not found for reqID=${reqID}`);
    return;
  }

  function getNextStageAndEmail(currStage) {
    switch (currStage) {
      case null:
        return { nextStage: 'R1', nextEmail: reqDetails.approverR1, nextName: reqDetails.approverR1Name };
      case 'R1':
        return { nextStage: 'R2', nextEmail: reqDetails.approverR2, nextName: reqDetails.approverR2Name };
      case 'R2':
        return { nextStage: 'R3', nextEmail: reqDetails.approverR3, nextName: reqDetails.approverR3Name };
      case 'R3':
        return { nextStage: null, nextEmail: null, nextName: null };
      default:
        return { nextStage: null, nextEmail: null, nextName: null };
    }
  }

  if (action === 'Submit') {
    const { nextStage, nextEmail, nextName } = getNextStageAndEmail(null);
    if (!nextStage) {
      req.error(500, 'Could not determine first stage (R1).');
      return;
    }
    await tx.run(
      INSERT.into('ProcessLog').entries({
        reqID,
        stage: nextStage,
        userName: nextName,
        userEmail: nextEmail,
        status: 'Pending',
        role: nextStage,
        receivedDt: now,
        remarks: remarks || ''
      })
    );
    
    return `Request ${reqID} submitted; log created for ${nextStage}.`;
  }

  const currLog = lastLog[0];
  const currStage = currLog.stage;

  if (action === 'Approve') {
    await tx.run(UPDATE('ProcessLog').set({ status: 'Approved', completionDt: now, remarks: remarks || currLog.remarks }).where({ reqID, receivedDt: currLog.receivedDt, stage: currStage }));
    const { nextStage, nextEmail, nextName } = getNextStageAndEmail(currStage);
    if (nextStage) {
      await tx.run(
        INSERT.into('ProcessLog').entries({
          reqID,
          stage: nextStage,
          userName: nextName,
          userEmail: nextEmail,
          status: 'Pending',
          role: nextStage,
          receivedDt: now,
          remarks: ''
        })
      );
      return `Stage ${currStage} approved; log created for ${nextStage}.`;
    } else {
      await tx.run(UPDATE('ReqFormNB_Details').set({ approvedBy: currStage }).where({ reqID }));
      return `Request ${reqID} fully approved at ${currStage}.`;
    }
  }

  if (action === 'Reject') {
    await tx.run(UPDATE('ProcessLog').set({ status: 'Rejected', completionDt: now, remarks: remarks || currLog.remarks }).where({ reqID, receivedDt: currLog.receivedDt, stage: currStage }));
    await tx.run(UPDATE('ReqFormNB_Details').set({ approvedBy: currStage + '_Rejected' }).where({ reqID }));
    return `Request ${reqID} was rejected at stage ${currStage}.`;
  }

  return `No action taken for ${reqID}.`;
}



async function sendNBApprovalEmail(reqDetails, reqID, approverEmail, approverName, stage, date) {
    const approvalLink = `https://mamdevuat-o55cwsdo.launchpad.cfapps.eu10.hana.ondemand.com/ad0537a5-59e8-4423-9140-e0c59ca45250.comapprovalhub.commmapprovalhubapprovalhub-0.0.1/index.html?role=${stage}`;
  
    const subject = `NB Request #${reqID} - Approval Required at Stage ${stage}`;
    const body = `
      <p>Dear ${approverName || 'Sir/Madam'},</p>
      <p>You have a pending approval request for the following NB Request:</p>
      <table border="1" cellpadding="8" cellspacing="0" style="border-collapse: collapse; width: 100%; font-family: Arial, sans-serif; font-size: 14px;">
        <tr>
          <td style="background-color: red; color: white;">Request ID</td><td>${reqID}</td>
          <td style="background-color: red; color: white;">Date</td><td>${date || new Date().toLocaleDateString()}</td>
        </tr>
        <tr>
          <td style="background-color: red; color: white;">Requestor Name</td><td>${reqDetails.requestorName || ''}</td>
          <td style="background-color: red; color: white;">Department</td><td>${reqDetails.department || ''}</td>
        </tr>
        <tr>
          <td style="background-color: red; color: white;">Item Description</td><td colspan="3">${reqDetails.itemDescription || ''}</td>
        </tr>
        <tr>
          <td style="background-color: red; color: white;">Estimated Cost</td><td>${reqDetails.estimatedCost || ''}</td>
          <td style="background-color: red; color: white;">Remarks</td><td>${reqDetails.remarks || ''}</td>
        </tr>
      </table>
      <p>
        <a href="${approvalLink}" style="background-color: #007bff; color: #fff; padding: 10px 15px; text-decoration: none; border-radius: 4px;">
          Go to Approval Portal
        </a>
      </p>
    `;
  
    console.log(body);
  
    await sendMail({ to: approverEmail, subject, body });
  }
  