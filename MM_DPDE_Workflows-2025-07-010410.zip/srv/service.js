const cds = require('@sap/cds');
const { OnCreateReq, OnUpdateReq, OnGetReqAP, getCurrentUser } = require('./controllers/Request.js');
const { OnGetSSFD, OnSSFDApproval, getNextStage } = require('./controllers/SSFD.js');
const {validateApprovers, OnNBApproval,IsLastRecommender} = require('./controllers/NABudget.js');
const { OnISRApproval } = require('./controllers/ISR.js');
const {approveRequest} = require('./controllers/ApproveRequestHandler');
const { OnEXPApproval } = require('./controllers/EXPApproval.js');
const { onADPDApproval, onblankApprovers } = require('./controllers/ADPD.js');



console.log(process.env.NODE_ENV)
module.exports = async function () {
  const { Requests,RequestsAP,ReqFormFD, ProcessLogs, Approvers } = this.entities;
  this.on('CREATE', Requests, OnCreateReq);
  this.on('UPDATE', Requests, OnUpdateReq);
  this.on('READ', RequestsAP, OnGetReqAP);
  this.on('READ', ReqFormFD, OnGetSSFD);
  this.on('ApproveRequest', approveRequest);
  this.on('SSFDApproval', OnSSFDApproval);
  this.on('validateApprovers',validateApprovers);
  this.on('NBApproval', OnNBApproval);
  this.on('getNextStage', async (req)=>{
    const tx = cds.transaction(req);
    return await getNextStage(req.data,tx);
  });
  this.on('getCurrentUser', getCurrentUser )

   //ADPD
   this.on('ADPDApproval', onADPDApproval);
   this.on('blankApprovers', onblankApprovers ) 
   
  //ISR
  this.on('ISRApproval', OnISRApproval);

  this.on('EXPApproval', OnEXPApproval);
};





