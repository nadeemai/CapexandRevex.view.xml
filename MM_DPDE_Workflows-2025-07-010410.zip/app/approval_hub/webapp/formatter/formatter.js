sap.ui.define([], function () {
    "use strict";

    return {
        formatDate: function(dateValue) {
            if (!dateValue) return "";
            const date = new Date(dateValue);
            const options = { day: '2-digit', month: 'short', year: 'numeric' };
            return date.toLocaleDateString('en-GB', options).replace(/ /g, '-');
        }
                
        
    };
});
