sap.ui.define([
    "sap/ui/core/UIComponent",
    "com/mmapprovalhub/approvalhub/model/models"
], (UIComponent, models) => {
    "use strict";

    return UIComponent.extend("com.mmapprovalhub.approvalhub.Component", {
        metadata: {
            manifest: "json",
            interfaces: [
                "sap.ui.core.IAsyncContentCreation"
            ]
        },
        
        _ongetParameter: function () {
            var sHash = window.location.hash;
            if (!sHash || sHash === "#/") { 
                var param1 = this.getUrlParameter("role");
                if (param1 === "AP") {
                    this.getRouter().navTo("approverdashboard");
                } else if (param1 === "IN") {
                    this.getRouter().navTo("Cordys_DashboardUi");
                } else {
                    this.getRouter().navTo("App");
                }
                console.log("Role param:", param1);
            } else {
            }
        },        
         getUrlParameter: function(name) {
            name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
            var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
            var results = regex.exec(window.location.search);
            return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
        },
        init: function () {
            UIComponent.prototype.init.apply(this, arguments);
            this.setModel(models.createDeviceModel(), "device");
             this.getRouter().initialize();
           // this._ongetParameter(); // for local 
         this.onStartParameter(); // for workzone
        },
        onStartParameter: function () {
            let sType = "";
            const urlParams = new URLSearchParams(window.location.search);
            const roleParam = urlParams.get("role");
            if (roleParam) {
                sType = roleParam;
            } else {
                const aApp = this.getComponentData()?.startupParameters?.role;
                if (aApp && aApp.length > 0) {
                    sType = aApp[0];
                }
            }
            if (sType === "IN") {
                this.getRouter().navTo("Cordys_DashboardUi");
            } else if (sType === "AP") {
                this.getRouter().navTo("approverdashboard");
            } else {
                this.getRouter().navTo("Cordys_DashboardUi");
            }
        }
        
        // onStartParameter: function(){
        //     const aApp = this.getComponentData()?.startupParameters?.role;
        //     let sType = "";
        //     if (aApp && aApp.length > 0) {
        //         sType = aApp[0];
        //         if (sType === "IN") {
        //             this.getRouter().navTo("Cordys_DashboardUi");
        //         } else if (sType === "AP") {
        //             this.getRouter().navTo("approverdashboard");
        //         } else {
        //             this.getRouter().navTo("Cordys_DashboardUi");
        //         }
        //     } else {
        //         this.getRouter().navTo("Cordys_DashboardUi");
        //     }
        // }
        
       
    });
});