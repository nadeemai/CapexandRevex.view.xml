sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageToast",
  "sap/m/MessageBox",
  "sap/ui/core/Fragment",
  "sap/ui/export/library",
  "sap/ui/export/Spreadsheet",
  "sap/m/Dialog",
  "sap/m/Button",
  "sap/m/Link",
  "sap/m/Text",
  "sap/ui/unified/FileUploader"
], (Controller, JSONModel, MessageBox, Fragment, MessageToast, exportLibrary, Spreadsheet, Dialog, Button, Link, Text, FileUploader) => {
  "use strict";

  return Controller.extend("com.mmapprovalhub.approvalhub.controller.CostApproval", {
    onInit() {

      var oAttachmentData = {
        attachments: []
      };
      var oAttachmentModel = new JSONModel(oAttachmentData);
      this.getView().setModel(oAttachmentModel, "UploadDocSrvTabDataCA");


      var oViewEnabledModel = new JSONModel({
        enableRowActions: true,
        approvebuttonvisiblity: false,
        deleteTabVisible: true,
        holdbuttonvisiblity: false,
        rejectbuttonvisiblity: false,

        approvebuttonfragment: false,
        rejetedbuttonfragmnet: false,
        sendbackbuttonvisiblity: false,
        remarkModel: "",
        approverRequiredVisible: false,
        currentUserRole: ""
      });
      this.getView().setModel(oViewEnabledModel, "viewenableddatacheck");


      this._oRemarkDialog = new sap.ui.xmlfragment("com/mmapprovalhub/approvalhub/Fragments/HoldRemarks", this);
      this.getView().addDependent(this._oRemarkDialog);


      var oPartsModel = new sap.ui.model.json.JSONModel({
        parts: []
      });
      this.getView().setModel(oPartsModel, "partsModel");

      var oTimelineData = {};
      var oTimelineModel = new JSONModel(oTimelineData);
      this.getView().setModel(oTimelineModel, "timelineModel");

      this.onFromApplicableModelsDataFetch();
      this.onFromFieldQualityDataFetch();
      this.onFromPVELeadDataFetch();
      this.onFromAggregateDataFetch();
      // this.onFetchTimelinessData();
      this.onFromBudgetProvisionDataFetch();
      this.onFromWarrantyCostDataFetch();
      this.onFromChangeCategoryDataFetch();

      var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
      oRouter.getRoute("CostApprovalReqID").attachPatternMatched(this._onRouteCostApprovalReqID, this);
      oRouter.getRoute("CostApproval").attachPatternMatched(this._onRouteCostApproval, this);
      oRouter.getRoute("CostApprovalReqIDApprover").attachPatternMatched(this._onRouteCostApprovalReqIDApprover, this);

    },

    _onRouteCostApprovalReqIDApprover: function (oEvent) {
      this._ApprovedCheck = "";
      var oArgs = oEvent.getParameter("arguments");
      this._basedNameUICap = oArgs.basedNameUICap;
      var reqID = oArgs.reqID;
      var refNo = oArgs.reqID
      this._reqIDData = reqID;

      this._ApprovedCheck = oArgs.approved;
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      var that = this;

      oModelV2.read("/Requests", {
        urlParameters: {
          "$filter": "reqID eq '" + reqID + "'",
          "$expand": "approvalDtl/parts"
        },
        success: function (oData) {
          if (oData && oData.results.length > 0) {

            var statusDatacheck = oData.results[0].status;
            that.statusData = statusDatacheck;
            let requestData = oData.results[0];
            var oRequestDataModel = that.getOwnerComponent().getModel("RequestDataModel") || new JSONModel();
            oRequestDataModel.setData(requestData);
            that.getOwnerComponent().setModel(oRequestDataModel, "RequestDataModel");

            var partsData = requestData.approvalDtl?.parts?.results || [];
            var partsModel = that.getView().getModel("partsModel");
            if (!partsModel) {
              partsModel = new sap.ui.model.json.JSONModel();
              that.getView().setModel(partsModel, "partsModel");
            }
            partsModel.setData({ parts: partsData });


            that.onFetchTimelinessData(oData.results[0].reqID);
            that._ApprovedCheck = "Approved";


            var oViewModel = that.getView().getModel("viewenableddatacheck");

            var stage = oData.results[0].stage;
            var statusDatacheck = oData.results[0].status;
            var oViewModel = that.getView().getModel("viewenableddatacheck");

            oViewModel.setProperty("/enableRowActions", false);
            oViewModel.setProperty("/approvebuttonvisiblity", false);
            oViewModel.setProperty("/rejectbuttonvisiblity", false);
            oViewModel.setProperty("/holdbuttonvisiblity", false);
            oViewModel.setProperty("/sendbackbuttonvisiblity", false);
            oViewModel.setProperty("/approverRequiredVisible", false);
            oViewModel.setProperty("/remarkModel", "");

            // const sequentialStages = [
            //   "PVE-LEAD",
            //   "PVE-HEAD",
            //   "CDMM-PUL",
            //   "HEAD MFG",
            //   "FINANCE & ACCOUNTS-PUL",
            //   "FINANCE & ACCOUNTS-HEAD",
            //   "VP-FINANCE & ACCOUNTS"
            // ];

            // const parallelStages = [
            //   "CDMM-HEAD",
            //   "FDPD-HEAD",
            //   "FDQA-HEAD",
            //   "CUSTOMER CARE HEAD"
            // ];
            const sequentialStages = [

              "PVE-LEAD",
            
              "PVE-HEAD",
            
              "CDMM-PUL",
            
              "CUSTOMER CARE-PUL",
            
              "QA-PUL",
            
              "FINANCE & ACCOUNTS-PUL",
            
              "FINANCE & ACCOUNTS-HEAD",
            
              "VP-FINANCE & ACCOUNTS",
            
              "MFG-HEAD"
            
            ];
            
            const parallelStages = [
            
              "CDMM-HEAD",
            
              "FDPD-HEAD",
            
              "FD QA HEAD",
            
              "CUSTOMER CARE HEAD",
            
              "FDQA-HEAD",
            
              "FDQA & CUSTOMER CARE-HEAD",
            
              "CDMM-FDPD HEAD",
            
              "CUSTOMER CARE & QA-PUL"
            
            ];
                      

            if (statusDatacheck === "Draft" || statusDatacheck === "Rejected") {
              oViewModel.setProperty("/enableRowActions", true);
            }
            else if (statusDatacheck === "Pending" || statusDatacheck === "InProgress") {
              oViewModel.setProperty("/enableRowActions", false);

          //     switch (stage?.toUpperCase()) {
          //       case "PVE-LEAD":
          //       case "PVE-HEAD":
          //       case "CDMM-PUL":
          //         case "MFG-HEAD":
          //       case "FINANCE & ACCOUNTS-PUL":
          //       case "FINANCE & ACCOUNTS-HEAD":
          //       case "VP-FINANCE & ACCOUNTS":
                    
          //         oViewModel.setProperty("/approvebuttonvisiblity", true);
          //         oViewModel.setProperty("/rejectbuttonvisiblity", true);
          //         oViewModel.setProperty("/approverRequiredVisible", true);
          //         break;

          //       // case "CDMM-HEAD":
          //       // case "FDPD-HEAD":
          //       // case "FDQA-HEAD":
          //       // case "CUSTOMER CARE HEAD":
          //  case "CDMM-FDPD HEAD":
          //    case "FDQA & Customer Care-HEAD":
          //  case "Customer Care & QA-PUL":
          //         oViewModel.setProperty("/approvebuttonvisiblity", true);
          //         oViewModel.setProperty("/rejectbuttonvisiblity", true);
          //         oViewModel.setProperty("/holdbuttonvisiblity", true); // Parallel approval
          //         oViewModel.setProperty("/approverRequiredVisible", true);
          //         break;

          //       default:
          //         oViewModel.setProperty("/approvebuttonvisiblity", false);
          //         oViewModel.setProperty("/rejectbuttonvisiblity", false);
          //         oViewModel.setProperty("/holdbuttonvisiblity", false);
          //         oViewModel.setProperty("/approverRequiredVisible", false);
          //         break;
              // }
              oViewModel.setProperty("/enableRowActions", false);
 
  const stageUpper = stage?.toUpperCase();
 
  const sequentialStages = [
    "PVE-LEAD",
    "PVE-HEAD",
    "CDMM-PUL",
    "CUSTOMER CARE-PUL",
    "QA-PUL",
    "FINANCE & ACCOUNTS-PUL",
    "FINANCE & ACCOUNTS-HEAD",
    "VP-FINANCE & ACCOUNTS",
    "MFG-HEAD"
  ];
 
  const parallelStages = [
    "CDMM-HEAD",
    "FDPD-HEAD",
    "FDQA-HEAD",
    "CUSTOMER CARE HEAD",
    "FDQA & CUSTOMER CARE-HEAD",
    "CDMM-FDPD HEAD",
    "CUSTOMER CARE & QA-PUL"
  ];
 
  if (sequentialStages.includes(stageUpper)) {
    oViewModel.setProperty("/approvebuttonvisiblity", true);
    oViewModel.setProperty("/rejectbuttonvisiblity", true);
    oViewModel.setProperty("/holdbuttonvisiblity", false);
    oViewModel.setProperty("/approverRequiredVisible", true);
  } else if (parallelStages.includes(stageUpper)) {
    oViewModel.setProperty("/approvebuttonvisiblity", true);
    oViewModel.setProperty("/rejectbuttonvisiblity", true);
    oViewModel.setProperty("/holdbuttonvisiblity", true);
    oViewModel.setProperty("/approverRequiredVisible", true);
  } else {
    oViewModel.setProperty("/approvebuttonvisiblity", false);
    oViewModel.setProperty("/rejectbuttonvisiblity", false);
    oViewModel.setProperty("/holdbuttonvisiblity", false);
    oViewModel.setProperty("/approverRequiredVisible", false);
  }
            }
            else if (statusDatacheck === "Approved") {
              oViewModel.setProperty("/enableRowActions", false);
              oViewModel.setProperty("/approvebuttonvisiblity", false);
              oViewModel.setProperty("/rejectbuttonvisiblity", false);
              oViewModel.setProperty("/holdbuttonvisiblity", false);
              oViewModel.setProperty("/approverRequiredVisible", false);
            }

            that.onAttchmentDataFetch(refNo);
          } else {
            MessageToast.show("No data found for Req ID: " + reqID, { position: "bottom center" });
          }
        },
        error: function (oError) {
          MessageToast.show("Failed to load  data.", { position: "bottom center" });
          console.error("Error fetching data:", oError);
        }
      });
    },

    _onRouteCostApproval: function (oEvent) {
      var oArgs = oEvent.getParameter("arguments");
      var oAttachmentModel = this.getView().getModel("UploadDocSrvTabDataCA");
      if (oAttachmentModel) {
        oAttachmentModel.setData({ attachments: [] });
      } else {
        oAttachmentModel = new sap.ui.model.json.JSONModel({ attachments: [] });
        this.getView().setModel(oAttachmentModel, "UploadDocSrvTabDataCA");
      }
      this._basedNameUICap = oArgs.basedNameUICap;
      this._reqIDData = "";
      this._ApprovedCheck = "";
      this.onResetForm();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      var that = this;

    },

    _onRouteCostApprovalReqID: function (oEvent) {
      var oArgs = oEvent.getParameter("arguments");
      this._basedNameUICap = oArgs.basedNameUICap;
      var reqID = oArgs.reqID;
      var refNo = oArgs.reqID
      this._reqIDData = reqID;
      this._ApprovedCheck = "";
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      var that = this;

      oModelV2.read("/Requests", {
        urlParameters: {
          "$filter": "reqID eq '" + reqID + "'",
          "$expand": "approvalDtl/parts"
        },
        success: function (oData) {
          if (oData && oData.results.length > 0) {
            // let oRequestDataModel = that.getOwnerComponent().getModel("RequestDataModel") || new JSONModel();
            // that.getOwnerComponent().setModel(oRequestDataModel, "RequestDataModel");
            // that.partsModel.setData(oData.approvalDtl.parts || []);
            // oRequestDataModel.setData(oData.results[0]);
            var statusDatacheck = oData.results[0].status;
            that.statusData = statusDatacheck;
            let requestData = oData.results[0];
            var oRequestDataModel = that.getOwnerComponent().getModel("RequestDataModel") || new JSONModel();
            oRequestDataModel.setData(requestData);
            that.getOwnerComponent().setModel(oRequestDataModel, "RequestDataModel");
            var partsData = requestData.approvalDtl?.parts?.results || [];
            var partsModel = that.getView().getModel("partsModel");
            if (!partsModel) {
              partsModel = new sap.ui.model.json.JSONModel();
              that.getView().setModel(partsModel, "partsModel");
            }
            partsModel.setData({ parts: partsData });

            that.onFetchTimelinessData(oData.results[0].reqID);



            var oViewModel = that.getView().getModel("viewenableddatacheck");
            if (statusDatacheck === "Draft" || !statusDatacheck || statusDatacheck === "Send Back") {
              oViewModel.setProperty("/enableRowActions", true);
              oViewModel.setProperty("/approvebuttonvisiblity", false);
              oViewModel.setProperty("/approverRequiredVisible", false);
              //forapproavl
              // oViewModel.setProperty("/isApproverScreen", false);
              // oViewModel.setProperty("/enableRowActionsapproval", false);  
            } else if (statusDatacheck === "Pending" || statusDatacheck === "PVE-HEAD") {
              oViewModel.setProperty("/enableRowActions", false);
              oViewModel.setProperty("/approvebuttonvisiblity", false);
              oViewModel.setProperty("/approverRequiredVisible", false);
              //forapproavl
              // oViewModel.setProperty("/isApproverScreen", false);
              // oViewModel.setProperty("/enableRowActionsapproval", false);  
            } else if (statusDatacheck === "Approved") {
              oViewModel.setProperty("/enableRowActions", false);
              oViewModel.setProperty("/approvebuttonvisiblity", false);
              oViewModel.setProperty("/approverRequiredVisible", false);
              //forapproavl
              // oViewModel.setProperty("/isApproverScreen", false);
              // oViewModel.setProperty("/enableRowActionsapproval", false);  
            }

            that.onAttchmentDataFetch(refNo);
          } else {
            MessageToast.show("No data found for Req ID: " + reqID, { position: "bottom center" });
          }
        },
        error: function (oError) {
          MessageToast.show("Failed to load HOD data.", { position: "bottom center" });
          console.error("Error fetching HOD data:", oError);
        }
      });
    },


    onAfterRendering: function () {
      var oView = this.getView();

      var aComboBoxes = oView.findAggregatedObjects(true, function (oControl) {
        return oControl.isA("sap.m.ComboBox");
      });

      aComboBoxes.forEach(function (oComboBox) {
        var oDomRef = oComboBox.getDomRef("inner");

        if (oDomRef) {

          if (oComboBox._focusOutListener) {
            oDomRef.removeEventListener("focusout", oComboBox._focusOutListener);
          }

          oComboBox._focusOutListener = function () {
            var sValue = oComboBox.getValue();
            var aItems = oComboBox.getItems();

            var bValid = aItems.some(function (oItem) {
              return oItem.getText() === sValue || oItem.getKey() === sValue;
            });

            if (!bValid) {
              oComboBox.setValue("");
              oComboBox.setSelectedKey("");
              oComboBox.setValueState("None");
            }
          };

          oDomRef.addEventListener("focusout", oComboBox._focusOutListener);
        }
      });
    },
    onFromAggregateDataFetch: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

      oModelV2.read("/ControlValues", {
        urlParameters: {
          "$filter": "category eq 'Aggregate'"
        },
        success: function (oData) {
          if (oData && oData.results) {
            var oJSONModel = new sap.ui.model.json.JSONModel({
              results: oData.results
            });
            oView.setModel(oJSONModel, "aFormAggregateModel");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load Aggregate data.");
          console.error("Aggregate load error:", oError);
        }
      });
    },

    onFromBudgetProvisionDataFetch: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

      oModelV2.read("/ControlValues", {
        urlParameters: {
          "$filter": "category eq 'Budget Provision'"
        },
        success: function (oData) {
          if (oData && oData.results) {
            var oJSONModel = new sap.ui.model.json.JSONModel({
              results: oData.results
            });
            oView.setModel(oJSONModel, "aFormBudgetProvisionModel");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load Budget Provision data.");
          console.error("Budget Provision load error:", oError);
        }
      });
    },

    onFromWarrantyCostDataFetch: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

      oModelV2.read("/ControlValues", {
        urlParameters: {
          "$filter": "category eq 'Warranty Cost'"
        },
        success: function (oData) {
          if (oData && oData.results) {
            var oJSONModel = new sap.ui.model.json.JSONModel({
              results: oData.results
            });
            oView.setModel(oJSONModel, "aFormWarrantyCostModel");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load Warranty Cost data.");
          console.error("Warranty Cost load error:", oError);
        }
      });
    },

    onFromChangeCategoryDataFetch: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

      oModelV2.read("/ControlValues", {
        urlParameters: {
          "$filter": "category eq 'Change Category'"
        },
        success: function (oData) {
          if (oData && oData.results) {
            var oJSONModel = new sap.ui.model.json.JSONModel({
              results: oData.results
            });
            oView.setModel(oJSONModel, "aFormChangeCategoryModel");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load Change Category data.");
          console.error("Change Category load error:", oError);
        }
      });
    },
    onFromApplicableModelsDataFetch: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

      oModelV2.read("/ControlValues", {
        urlParameters: {
          "$filter": "category eq 'Applicable Models'"
        },
        success: function (oData) {
          if (oData && oData.results) {
            var oJSONModel = new sap.ui.model.json.JSONModel({ results: oData.results });
            oView.setModel(oJSONModel, "ApplicableModelsModel");
            console.log("Applicable_Models data:", oData.results);
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load Applicable_Models data.");
          console.error("Applicable_Models load error:", oError);
        }
      });
    },
    onFromFieldQualityDataFetch: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

      oModelV2.read("/ControlValues", {
        urlParameters: {
          "$filter": "category eq 'Field Quality'"
        },
        success: function (oData) {
          if (oData && oData.results) {
            var oJSONModel = new sap.ui.model.json.JSONModel({ results: oData.results });
            oView.setModel(oJSONModel, "FieldQualityModel");
            console.log("Field_Quality data:", oData.results);
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load Field_Quality data.");
          console.error("Field_Quality load error:", oError);
        }
      });
    },

    onFromPVELeadDataFetch: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

      oModelV2.read("/ControlValues", {
        urlParameters: {
          "$filter": "category eq 'PVE_LEAD'"
        },
        success: function (oData) {
          if (oData && oData.results) {
            var oJSONModel = new sap.ui.model.json.JSONModel({ results: oData.results });
            oView.setModel(oJSONModel, "PVELeadModel");
            console.log("PVE_LEAD data:", oData.results);
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load PVE_LEAD data.");
          console.error("PVE_LEAD load error:", oError);
        }
      });
    },
    
    formatTimelineTitle: function (role, userName, userEmail) {
      return role + " " + userName + " (" + userEmail + ")";
    },


    onImportPartsPress: function () {
      this._oImportDialog.open();
    },

    onFileSelected: function (oEvent) {
      var oFileUploader = oEvent.getSource();
      var sFileName = oFileUploader.getValue();
      if (sFileName) {
        sap.m.MessageToast.show("File selected: " + sFileName);
      }
    },

    onUploadPress: function () {
      var oFileUploader = this.byId("costApprovalImportPartDetailsFileUploader");
      var oComboBox = this.byId("costApprovalImportPartDetailsFileTypeComboBox");

      if (!oComboBox.getSelectedKey()) {
        sap.m.MessageToast.show("Please select a file type.");
        return;
      }
      if (!oFileUploader.getValue()) {
        sap.m.MessageToast.show("Please choose a file to upload.");
        return;
      }

      sap.m.MessageToast.show("Uploading file...");
      this.onCloseDialog();
    },

    onCloseDialog: function () {
      if (this._oImportDialog) {
        this._oImportDialog.close();
      }
    },
    onCancelCostApprovalform: function () {
      var Approved = this._ApprovedCheck;
      if (Approved === "Approved") {

        var oRouter = this.getOwnerComponent().getRouter();
        oRouter.navTo("approverdashboard", {

        });
      } else {
       // this.onResetForm();
        var oRouter = this.getOwnerComponent().getRouter();
        oRouter.navTo("DashboardUI", {
          Name: "CostApproval"
        });

      }

    },

    onCostApprovalBulkUploadTemplateExport: function () {
      var oModel = this.getView().getModel("partsModel");
     // var aData = oModel.getProperty("/parts") || [{}];

      const aCols = [
        { label: "Old Part Number", property: "oldPartNumber", type: "string" },
        { label: "Old Part Nomenclature", property: "oldPartManufacturer", type: "string" },
        { label: "Old Part Change Letter", property: "oldPartChangeLetter", type: "string" },
        { label: "Old Part Warranty Capacity", property: "oldPartCapacityPerYear", type: "string" },
        { label: "New Part Number", property: "newPartNumber", type: "string" },
        { label: "New Part Nomenclature", property: "newPartNomenclature", type: "string" },
        { label: "New Part Change Letter", property: "newPartChangeLetter", type: "string" },
        { label: "New Part Warranty Capacity", property: "newPartCapacityPerYear", type: "string" }
      ];

      const oSettings = {
        workbook: { columns: aCols },
        dataSource: [{}],
        fileName: "CostApproval_Template.xlsx"
      };

      new sap.ui.export.Spreadsheet(oSettings).build()
        .then(() => {
          sap.m.MessageToast.show("Template downloaded");
        })
        .catch(function (oError) {
          sap.m.MessageBox.error("Failed to download template:\n" + oError.message);
        });
    },

    onOpenUploadDialog: function () {
      this._openUploadDialog();
    },

    _openUploadDialog: function () {
      const that = this;

      if (this._oUploadDialog) {
        this._oUploadDialog.destroy();
        this._oUploadDialog = null;
      }

      const oFileUploader = new FileUploader({
        fileType: ["xlsx", "xls", "csv"],
        placeholder: "Select Excel/CSV file",
        buttonText: "Browse...",
        change: function (oEvent) {
          that._selectedFile = oEvent.getParameter("files")[0];
        }
      }).addStyleClass("sapUiSmallMargin");

      this._oUploadDialog = new Dialog({
        title: "Bulk Upload",
        content: [
          new Link({
            text: "Download Template",
            press: function () {
              that.onCostApprovalBulkUploadTemplateExport();
            }
          }).addStyleClass("sapUiSmallMarginBottom"),
          oFileUploader
        ],
        beginButton: new Button({
          text: "Upload",
          type: "Emphasized",
          press: function () {
            if (that._selectedFile) {
              that._processUploadedCostApprovalFile(that._selectedFile);
              that._oUploadDialog.close();
            } else {
              sap.m.MessageToast.show("Please select a file to upload.");
            }
          }
        }),
        endButton: new Button({
          text: "Cancel",
          press: function () {
            that._oUploadDialog.close();
          }
        }),
        afterClose: function () {
          that._selectedFile = null;
          that._oUploadDialog.destroy();
          that._oUploadDialog = null;
        }
      });

      this._selectedFile = null;
      this._oUploadDialog.open();
    },

    _processUploadedCostApprovalFile: function (file) {
      const that = this;
      const reader = new FileReader();

      reader.onload = function (e) {
        try {
          const arrayBuffer = e.target.result;
          const workbook = XLSX.read(arrayBuffer, { type: "array" });
          const sheet = workbook.Sheets[workbook.SheetNames[0]];
          const jsonData = XLSX.utils.sheet_to_json(sheet, { defval: "" });

          if (!jsonData.length) {
            sap.m.MessageToast.show("No data found in the uploaded file.");
            return;
          }

          const columnMapping = [
            { label: "Old Part Number", property: "oldPartNumber" },
            { label: "Old Part Nomenclature", property: "oldPartManufacturer" },
            { label: "Old Part Change Letter", property: "oldPartChangeLetter" },
            { label: "Old Part Warranty Capacity", property: "oldPartCapacityPerYear" },
            { label: "New Part Number", property: "newPartNumber" },
            { label: "New Part Nomenclature", property: "newPartNomenclature" },
            { label: "New Part Change Letter", property: "newPartChangeLetter" }
          ];

          // Format new Excel data
          const formattedData = jsonData.map(row => {
            const item = {};
            columnMapping.forEach(col => {
              item[col.property] = row[col.label] || "";
            });
            return item;
          });

          // Merge with existing table data
          const oModel = that.getView().getModel("partsModel");
          const existingData = oModel.getProperty("/parts") || [];
          const mergedData = existingData.concat(formattedData);
          oModel.setProperty("/parts", mergedData);

          sap.m.MessageToast.show("Bulk upload completed successfully.");
        } catch (err) {
          console.error("Failed to process uploaded file:", err);
          sap.m.MessageToast.show("Error processing file.");
        }
      };

      reader.readAsArrayBuffer(file);
    },


    // onCostApprovalBulkUploadTemplateExport: function () {
    //   const headerRow = this._aCostApprovalColumns.map(col => col.label);
    //   const ws = XLSX.utils.aoa_to_sheet([headerRow]);
    //   const wb = XLSX.utils.book_new();
    //   XLSX.utils.book_append_sheet(wb, ws, "Parts Template");
    //   XLSX.writeFile(wb, "CostApprovalPartsTemplate.xlsx");
    // },

    onNavBack: function () {
      var Approved = this._ApprovedCheck;
      if (Approved === "Approved") {

        var oRouter = this.getOwnerComponent().getRouter();
        oRouter.navTo("approverdashboard", {

        });
      } else {
       // this.onResetForm();
        var oRouter = this.getOwnerComponent().getRouter();
        oRouter.navTo("DashboardUI", {
          Name: "CostApproval"
        });

      }

    },

    onAddPartPress: function () {
      var oTable = this.byId("costApprovalPartsTable");
      var oModel = oTable.getModel("partsModel");
      var aParts = oModel.getProperty("/parts") || [];

      aParts.push({
        oldPartNumber: "",
        oldPartManufacturer: "",
        oldPartChangeLetter: "",
        oldPartCapacityPerYear: "",
        newPartNumber: "",
        newPartNomenclature: "",
        newPartChangeLetter: "",
        newPartCapacityPerYear: ""
      });

      oModel.setProperty("/parts", aParts);

      sap.m.MessageToast.show("New part row added.");
    },


    onRemovePartPress: function () {
      var oTable = this.byId("costApprovalPartsTable");
      var aSelectedItems = oTable.getSelectedItems();

      if (aSelectedItems.length === 0) {
        sap.m.MessageToast.show("Please select a row to remove.");
        return;
      }

      var oModel = oTable.getModel("partsModel");
      var aParts = oModel.getProperty("/parts");
      var aIndicesToRemove = aSelectedItems.map(function (oItem) {
        var sPath = oItem.getBindingContext("partsModel").getPath(); // e.g., "/parts/3"
        return parseInt(sPath.split("/").pop(), 10);
      });

      aIndicesToRemove.sort((a, b) => b - a).forEach(function (iIndex) {
        aParts.splice(iIndex, 1);
      });

      oModel.setProperty("/parts", aParts);
      oTable.removeSelections();
      sap.m.MessageToast.show("Selected part row(s) removed.");
    },

    attachmentuploadFilesData: function (reqid) {
      var oModelTabdata = this.getView().getModel("UploadDocSrvTabDataCA");
      var aFilesData = oModelTabdata.getProperty("/attachments") || [];
      var oModel = this.getOwnerComponent().getModel("approvalservicev2");
      //sap.ui.core.BusyIndicator.show(0);

      aFilesData.forEach(function (file) {
        if (!file.fileName || file.uploaded) return;

        if (file.content && typeof file.content === "string" && file.content.includes(',')) {
          var base64Content = file.content.split(',')[1];
          var payload = {
            fileName: file.fileName,
            content: base64Content,
            mediaType: file.mimeType || "text/plain",
            reqID: reqid
          };

          oModel.create("/ReqAttachments", payload, {
            success: function () {
              file.uploaded = true;
              oModelTabdata.refresh(true);
              // sap.ui.core.BusyIndicator.hide();
            },
            error: function (oError) {
              sap.m.MessageToast.show("Error uploading attachment: " + file.fileName, { position: "bottom center" });
              console.error("Error uploading attachment:", oError);
              //sap.ui.core.BusyIndicator.hide();
            }
          });
        }
      });
    },
    onAttchmentDataFetch: function (refNo) {
      var reqid = refNo;
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

      var that = this;
      oModelV2.read("/ReqAttachments", {
        filters: [
          new sap.ui.model.Filter("reqID", sap.ui.model.FilterOperator.EQ, reqid)
        ],
        success: function (oData) {
          if (oData && oData.results) {
            var oJSONModel = new JSONModel({
              attachments: oData.results
            });
            that.getView().setModel(oJSONModel, "UploadDocSrvTabDataCA");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load attachment data.", { position: "bottom center" });
          console.error("Error fetching attachment data:", oError);
        }
      });
    },
  
    _formatDate: function (oDate) {
      const dd = String(oDate.getDate()).padStart(2, '0');
      const mm = String(oDate.getMonth() + 1).padStart(2, '0');
      const yyyy = oDate.getFullYear();
      return `${dd}-${mm}-${yyyy}`;
    },

    onComboBoxChange: function (oEvent) {
      var oComboBox = oEvent.getSource();
      var sValue = oEvent.getParameter("newValue") || oComboBox.getValue();
      var aItems = oComboBox.getItems();
      var bValid = aItems.some(function (oItem) {
        return oItem.getKey() === sValue || oItem.getText() === sValue;
      });
      if (bValid) {
        oComboBox.setValueState("None");
      } else {
        oComboBox.setValueState("Error");
        //oComboBox.setValue("");          
        // oComboBox.setSelectedKey(""); 
        //oComboBox.setValueState(bValid ? "None" : "Error");
      }
    },
   
    onNumberInputLiveChange: function (oEvent) {
      var oInput = oEvent.getSource();
      var sValue = oInput.getValue();
      let filteredValue = "";
      let dotSeen = false;

      for (let i = 0; i < sValue.length; i++) {
        let char = sValue.charAt(i);
        if (char >= '0' && char <= '9') {
          filteredValue += char;
        } else if (char === '.' && !dotSeen) {
          filteredValue += char;
          dotSeen = true;
        }
      }

      let parts = filteredValue.split(".");
      let integerPart = parts[0];
      let decimalPart = parts[1] || "";

      if (integerPart.length > 8) {
        integerPart = integerPart.substring(0, 8);
      }
      if (decimalPart.length > 2) {
        decimalPart = decimalPart.substring(0, 2);
      }

      let finalValue = integerPart;
      if (dotSeen) {
        finalValue += "." + decimalPart;
      }

      if (finalValue && parseFloat(finalValue) > 99999999.99) {
        return; 
      }

      oInput.setValue(finalValue);
      oInput.setValueState("None");
      oInput.setValueStateText("");
    },

    onTextAreaLiveChange: function (oEvent) {
      const oTextArea = oEvent.getSource();
      const sValue = oTextArea.getValue().trim();
      const iValueLength = sValue.length;
      const iMaxLength = oTextArea.getMaxLength();

      if (iValueLength > iMaxLength) {
        oTextArea.setValueState("Warning");
        oTextArea.setValueStateText("Maximum length exceeded");
      } else {
        oTextArea.setValueState("None");
        oTextArea.setValueStateText("");
      }
    },

    onTextInputLiveChange: function (oEvent) {
      var oInput = oEvent.getSource();
      var sValue = oInput.getValue();

      var filteredValue = sValue.replace(/[^a-zA-Z0-9]/g, '');

      if (filteredValue !== sValue) {
        oInput.setValue(filteredValue);
      }
      if (filteredValue) {
        oInput.setValueState("None");
        oInput.setValueStateText("");
      }
    },

    onDownloadbtn: function () {
      var oTable = this.byId("costApprovalAttachmentTable");
      var aSelectedItems = oTable.getSelectedItems();

      if (aSelectedItems.length === 0) {
        sap.m.MessageBox.error("No files selected for download", {
          title: "Error"
        });
        return;
      }

      aSelectedItems.forEach(function (oItem) {
        var oContext = oItem.getBindingContext("UploadDocSrvTabData");
        var sFileName = oContext.getProperty("fileName");
        var sId = oContext.getProperty("ID");
        this._downloadFile(sId, sFileName);
      }, this);
    },

    onDownloadTabAttachment: function (oEvent) {
      var oButton = oEvent.getSource();
      var oCustomData = oButton.getCustomData();
      var sFileName = oCustomData.find(oData => oData.getKey() === "fileName").getValue();
      var sId = oCustomData.find(oData => oData.getKey() === "ID").getValue();
      this._downloadFile(sId, sFileName);
    },


    _downloadFile: function (sId, sFileName) {
      const oModel = this.getView().getModel("UploadDocSrvTabData");
      const aFiles = oModel.getProperty("/attachments") || [];

      const oFile = aFiles.find(file => file.ID === sId);

      if (!oFile) {
        sap.m.MessageBox.error(`File "${sFileName}" not found in model.`, { title: "Error" });
        console.error("File not found:", sId, sFileName);
        return;
      }

      if (!oFile.base64Content || !oFile.mimeType) {
        sap.m.MessageBox.error(`No content or MIME type available for "${sFileName}".`, { title: "Error" });
        console.error("File data incomplete:", oFile);
        return;
      }

      try {

        const sBase64 = oFile.base64Content.includes(",")
          ? oFile.base64Content.split(",")[1]
          : oFile.base64Content;


        const byteCharacters = atob(sBase64);
        const byteArrays = new Uint8Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteArrays[i] = byteCharacters.charCodeAt(i);
        }

        const oBlob = new Blob([byteArrays], { type: oFile.mimeType });


        const oLink = document.createElement("a");
        const sUrl = URL.createObjectURL(oBlob);
        oLink.href = sUrl;
        oLink.download = sFileName;

        document.body.appendChild(oLink);
        oLink.click();
        document.body.removeChild(oLink);
        URL.revokeObjectURL(sUrl);

        sap.m.MessageToast.show(`Download started for "${sFileName}"`);
      } catch (e) {
        sap.m.MessageBox.error(`Failed to download "${sFileName}": ${e.message}`, { title: "Error" });
        console.error("Download error:", e);
      }
    },

    onFetchTimelinessData: function (areqid) {
      var reqid = areqid;
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

      oModelV2.read("/ProcessLogs", {
        filters: [
          new sap.ui.model.Filter("reqID", sap.ui.model.FilterOperator.EQ, reqid)
        ],
        urlParameters: {
          "$orderby": "createdAt desc"
        },
        success: function (oData) {
          if (oData && oData.results) {
            var aProcessedData = oData.results.map(function (oLog) {
              return {
                createdAt: oLog.createdAt,
                role: oLog.stage ? "[" + oLog.stage + "]" : "[N/A]",
                userName: oLog.userName || "Unknown User",
                userEmail: oLog.userEmail || "N/A",
                remarks: oLog.remarks || "No remarks provided"
              };
            });

            var initiatorIndex = aProcessedData.findIndex(function (item) {
              return item.role.toLowerCase().includes("initiator");
            });

            if (initiatorIndex > -1) {
              var initiatorEntry = aProcessedData.splice(initiatorIndex, 1)[0];
              aProcessedData.push(initiatorEntry);
            }

            var oJSONModel = new sap.ui.model.json.JSONModel({
              results: aProcessedData
            });
            oView.setModel(oJSONModel, "timelinesslogdata");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load process log data.", { position: "bottom center" });
          console.error("Error fetching timeliness data:", oError);
        }
      });
    },

    formatTimelineTitle: function (role, userName, userEmail) {
      return role + " " + userName + " (" + userEmail + ")";
    },

    onDeleteTabAttachment: function (oEvent) {
      var oContext = oEvent.getSource().getBindingContext("UploadDocSrvTabData");
      var sPath = oContext.getPath();
      var oModel = this.getView().getModel("UploadDocSrvTabData");
      var aRows = oModel.getProperty("/attachments");

      var iIndex = parseInt(sPath.split("/").pop());
      aRows.splice(iIndex, 1);
      oModel.setProperty("/attachments", aRows);
      MessageBox.success("Attachment deleted successfully.");
    },

    _removeAttachmentFromLocal: function (oModel, sID, sFileName) {
      var aAttachments = oModel.getProperty("/attachments");
      var iIndex = aAttachments.findIndex(o => o.ID === sID);
      if (iIndex !== -1) {
        aAttachments.splice(iIndex, 1);
        oModel.setProperty("/attachments", aAttachments);
        oModel.refresh(true);
        MessageToast.show(`File '${sFileName}' deleted successfully`);
      }
    },

    _downloadLocalAttachment: function (oAttachment, sFileName) {
      if (!oAttachment || !oAttachment.content) {
        MessageToast.show("No file content available for download");
        return;
      }
      this._downloadBase64(oAttachment.content, sFileName);
    },

    _downloadBase64: function (sBase64Content, sFileName) {
      try {
        var sBase64Data = sBase64Content.split(',')[1];
        var sMimeType = sBase64Content.split(';')[0].split(':')[1];
        var byteCharacters = atob(sBase64Data);
        var byteNumbers = new Array(byteCharacters.length);
        for (var i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        var blob = new Blob([byteArray], { type: sMimeType });
        var url = URL.createObjectURL(blob);

        var link = document.createElement("a");
        link.href = url;
        link.download = sFileName;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);

        sap.m.MessageToast.show(`Downloading ${sFileName}`);
      } catch (e) {
        sap.m.MessageBox.error(`Error while downloading ${sFileName}`);
      }
    },

    _validateSubmitFormFields: function () {
      var that = this;
      var isValid = true;

      var requiredInputIds = [
        "costApprovalProjectInput",
        "costApprovalErNumberInput",
        "costApprovalChangeDescriptionInput",
        "costApprovalModelInput",
        "costApprovalProjectDescriptionInput",
        "costApprovalReasonForChangeInput",
        "costApprovalAnnualCostImpactInput",
        "costApprovalCostImpactBasisInput",
        "costApprovalTestingCapexDetailsInput",
        "costApprovalCostImpactLandedInput",
        "costApprovalAggregateComboBox",
        "costApprovalWarrantyCostComboBox",
        "costApprovalFieldQualityComboBox",
        "costApprovalPveLeadComboBox",
        "costApprovalBudgetProvisionComboBox",
        "costApprovalChangeCategoryComboBox",
        "costApprovalApplicableModelsComboBox"
      ];

      requiredInputIds.forEach(function (id) {
        var input = that.byId(id);
        if (input && (!input.getValue || input.getValue().trim() === "")) {
          input.setValueState("Error");
          input.setValueStateText("This field is required.");
          isValid = false;
        } else if (input) {
          input.setValueState("None");
        }
      });

      return isValid;

    },

    _validateSaveFormFields: function () {
      var that = this;
      var isAnyFieldFilled = false;
      var firstEmptyControl = null;

      var requiredInputIds = [
        "costApprovalProjectInput",
        "costApprovalErNumberInput",
        "costApprovalChangeDescriptionInput",
        "costApprovalModelInput",
        "costApprovalProjectDescriptionInput",
        "costApprovalReasonForChangeInput",
        "costApprovalAnnualCostImpactInput",
        "costApprovalCostImpactBasisInput",
        "costApprovalTestingCapexDetailsInput",
        "costApprovalCostImpactLandedInput",
        "costApprovalAggregateComboBox",
        "costApprovalWarrantyCostComboBox",
        "costApprovalFieldQualityComboBox",
        "costApprovalPveLeadComboBox",
        "costApprovalBudgetProvisionComboBox",
        "costApprovalChangeCategoryComboBox",
        "costApprovalApplicableModelsComboBox"
      ];

      requiredInputIds.forEach(function (id) {
        var control = that.byId(id);
        if (!control) return;

        var value = "";

        if (control.getValue) {
          value = control.getValue().trim();
        } else if (control.getSelectedKey) {
          value = control.getSelectedKey().trim();
        } else if (control.getSelected) {
          value = control.getSelected() ? "X" : "";
        }

        if (value) {
          isAnyFieldFilled = true;
          control.setValueState("None");
        } else {
          control.setValueState("None"); 
          if (!firstEmptyControl) {
            firstEmptyControl = control;
          }
        }
      });

      if (!isAnyFieldFilled && firstEmptyControl) {
        firstEmptyControl.setValueState("Error");
        firstEmptyControl.setValueStateText("Please fill at least one required field.");
        sap.m.MessageToast.show("Please fill at least one required field.");
        return false;
      }

      return true;
    },


    onSubmitCostApprovalform: function () {
      if (this._validateSubmitFormFields()) {
        var oView = this.getView();
        oView.getModel("viewenableddatacheck").setProperty("/remarkModel", "");
        oView.getModel("viewenableddatacheck").setProperty("/rejectbuttonvisiblity", false);
        oView.getModel("viewenableddatacheck").setProperty("/enableRowActions", true);
        oView.getModel("viewenableddatacheck").setProperty("/holdbuttonvisiblity", false);
        oView.getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblity", false);
        this._oRemarkDialog.open();
      } else {
        sap.m.MessageToast.show("Please fill all required fields before submitting.");
      }
    },


    _buildRequestPayload: function () {
      const oView = this.getView();
      const oPartsModel = oView.getModel("partsModel")?.getData() || {};
      const parts = oPartsModel.parts || [];
 
      return {
        project: oView.byId("costApprovalProjectInput")?.getValue() || "",
        models: oView.byId("costApprovalModelInput")?.getValue() || "",
        erNumber: oView.byId("costApprovalErNumberInput")?.getValue() || "",
        projectDesc: oView.byId("costApprovalProjectDescriptionInput")?.getValue() || "",
        changeDesc: oView.byId("costApprovalChangeDescriptionInput")?.getValue() || "",
        reason: oView.byId("costApprovalReasonForChangeInput")?.getValue() || "",
        annualImpact: parseFloat(oView.byId("costApprovalAnnualCostImpactInput")?.getValue()) || 0,
        toolingCapex: parseFloat(oView.byId("costApprovalTestingCapexDetailsInput")?.getValue()) || 0,
        aggregate: oView.byId("costApprovalAggregateComboBox")?.getSelectedKey() || "",
        budgetProvision: oView.byId("costApprovalBudgetProvisionComboBox")?.getSelectedKey() || "",
        warrantyCost: oView.byId("costApprovalWarrantyCostComboBox")?.getSelectedKey() || "",
        changeCategory: oView.byId("costApprovalChangeCategoryComboBox")?.getSelectedKey() || "",
        warrantyRemarks: oView.byId("costApprovalWarrantyCostRemarksInput")?.getValue() || "",
        costImpactBasic: parseFloat(oView.byId("costApprovalCostImpactBasisInput")?.getValue()) || 0,
        costImpactLanded: parseFloat(oView.byId("costApprovalCostImpactLandedInput")?.getValue()) || 0,
        fieldQuality: oView.byId("costApprovalFieldQualityComboBox")?.getSelectedKey() || "",
        applicableModels: oView.byId("costApprovalApplicableModelsComboBox")?.getSelectedKey() || "",
        pveLead: oView.byId("costApprovalPveLeadComboBox")?.getSelectedKey() || "",
        verifiedBy: oView.byId("costApprovalVerifiedByInput")?.getValue() || "Initiator",
        ptd_cdmm: oView.byId("costApprovalPtdCdmmCheckBox")?.getSelected(),
        parts: parts
      };
    },


    onSaveCostApprovalform: function () {
      if (this._validateSaveFormFields()) {
        this.handleSaveRequest();
      } else {
        sap.m.MessageToast.show("Please fill any required field before saving.");
      }
    },

    onSubmitRemarksData: function () {
      if (this._validateSubmitFormFields()) {
        this.handleSubmitRequest();
        this._oRemarkDialog.close();
      } else {
        sap.m.MessageToast.show("Please fill all required fields before submitting.");
      }
    },
    onCloseRemarksFregment: function () {
      this._oRemarkDialog.close();
    },

   
    handleSaveRequest: function () {
      const oView = this.getView();
      const oModel = this.getOwnerComponent().getModel("approvalservicev2");
      const that = this;
      const reqId = this._reqIDData;
      const remarks = oView.getModel("viewenableddatacheck").getProperty("/remarkModel");
      const oPayload = this._buildRequestPayload();

      const oRequestPayload = {
        status: "Draft",
        type: "P24",
        stage: "Initiator",
        approvalDtl: oPayload
      };

      oView.setBusy(true);

      if (!reqId) {
        oModel.create("/Requests", oRequestPayload, {
          success: function (oData) {
            that._reqIDData = oData.reqID;
            that.attachmentuploadFilesData(oData.reqID);
            let oRequestDataModel = that.getOwnerComponent().getModel("RequestDataModel");
            if (!oRequestDataModel) {
              oRequestDataModel = new sap.ui.model.json.JSONModel();
              that.getOwnerComponent().setModel(oRequestDataModel, "RequestDataModel");
            }
            oRequestDataModel.setData(oData);

            oView.setBusy(false);
            sap.m.MessageBox.success("CAP No " + oData.refNo + " created and saved in Draft.", {
              title: "Save Successful",
              onClose: function () {
                that._oRemarkDialog.close();
              }
            });
          },
          error: function (oError) {
            oView.setBusy(false);
            sap.m.MessageBox.error("Create (Save) failed: " + oError.message);
          }
        });
      } else {
        oModel.update("/Requests('" + reqId + "')", oRequestPayload, {
          success: function (oData) {
            that.attachmentuploadFilesData(reqId);
            oView.setBusy(false);

            sap.m.MessageBox.success("CAP No " + reqId + " updated and saved in Draft.", {
              title: "Update Successful",
              onClose: function () {
                that._oRemarkDialog.close();
              }
            });
          },
          error: function (oError) {
            oView.setBusy(false);
            sap.m.MessageBox.error("Update (Save) failed: " + oError.message);
          }
        });
      }
    },

    handleSubmitRequest: function () {
      const oView = this.getView();
      const oModel = this.getOwnerComponent().getModel("approvalservicev2");
      const that = this;
      const reqId = this._reqIDData;
      const remarks = oView.getModel("viewenableddatacheck").getProperty("/remarkModel");
      const oPayload = this._buildRequestPayload();

      const oRequestPayload = {
        status: "Pending",
        type: "P24",
        remarks: remarks,
        stage: "PVE-LEAD", 
        approvalDtl: oPayload
      };

      oView.setBusy(true);

      if (!reqId) {
        oModel.create("/Requests", oRequestPayload, {
          success: function (oData) {
            that._reqIDData = oData.reqID;
            that.attachmentuploadFilesData(oData.reqID);

            let oRequestDataModel = that.getOwnerComponent().getModel("RequestDataModel");
            if (!oRequestDataModel) {
              oRequestDataModel = new sap.ui.model.json.JSONModel();
              that.getOwnerComponent().setModel(oRequestDataModel, "RequestDataModel");
            }
            oRequestDataModel.setData(oData);

            oView.setBusy(false);
            that._oRemarkDialog.close();
            that.approverdatacheck(oData.reqID);

            sap.m.MessageBox.success("CAP No " + oData.refNo + " submitted successfully.", {
              title: "Submit Successful"
            });
          },
          error: function (oError) {
            oView.setBusy(false);
            sap.m.MessageBox.error("Create (Submit) failed: " + oError.message);
          }
        });
      } else {
        oModel.update("/Requests('" + reqId + "')", oRequestPayload, {
          success: function (oData) {
            that.attachmentuploadFilesData(reqId);
            oView.setBusy(false);
            that._oRemarkDialog.close();
            that.approverdatacheck(reqId);

            sap.m.MessageBox.success("CAP No " + reqId + " updated and submitted.", {
              title: "Submit Successful"
            });
          },
          error: function (oError) {
            oView.setBusy(false);
            sap.m.MessageBox.error("Update (Submit) failed: " + oError.message);
          }
        });
      }
    },

    approverdatacheck: function (reqid) {
      var oModel = this.getOwnerComponent().getModel("approvalservicev2");
      var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
      var that = this;

      var oApprovedPayload = {
        reqID: reqid,
        action: "Submit",
        remarks: remarkInput
      };
      // Show busy indicator
      sap.ui.core.BusyIndicator.show(0);

      oModel.create("/ApproveRequest", oApprovedPayload, {
        success: function (oData) {
          sap.ui.core.BusyIndicator.hide();
          //sap.m.MessageBox.success( oData.ApproveRequest.message || "Request submitted successfully!",
          sap.m.MessageBox.success("Request submitted successfully!",

            {
              title: "Approval Started",
              onClose: function () {
                if (that._basedNameUICap === "Costapproval") {
                  that.getOwnerComponent().getRouter().navTo("DashboardUI", { Name: "CostApproval" });
                }
              }
            }
          );
        },
        error: function (oError) {
          sap.ui.core.BusyIndicator.hide();
          sap.m.MessageBox.error("Failed in Approval Process.\nA technical error has occurred. Please contact the administrator");
        }
      });
    },


    
    onAddDocumentWDRS: function (oEvent) {
      const oFileUploader = oEvent.getSource();
      const aFiles = oEvent.getParameter("files");
      if (!aFiles || aFiles.length === 0) {
        sap.m.MessageToast.show("No file selected.");
        return;
      }

      const oModel = this.getView().getModel("UploadDocSrvTabDataCA");
      const aAttachments = oModel.getProperty("/attachments") || [];

      const reqID = this._reqIDData || "";
      const that = this;

      const oUserModel = this.getOwnerComponent().getModel("approvalservicev2");
      let sUploadedBy = "User";

      oUserModel.read("/getCurrentUser", {
        success: function (oData) {
          if (oData) {
            sUploadedBy = oData.name || oData.userID || "User";
          }

          that._processWDRSFileUpload(aFiles, aAttachments, oModel, oFileUploader, sUploadedBy);
        },
        error: function () {
          that._processWDRSFileUpload(aFiles, aAttachments, oModel, oFileUploader, sUploadedBy);
        }
      });
    },
    _processWDRSFileUpload: function (aFiles, aAttachments, oModel, oFileUploader, sUploadedBy) {
      const today = new Date();
      const uploadedOn = this._formatDate(today);

      for (let i = 0; i < aFiles.length; i++) {
        ((file, index) => {
          const reader = new FileReader();

          reader.onload = (e) => {
            const base64Content = e.target.result;

            aAttachments.push({
              ID: new Date().getTime().toString() + index,
              fileName: file.name,
              mimeType: file.type,
              content: base64Content,
              createdBy: sUploadedBy,
              createdAt: uploadedOn
            });

            if (index === aFiles.length - 1) {
              oModel.setProperty("/attachments", aAttachments);
              oModel.refresh(true);
              sap.m.MessageToast.show("Files uploaded: " + aFiles.length);
              oFileUploader.setValue("");
            }
          };

          reader.onerror = () => {
            sap.m.MessageToast.show("Error reading file: " + file.name);
          };

          reader.readAsDataURL(file);
        })(aFiles[i], i);
      }
    },
    _formatDate: function (oDate) {
      const dd = String(oDate.getDate()).padStart(2, '0');
      const mm = String(oDate.getMonth() + 1).padStart(2, '0');
      const yyyy = oDate.getFullYear();
      return `${dd}-${mm}-${yyyy}`;
    },

    /*******************
     * tableattachmentdelete, download
     *************/
    onDeleteTabAttchment: function (oEvent) {
      var oButton = oEvent.getSource();
      var oModel = this.getView().getModel("UploadDocSrvTabDataCA");
      var aAttachments = oModel.getProperty("/attachments");
      var sID = oButton.getCustomData().find(function (oData) {
        return oData.getKey() === "ID";
      }).getValue();
      var iIndex = aAttachments.findIndex(function (oItem) {
        return oItem.ID === sID;
      });
      if (iIndex === -1) return;

      var sFileName = aAttachments[iIndex].fileName;
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      var sPath = "/ReqAttachments(guid'" + sID + "')";
      var that = this;

      oModelV2.remove(sPath, {
        success: function () {
          that._removeAttachmentFromLocalModel(oModel, aAttachments, iIndex, sFileName);
          sap.m.MessageToast.show("Deleted " + sFileName, { position: "bottom center" });
        },
        error: function (oError) {
          that._removeAttachmentFromLocalModel(oModel, aAttachments, iIndex, sFileName);
          sap.m.MessageToast.show("Deleted " + sFileName, { position: "bottom center" });
          console.error("Error deleting attachment:", oError);
        }
      });
    },

    _removeAttachmentFromLocalModel: function (oModel, aAttachments, iIndex, sFileName) {
      aAttachments.splice(iIndex, 1);
      oModel.setProperty("/attachments", aAttachments);
      oModel.refresh(true);
    },
    onDownloadTabAttachment: function (oEvent) {
      var oButton = oEvent.getSource();
      var sID = oButton.getCustomData().find(function (oData) {
        return oData.getKey() === "ID";
      }).getValue();
      var sFileName = oButton.getCustomData().find(function (oData) {
        return oData.getKey() === "fileName";
      }).getValue();

      var oModel = this.getView().getModel("UploadDocSrvTabDataCA");
      var aAttachments = oModel.getProperty("/attachments") || [];
      var oAttachment = aAttachments.find(function (oItem) {
        return oItem.ID === sID;
      });

      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      var sPath = "/ReqAttachments(guid'" + sID + "')";
      var that = this;

      oModelV2.read(sPath, {
        success: function (oData) {
          if (oData && oData.__metadata && oData.__metadata.media_src) {
            var oLink = document.createElement("a");
            oLink.href = oData.__metadata.media_src;
            oLink.download = sFileName;
            document.body.appendChild(oLink);
            oLink.click();
            document.body.removeChild(oLink);
            sap.m.MessageToast.show("Downloading file from server: " + sFileName, { position: "bottom center" });
          } else {
            that._downloadLocalAttachment(oAttachment, sFileName);
          }
        },
        error: function () {
          that._downloadLocalAttachment(oAttachment, sFileName);
        }
      });
    },

    _downloadBase64File: function (sBase64Content, sFileName) {
      try {
        var sBase64Data = sBase64Content.split(',')[1];
        var sMimeType = sBase64Content.split(';')[0].split(':')[1];
        var byteCharacters = atob(sBase64Data);
        var byteNumbers = new Array(byteCharacters.length);
        for (var i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        var oBlob = new Blob([byteArray], { type: sMimeType });
        var sUrl = URL.createObjectURL(oBlob);

        var oLink = document.createElement("a");
        oLink.href = sUrl;
        oLink.download = sFileName;
        document.body.appendChild(oLink);
        oLink.click();
        document.body.removeChild(oLink);
        URL.revokeObjectURL(sUrl);
        sap.m.MessageToast.show("Downloading file: " + sFileName, { position: "bottom center" });
      } catch (e) {
        sap.m.MessageToast.show("Error downloading file: " + sFileName, { position: "bottom center" });
        console.error("Error downloading file:", e);
      }
    },

    _downloadLocalAttachment: function (oAttachment, sFileName) {
      if (!oAttachment || !oAttachment.content) {
        sap.m.MessageToast.show("Local file content not found for: " + sFileName, { position: "bottom center" });
        return;
      }
      this._downloadBase64File(oAttachment.content, sFileName);
    },
    onDeleteRowAttachmentWDRS: function () {
      const oTable = this.byId("documentTableInitiatecost");
      const aSelectedItems = oTable.getSelectedItems();
      const oModel = this.getView().getModel("UploadDocSrvTabDataCA");
      const aAttachments = oModel.getProperty("/attachments");

      if (!aSelectedItems.length) {
        sap.m.MessageToast.show("Please select at least one attachment to delete.");
        return;
      }

      sap.m.MessageBox.confirm("Do you want to delete the selected attachment(s)?", {
        actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
        onClose: (oAction) => {
          if (oAction === sap.m.MessageBox.Action.OK) {
            const aSelectedIds = aSelectedItems.map(oItem =>
              oItem.getBindingContext("UploadDocSrvTabDataCA").getProperty("ID")
            );

            const aNewAttachments = aAttachments.filter(oAttachment =>
              !aSelectedIds.includes(oAttachment.ID)
            );

            oModel.setProperty("/attachments", aNewAttachments);
            oTable.removeSelections();
            sap.m.MessageToast.show("Selected attachment(s) deleted.");
          }
        }
      });
    },
    // onResetForm: function () {
    //   // Reset RequestDataModel
    //   this.getOwnerComponent().getModel("RequestDataModel").setData({
    //     refNo: "",
    //     approvalDtl: {
    //       capNumber: "",
    //       project: "",
    //       erNumber: "",
    //       changeDesc: "",
    //       models: "",
    //       projectDesc: "",
    //       reason: "",
    //       annualImpact: "",
    //       aggregate: "",
    //       warrantyCost: "",
    //       warrantyRemarks: "",
    //       costImpactBasic: "",
    //       fieldQuality: "",
    //       pveLead: "",
    //       toolingCapex: "",
    //       budgetProvision: "",
    //       changeCategory: "",
    //       verifiedBy: "",
    //       ptd_cdmm:false,
    //       costImpactLanded: "",
    //       applicableModels: ""
    //     }
    //   });

    //   // Reset partsModel
    //   this.getView().getModel("partsModel").setData({
    //     parts: []
    //   });

    //   // Reset UploadDocSrvTabData
    //   this.getView().getModel("UploadDocSrvTabData").setData({
    //     attachments: []
    //   });

    //   // Reset visibility and enabled states
    //   this.getView().getModel("viewenableddatacheck").setData({
    //     enableRowActions: true,
    //     approvebuttonvisiblity: false
    //   });

    //   // Reset CheckBox
    //   this.getView().byId("costApprovalPtdCdmmCheckBox").setSelected(false);

    //   // Refresh bindings to update the UI
    //   this.getView().getModel("RequestDataModel").refresh();
    //   this.getView().getModel("partsModel").refresh();
    //   this.getView().getModel("UploadDocSrvTabData").refresh();
    //   this.getView().getModel("viewenableddatacheck").refresh();

    //   // Optional: Clear FileUploader
    //   var oFileUploader = this.getView().byId("costApprovalFileUploader");
    //   if (oFileUploader) {
    //     oFileUploader.clear();
    //   }

    //   // Optional: Reset ComboBox selections explicitly if needed
    //   var aComboBoxes = [
    //     "costApprovalAggregateComboBox",
    //     "costApprovalWarrantyCostComboBox",
    //     "costApprovalFieldQualityComboBox",
    //     "costApprovalPveLeadComboBox",
    //     "costApprovalBudgetProvisionComboBox",
    //     "costApprovalChangeCategoryComboBox",
    //     "costApprovalApplicableModelsComboBox"
    //   ];

    //   aComboBoxes.forEach(function (sComboBoxId) {
    //     var oComboBox = this.getView().byId(sComboBoxId);
    //     if (oComboBox) {
    //       oComboBox.setSelectedKey("");
    //     }
    //   }, this);

    //   // Optional: Show a success message
    //   sap.m.MessageToast.show("Form has been reset successfully.");
    // },

    onResetForm: function () {
      const oView = this.getView();
      const oEmptyRequestData = {
        reqID: "",
        refNo: "",
        status: "",
        stage: "",
        remarks: "",
        approvalDtl: {
          capNumber: "",
          project: "",
          erNumber: "",
          changeDesc: "",
          models: "",
          projectDesc: "",
          reason: "",
          annualImpact: "",
          aggregate: "",
          warrantyCost: "",
          warrantyRemarks: "",
          costImpactBasic: "",
          fieldQuality: "",
          pveLead: "",
          toolingCapex: "",
          budgetProvision: "",
          changeCategory: "",
          verifiedBy: "",
          ptd_cdmm: false,
          costImpactLanded: "",
          applicableModels: ""
        }
      };
      
      // Ensure model exists and assign default data
      let oRequestDataModel = this.getOwnerComponent().getModel("RequestDataModel");
      if (!oRequestDataModel) {
        oRequestDataModel = new sap.ui.model.json.JSONModel();
        this.getOwnerComponent().setModel(oRequestDataModel, "RequestDataModel");
      }
      oRequestDataModel.setData(oEmptyRequestData);
      
      oView.getModel("partsModel").setData({ parts: [] });
      oView.getModel("viewenableddatacheck").setData({
        enableRowActions: true,
        approvebuttonvisiblity: false
      });

      let rcapNo = oView.byId("costApprovalAdpdInpwutRequestID").setText("");
      const oCheckBox = oView.byId("costApprovalPtdCdmmCheckBox");
      if (oCheckBox) {
        oCheckBox.setSelected(false);
      }
      const aInputFields = [
        "costApprovalProjectInput",
        "costApprovalModelInput",
        "costApprovalErNumberInput",
        "costApprovalProjectDescriptionInput",
        "costApprovalChangeDescriptionInput",
        "costApprovalReasonForChangeInput",
        "costApprovalAnnualCostImpactInput",
        "costApprovalTestingCapexDetailsInput",
        "costApprovalWarrantyCostRemarksInput",
        "costApprovalCostImpactBasisInput",
        "costApprovalCostImpactLandedInput",
        "costApprovalPveLeadInput",
        "costApprovalVerifiedByInput"
      ];
      aInputFields.forEach(function (sInputId) {
        const oInput = oView.byId(sInputId);
        if (oInput) {
          oInput.setValue("");
          oInput.setValueState("None");
          oInput.setValueStateText("");
        }
      });
      const oVerifiedBy = oView.byId("costApprovalVerifiedByInput");
      if (oVerifiedBy) {
        oVerifiedBy.setValue("");
      }
      const aComboBoxes = [
        "costApprovalAggregateComboBox",
        "costApprovalWarrantyCostComboBox",
        "costApprovalFieldQualityComboBox",
        "costApprovalPveLeadComboBox",
        "costApprovalBudgetProvisionComboBox",
        "costApprovalChangeCategoryComboBox",
        "costApprovalApplicableModelsComboBox"
      ];

      aComboBoxes.forEach(function (sComboBoxId) {
        const oComboBox = oView.byId(sComboBoxId);
        if (oComboBox) {
          oComboBox.setSelectedKey("");
          oComboBox.setValueState("None");
          oComboBox.setValueStateText("");
        }
      });

      const oFileUploader = oView.byId("costApprovalFileUploader");
      if (oFileUploader) {
        oFileUploader.clear();
      }

      oView.getModel("partsModel").refresh();
      oView.getModel("viewenableddatacheck").refresh();

    },

    onApprovedCostApprovalform: function () {
      const oView = this.getView();
      const oModel = oView.getModel("viewenableddatacheck");

      oModel.setProperty("/remarkModel", "");
      oModel.setProperty("/enableRowActions", false);
      oModel.setProperty("/rejectbuttonvisiblity", false);
      oModel.setProperty("/approvebuttonvisiblity", true);
      oModel.setProperty("/currentAction", "Approved");

      this._oRemarkDialog.open();
    },

    onRejectCostApprovalForm: function () {
      const oView = this.getView();
      const oModel = oView.getModel("viewenableddatacheck");

      oModel.setProperty("/remarkModel", "");
      oModel.setProperty("/enableRowActions", false);
      oModel.setProperty("/rejectbuttonvisiblity", true);
      oModel.setProperty("/approvebuttonvisiblity", false);
       oModel.setProperty("/currentAction", "Rejected");

      this._oRemarkDialog.open();
    },

    onApprovedData: function () {
      const oView = this.getView();
      const oModel = this.getOwnerComponent().getModel("approvalservicev2");
      const that = this;
      const remarks = oView.getModel("viewenableddatacheck").getProperty("/remarkModel");

      if (!remarks) {
        sap.m.MessageToast.show("Remarks are mandatory.");
        return;
      }

      const oPayload = this._buildRequestPayload();
      const oRequestPayload = {
        //status: "Pending",
        type: "P24",
        remarks: remarks,
        // pendingWithName: "PVE LEAD",
        // stage: "PVE-LEAD",
        approvalDtl: oPayload
      };

      oView.setBusy(true);
      const reqId = this._reqIDData;

      const fnSetODataToModel = function (oData) {
        const oComponent = that.getOwnerComponent();
        let oRequestDataModel = oComponent.getModel("RequestDataModel");
        if (!oRequestDataModel) {
          oRequestDataModel = new sap.ui.model.json.JSONModel();
          oComponent.setModel(oRequestDataModel, "RequestDataModel");
        }
        oRequestDataModel.setData(oData);

        
        oView.getModel("viewenableddatacheck").setProperty("/requestStatus", oData.status);
      };

      if (reqId) {
      
        oModel.update(`/Requests('${reqId}')`, oRequestPayload, {
          success: function (oData) {
            that.attachmentuploadFilesData(reqId);
            fnSetODataToModel(oData);
            that._handleDecision("Approve", remarks, reqId);
            that._oRemarkDialog.close();
            oView.setBusy(false);
          },
          error: function (oError) {
            oView.setBusy(false);
            sap.m.MessageBox.error("Update (Approval) failed: " + oError.message);
          }
        });
      } else {
        // Create
        oModel.create("/Requests", oRequestPayload, {
          success: function (oData) {
            const newReqId = oData.reqID;
            that._reqIDData = newReqId;
            that.attachmentuploadFilesData(newReqId);
            fnSetODataToModel(oData);
            that._handleDecision("Approve", remarks, newReqId);
            that._oRemarkDialog.close();
            oView.setBusy(false);
          },
          error: function (oError) {
            oView.setBusy(false);
            sap.m.MessageBox.error("Create (Approval) failed: " + oError.message);
          }
        });
      }
    },

    onRejectdData: function () {
      const oView = this.getView();
      const oModel = this.getOwnerComponent().getModel("approvalservicev2");
      const that = this;
      const remarks = oView.getModel("viewenableddatacheck").getProperty("/remarkModel");

      if (!remarks) {
        sap.m.MessageToast.show("Remarks are mandatory.");
        return;
      }

      const oPayload = this._buildRequestPayload();
      const oRequestPayload = {
        //status: "Pending",
        type: "P24",
        remarks: remarks,
        //  pendingWithName: "PVE LEAD",
        //  stage: "PVE-LEAD",
        approvalDtl: oPayload
      };

      oView.setBusy(true);
      const reqId = this._reqIDData;

      const fnSetODataToModel = function (oData) {
        const oComponent = that.getOwnerComponent();
        let oRequestDataModel = oComponent.getModel("RequestDataModel");
        if (!oRequestDataModel) {
          oRequestDataModel = new sap.ui.model.json.JSONModel();
          oComponent.setModel(oRequestDataModel, "RequestDataModel");
        }
        oRequestDataModel.setData(oData);

       
        oView.getModel("viewenableddatacheck").setProperty("/requestStatus", oData.status);
      };

      if (reqId) {
        
        oModel.update(`/Requests('${reqId}')`, oRequestPayload, {
          success: function (oData) {
            that.attachmentuploadFilesData(reqId);
            fnSetODataToModel(oData);
            that._handleDecision("Reject", remarks, reqId);
            that._oRemarkDialog.close();
            oView.setBusy(false);
          },
          error: function (oError) {
            oView.setBusy(false);
            sap.m.MessageBox.error("Update (Rejection) failed: " + oError.message);
          }
        });
      } else {
        // Create
        oModel.create("/Requests", oRequestPayload, {
          success: function (oData) {
            const newReqId = oData.reqID;
            that._reqIDData = newReqId;
            that.attachmentuploadFilesData(newReqId);
            fnSetODataToModel(oData);
            that._handleDecision("Reject", remarks, newReqId);
            that._oRemarkDialog.close();
            oView.setBusy(false);
          },
          error: function (oError) {
            oView.setBusy(false);
            sap.m.MessageBox.error("Create (Rejection) failed: " + oError.message);
          }
        });
      }
    },


    _handleDecision: function (action, remarks, reqID) {
      const oModel = this.getOwnerComponent().getModel("approvalservicev2");
      const that = this;

      const payload = {
        reqID: reqID,
        action: action,
        remarks: remarks
      };

      oModel.callFunction("/ApproveRequest", {
        method: "POST",
        urlParameters: payload,
        success: (oData) => {
          // sap.m.MessageToast.show(`Request ${action} successfully.`);
          sap.m.MessageBox.success(oData.ApproveRequest.message || "Request Approved Successfully!", {
            onClose: function () {
              // if (that._ApprovedCheck === "Approved") {
              //   sap.ui.core.BusyIndicator.hide();
              //   that.getOwnerComponent().getRouter().navTo("approverdashboard");
              // }
              const Approved = that._ApprovedCheck;

              // Optional: Remove this check if you want to always navigate
              if (Approved === "Approved" || Approved === "Rejected") {
                const oRouter = that.getOwnerComponent().getRouter();
                oRouter.navTo("approverdashboard", {}, true); // hard navigation
              }

            }
          });

        },
        error: (err) => {
          sap.m.MessageToast.show("Error while processing action.");
          console.error("Action Error:", err);
        }
      });
    }

  });
});
