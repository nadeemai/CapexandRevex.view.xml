sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/core/util/Export",
    "sap/ui/core/util/ExportTypeCSV",
    "com/mmapprovalhub/approvalhub/formatter/formatter",



], (Controller, MessageToast, MessageBox, Export, ExportTypeCSV, formatter) => {
    "use strict";

    return Controller.extend("com.mmapprovalhub.approvalhub.controller.DashboardUI", {
        formatter: formatter,
        onInit() { 
            var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            oRouter.getRoute("DashboardUI").attachPatternMatched(this._onRouteDashboardController, this);
            this.CreateDialog = sap.ui.xmlfragment("com/mmapprovalhub/approvalhub/Fragments/CreateDialog", this);
            this.getView().addDependent(this.CreateDialog);

        },

        onListItemPress: function(oEvent){
            let basedNameUI =    this._basedNameUI;
            var oSelectedItem = oEvent.getParameter("listItem");
            var oContext = oSelectedItem.getBindingContext("dashboardtabledata");
            var oData = oContext.getObject();
            //var sRefNo = oData.refNo;
            var sRefNo = oData.reqID;
            var sType = oData.type;
            sap.ui.core.BusyIndicator.show(0);

            if(basedNameUI === "ADPD"){
                this.onInitiationChangeReqid("ADPD", sRefNo);
                sap.ui.core.BusyIndicator.hide();

                // var oRouter = this.getOwnerComponent().getRouter();
                // oRouter.navTo("adpd", {
                //     basedNameUIadpd: "ADPD"
                // });
                
            }else if(basedNameUI === "SSFD"){
                sap.ui.core.BusyIndicator.hide();
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("SanctionfdRef", {
                    basedNameUISSFD: "SSFD",
                    reqID: sRefNo 
                });
           
            }else if(basedNameUI === "capexrevex"){
                sap.ui.core.BusyIndicator.hide();
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("capexrevex", {
                    basedNameUI: "capexrevex"
                });
            }else if(basedNameUI === "NBRF"){
                sap.ui.core.BusyIndicator.hide();
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("NewBudgetRequestFormRef", {
                    basedNameUINBRF: "NBRF",
                    reqID: sRefNo 
                });
            }else if(basedNameUI === "CostApproval"){
            sap.ui.core.BusyIndicator.hide();
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("CostApprovalReqID", {
                basedNameUICap: "Costapproval",
                reqID: sRefNo 
            });
        // INTEGRATED PAYMENT MANAGEMENT PORTAL
        } else if (basedNameUI === "CAPEX_AND_REVEX") {
            sap.ui.core.BusyIndicator.hide();
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("CAPEX_AND_REVEXReqID", {
                basedNameUICap: "CAPEX_AND_REVEX",
                reqID: sRefNo
            });
        }        

        //Infra
        else if (basedNameUI === "INFRA") { 
            const oRouter = this.getOwnerComponent().getRouter(); 
            const refNo = oData.refNo || "";
            const subtype = refNo.split("-")[0].toLowerCase(); 
            const validSubtypes = ["frs", "crs", "srs", "wdrs"];
            if (!validSubtypes.includes(subtype)) {
                sap.m.MessageBox.error("Invalid subtype extracted from refNo.");
                sap.ui.core.BusyIndicator.hide();
                return;
            }
         
            const oSharedModel = this.getOwnerComponent().getModel("shared") || new sap.ui.model.json.JSONModel();
            oSharedModel.setProperty("/approvalType", subtype.toUpperCase());
            this.getOwnerComponent().setModel(oSharedModel, "shared");
        
            sap.ui.core.BusyIndicator.hide();
        
            oRouter.navTo("ISRFormRef", {
                type: subtype,       // "frs", "wdrs" 
                reqID: sRefNo        //  "REQ-IS-0001"
            });
        
        } 
        },

        onproceedForm: function(){
            let oninitiatevalue = sap.ui.getCore().byId("Initiationcombo").getValue();
            sap.ui.core.BusyIndicator.show(0);

            let basedNameUI =    this._basedNameUI;
            if(basedNameUI === "ADPD"){
                let oRadioGroupIn = sap.ui.getCore().byId("radiobuttonformdata");
                let iSelectedIndex = oRadioGroupIn.getSelectedIndex();
                if (iSelectedIndex === -1) {
                    sap.ui.core.BusyIndicator.hide();
                    MessageBox.information("Please select Note Approval or Forum Approval before proceeding.");
                    return;
                }
                if(oninitiatevalue === ""){
                    sap.ui.core.BusyIndicator.hide();
                    MessageBox.information("Please provide initiation before proceeding.");
                    return;
                }
                sap.ui.core.BusyIndicator.hide();
                localStorage.setItem("onInitiateValue", oninitiatevalue);
                this.onInitiationChange();
                // this.getView().byId("dashboardui").setTitle("AD PD Special Approval Dashboard");
            }else if(basedNameUI === "SSFD"){
                if(oninitiatevalue === ""){
                    sap.ui.core.BusyIndicator.hide();
                    MessageBox.information("Please provide initiation before proceeding.");
                    return;
                }
                localStorage.setItem("onInitiateValue", oninitiatevalue);
                sap.ui.core.BusyIndicator.hide();
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("Sanctionfd", {
                    basedNameUISSFD: "SSFD"
                });
            // INTEGRATED PAYMENT MANAGEMENT PORTAL
            // }else if(basedNameUI === "CAPEX AND REVEX"){
            //     if(oninitiatevalue === ""){
            //         sap.ui.core.BusyIndicator.hide();
            //         // MessageBox.information("Please provide initiation before proceeding.");
            //         return;
            //     }
            //     sap.ui.core.BusyIndicator.hide();
            //     // localStorage.setItem("onInitiateValue", oninitiatevalue);
            //     var oRouter = this.getOwnerComponent().getRouter();
            //     oRouter.navTo("CAPEX AND REVEX", {
            //         basedNameUI: "CAPEX AND REVEX"
            //     });
            }else if(basedNameUI === "CostApproval"){
                   
                    sap.ui.core.BusyIndicator.hide(); 
                    var oRouter = this.getOwnerComponent().getRouter();
                    oRouter.navTo("CostApproval", {
                        basedNameUICap: "Costapproval"
                    });
                
            }else if(basedNameUI === "NBRF"){
                sap.ui.core.BusyIndicator.hide();
                var oRadioGroup = sap.ui.getCore().byId("radiobuttonBudgetformdata");
                var selectedIndex = oRadioGroup.getSelectedIndex();
                var oRouter = this.getOwnerComponent().getRouter();
            
                if (selectedIndex === 0) {
                    oRouter.navTo("NewBudgetRequestForm", {
                        formType: "NBRF"
                    });
                } else if (selectedIndex === 1) {
                    oRouter.navTo("NewBudgetRequestForm", {
                        formType: "ABRF"
                    });
                }

                oRadioGroup.setSelectedIndex(-1);

            // INTEGRATED PAYMENT MANAGEMENT PORTAL
            }else if (basedNameUI === "CAPEX_AND_REVEX") {
                sap.ui.core.BusyIndicator.hide();
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("CAPEX_AND_REVEX", {
                    basedNameUICap: "CAPEX_AND_REVEX"
                });
            }
            
            //Infra navigation 
    else if (basedNameUI === "INFRA") {
                
    const oInfraGroup = sap.ui.getCore().byId("radiobuttonformdataInfra");
    const iInfraIndex = oInfraGroup.getSelectedIndex();

    // Check if a radio button is selected
    if (iInfraIndex === -1) {
        sap.m.MessageBox.warning("Please select an option before proceeding.");
        sap.ui.core.BusyIndicator.hide();
        return;  
    }

    const sInfraText = oInfraGroup.getAggregation("buttons")[iInfraIndex].getText();
    let sRouteKey = "";

    switch (sInfraText) {
        case "Fuel Request":
            sRouteKey = "frs";
            break;
        case "Consumable Request":
            sRouteKey = "crs";
            break;
        case "Stationary Request":
            sRouteKey = "srs";
            break;
        case "Waste Disposal Request":
            sRouteKey = "wdrs";
            break;
        default:
            sap.m.MessageBox.error("Invalid selection.");
            return;
    }

    const oSharedModel = this.getOwnerComponent().getModel("shared") || new sap.ui.model.json.JSONModel();
    oSharedModel.setProperty("/approvalType", sRouteKey);
    this.getOwnerComponent().setModel(oSharedModel, "shared");

    sap.ui.core.BusyIndicator.hide();
    this.getOwnerComponent().getRouter().navTo("ISRForm", { type: sRouteKey }, true);

            }
        },
        onRadioSelectionNBRF: function (oEvent) {
            var oRadioGroup = sap.ui.getCore().byId("radiobuttonBudgetformdata");
            var selectedIndex = oRadioGroup.getSelectedIndex();
            var oProceedBtn = sap.ui.getCore().byId("nextButton");

                if (selectedIndex !== -1) {
                    oProceedBtn.setEnabled(true);
                } else {
                    oProceedBtn.setEnabled(false);
                }
        },
        onSentBackPress: function () {
            var oTable = this.byId("pendingWithMeTable");
            var oBinding = oTable.getBinding("items");
            var oFilter = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "Sent Back");
            oBinding.filter([oFilter]);
        },
        onDraftPress: function () {
            var oTable = this.byId("pendingWithMeTable");
            var oBinding = oTable.getBinding("items");
            var oFilter = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "Draft");
            oBinding.filter([oFilter]);
        },
        onAllRequestsPress: function () {
            var oTable = this.byId("pendingWithMeTable");
            var oBinding = oTable.getBinding("items");
            oBinding.filter([]); 
        },
        onInProgressPress: function () {
            var oTable = this.byId("pendingWithMeTable");
            var oBinding = oTable.getBinding("items");
            var oFilter = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "Pending");
            oBinding.filter([oFilter]);
        },
        onApprovedPress: function () {
            var oTable = this.byId("pendingWithMeTable");
            var oBinding = oTable.getBinding("items");
            var oFilter = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "Approved");
            oBinding.filter([oFilter]);
        },   
             
        _onRouteDashboardController: async function(oEvent) {
            var oTileModel = new sap.ui.model.json.JSONModel({
                MyDraft: 0,
                SentBack: 0,
                Rejected: 0,
                PendingRequest: 0,
                AllRequests: 0
            });
            this.getView().setModel(oTileModel, "tileModel");
            var oArgs = oEvent.getParameter("arguments");
            var NameUI = oArgs.Name;
            this._basedNameUI = NameUI;
            let DataName = "";
            var oView = this.getView();
            if (NameUI === "ADPD") {
                oView.byId("dashboardui").setTitle("AD PD Special Dashboard");
                DataName = "ADPD";
            } else if (NameUI === "SSFD") {
                oView.byId("dashboardui").setTitle("Special Sanction FD Dashboard");
                DataName = "SSFD";
            // // INTEGRATED PAYMENT MANAGEMENT PORTAL
            // } else if (NameUI === "capexrevex") {
            //     oView.byId("dashboardui").setTitle("FD CAPEX AND REVEX");
            //     DataName = "CAPEX AND REVEX";
            }else if(NameUI === "NBRF"){
                this.getView().byId("dashboardui").setTitle("Budget Request Dashboard");
                 DataName = "NAB"
            } else if (NameUI === "CostApproval") {
            oView.byId("dashboardui").setTitle("Cost Approval Dashboard");
            DataName = "P24";
        } else if (NameUI == "INFRA") {
                oView.byId("dashboardui").setTitle("Infra Service Request");
                DataName = "ISR";
            // INTEGRATED PAYMENT MANAGEMENT PORTAL
            }else if (NameUI === "CAPEX_AND_REVEX") {
                oView.byId("dashboardui").setTitle("FD CAPEX AND REVEX");
                DataName = "P25";
            }

            try {
                await this._loadControlValues(DataName);
                    await this._loadDashboardData(DataName);
            } catch (error) {
                // console.error("Error during data loading:", error);
                sap.m.MessageToast.show("Error loading dashboard data.");
            }
        },

        _loadControlValues: function(DataName) {
            return new Promise((resolve, reject) => {
                var oView = this.getView();
                var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
        
                oModelV2.read("/ControlValues", {
                    urlParameters: {
                        "$filter": "category eq '" + DataName + "'"
                    },
                    success: function(oData) {
                        if (oData) {
                            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
                            oView.setModel(oJSONModel, "SelectInitiationData");
                            resolve();
                        } else {
                            reject("No data received from ControlValues.");
                        }
                    },
                    error: function(oError) {
                        reject(oError);
                    }
                });
            });
        }, 
        onLiveSearchRefrence_Number: function() {
            let oTable = this.byId("pendingWithMeTable");
            let oBinding = oTable.getBinding("items");
            let aFilters = [];
            let sRequestIDValue = this.byId("Refrence_Number").getValue();
            if (sRequestIDValue) {
                aFilters.push(new sap.ui.model.Filter("refNo", sap.ui.model.FilterOperator.Contains, sRequestIDValue));
            }
            oBinding.filter(aFilters.length > 0 ? new sap.ui.model.Filter(aFilters, false) : []);
        },
       
        onClearFilters: function () {
            let oView = this.getView();
            let aControlIds = [
                "Refrence_Number",
                "Pending_withsearcg",
                "Created_ByDash",
                "Created_OnDash",
                "dashboardfilterStageid",
                "dashboardfilterstatusid"
            ];
            aControlIds.forEach(function (sId) {
                var oControl = oView.byId(sId);
                if (oControl) {
                    if (oControl.setValue) {
                        oControl.setValue("");
                    }
                    if (oControl.setSelectedKeys) {
                        oControl.setSelectedKeys([]);
                    }
                }
            });
            var oTable = oView.byId("pendingWithMeTable");
            var oBinding = oTable.getBinding("items");
            if (oBinding) {
                oBinding.filter([]); 
            }
        },                       
        onFilterStatusChange: function () {
            var that = this;
            var aSelectedStatuses = that.byId("dashboardfilterstatusid").getSelectedKeys() || [];
            var aSelectedStages = that.byId("dashboardfilterStageid").getSelectedKeys() || [];
            var oTable = this.byId("pendingWithMeTable");
            if (!oTable) {
                console.error("Table not found!");
                return;
            }
            var oBinding = oTable.getBinding("items");
            if (!oBinding) {
                console.error("Table binding not found!");
                return;
            }
            var aFilters = [];
          
            if (aSelectedStages.length > 0) {
                var aStageFilters = aSelectedStages.map(function (sStage) {
                    return new sap.ui.model.Filter("stage", sap.ui.model.FilterOperator.EQ, sStage);
                });
                aFilters.push(new sap.ui.model.Filter(aStageFilters, false));
            }
            if (aSelectedStatuses.length > 0) {
                var aStatusFilters = aSelectedStatuses.map(function (sStatus) {
                    return new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, sStatus);
                });
                aFilters.push(new sap.ui.model.Filter(aStatusFilters, false));
            }
            var oCombinedFilter = aFilters.length > 0 ? new sap.ui.model.Filter(aFilters, true) : null;
            oBinding.filter(oCombinedFilter);
        },

        onLiveSearchpending_with: function() {
            let oTable = this.byId("pendingWithMeTable");
            let oBinding = oTable.getBinding("items");
            let aFilters = [];
            let sRequestIDValue = this.byId("Pending_withsearcg").getValue();
            if (sRequestIDValue) {
                aFilters.push(new sap.ui.model.Filter("pendingWithName", sap.ui.model.FilterOperator.Contains, sRequestIDValue));
            }
            oBinding.filter(aFilters.length > 0 ? new sap.ui.model.Filter(aFilters, false) : []);
        },
        // onLiveSearchcreatedon: function() {
        //     let oTable = this.byId("pendingWithMeTable");
        //     let oBinding = oTable.getBinding("items");
        //     let aFilters = [];
        //     let sRequestIDValue = this.byId("Created_OnDash").getValue();
        //     if (sRequestIDValue) {
        //         aFilters.push(new sap.ui.model.Filter("createdAt", sap.ui.model.FilterOperator.Contains, sRequestIDValue));
        //     }
        //     oBinding.filter(aFilters.length > 0 ? new sap.ui.model.Filter(aFilters, false) : []);
        // },
        onLiveSearchcreatedon: function() {
            let oTable = this.byId("pendingWithMeTable");
            let oBinding = oTable.getBinding("items");
            let aFilters = [];
        
            let oDate = this.byId("Created_OnDash").getDateValue(); 
        
            if (oDate) {
                let oStartDate = new Date(oDate);
                oStartDate.setHours(0, 0, 0, 0);
                let oEndDate = new Date(oDate);
                oEndDate.setHours(23, 59, 59, 999);
                aFilters.push(new sap.ui.model.Filter("createdAt", sap.ui.model.FilterOperator.BT, oStartDate, oEndDate));
            }
        
            oBinding.filter(aFilters.length > 0 ? new sap.ui.model.Filter(aFilters, false) : []);
        },      
        onLiveSearchcreatedby: function() {
            let oTable = this.byId("pendingWithMeTable");
            let oBinding = oTable.getBinding("items");
            let aFilters = [];
            let sRequestIDValue = this.byId("Created_onDash_approval").getValue();
            if (sRequestIDValue) {
                aFilters.push(new sap.ui.model.Filter("createdBy", sap.ui.model.FilterOperator.Contains, sRequestIDValue));
            }
            oBinding.filter(aFilters.length > 0 ? new sap.ui.model.Filter(aFilters, false) : []);
        },
        
        _loadDashboardData: function(DataName) {
            return new Promise((resolve, reject) => {
                // var DataName = this._basedNameUI;
                // var DataName = DataName;
                // if(DataName === "NBRF"){
                //     DataName = "CR"
                // }
                var oView = this.getView();
                var oODataTablebinding = this.getOwnerComponent().getModel("approvalservicev2");
        
                oODataTablebinding.read("/Requests", {
                    success: function(oData) {
                        if (oData && oData.results) {

                            // Filter the data by type
                            // var filteredResults = oData.results.filter(item => item.type === DataName);

                              // Filter the data by type
                              var filteredResults = oData.results.filter(item => item.type === DataName);
        
                            // var oJSONModel = new sap.ui.model.json.JSONModel({ results: filteredResults });
                            // oView.setModel(oJSONModel, "dashboardtabledata");

                            var oJSONModel = new sap.ui.model.json.JSONModel({ results: filteredResults });
                            oView.setModel(oJSONModel, "dashboardtabledata");
        
                            // Initialize counters
                            var counts = {
                                Draft: 0,
                                InProgress: 0,
                                SentBack: 0,
                                Approved: 0,
                                AllRequests: filteredResults.length
                            };
        
                            // Count status-specific values
                            filteredResults.forEach(function(item) {
                                var status = item.status;
                                switch (status) {
                                    case "Draft":
                                        counts.Draft++;
                                        break;
                                    case "Pending":
                                        counts.InProgress++;
                                        break;
                                    case "Sent Back":
                                        counts.SentBack++;
                                        break;
                                    case "Approved":
                                        counts.Approved++;
                                        break;
                                }
                            });
        
                            var oCountModel = new sap.ui.model.json.JSONModel(counts);
                            oView.setModel(oCountModel, "dashboardCounts");
        
                            resolve();
                        } else {
                            reject("No data received from /Requests.");
                        }
                    },
                    error: function(oError) {
                        reject(oError);
                    }
                });
            });
        },        
        onSortRefrenceNumber: function (oEvent) {
            let oButton = oEvent.getSource();
            this.sortColumnByPath("refNo", oButton);
        },   
        onSortPendingWith: function (oEvent) {
            let oButton = oEvent.getSource();
            this.sortColumnByPath("pendingWithName", oButton);
        },   
        onSortStatus: function (oEvent) {
            let oButton = oEvent.getSource();
            this.sortColumnByPath("status", oButton);
        },   
        onSortStagesData: function (oEvent) {
            let oButton = oEvent.getSource();
            this.sortColumnByPath("stage", oButton);
        },   
        onSortCreatedondata: function (oEvent) {
            let oButton = oEvent.getSource();
            this.sortColumnByPath("createdAt", oButton);
        }, 
        onSortCreatedbydata: function (oEvent) {
            let oButton = oEvent.getSource();
            this.sortColumnByPath("createdBy", oButton);
        },   
        onSortCurrentApprover: function (oEvent) {
            let oButton = oEvent.getSource();
            this.sortColumnByPath("currApprover", oButton);
        },   
        sortColumnByPath: function (sPath, oButton) {
            var oTable = this.getView().byId("pendingWithMeTable");
            var oBinding = oTable.getBinding("items");
            this._mSortDescending = this._mSortDescending || {};
            var bDescending = !this._mSortDescending[sPath];
            this._mSortDescending[sPath] = bDescending;
            var oSorter = new sap.ui.model.Sorter(sPath, bDescending);
            if (oBinding) {
                oBinding.sort(oSorter);
            }
            if (oButton && typeof oButton.setIcon === "function") {
                var sIcon = bDescending ? "sap-icon://sort-descending" : "sap-icon://sort-ascending";
                oButton.setIcon(sIcon);
            }
            var oLabelMap = {
                refNo: "Reference Number",
                pendingWith: "Pending With",
                status: "Status",
                stage: "Stage",
                createdBy: "Created By",
                createdAt: "Created On",
                currApprover: "Current Approver"
            };
            var sLabel = oLabelMap[sPath] || sPath;
            sap.m.MessageToast.show(`Sorted by ${sLabel} in ${bDescending ? "Descending" : "Ascending"} order`);
        },        
        onExportTableData: function () {
            var oTable = this.byId("pendingWithMeTable");
            var aContexts = oTable.getBinding("items").getCurrentContexts();
            if (!aContexts || aContexts.length === 0) {
                sap.m.MessageToast.show("No data available for export.");
                return;
            }
            var aDataToExport = aContexts.map(function (oContext) {
                return oContext.getObject();
            });
        
            var oExport = new sap.ui.core.util.Export({
                exportType: new sap.ui.core.util.ExportTypeCSV({
                    separatorChar: ","
                }),
                models: new sap.ui.model.json.JSONModel(aDataToExport),
                rows: {
                    path: "/"
                },
                columns: [
                    { name: "Reference Number", template: { content: "{refNo}" } },
                    { name: "Status", template: { content: "{status}" } },
                    { name: "Stage", template: { content: "{stage}" } },
                    { name: "Pending With", template: { content: "{pendingWithName}" } },
                    { name: "Created By", template: { content: "{createdBy}" } },
                    { name: "Created At", template: { content: "{createdAt}" } }
                ]
            });
            oExport.saveFile("Table Data")
                .catch(function (oError) {
                    sap.m.MessageBox.error("Export failed:\n" + oError);
                })
                .then(function () {
                    oExport.destroy();
                });
        },  

        onCorysDashboardui: function(){
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("Cordys_DashboardUi");
        },

        onOpenCreateDialog: function(){
            sap.ui.getCore().byId("Initiationcombo").setValue("");
            let visblityNameUI =    this._basedNameUI;
            if (visblityNameUI === "CostApproval") {
                var oRouter = this.getOwnerComponent().getRouter();
                    oRouter.navTo("CostApproval", {
                        basedNameUICap: "Costapproval"
                    });
                return; 
            }
            // INTEGRATED PAYMENT MANAGEMENT PORTAL
            sap.ui.getCore().byId("Initiationcombo").setValue("");
            if (visblityNameUI === "CAPEX_AND_REVEX") {
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("CAPEX_AND_REVEX", {
                    basedNameUICap: "CAPEX_AND_REVEX"
                });
                return;
            }            
        
            if(visblityNameUI === "ADPD"){
              sap.ui.getCore().byId("radiobuttonformdata").setVisible(true);
              sap.ui.getCore().byId("radiobuttonBudgetformdata").setVisible(false);
              sap.ui.getCore().byId("radiobuttonformdataInfra").setVisible(false);
              var oRadioGroup = sap.ui.getCore().byId("radiobuttonformdata");
              if (oRadioGroup) {
                  oRadioGroup.setSelectedIndex(-1); 
              }
            }else if(visblityNameUI === "SSFD"){
                sap.ui.getCore().byId("radiobuttonformdata").setVisible(false);
                sap.ui.getCore().byId("radiobuttonBudgetformdata").setVisible(false);
                sap.ui.getCore().byId("radiobuttonformdataInfra").setVisible(false);

            }else if(visblityNameUI === "IPMP"){
                sap.ui.getCore().byId("radiobuttonformdata").setVisible(false);
                sap.ui.getCore().byId("radiobuttonBudgetformdata").setVisible(false);
                sap.ui.getCore().byId("radiobuttonformdataInfra").setVisible(false);
            }
            else if(visblityNameUI === "NBRF"){
                sap.ui.getCore().byId("radiobuttonformdata").setVisible(false);
                sap.ui.getCore().byId("radiobuttonBudgetformdata").setVisible(true);
                sap.ui.getCore().byId("radiobuttonformdataInfra").setVisible(false);
            }
            // else if(visblityNameUI === "CostApproval"){
            //     sap.ui.getCore().byId("radiobuttonformdata").setVisible(false);
            //     sap.ui.getCore().byId("radiobuttonBudgetformdata").setVisible(false);
            //     sap.ui.getCore().byId("radiobuttonformdataInfra").setVisible(false);
            // }
            // INTEGRATED PAYMENT MANAGEMENT PORTAL
            // else if (visblityNameUI === "CAPEX_AND_REVEX") {
            //     sap.ui.getCore().byId("radiobuttonformdata").setVisible(false);
            //     sap.ui.getCore().byId("radiobuttonBudgetformdata").setVisible(false);
            //     sap.ui.getCore().byId("radiobuttonformdataInfra").setVisible(false);
            // }
            //  //infra visbility
             else if(visblityNameUI === "INFRA"){
                sap.ui.getCore().byId("radiobuttonformdata").setVisible(false);
                sap.ui.getCore().byId("radiobuttonBudgetformdata").setVisible(false);
                sap.ui.getCore().byId("radiobuttonformdataInfra").setVisible(true);
                // sap.ui.getCore().byId("Initiationcombo").setVisible(false);
            }

            
            if(visblityNameUI === "NBRF" || visblityNameUI === "INFRA"){
                sap.ui.getCore().byId("Initiationcombo").setVisible(false);
                }else{
                    sap.ui.getCore().byId("Initiationcombo").setVisible(true); 
                }
            this.CreateDialog.open();

        },
        
        onCloseDialog: function(){
            this.CreateDialog.close();

        },

        onInitiationChange: function (oEvent) {
            let oRadioGroup = sap.ui.getCore().byId("radiobuttonformdata");
            let iSelectedIndex = oRadioGroup.getSelectedIndex();

            if (iSelectedIndex === -1) {
                MessageBox.information("Please select an approval type before proceeding.");
                return;
            }


            let sSelectedText = oRadioGroup.getAggregation("buttons")[iSelectedIndex].getText();

            var sDescription = sap.ui.getCore().byId("Initiationcombo").getValue();
            var sDescription = sDescription.split(" - ")[0];
            if (!sDescription) {
                // MessageBox.warning("Please select initiation key.");
                return;
            }

            let sType;
            switch (sDescription) {
                case "IIIT":
                    sType = "ADPD";
                    break;
                case "CBU":
                    sType = "ContingencyBudgetUtil";
                    break;
                case "PS":
                    sType = "ParkedSaving";
                    break;
                case "PPBA":
                    sType = "preProBud";
                    break;
                case "EXIG":
                    sType = "Exigency";
                    break;
                case "BA":
                    sType = "BudgetAd";
                    break;
                case "CO":
                    sType = "CostOverrun";
                    break;
                default:
                    console.log("Navigation type not defined for: " + sDescription);
                    return;
            }
            const oComponent = this.getOwnerComponent();
            const oSharedModel = this.getOwnerComponent().getModel("shared") || new sap.ui.model.json.JSONModel();
            oSharedModel.setProperty("/approvalType", sSelectedText);
            localStorage.setItem("approvalType", sSelectedText);

            // Determine visibility of forum section
            const bShowForum = (
                sSelectedText === "Forum Approval" &&
                sDescription === "INTERLINE/INTRALINE/INTERHEAD Transfer"
            );
            oSharedModel.setProperty("/showForum", bShowForum);
            oComponent.setModel(oSharedModel, "shared");

            this.getOwnerComponent().getRouter().navTo("adpd", { basedNameUIadpd: sType }, true);
        },
        onInitiationChangeReqid: function (sBasedName, sReqID) {
            const oComponent = this.getOwnerComponent();
            const oRouter = oComponent.getRouter();
        
            
            let oSharedModel = oComponent.getModel("shared");
            if (!oSharedModel) {
                oSharedModel = new sap.ui.model.json.JSONModel();
                oComponent.setModel(oSharedModel, "shared");
            }
        
            const sApprovalType = oSharedModel.getProperty("/approvalType") || "";
        
            const bShowForum = (sApprovalType === "Forum Approval" && sBasedName === "ADPD");
            oSharedModel.setProperty("/showForum", bShowForum);
        
            oSharedModel.setProperty("/approvalType", sApprovalType);
        
    
    oRouter.navTo("adpdReqID", {
            
        basedNameUIadpd: sBasedName,
        reqID: sReqID
    }, true);
                  
        },



        // INFRA onRadioSelectionINFRA
        onRadioSelectionINFRA: function(oEvent) {
            sap.ui.getCore().byId("Initiationcombo").setSelectedKey(null);
            const oSelectedButton = oEvent.getSource().getSelectedButton();
            if (!oSelectedButton) return;
        
            const sSelectedText = oSelectedButton.getText().replace(/\s/g, ''); // remove spaces if needed
            const oView = this.getView();
            const oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
        
            oModelV2.read("/ControlValues", {
                urlParameters: {
                    "$filter": "category eq 'INFRA'"
                },
                success: function(oData) {
                    if (oData && oData.results) {
                        const aFilteredData = oData.results.filter(item =>
                            item.subCategory === sSelectedText
                        );
        
                        const oFilteredModel = new sap.ui.model.json.JSONModel({ results: aFilteredData });
                        oView.setModel(oFilteredModel, "SelectInitiationData");
                    }
                },
                error: function(err) {
                    MessageBox.error("Failed to load initiation data.");
                }
            });
        },
        
    });
});