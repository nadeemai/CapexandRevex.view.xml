sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast"

], (Controller) => {
    "use strict";

    return Controller.extend("com.mmapprovalhub.approvalhub.controller.Cordys_DashboardUi", {
        onInit() {
        },
        onDashboarduirouteadpd: function(){
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("DashboardUI", {
                Name: "ADPD"
            });
        },
        onDashboarduiroutessfd: function(){
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("DashboardUI", {
                Name: "SSFD"
            });
        },
        onDashboarduirouteIP: function(){
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("DashboardUI", {
                Name: "INTP"
            });
        },
        onDashboarduirouteBR: function(){
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("DashboardUI", {
                Name: "NBRF"
            });
        },
        // infraNavigation
        onNavigateToInfraDashboard: function() { 
            var oRouter = this.getOwnerComponent().getRouter(); 
            oRouter.navTo("DashboardUI", { 
                Name: "INFRA" 
            }); 
        },
        onDashboarduirouteCostApproval: function(){
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("DashboardUI", {
                Name: "CostApproval"
            });
        },
        // INTEGRATED PAYMENT MANAGEMENT PORTAL
        onDashboardUIRouteCapexRevex: function() {
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("DashboardUI", {
                Name: "CAPEX_AND_REVEX"
            });
        }
    });
});