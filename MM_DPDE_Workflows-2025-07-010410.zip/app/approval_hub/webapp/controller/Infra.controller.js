
sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "com/mmapprovalhub/approvalhub/model/formatter",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageToast",
  "sap/ui/core/Fragment",
  "sap/m/MessageBox",
  "sap/ui/export/library",
  "sap/ui/export/Spreadsheet",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator"
], function(Controller,formatter, JSONModel, MessageToast, Fragment, MessageBox, exportLibrary, Spreadsheet, Filter,
  FilterOperator
) {
  "use strict";
  let EdmType = exportLibrary.EdmType;
  return Controller.extend("com.mmapprovalhub.approvalhub.controller.Infra", {
      
formatter: formatter,
      onInit: function () {

        const oSuggestionsModel = new sap.ui.model.json.JSONModel({
          number: [],
          desc: []
        });
        this.getView().setModel(oSuggestionsModel, "suggestionsModel");
      


//Attachemnt
var oAttachmentData = {
attachments: []
};
var oAttachmentModel = new JSONModel(oAttachmentData);
this.getView().setModel(oAttachmentModel, "UploadDocSrvTabDataWDRS");

// timeline
var oTimelineData = { };
var oTimelineModel = new JSONModel(oTimelineData);
this.getView().setModel(oTimelineModel, "timelinelogdataallApporval");

// forvisiblity matrix model
var oViewModel = new JSONModel({
  enableRowActions: true,  //save submit //whole page page initiation time all atctive
  approvebuttonvisiblity: false, // apprve, sendback
  enableRowActionsNOT: false, //object status inputboxs all box not editable for initiation page
  forpanelrowandbuttoninputbox: true, //for panel table inpubox
  approvebuttonvisiblityForStoreTask: false, //store operaiton task
  iscancelenableRowActions: true,

  //whenapprove
  isApproverOrApproved : false,
  whenapprovedisApproverOrApproved: false,
  Forcrsandsrsapprovebuttonvisiblity: false,
  WDRSapprovebuttonvisiblityedit: false, //wdrs wegit aprover
  WDRSapprovebuttonvisiblity: false,



  approvebuttonfragment: false,
  rejetedbuttonfragmnet: false,
  enableIRR: false,
  sendbackbuttonvisiblity: false,
  remarkModel: "",
  approverRequiredVisible: false,  
  currentUserRole: ""
});
this.getView().setModel(oViewModel, "viewenableddatacheck");


var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
oRouter.getRoute("ISRForm").attachPatternMatched(this._onRouteMatchedInfra, this);
oRouter.getRoute("ISRFormRef").attachPatternMatched(this._onRouteMatchedInfraREF, this);
oRouter.getRoute("ISRFormRefApproved").attachPatternMatched(this._onRouteMatchedInfraApproved, this);

 

this.remarksDialog = sap.ui.xmlfragment(this.getView().getId(), "com.mmapprovalhub.approvalhub.Fragments.remarks", this);
this.getView().addDependent(this.remarksDialog);

 
 },


   

onSuggestPartNumber: function (oEvent) {
  this._handleSuggestion(oEvent, "partNo", "/number");
},

onSuggestPartDesc: function (oEvent) {
  this._handleSuggestion(oEvent, "partDesc", "/desc");
},

_handleSuggestion: function (oEvent, sFieldName, sModelPath) {
  const sTerm = oEvent.getParameter("suggestValue");
  if (!sTerm || sTerm.length < 2) return;

  const oContext = oEvent.getSource().getBindingContext("Requestservicemodel");
  const sPath = oContext?.getPath() || "";
  const oModel = oContext?.getModel();

  const department = oModel.getProperty(sPath)?.department ||
                     (sPath.includes("WDRS") ? "WDRS" :
                      sPath.includes("SRS") ? "SRS" :
                      "CRS");

  const aFilters = [
    new sap.ui.model.Filter("department", sap.ui.model.FilterOperator.EQ, department),
    new sap.ui.model.Filter(sFieldName, sap.ui.model.FilterOperator.Contains, sTerm)
  ];

  this.getOwnerComponent().getModel("approvalservicev2").read("/PartDetails", {
    filters: aFilters,
    success: (oData) => {
      this.getView().getModel("suggestionsModel").setProperty(sModelPath, oData.results);
    }
  });
},

 


/*****************
* frsaddrow 
*****************/
onAddVehicleRowFRS: function () {
const oModel = this.getOwnerComponent().getModel("Requestservicemodel");
const aRows = oModel.getProperty("/FRS/VehicleDetailsPayload") || [];

aRows.push({
  VehicleNoFRS: "",
  ProjectNoFRS: "",
  ProductDescriptionFRS: "",
  UOMFRS: "",
  RequestedQtyFRS: "",
  ApprovedQtyFRS: ""
});

oModel.setProperty("/FRS/VehicleDetailsPayload", aRows);
}, 


//***************
// DeletefRS row
//  *************/
onDeleteRowFRS: function () {
  const oTable = this.byId("VehicleTableInitiateFRS");
  const aSelectedItems = oTable.getSelectedItems();
  const oModel = this.getOwnerComponent().getModel("Requestservicemodel");
  const aData = oModel.getProperty("/FRS/VehicleDetailsPayload");
  
  if (!aSelectedItems.length) {
    sap.m.MessageToast.show("Please select at least one row to delete.");
    return;
  }
  
   
  const aIndexesToRemove = aSelectedItems.map(oItem => {
    const sPath = oItem.getBindingContext("Requestservicemodel").getPath();
    return parseInt(sPath.split("/").pop());
  });
   aIndexesToRemove.sort((a, b) => b - a);
   aIndexesToRemove.forEach(iIndex => {
    aData.splice(iIndex, 1);
  });
  
  // Update the model
  oModel.setProperty("/FRS/VehicleDetailsPayload", aData);
  
  oTable.removeSelections();
  },


onCloseReamrksFrag: function() {
  this.remarksDialog.close();
},
/***************
 * onsubmitallfrs,wdrs,srs,crs
 *************/
onSubmitReamrksData: function () {
  var oView = this.getView();
  const oModel = this.getOwnerComponent().getModel("approvalservicev2");
  const oRequestModel = this.getOwnerComponent().getModel("Requestservicemodel");
  const oSharedModel = this.getOwnerComponent().getModel("shared");
  const sApprovalType = oSharedModel.getProperty("/approvalType");
  const sReqTypeNumber = this._refNo || "";
  const sReqType = this._reqID;
  var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");

  if (!remarkInput) {
    MessageBox.information("Please provide a remark before submitting.");
    return;
  }

  const sKey = sApprovalType.includes("Fuel") ? "FRS" :
               sApprovalType.includes("Consumable") ? "CRS" :
               sApprovalType.includes("Stationary") ? "SRS" :
               sApprovalType.includes("Waste") ? "WDRS" : "";

  if (!sKey) {
    sap.m.MessageToast.show("Invalid approval type");
    return;
  }

  const oInfraPayload = this._buildUnifiedPayload(sKey);
  let stageValue = "";
  if(sKey == "FRS" || sKey == "WDRS"){  
    stageValue = "Approver"
  } else {
    stageValue = "HOD"
  }
  const oSubmitPayload = {
    stage: stageValue,
    status: "Pending",
    type: "ISR",
    remarks: remarkInput,
    infraDtl: oInfraPayload
  };

  var that = this;
  sap.ui.core.BusyIndicator.show(0);

  if (!sReqType) {
    oModel.create("/Requests", oSubmitPayload, {
      success: (oData) => {
        sap.ui.core.BusyIndicator.hide();
        var reqIdData = oData.refNo;
        that._reqID = oData.reqID;
        var actualreqid = oData.reqID;

        if (oData?.refNo) {
          if (sKey === "FRS") {
            oRequestModel.setProperty("/FRS/slipNumberFRS", reqIdData);
          } else if (sKey === "CRS") {
            oRequestModel.setProperty("/CRS/slipNumberCRS", reqIdData);
          } else if (sKey === "SRS") {
            oRequestModel.setProperty("/SRS/slipNumberSRS", reqIdData);
          } else if (sKey === "WDRS") {
            oRequestModel.setProperty("/WDRS/slipNumberWDRS", reqIdData);
            that.attachmentuploadFilesData(oData.reqID);
          }

          const existingData = oRequestModel.getData() || {};
          const subType = oData?.infraDtl?.subType;
          if (subType) {
            existingData[subType] = {
              ...(existingData[subType] || {}),
              ...oData.infraDtl
            };
            oRequestModel.setData(existingData);
          }
          that.approverdatacheck(oData.reqID)
          that.infraDtlforallDataFetch(actualreqid);
        }

        that.onCloseReamrksFrag();
         
      },
      error: (oError) => {
        sap.ui.core.BusyIndicator.hide();
        sap.m.MessageBox.error("Error submitting request \nA technical error has occurred. Please contact the administrator");
      }
    });

  } else {
    oModel.update("/Requests('" + sReqType + "')", oSubmitPayload, {
      success: (oData) => {
        sap.ui.core.BusyIndicator.hide();
        var uactualreqid = oData.reqID;
        that.approverdatacheck(oData.reqID)
        that.infraDtlforallDataFetch(uactualreqid);
        if (sKey === "WDRS") {
          that.attachmentuploadFilesData(oData.reqID);
        }

        that.onCloseReamrksFrag();
         
      },
      error: () => {
        sap.ui.core.BusyIndicator.hide();
        sap.m.MessageBox.error("Failed to Update Request.\nA technical error has occurred. Please contact the administrator");
      }
    });
  }
},

approverdatacheck: function(reqid) {
  var oModel = this.getOwnerComponent().getModel("approvalservicev2");
  var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
  var oApprovedPayload = {
      reqID: reqid,
      action: "SUBMIT",
      remarks: remarkInput
  };
  var that = this;
  sap.ui.core.BusyIndicator.show(0);

  oModel.create("/ISRApproval", oApprovedPayload, {
      success: function(oData) {
          MessageBox.success(oData.ISRApproval?.message || "Request submitted successfully!", {
              onClose: function() {
                  if (that._SanctionfdNameUI === "INFRA") {
                      sap.ui.core.BusyIndicator.hide();
                      that.getOwnerComponent().getRouter().navTo("DashboardUI", { Name: "INFRA" });
                  }
              }
          });
      },
      error: function(oError) {
        sap.ui.core.BusyIndicator.hide();
        sap.m.MessageBox.error("Failed in Approval Process.\nA technical error has occurred. Please contact the administrator");
    }
});
},


/********************
 * Timelineall
 **********************/
onFetchTimelinessData: function (reqidNo) {
  const reqid = reqidNo;
  const oView = this.getView();
  const oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

  if (!reqid) {
    console.warn("Request ID is missing. Cannot fetch timeliness data.");
    return;
  }

  oModelV2.read("/ProcessLogs", {
    filters: [
      new sap.ui.model.Filter("reqID", sap.ui.model.FilterOperator.EQ, reqid)
    ],
    urlParameters: {
      "$orderby": "createdAt desc"
    },
    success: function (oData) {
      if (oData && Array.isArray(oData.results)) {
        const aProcessedData = oData.results.map(oLog => ({
          createdAt: oLog.createdAt,
          role: oLog.stage ? `[${oLog.stage}]` : "[N/A]",
          userName: oLog.userName || "Unknown User",
          userEmail: oLog.userEmail || "N/A",
          remarks: oLog.remarks || "No remarks provided"
        }));

        // Move Initiator to end
        const initiatorIndex = aProcessedData.findIndex(item =>
          item.role.toLowerCase().includes("initiator")
        );

        if (initiatorIndex > -1) {
          const initiatorEntry = aProcessedData.splice(initiatorIndex, 1)[0];
          aProcessedData.push(initiatorEntry);
        }

        const oTimelineModel = new sap.ui.model.json.JSONModel({
          results: aProcessedData
        });

        // You can standardize this model name across all subtypes
        oView.setModel(oTimelineModel, "timelinelogdataallApporval");
      }
    },
    error: function (oError) {
      sap.m.MessageToast.show("Failed to load process log data.", { position: "bottom center" });
      console.error("Error fetching timeliness data:", oError);
    }
  });
},


formatTimelineTitle: function(role, userName, userEmail) {
  return role + " " + userName + " (" + userEmail + ")";
},





/*****************
 * wbscodefrs
 *****************/
onSelectedwbsCodeFRS: function(oEvent) { 
  var oSelectedItem = oEvent.getParameter("selectedItem");

  if (oSelectedItem) { 
      var sSelectedWBSCode = oSelectedItem.getKey();  
      var oModel = this.getView().getModel("Requestservicemodel");
      if (oModel) {
          oModel.setProperty("/FRS/wbsCodeFRS", sSelectedWBSCode);
      }
  }
},


/*****************
 * approversfrs
 *****************/
onFetchApproverFRS: function () {
  const oModel = this.getOwnerComponent().getModel("approvalservicev2"); // This should be your OData model
  const oRequestServiceModel = this.getOwnerComponent().getModel("Requestservicemodel");

  // Define filters for department and role
  const aFilters = [
    new sap.ui.model.Filter("department", sap.ui.model.FilterOperator.EQ, "ISR_FRS"),
    new sap.ui.model.Filter("role", sap.ui.model.FilterOperator.EQ, "Approver")
  ];

  oModel.read("/Approvers", {
    filters: aFilters,
    success: function (oData) {
      if (oData?.results?.length) {
        oRequestServiceModel.setProperty("/FRS/ApproverList", oData.results);
      } else {
        oRequestServiceModel.setProperty("/FRS/ApproverList", []);
      }
    },
    error: function () {
      sap.m.MessageBox.error("Failed to fetch approvers.");
    }
  });
},
onApproverSelectionChangeFRS: function (oEvent) {
  var oSelectedItem = oEvent.getParameter("selectedItem");

  if (oSelectedItem) {
      var sKey = oSelectedItem.getKey();  
      var oModel = this.getView().getModel("Requestservicemodel");
      oModel.setProperty("/FRS/approverFRS", sKey);
  } else { 
      var oModel = this.getView().getModel("Requestservicemodel");
      oModel.setProperty("/FRS/approverFRS", "");
  }
},


/******************
 * onProductDescriptionDataFetchFRS
 ******************/
onProductDescriptionDataFetchFRS: function() {
  var oView = this.getView();
  var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

  oModelV2.read("/ControlValues", {
      urlParameters: {
          "$filter": "category eq 'ISR_PROD_DESC'"
      },
      success: function(oData) {
          if (oData) {
              var oJSONModel = new sap.ui.model.json.JSONModel(oData);
              oView.setModel(oJSONModel, "ProductDescriptionDataFRS");
          }
      },
      error: function(oError) {
          sap.m.MessageToast.show("Failed to load product descriptions.", { position: "bottom center" });
          console.error("Error fetching product descriptions:", oError);
      }
  });
},


/******************
 * onUOMFetchFRS
 ******************/
onUOMFetchFRS: function() {
  var oView = this.getView();
  var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

  oModelV2.read("/ControlValues", {
      urlParameters: {
          "$filter": "category eq 'ISR_UOM'"
      },
      success: function(oData) {
          if (oData) {
              var oJSONModel = new sap.ui.model.json.JSONModel(oData);
              oView.setModel(oJSONModel, "UOMDataFRS");
          }
      },
      error: function(oError) {
          sap.m.MessageToast.show("Failed to load UOM data.", { position: "bottom center" });
          console.error("Error fetching UOMs:", oError);
      }
  });
},

/*********************
 * locationfrslivechange
 ***********************/
onLocationChange: function (oEvent) {
  var oRadioButtonGroup = oEvent.getSource();
  var iSelectedIndex = oRadioButtonGroup.getSelectedIndex();
  if (iSelectedIndex === -1) {
      return;  
  } 
  var oSelectedButton = oRadioButtonGroup.getAggregation("buttons")[iSelectedIndex];
  var sSelectedText = oSelectedButton.getText(); 
  var oModel = this.getView().getModel("Requestservicemodel");
  oModel.setProperty("/FRS/locationFRS", sSelectedText);
},









/**************************************************
* consumable request
**********************************************/
// addrowCRS
onAddRowCRS: function () {
const oModel = this.getOwnerComponent().getModel("Requestservicemodel");
const aPartDetails = oModel.getProperty("/CRS/PartDetailsCRS") || [];

// Add an empty row structure
aPartDetails.push({
  PartDescriptionCRS: "",
  PartNumberCRS: "",
  BinNumberCRS: "",
  PriceCRS: "",
  RequestedQtyCRS: ""
});

 
oModel.setProperty("/CRS/PartDetailsCRS", aPartDetails);
},

/****************
* BulkUploadcrs
****************/
createColumnConfig: function () {
return [
    { label: "Part Description", property: "PartDescription", type: EdmType.String },
    { label: "Part Number", property: "PartNumber", type: EdmType.String },
    { label: "Bin Number", property: "BinNumber", type: EdmType.String },
    { label: "Price", property: "Price", type: EdmType.String },
    { label: "Requested Qty", property: "RequestedQty", type: EdmType.String },
];
},
//template downloadcrs
onUploadMassChange: function (oEvent) {
const sKey = oEvent.getParameter("item").getKey();
if (sKey === "template") {
    this.onDownloadTemplateCRS();
} else if (sKey === "upload") {
    this._openUploadDialogCRS();
}
},
//downloadtemplatecrs
onDownloadTemplateCRS: function () {
if (!this._oTable) {
    this._oTable = this.byId("partDetailsTableInitiateCRS");
}

let aCols = this.createColumnConfig();
let oSettings = {
    workbook: {
        columns: aCols,
        autoFilter: false 
        
    },
    dataSource: [{}],
    fileName: "Part_Details_CRS.xlsx",
    worker: false
};

let oSheet = new Spreadsheet(oSettings);
oSheet.build().finally(() => oSheet.destroy());
},

//crsuploadbulk
_openUploadDialogCRS: function () {
  let that = this; 
  if (this._oUploadDialog) {
      this._oUploadDialog.destroy(); 
      this._oUploadDialog = null;
  }

  // File uploader
  let oFileUploader = new sap.ui.unified.FileUploader({
      // id: this.createId("partDetailsTableInitiateCRS"),  
      fileType: ["xlsx", "xls", "csv"],
      placeholder: "Select file",
      buttonText: "Browse...",
      change: function (oEvent) {
          that._selectedFile = oEvent.getParameter("files")[0];
      }
  }).addStyleClass("sapUiSmallMargin");

  // Dialog creation
  this._oUploadDialog = new sap.m.Dialog({
      title: "Bulk Upload",
      content: [
          new sap.m.Link({
              text: "Download Template",
              press: function () {
                  that.onDownloadTemplateCRS();
              }
          }).addStyleClass("sapUiSmallMargin"),
          oFileUploader
      ],
      beginButton: new sap.m.Button({
          text: "Upload",
          type: "Emphasized",
          press: function () {
              if (that._selectedFile) {
                  that._processUploadedFileCommon(that._selectedFile, "CRS");
                  that._oUploadDialog.close();
              } else {
                  MessageToast.show("Please select a file.");
              }
          }
      }),
      endButton: new sap.m.Button({
          text: "Cancel",
          press: function () {
              that._oUploadDialog.close();
          }
      }),
      afterClose: function () {
          that._selectedFile = null;
          that._oUploadDialog.destroy();  
          that._oUploadDialog = null;
      }
  });

  this._selectedFile = null;
  this._oUploadDialog.open();
},



//***************
// DeleteCRS row
//  *************/
onDeleteRowCRS: function () {
const oTable = this.byId("partDetailsTableInitiateCRS");
const aSelectedItems = oTable.getSelectedItems();
const oModel = this.getOwnerComponent().getModel("Requestservicemodel");
const aData = oModel.getProperty("/CRS/PartDetailsCRS");

if (!aSelectedItems.length) {
  sap.m.MessageToast.show("Please select at least one row to delete.");
  return;
}

 
const aIndexesToRemove = aSelectedItems.map(oItem => {
  const sPath = oItem.getBindingContext("Requestservicemodel").getPath();
  return parseInt(sPath.split("/").pop());
});
 aIndexesToRemove.sort((a, b) => b - a);
 aIndexesToRemove.forEach(iIndex => {
  aData.splice(iIndex, 1);
});

// Update the model
oModel.setProperty("/CRS/PartDetailsCRS", aData);

oTable.removeSelections();
},

/******************
 * crslocation
 *****************/
onLocationDataFetchCRS: function() {
  var oView = this.getView();
  var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

  oModelV2.read("/ControlValues", {
      urlParameters: {
          "$filter": "category eq 'ISR_LOC'" 
      },
      success: function(oData) {
          if (oData) {
              var oJSONModel = new sap.ui.model.json.JSONModel(oData);
              oView.setModel(oJSONModel, "INFRALocationFetchCRS");  
          }
      },
      error: function(oError) {
          sap.m.MessageToast.show("Failed to load location data.", { position: "bottom center" });
          console.error("Error fetching location data:", oError);
      }
  });
},
onLocationINFRACRS: function(oEvent) {
  var oSelectedItem = oEvent.getParameter("selectedItem");
  if (oSelectedItem) {
      var sKey = oSelectedItem.getKey();
      var sText = oSelectedItem.getText();
      console.log("Selected Location:", sKey, sText);
 
      var oModel = this.getView().getModel("Requestservicemodel");
      if (oModel) {
          oModel.setProperty("/CRS/location", sKey);  
      }
  }
},

/****************
 * HODCRSHOD
 *****************/
onFetchHODCRS: function() {
  var oView = this.getView();
  var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

  oModelV2.read("/Approvers", {
      urlParameters: {
          "$filter": "department eq 'ISR_CRS' and role eq 'HOD'"
      },
      success: function(oData) {
          if (oData && oData.results) {
              var oJSONModel = new sap.ui.model.json.JSONModel(oData);
              oView.setModel(oJSONModel, "FetchHODCRS"); // Make sure the model name matches the XML view
          }
      },
      error: function(oError) {
          sap.m.MessageToast.show("Failed to load HOD data.", { position: "bottom center" });
          console.error("Error fetching HOD data:", oError);
      }
  });
},
onHodINFRAChangeCRS: function(oEvent) {
  var oSelectedItem = oEvent.getParameter("selectedItem");
  if (oSelectedItem) {
      var sKey = oSelectedItem.getKey();
      var sText = oSelectedItem.getText();

      console.log("Selected HOD:", sKey, sText);

      var oModel = this.getView().getModel("Requestservicemodel");
      if (oModel) {
          oModel.setProperty("/CRS/hod", sKey);
      }
  }
},

/*********************
 * crstablepartnumberbinnumbercrs
 *********************/
onLiveChangePartField: function (oEvent) {
  const oSource = oEvent.getSource();
  const sValue = oSource.getValue(); //  Correct way to get value for 'suggest' event
  const bIsDesc = oSource.getId().includes("Desc");
  const sParam = bIsDesc ? "partDesc" : "partNo";

  if (!sValue) return this._clearRow(oEvent);
  if (sValue.length < 3) return;

  this._fetchPartDetails({ [sParam]: sValue }, oEvent);
},



_fetchPartDetails: function(oParams, oEvent) {
  const oContext = oEvent.getSource().getBindingContext("Requestservicemodel");
  if (!oContext) return;

  const sPath = oContext.getPath();
  const oModel = oContext.getModel();
  const oRow = oModel.getProperty(sPath);
  const department = oRow?.department || sPath.split("/")[1]; // fallback

  const aFilters = [new sap.ui.model.Filter("department", "EQ", department)];

  if (oParams.partDesc) {
    aFilters.push(new sap.ui.model.Filter("partDesc", "Contains", oParams.partDesc));
  }
  if (oParams.partNo) {
    aFilters.push(new sap.ui.model.Filter("partNo", "Contains", oParams.partNo));
  }

  const oReadModel = this.getOwnerComponent().getModel("approvalservicev2");

  oReadModel.read("/PartDetails", {
    filters: aFilters,
    success: (oData) => {
      if (!oData.results.length) return;

      // Update suggestions model
      const oSuggestModel = new sap.ui.model.json.JSONModel(oData.results);
      this.getView().setModel(oSuggestModel, "suggestionsModel");

      // Optionally auto-fill first match
      const hit = oData.results[0];
      const updateData = {
        [`PartDescription${department}`]: hit.partDesc,
        [`PartNumber${department}`]: hit.partNo,
        [`BinNumber${department}`]: hit.binNo,
        [`Price${department}`]: hit.price,
        [`RequestedQty${department}`]: ""
      };

      this._mergeRow(sPath, oModel, updateData);
    },
    error: (err) => {
      console.error("Error fetching part details:", err);
    }
  });
},

 

onSuggestionItemSelected: function (oEvent) {
  const oSelectedItem = oEvent.getParameter("selectedItem");
  const oSource = oEvent.getSource();
  const oContext = oSource.getBindingContext("Requestservicemodel");
  if (!oContext) return;

  const sPath = oContext.getPath();
  const oModel = oContext.getModel();
  const oRow = oModel.getProperty(sPath);
  const department = oRow?.department || sPath.split("/")[1];

  // Clear case: user clicked the clear icon (no selected item)
  if (!oSelectedItem) {
    const clearData = {
      [`PartDescription${department}`]: "",
      [`PartNumber${department}`]: "",
      [`BinNumber${department}`]: "",
      [`Price${department}`]: "",
      [`RequestedQty${department}`]: "",
      [`ApprovedQty${department}`]: "",
      [`IssuedQty${department}`]: ""
    };
    oModel.setProperty(sPath, { ...oRow, ...clearData });
    return;
  }

  //   User selected a suggestion item
  const oSuggestContext = oSelectedItem.getBindingContext("suggestionsModel");
  const oSelectedData = oSuggestContext.getObject();

  const updateData = {
    [`PartDescription${department}`]: oSelectedData.partDesc,
    [`PartNumber${department}`]: oSelectedData.partNo,
    [`BinNumber${department}`]: oSelectedData.binNo,
    [`Price${department}`]: oSelectedData.price,
    [`RequestedQty${department}`]: ""
  };

  this._mergeRow(sPath, oModel, updateData);
},

_mergeRow: function(sPath, oModel, oNewData) {
  const oRow = oModel.getProperty(sPath);
  Object.assign(oRow, oNewData);
  oModel.setProperty(sPath, oRow);
},

_clearRow: function(oEvent) {
  const oSource = oEvent.getSource();
  const oContext = oSource.getBindingContext("Requestservicemodel");
  if (!oContext) return;

  const sPath = oContext.getPath();
  const oModel = oContext.getModel();
  const oRow = oModel.getProperty(sPath);
  const department = oRow?.department || sPath.split("/")[1];

  const clearData = {
    [`PartDescription${department}`]: "",
    [`PartNumber${department}`]: "",
    [`BinNumber${department}`]: "",
    [`Price${department}`]: "",
    [`RequestedQty${department}`]: "",
    [`ApprovedQty${department}`]: "",
    [`IssuedQty${department}`]: ""
  };

  oModel.setProperty(sPath, { ...oRow, ...clearData });
},

onPartComboChange: function (oEvent) {
  const sValue = oEvent.getParameter("value");
  const oSource = oEvent.getSource();
  const oContext = oSource.getBindingContext("Requestservicemodel");

  if (!oContext) return;

  const sPath = oContext.getPath();
  const oModel = oContext.getModel();
  const oRow = oModel.getProperty(sPath);
  const department = oRow?.department || sPath.split("/")[1];

  // If field is cleared manually or using clear icon
  if (!sValue) {
    const clearData = {
      [`PartDescription${department}`]: "",
      [`PartNumber${department}`]: "",
      [`BinNumber${department}`]: "",
      [`Price${department}`]: "",
      [`RequestedQty${department}`]: "",
      [`ApprovedQty${department}`]: "",
      [`IssuedQty${department}`]: ""
    };
    oModel.setProperty(sPath, { ...oRow, ...clearData });
  }
}
,


 

 
/***************************************************
* Stationary Request SRS
***************************************************/
//addrowsrs
onAddRowSRS: function() {
const oModel = this.getOwnerComponent().getModel("Requestservicemodel");
const aPartDetails = oModel.getProperty("/SRS/PartDetailsSRS") || [];

// Add an empty row structure
aPartDetails.push({
  PartDescriptionSRS: "",
  PartNumberSRS: "",
  BinNumberSRS: "",
  PriceCRS: "",
  RequestedQtySRS: ""
});

 
oModel.setProperty("/SRS/PartDetailsSRS", aPartDetails);
},
/****************
* BulkUploadcrs
****************/
createColumnConfigSRS: function () {
return [
    { label: "Part Description", property: "PartDescription", type: EdmType.String },
    { label: "Part Number", property: "PartNumber", type: EdmType.String },
    { label: "Bin Number", property: "BinNumber", type: EdmType.String },
    { label: "Price", property: "Price", type: EdmType.String },
    { label: "Requested Qty", property: "RequestedQty", type: EdmType.String },
];
},
//template downloadcrs
onUploadMassChangeSRS: function (oEvent) {
const sKey = oEvent.getParameter("item").getKey();
if (sKey === "templatesrs") {
    this.onDownloadTemplateSRS();
} else if (sKey === "uploadsrs") {
    this._openUploadDialogSRS();
}
},
//downloadtemplatecrs
onDownloadTemplateSRS: function () {
if (!this._oTable) {
    this._oTable = this.byId("tblPartDetailsInitiateSRS");
}

let aCols = this.createColumnConfigSRS();
let oSettings = {
    workbook: {
        columns: aCols,
        autoFilter: false 
        
    },
    dataSource: [{}],
    fileName: "Part_Details_SRS.xlsx",
    worker: false
};

let oSheet = new Spreadsheet(oSettings);
oSheet.build().finally(() => oSheet.destroy());
},

//srsuploadbulk
_openUploadDialogSRS: function () {
  let that = this; 
  if (this._oUploadDialog) {
      this._oUploadDialog.destroy(); 
      this._oUploadDialog = null;
  }

  // File uploader
  let oFileUploader = new sap.ui.unified.FileUploader({
      // id: this.createId("tblPartDetailsInitiateSRS"),  
      fileType: ["xlsx", "xls", "csv"],
      placeholder: "Select file",
      buttonText: "Browse...",
      change: function (oEvent) {
          that._selectedFile = oEvent.getParameter("files")[0];
      }
  }).addStyleClass("sapUiSmallMargin");

  // Dialog creation
  this._oUploadDialog = new sap.m.Dialog({
      title: "Bulk Upload",
      content: [
          new sap.m.Link({
              text: "Download Template",
              press: function () {
                  that.onDownloadTemplateSRS();
              }
          }).addStyleClass("sapUiSmallMargin"),
          oFileUploader
      ],
      beginButton: new sap.m.Button({
          text: "Upload",
          type: "Emphasized",
          press: function () {
              if (that._selectedFile) {
                  that._processUploadedFileCommon(that._selectedFile, "SRS");
                  that._oUploadDialog.close();
              } else {
                  MessageToast.show("Please select a file.");
              }
          }
      }),
      endButton: new sap.m.Button({
          text: "Cancel",
          press: function () {
              that._oUploadDialog.close();
          }
      }),
      afterClose: function () {
          that._selectedFile = null;
          that._oUploadDialog.destroy();  
          that._oUploadDialog = null;
      }
  });

  this._selectedFile = null;
  this._oUploadDialog.open();
},





//***************
// DeleteSRS row
//  *************/
onDeleteRowSRS: function () {
const oTable = this.byId("tblPartDetailsInitiateSRS");
const aSelectedItems = oTable.getSelectedItems();
const oModel = this.getOwnerComponent().getModel("Requestservicemodel");
const aData = oModel.getProperty("/SRS/PartDetailsSRS");

if (!aSelectedItems.length) {
  sap.m.MessageToast.show("Please select at least one row to delete.");
  return;
}

 
const aIndexesToRemove = aSelectedItems.map(oItem => {
  const sPath = oItem.getBindingContext("Requestservicemodel").getPath();
  return parseInt(sPath.split("/").pop());
});
 aIndexesToRemove.sort((a, b) => b - a);
 aIndexesToRemove.forEach(iIndex => {
  aData.splice(iIndex, 1);
});

// Update the model
oModel.setProperty("/SRS/PartDetailsSRS", aData);

oTable.removeSelections();
},

/****************************
 * locationsrs
 ****************************/
onLocationDataFetchSRS: function() {
  var oView = this.getView();
  var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

  oModelV2.read("/ControlValues", {
      urlParameters: {
          "$filter": "category eq 'ISR_LOC'"
      },
      success: function(oData) {
          if (oData && oData.results) {
              var oJSONModel = new sap.ui.model.json.JSONModel(oData);
              oView.setModel(oJSONModel, "INFRADataFetchSRS"); // Match the XML view model name
          }
      },
      error: function(oError) {
          sap.m.MessageToast.show("Failed to load location data.", { position: "bottom center" });
          console.error("Error fetching location data:", oError);
      }
  });
},
onLocationINFRASRS: function(oEvent) {
  var oSelectedItem = oEvent.getParameter("selectedItem");
  if (oSelectedItem) {
      var sKey = oSelectedItem.getKey();
      var sText = oSelectedItem.getText();

      console.log("Selected SRS Location:", sKey, sText);

      var oModel = this.getView().getModel("Requestservicemodel");
      if (oModel) {
          oModel.setProperty("/SRS/LocationSRS", sKey); // Set selected location in the model
      }
  }
},

/****************************
 * HODsrshod
 ****************************/
onFetchHODSRS: function() {
  var oView = this.getView();
  var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

  oModelV2.read("/Approvers", {
      urlParameters: {
          "$filter": "department eq 'ISR_SRS' and role eq 'HOD'"
      },
      success: function(oData) {
          if (oData && oData.results) {
              var oJSONModel = new sap.ui.model.json.JSONModel(oData);
              oView.setModel(oJSONModel, "InfraHODSRS"); // Same name used in the ComboBox binding
          }
      },
      error: function(oError) {
          sap.m.MessageToast.show("Failed to load HOD data for SRS.", { position: "bottom center" });
          console.error("Error fetching HOD data (ISR_SRS):", oError);
      }
  });
},
onHodINFRAChangeSRS: function(oEvent) {
  var oSelectedItem = oEvent.getParameter("selectedItem");

  if (oSelectedItem) {
      var sKey = oSelectedItem.getKey();  
      var sText = oSelectedItem.getText(); 

      console.log("Selected ISR_SRS HOD:", sKey, sText);

      var oModel = this.getView().getModel("Requestservicemodel");
      if (oModel) {
          oModel.setProperty("/SRS/HodSRS", sKey);
      }
  }
},

/***********************
 * partbinsrspartbin
 ***********************/
onLiveChangePartDescSRS: function(oEvent) {
  const sValue = oEvent.getParameter("value");
  if (!sValue) return this._clearRowSRS(oEvent);
  if (sValue.length < 6) return;

  this._fetchPartDetailsSRS({ partDesc: sValue }, oEvent);
},

onLiveChangePartNumberSRS: function(oEvent) {
  const sValue = oEvent.getParameter("value");
  if (!sValue) return this._clearRowSRS(oEvent);
  if (sValue.length < 6) return;

  this._fetchPartDetailsSRS({ partNo: sValue }, oEvent);
},
_fetchPartDetailsSRS: function(oParams, oEvent) {
  const sPath = oEvent.getSource().getBindingContext("Requestservicemodel").getPath();
  const oModel = this.getOwnerComponent().getModel("Requestservicemodel");
  const oReadModel = this.getOwnerComponent().getModel("approvalservicev2");

  const aFilters = [
    new sap.ui.model.Filter("department", sap.ui.model.FilterOperator.EQ, "SRS")
  ];

  if (oParams.partDesc) {
    aFilters.push(new sap.ui.model.Filter("partDesc", sap.ui.model.FilterOperator.EQ, oParams.partDesc));
  }
  if (oParams.partNo) {
    aFilters.push(new sap.ui.model.Filter("partNo", sap.ui.model.FilterOperator.EQ, oParams.partNo));
  }

  oReadModel.read("/PartDetails", {
    filters: aFilters,
    success: (data) => {
      if (data.results.length) {
        const hit = data.results[0];
        this._mergeRowSRS(sPath, oModel, {
          PartDescriptionSRS: hit.partDesc,
          PartNumberSRS:      hit.partNo,
          BinNumberSRS:       hit.binNo,
          PriceSRS:           hit.price,
          RequestedQtySRS:    "" // or set default
        });
      }
    },
    error: (err) => {
      console.error("SRS PartDetails read failed:", err);
    }
  });
},
_mergeRowSRS: function(sPath, oModel, oNewData) {
  const oRow = oModel.getProperty(sPath);
  Object.assign(oRow, oNewData);
  oModel.setProperty(sPath, oRow);
},
_clearRowSRS: function(oEvent) {
  const oSource = oEvent.getSource();
  const oContext = oSource.getBindingContext("Requestservicemodel");

  if (!oContext) return;

  const sPath = oContext.getPath();
  const oModel = oContext.getModel();

  oModel.setProperty(sPath, {
    PartDescriptionSRS: "",
    PartNumberSRS: "",
    BinNumberSRS: "",
    PriceSRS: "",
    RequestedQtySRS: "",
    ApprovedQtySRS: "",
    IssuedQtySRS: ""
  });
},















/***********************************************************
* Waste Disposal Request wdrs
*************************************************************/
onAddRowWDRS: function() {
const oModel = this.getOwnerComponent().getModel("Requestservicemodel");
const aPartDetails = oModel.getProperty("/WDRS/PartDetailsWDRS") || [];

// Add an empty row structure
aPartDetails.push({
  PartDescriptionWDRS: "",
  PartNumberWDRS: "",
  UOMWDRS: "",
  TentativeWeightWDRS: ""
});

 
oModel.setProperty("/WDRS/PartDetailsWDRS", aPartDetails);
},

/****************
* BulkUploadwdrs
****************/
createColumnConfigWDRS: function () {
return [
    { label: "Part Description", property: "PartDescription", type: EdmType.String },
    { label: "Part Number", property: "PartNumber", type: EdmType.String },
    { label: "UOM", property: "UOM", type: EdmType.String },
    { label: "Tentative Weight", property: "TentativeWeight", type: EdmType.Number },
];
},
//template downloadwdrs
onUploadMassChangeWDRS: function (oEvent) {
const sKey = oEvent.getParameter("item").getKey();
if (sKey === "templatewdrs") {
    this.onDownloadTemplateWDRS();
} else if (sKey === "uploadwdrs") {
    this._openUploadDialogWDRS();
}
},
//downloadtemplatewdrs
onDownloadTemplateWDRS: function () {
if (!this._oTable) {
    this._oTable = this.byId("tblPartDetailsInitiateSRS");
}

let aCols = this.createColumnConfigWDRS();
let oSettings = {
    workbook: {
        columns: aCols,
        autoFilter: false 
        
    },
    dataSource: [{}],
    fileName: "Waste_Details_WDRS.xlsx",
    worker: false
};

let oSheet = new Spreadsheet(oSettings);
oSheet.build().finally(() => oSheet.destroy());
},

//wdrsuploadbulk
_openUploadDialogWDRS: function () {
  let that = this; 
  if (this._oUploadDialog) {
      this._oUploadDialog.destroy(); 
      this._oUploadDialog = null;
  }

  // File uploader
  let oFileUploader = new sap.ui.unified.FileUploader({
      // id: this.createId("tblPartDetailsInitiateWDRS"),  
      fileType: ["xlsx", "xls", "csv"],
      placeholder: "Select file",
      buttonText: "Browse...",
      change: function (oEvent) {
          that._selectedFile = oEvent.getParameter("files")[0];
      }
  }).addStyleClass("sapUiSmallMargin");

  // Dialog creation
  this._oUploadDialog = new sap.m.Dialog({
      title: "Bulk Upload",
      content: [
          new sap.m.Link({
              text: "Download Template",
              press: function () {
                  that.onDownloadTemplateWDRS();
              }
          }).addStyleClass("sapUiSmallMargin"),
          oFileUploader
      ],
      beginButton: new sap.m.Button({
          text: "Upload",
          type: "Emphasized",
          press: function () {
              if (that._selectedFile) {
                  that._processUploadedFileCommon(that._selectedFile, "WDRS");
                  that._oUploadDialog.close();
              } else {
                  MessageToast.show("Please select a file.");
              }
          }
      }),
      endButton: new sap.m.Button({
          text: "Cancel",
          press: function () {
              that._oUploadDialog.close();
          }
      }),
      afterClose: function () {
          that._selectedFile = null;
          that._oUploadDialog.destroy();  
          that._oUploadDialog = null;
      }
  });

  this._selectedFile = null;
  this._oUploadDialog.open();
},
           
  
//***************
// DeleteWDRS row
//  *************/
onDeleteRowWDRS: function () {
const oTable = this.byId("tblPartDetailsInitiateWDRS");
const aSelectedItems = oTable.getSelectedItems();
const oModel = this.getOwnerComponent().getModel("Requestservicemodel");
const aData = oModel.getProperty("/WDRS/PartDetailsWDRS");

if (!aSelectedItems.length) {
  sap.m.MessageToast.show("Please select at least one row to delete.");
  return;
}

const aIndexesToRemove = aSelectedItems.map(oItem => {
  const sPath = oItem.getBindingContext("Requestservicemodel").getPath();
  return parseInt(sPath.split("/").pop());
});
 aIndexesToRemove.sort((a, b) => b - a);
 aIndexesToRemove.forEach(iIndex => {
  aData.splice(iIndex, 1);
});

// Update the model
oModel.setProperty("/WDRS/PartDetailsWDRS", aData);

oTable.removeSelections();
},



/*****************
* uploadwdrsdocumentwdrsonuploadfile
*****************/
 onAddDocumentWDRS: function (oEvent) {
const oFileUploader = oEvent.getSource();
const aFiles = oEvent.getParameter("files");
if (!aFiles || aFiles.length === 0) {
  sap.m.MessageToast.show("No file selected.");
  return;
}

const oModel = this.getView().getModel("UploadDocSrvTabDataWDRS");
const aAttachments = oModel.getProperty("/attachments") || [];

const reqID = this._reqIDData || "";
const that = this;

// Get current user
const oUserModel = this.getOwnerComponent().getModel("approvalservicev2");
let sUploadedBy = "User";

oUserModel.read("/getCurrentUser", {
  success: function (oData) {
    if (oData) {
      sUploadedBy = oData.name || oData.userID || "User";
    }

    that._processWDRSFileUpload(aFiles, aAttachments, oModel, oFileUploader, sUploadedBy);
  },
  error: function () {
    that._processWDRSFileUpload(aFiles, aAttachments, oModel, oFileUploader, sUploadedBy);
  }
});
},
_processWDRSFileUpload: function (aFiles, aAttachments, oModel, oFileUploader, sUploadedBy) {
const today = new Date();
const uploadedOn = this._formatDate(today); // formatted as dd-MM-yyyy

for (let i = 0; i < aFiles.length; i++) {
  ((file, index) => {
    const reader = new FileReader();

    reader.onload = (e) => {
      const base64Content = e.target.result;

      aAttachments.push({
        ID: new Date().getTime().toString() + index,
        fileName: file.name,
        mimeType: file.type,
        content: base64Content,
        createdBy: sUploadedBy,
        createdAt: uploadedOn
      });

      if (index === aFiles.length - 1) {
        oModel.setProperty("/attachments", aAttachments);
        oModel.refresh(true);
        sap.m.MessageToast.show("Files uploaded: " + aFiles.length);
        oFileUploader.setValue(""); // reset input
      }
    };

    reader.onerror = () => {
      sap.m.MessageToast.show("Error reading file: " + file.name);
    };

    reader.readAsDataURL(file);
  })(aFiles[i], i);
}
},
_formatDate: function (oDate) {
const dd = String(oDate.getDate()).padStart(2, '0');
const mm = String(oDate.getMonth() + 1).padStart(2, '0');
const yyyy = oDate.getFullYear();
return `${dd}-${mm}-${yyyy}`;
},

//attachment
/*******************
 * tableattachmentdelete, download
 *************/
onDeleteTabAttchment: function(oEvent) {
  var oButton = oEvent.getSource();
  var oModel = this.getView().getModel("UploadDocSrvTabDataWDRS");
  var aAttachments = oModel.getProperty("/attachments");
  var sID = oButton.getCustomData().find(function(oData) {
      return oData.getKey() === "ID";
  }).getValue();
  var iIndex = aAttachments.findIndex(function(oItem) {
      return oItem.ID === sID;
  });
  if (iIndex === -1) return;

  var sFileName = aAttachments[iIndex].fileName;
  var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
  var sPath = "/ReqAttachments(guid'" + sID + "')";
  var that = this;

  oModelV2.remove(sPath, {
      success: function() {
          that._removeAttachmentFromLocalModel(oModel, aAttachments, iIndex, sFileName);
          MessageToast.show("Deleted " + sFileName, { position: "bottom center" });
      },
      error: function(oError) {
          that._removeAttachmentFromLocalModel(oModel, aAttachments, iIndex, sFileName);
          MessageToast.show("Deleted " + sFileName, { position: "bottom center" });
          console.error("Error deleting attachment:", oError);
      }
  });
},

_removeAttachmentFromLocalModel: function(oModel, aAttachments, iIndex, sFileName) {
  aAttachments.splice(iIndex, 1);
  oModel.setProperty("/attachments", aAttachments);
  oModel.refresh(true);
},
onDownloadTabAttachment: function(oEvent) {
  var oButton = oEvent.getSource();
  var sID = oButton.getCustomData().find(function(oData) {
      return oData.getKey() === "ID";
  }).getValue();
  var sFileName = oButton.getCustomData().find(function(oData) {
      return oData.getKey() === "fileName";
  }).getValue();

  var oModel = this.getView().getModel("UploadDocSrvTabDataWDRS");
  var aAttachments = oModel.getProperty("/attachments") || [];
  var oAttachment = aAttachments.find(function(oItem) {
      return oItem.ID === sID;
  });

  var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
  var sPath = "/ReqAttachments(guid'" + sID + "')";
  var that = this;

  oModelV2.read(sPath, {
      success: function(oData) {
          if (oData && oData.__metadata && oData.__metadata.media_src) {
              var oLink = document.createElement("a");
              oLink.href = oData.__metadata.media_src;
              oLink.download = sFileName;
              document.body.appendChild(oLink);
              oLink.click();
              document.body.removeChild(oLink);
              MessageToast.show("Downloading file from server: " + sFileName, { position: "bottom center" });
          } else {
              that._downloadLocalAttachment(oAttachment, sFileName);
          }
      },
      error: function() {
          that._downloadLocalAttachment(oAttachment, sFileName);
      }
  });
},

_downloadBase64File: function(sBase64Content, sFileName) {
  try {
      var sBase64Data = sBase64Content.split(',')[1];
      var sMimeType = sBase64Content.split(';')[0].split(':')[1];
      var byteCharacters = atob(sBase64Data);
      var byteNumbers = new Array(byteCharacters.length);
      for (var i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
      }
      var byteArray = new Uint8Array(byteNumbers);
      var oBlob = new Blob([byteArray], { type: sMimeType });
      var sUrl = URL.createObjectURL(oBlob);

      var oLink = document.createElement("a");
      oLink.href = sUrl;
      oLink.download = sFileName;
      document.body.appendChild(oLink);
      oLink.click();
      document.body.removeChild(oLink);
      URL.revokeObjectURL(sUrl);
      MessageToast.show("Downloading file: " + sFileName, { position: "bottom center" });
  } catch (e) {
      MessageToast.show("Error downloading file: " + sFileName, { position: "bottom center" });
      console.error("Error downloading file:", e);
  }
},

_downloadLocalAttachment: function(oAttachment, sFileName) {
  if (!oAttachment || !oAttachment.content) {
      MessageToast.show("Local file content not found for: " + sFileName, { position: "bottom center" });
      return;
  }
  this._downloadBase64File(oAttachment.content, sFileName);
},
onDeleteRowAttachmentWDRS: function () {
  const oTable = this.byId("documentTableInitiateWDRS");
  const aSelectedItems = oTable.getSelectedItems();
  const oModel = this.getView().getModel("UploadDocSrvTabDataWDRS");
  const aAttachments = oModel.getProperty("/attachments");

  if (!aSelectedItems.length) {
      sap.m.MessageToast.show("Please select at least one attachment to delete.");
      return;
  }

  sap.m.MessageBox.confirm("Do you want to delete the selected attachment(s)?", {
      actions: [sap.m.MessageBox.Action.OK, sap.m.MessageBox.Action.CANCEL],
      onClose: (oAction) => {
          if (oAction === sap.m.MessageBox.Action.OK) {
              //  Use ID-based filtering here
              const aSelectedIds = aSelectedItems.map(oItem =>
                  oItem.getBindingContext("UploadDocSrvTabDataWDRS").getProperty("ID")
              );

              const aNewAttachments = aAttachments.filter(oAttachment =>
                  !aSelectedIds.includes(oAttachment.ID)
              );

              // Update the model with new array
              oModel.setProperty("/attachments", aNewAttachments);

              //   clear table selection
              oTable.removeSelections();

              sap.m.MessageToast.show("Selected attachment(s) deleted.");
          }
      }
  });
},



/**********************
 * typeofwastewdrstypeofwaste
 ************************/
onTypeOfWasteWDRS: function() {
  var oView = this.getView();
  var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

  oModelV2.read("/ControlValues", {
      urlParameters: {
          "$filter": "category eq 'ISR_WASTETYPE'"
      },
      success: function(oData) {
          if (oData && oData.results) {
              var oJSONModel = new sap.ui.model.json.JSONModel(oData);
              oView.setModel(oJSONModel, "INFRADataFetchWDRS");
          }
      },
      error: function(oError) {
          sap.m.MessageToast.show("Failed to load waste types.", { position: "bottom center" });
          console.error("Error fetching waste types:", oError);
      }
  });
},
SelecttypeofWasteWDRS: function (oEvent) {
  var oSelectedItem = oEvent.getParameter("selectedItem");

  if (oSelectedItem) {
      var sSelectedKey = oSelectedItem.getKey(); // Gets the 'description' as per your ListItem key
      var oModel = this.getView().getModel("Requestservicemodel");

      // Set the selected key into the model at the correct path
      oModel.setProperty("/WDRS/typeOfwasteWDRS", sSelectedKey);

      console.log("Type of Waste Selected:", sSelectedKey);
  } else {
      console.warn("No item selected in Type of Waste ComboBox.");
  }
},


// allcommon data are here

/******************************
 * onfeatchapproverwdrsapprover
 ***************************/
onFetchApproverWDRS: function() {
  var oView = this.getView();
  var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

  oModelV2.read("/Approvers", {
      urlParameters: {
          "$filter": "department eq 'ISR_WDRS' and role eq 'Approver'"
      },
      success: function(oData) {
          if (oData && oData.results) {
              var oJSONModel = new sap.ui.model.json.JSONModel(oData);
              oView.setModel(oJSONModel, "ApproverIDWDRS");
          }
      },
      error: function(oError) {
          sap.m.MessageToast.show("Failed to load approver data.", { position: "bottom center" });
          console.error("Error fetching approver data:", oError);
      }
  });
},
onAprroverChangeWDRS: function(oEvent) {
  var oSelectedItem = oEvent.getParameter("selectedItem");
  if (oSelectedItem) {
      var sKey = oSelectedItem.getKey(); // userID
      var sText = oSelectedItem.getText(); // userID - name

      console.log("Selected WDRS Approver:", sKey, sText);

      var oModel = this.getView().getModel("Requestservicemodel");
      if (oModel) {
          oModel.setProperty("/WDRS/ApproverWDRS", sKey);
      }
  }
},
onFetchUOMWDRS: function() {
  var oView = this.getView();
  var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

  oModelV2.read("/ControlValues", {
      urlParameters: {
          "$filter": "category eq 'ISR_UOM'"
      },
      success: function(oData) {
          if (oData && oData.results) {
              var oJSONModel = new sap.ui.model.json.JSONModel(oData.results);
              oView.setModel(oJSONModel, "uomModelWDRS"); 
          }
      },
      error: function(oError) {
          sap.m.MessageToast.show("Failed to load UOM data.", { position: "bottom center" });
          console.error("Error fetching UOMs:", oError);
      }
  });
},

/****************************
 * partnumberwdrsparbinnumber
 *****************************/
onLiveChangePartDescWDRS: function (oEvent) {
  const sValue = oEvent.getParameter("value");
  if (!sValue) return this._clearRowWDRS(oEvent);
  if (sValue.length < 6) return;

  this._fetchPartDetailsWDRS({ partDesc: sValue }, oEvent);
},

onLiveChangePartNumberWDRS: function (oEvent) {
  const sValue = oEvent.getParameter("value");
  if (!sValue) return this._clearRowWDRS(oEvent);
  if (sValue.length < 6) return;

  this._fetchPartDetailsWDRS({ partNo: sValue }, oEvent);
},
_fetchPartDetailsWDRS: function (oParams, oEvent) {
  const sPath = oEvent.getSource().getBindingContext("Requestservicemodel").getPath();
  const oModel = this.getOwnerComponent().getModel("Requestservicemodel");
  const oReadModel = this.getOwnerComponent().getModel("approvalservicev2");

  const aFilters = [
    new sap.ui.model.Filter("department", sap.ui.model.FilterOperator.EQ, "WDRS")
  ];

  if (oParams.partDesc) {
    aFilters.push(new sap.ui.model.Filter("partDesc", sap.ui.model.FilterOperator.EQ, oParams.partDesc));
  }
  if (oParams.partNo) {
    aFilters.push(new sap.ui.model.Filter("partNo", sap.ui.model.FilterOperator.EQ, oParams.partNo));
  }

  oReadModel.read("/PartDetails", {
    filters: aFilters,
    success: (data) => {
      if (data.results.length) {
        const hit = data.results[0];
        this._mergeRowWDRS(sPath, oModel, {
          PartDescriptionWDRS:  hit.partDesc,
          PartNumberWDRS:       hit.partNo,
          UOMWDRS:              hit.UOM,
          TentativeWeightWDRS:  "", // Default or set as per requirement
          WeighmentWeightWDRS:  ""
        });
      }
    },
    error: (err) => {
      console.error("WDRS PartDetails fetch failed", err);
    }
  });
},
_mergeRowWDRS: function (sPath, oModel, oNewData) {
  const oRow = oModel.getProperty(sPath);
  Object.assign(oRow, oNewData);
  oModel.setProperty(sPath, oRow);
},
_clearRowWDRS: function (oEvent) {
  const oSource = oEvent.getSource();
  const oContext = oSource.getBindingContext("Requestservicemodel");

  if (!oContext) return;

  const sPath = oContext.getPath();
  const oModel = oContext.getModel();

  oModel.setProperty(sPath, {
    PartDescriptionWDRS:  "",
    PartNumberWDRS:       "",
    UOMWDRS:              "",
    TentativeWeightWDRS:  "",
    WeighmentWeightWDRS:  ""
  });
},





/**************************************************
 * common for all the pages
 **************************************************/
onCancelInfraProcessall: function() {
  var oRouter = this.getOwnerComponent().getRouter();
  MessageToast.show("Navigating back to dashboard...", { position: "bottom center" });
  if (this._ApprovedCheck === "Approved") {
      oRouter.navTo("approverdashboard", {});
  } else {
      oRouter.navTo("DashboardUI", { Name: this._SanctionfdNameUI });
  }
},



/************************
 * commonpayload for all
 **************************/
_buildUnifiedPayload: function (type) {
  const oModel = this.getOwnerComponent().getModel("Requestservicemodel");
  const FRS = oModel.getProperty("/FRS") || {};
  const CRS = oModel.getProperty("/CRS") || {};
  const SRS = oModel.getProperty("/SRS") || {};
  const WDRS = oModel.getProperty("/WDRS") || {};

  let infraDtl = {};

  switch (type) {
    case "FRS":
      // const locationMap = { "MRV": 0, "CE": 1, "OMSPT": 2 };
      const locationReverseMap = ["MRV", "CE", "OMSPT"];
      infraDtl = {
        initiationDt: FRS.initiationDt || "2025-06-12",
        subType : "FRS",
        initiator: FRS.requesteridFRS,
        // loc: FRS.locationFRS || "",
        loc: locationReverseMap[FRS.locationIndexFRS] || "MRV", 
        WBSCode: FRS.wbsCodeFRS || "",
        costCenter: FRS.costCodeFRS || "",
        dept: FRS.departmentNameFRS || "",
        approver: FRS.approverFRS || "",
        typeOfWaste: FRS.typeOfWaste || "",
        requirementDtl: Array.isArray(FRS.VehicleDetailsPayload)
          ? FRS.VehicleDetailsPayload.map((item) => ({
              vehicleNo: item.VehicleNoFRS || "",
              projectNo: item.ProjectNoFRS || "",
              productDesc: item.ProductDescriptionFRS || "",
              partDesc: item.PartDescriptionFRS || "",
              partNo: item.PartNumberFRS || "",
              binNo: item.BinNumberFRS || "",
              price: item.PriceFRS || "",
              UOM: item.UOMFRS || "",
              tentativeWt: item.TentativeWeightFRS || "",
              weighmentWt: item.WeighmentWeightFRS || "",
              requestedQty: item.RequestedQtyFRS || "",
              approvedQty: item.ApprovedQtyFRS || "",
              issuedQty: item.IssuedQtyFRS || ""
            }))
          : []
      };
      break;

    case "CRS":
      infraDtl = {
        initiationDt: CRS.InitiationDateCRS || "",
        subType : "CRS",
        initiator: CRS.RequesterTokenIDCRS,
        loc: CRS.LocationCRS || "",
        WBSCode: CRS.wbsCodeCRS || "",
        costCenter: CRS.costCodeCRS || "",
        dept: CRS.RequesterDepartmentCRS || "",
        approver: CRS.HodCRS || "",
        requirementDtl: Array.isArray(CRS.PartDetailsCRS)
          ? CRS.PartDetailsCRS.map((item) => ({
              partDesc: item.PartDescriptionCRS || "",
              partNo: item.PartNumberCRS || "",
              binNo: item.BinNumberCRS || "",
              price: item.PriceCRS || "",
              requestedQty: item.RequestedQtyCRS || "",
              approvedQty: item.ApprovedQtyCRS || "",
              issuedQty: item.IssuedQtyCRS || ""
            }))
          : []
      };
      break;

    case "SRS":
      infraDtl = {
        initiationDt: SRS.InitiationDateSRS || "",
        subType : "SRS",
        initiator: SRS.RequesterTokenIdSRS,
        loc: SRS.LocationSRS || "",
        WBSCode: SRS.wbsCodeSRS || "",
        costCenter: SRS.costCenterSRS || "",
        dept: SRS.RequesterDepartmentSRS || "",
        approver: SRS.HodSRS || "",
        requirementDtl: Array.isArray(SRS.PartDetailsSRS)
          ? SRS.PartDetailsSRS.map((item) => ({
              partDesc: item.PartDescriptionSRS || "",
              partNo: item.PartNumberSRS || "",
              binNo: item.BinNumberSRS || "",
              price: item.PriceSRS || "",
              requestedQty: item.RequestedQtySRS || "",
              approvedQty: item.ApprovedQtySRS || "",
              issuedQty: item.IssuedQtySRS || ""
            }))
          : []
      };
      break;

    case "WDRS":
      infraDtl = {
        initiationDt: WDRS.InitiationDateWDRS || "2025-06-12",
        subType : "WDRS",
        initiator: WDRS.RequestorIDWDRS,
        loc: WDRS.LocationWDRS || "",
        typeOfWaste: WDRS.typeOfwasteWDRS,
        WBSCode: WDRS.wbsCodeWDRS || "",
        costCenter: WDRS.costCenterWDRS || "",
        dept: WDRS.RequesterDepartmentWDRS || "",
        approver: WDRS.ApproverWDRS || "",
        requirementDtl: Array.isArray(WDRS.PartDetailsWDRS)
          ? WDRS.PartDetailsWDRS.map((item) => ({
              partDesc: item.PartDescriptionWDRS || "",
              partNo: item.PartNumberWDRS || "",
              UOM: item.UOMWDRS || "",
              tentativeWt: item.TentativeWeightWDRS || "",
              weighmentWt: item.WeighmentWeightWDRS || "",
              requestedQty: item.RequestedQtyWDRS || "",
              approvedQty: item.ApprovedQtyWDRS || "",
              issuedQty: item.IssuedQtyWDRS || ""
            }))
          : []
      };
      break;
  }

  return infraDtl;
},


//getusertype
_populateRequesterDeptAndDate: async function (documentType) {
  const getCurrentFormattedDate = () => {
    const today = new Date();
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0');
    const yyyy = today.getFullYear();
    return `${yyyy}-${mm}-${dd}`;
  };

  try {
    const oModel = this.getOwnerComponent().getModel("approvalservicev2");

    // Initialize
    let requester = "5002152 - Aman Anand";
    let department = "INFRA";

    // Valid types
    const validDocTypes = ["FRS", "CRS", "WDRS", "SRS"];

    if (!validDocTypes.includes(documentType)) {
      console.warn("Unsupported document type:", documentType);
      return {
        requester,
        department,
        initiationDate: getCurrentFormattedDate()
      };
    }

    // Read from Approvers
    const currentUser = await new Promise((resolve, reject) => {
      oModel.callFunction("/getCurrentUser", {
        success: function (data) {
          resolve(data);
        },
        error: reject
      });
    });

    // Find Initiator for given doc type
    if (currentUser && currentUser.userID && currentUser.name && currentUser.department) {
      requester = `${currentUser.userID} - ${currentUser.name}`;
      department = currentUser.department;
    }


    return {
      requester,
      department,
      initiationDate: getCurrentFormattedDate()
    };

  } catch (err) {
    console.error("Auto-population error:", err);
    return {
      requester: "5002152 - Aman Anand",
      department: "INFRA",
      initiationDate: getCurrentFormattedDate()
    };
  }
},

 
/*********************
* _onRouteMatchedInfra
*********************/
_onRouteMatchedInfra: async function (oEvent) {
  const oArgs = oEvent.getParameter("arguments");
  const basedNameUIType = oArgs.type;
  var oAttachmentModel = this.getView().getModel("UploadDocSrvTabDataWDRS");
  if (oAttachmentModel) {
    oAttachmentModel.setData({ attachments: [] });
  } else {
    oAttachmentModel = new sap.ui.model.json.JSONModel({ attachments: [] });
    this.getView().setModel(oAttachmentModel, "UploadDocSrvTabDataWDRS");
  }
  
    this._SanctionfdNameUI = "INFRA";
    this._reqID = "";
  this._ApprovedCheck = "";
  let subtypes = basedNameUIType ? basedNameUIType.toUpperCase() : "";
  const { requester, department, initiationDate } =  await this._populateRequesterDeptAndDate(subtypes);
  var oViewModel = this.getView().getModel("viewenableddatacheck");
  oViewModel.setProperty("/enableRowActions", true); 
  oViewModel.setProperty("/approvebuttonvisiblity", false);
  oViewModel.setProperty("/enableRowActionsNOT", false); 
  oViewModel.setProperty("/forpanelrowandbuttoninputbox", false);
  oViewModel.setProperty("/approvebuttonvisiblityForStoreTask", false);

  oViewModel.setProperty("/isApproverOrApproved", false);
  oViewModel.setProperty("/WDRSapprovebuttonvisiblity", false);
 
  // Empty initial structure
  const oPayload = {
    FRS: {
      requesteridFRS: requester,
      slipNumberFRS: "",
      costCodeFRS: "",
      locationFRS: "",
      wbsCodeFRS: "",
      // departmentNameFRS: "",
      departmentNameFRS: department,
      approverFRS: "",
      VehicleDetailsPayload: [] // VehicleNoFRS, ProjectNoFRS, ProductDescriptionFRS, UOMFRS, RequestedQtyFRS, ApprovedQtyFRS
    },
    CRS: {
      slipNumberCRS: "",
      // RequesterTokenIDCRS: "",
      RequesterTokenIDCRS: requester,
      // RequesterDepartmentCRS: "",
      RequesterDepartmentCRS: department,
      // InitiationDateCRS: "",
      InitiationDateCRS: initiationDate,
      LocationCRS: "",
      wbsCodeCRS: "",
      costCodeCRS: "",
      HodCRS: "",
      PartDetailsCRS: [] // PartDescriptionCRS, PartNumberCRS, BinNumberCRS, PriceCRS, RequestedQtyCRS
    },
    SRS: {
      slipNumberSRS: "",
      // RequesterTokenIdSRS: "",
      RequesterTokenIdSRS: requester,
      // RequesterDepartmentSRS: "",
      RequesterDepartmentSRS: department,
      // InitiationDateSRS: "",
      InitiationDateSRS: initiationDate,
      LocationSRS: "",
      wbsCodeSRS: "",
      costCenterSRS: "",
      HodSRS: "",
      PartDetailsSRS: [] // PartDescriptionSRS, PartNumberSRS, BinNumberSRS, PriceSRS, RequestedQtySRS
    },
    WDRS: {
      slipNumberWDRS: "",
      // RequestorIDWDRS: "",
      RequestorIDWDRS: requester,
      // RequesterDepartmentWDRS: "",
      RequesterDepartmentWDRS: department,
      // InitiationDateWDRS: "",
      InitiationDateWDRS: initiationDate,
      typeOfwasteWDRS: "",
      LocationWDRS: "",
      wbsCodeWDRS: "",
      ApproverWDRS: "",
      costCenterWDRS: "", 
      PartDetailsWDRS: [] // PartDescriptionWDRS, PartNumberWDRS, UOMWDRS, TentativeWeightWDRS
    }
  };
  
  // Map route param to model key
  const routeToModelKeyMap = {
    frs: "FRS",
    crs: "CRS",
    srs: "SRS",
    wdrs: "WDRS"
  };
  
  const sModelKey = routeToModelKeyMap[basedNameUIType];
  
  // Validate model key
  if (!sModelKey) {
    sap.m.MessageBox.error("Invalid route type.");
    return;
  }
  
  // Get or create the model
  let oRequestServiceModel = this.getOwnerComponent().getModel("Requestservicemodel");
  if (!oRequestServiceModel) {
    oRequestServiceModel = new sap.ui.model.json.JSONModel();
    this.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
  }
  
  // Set only the relevant section based on the route
  oRequestServiceModel.setData({ [sModelKey]: oPayload[sModelKey] });

  //for partbinandpartnubmer
  this.FetchPartBinandPartDesc(subtypes);
  
  // Call routing setup
  this.ISRFormRouteMatched(oEvent);
   

  if (sModelKey === "FRS") {
    this.onFetchApproverFRS();
    this.onProductDescriptionDataFetchFRS();
    this.onUOMFetchFRS();
  } else if (sModelKey === "CRS") {
    this.onLocationDataFetchCRS();
    this.onFetchHODCRS();
  } else if (sModelKey === "SRS") {
    this.onLocationDataFetchSRS();
    this.onFetchHODSRS();
  } else if (sModelKey === "WDRS") {
    this.onTypeOfWasteWDRS();
    this.onFetchApproverWDRS();
    this.onFetchUOMWDRS();
  }

  
  },


  FetchPartBinandPartDesc: function (sDepartment) {
    let oSuggestionsModel = this.getView().getModel("suggestionsModel");
  
    if (!oSuggestionsModel) {
      oSuggestionsModel = new sap.ui.model.json.JSONModel();
      this.getView().setModel(oSuggestionsModel, "suggestionsModel");
    }
  
    this.getOwnerComponent().getModel("approvalservicev2").read("/PartDetails", {
      success: (oData) => {
        //  Filter by department before setting data
        const filteredResults = oData.results.filter(item => item.department === sDepartment);
  
        oSuggestionsModel.setData({
          desc: filteredResults,
          number: filteredResults
        });
      },
      error: () => {
        sap.m.MessageToast.show("Failed to load suggestion data.");
      }
    });
  },
  
       
  /*****************
  * ISRFormRouteMatched for routing
  *****************/
          ISRFormRouteMatched: function (oEvent) {
           
            setTimeout(() => window.scrollTo(0, 0), 100);
        
            const sType = oEvent.getParameter("arguments").type;  
            const oComponent = this.getOwnerComponent();
        
            // Use or create the shared model
            let oSharedModel = oComponent.getModel("shared");
            if (!oSharedModel) {
                oSharedModel = new sap.ui.model.json.JSONModel();
                oComponent.setModel(oSharedModel, "shared");
            }
        
            // Route-to-data mapping
            const mapping = {
                "frs":        { approvalType: "Fuel Request", initiationKey: "Initiate FRS" },
        
                "crs":         { approvalType: "Consumable Request", initiationKey: "Initiate CRS" },
        
                "srs":         { approvalType: "Stationary Request", initiationKey: "Initiate SRS" },
        
                "wdrs":        { approvalType: "Waste Disposal Request", initiationKey: "Initiate WDRS" },
            };
        
            const data = mapping[sType] || {};
            oSharedModel.setProperty("/approvalType", data.approvalType || "");
            oSharedModel.setProperty("/initiationKey", data.initiationKey || "");
        },  


/************************
 * _onRouteMatchedInfraREF
 ****************************/
_onRouteMatchedInfraREF: function (oEvent) {
  const oArgs = oEvent.getParameter("arguments");
  const reqID = oArgs.reqID;
  if (!reqID) {
    sap.m.MessageToast.show("Missing reqID in route.");
    return;
  }

  this._SanctionfdNameUI = "INFRA";
  this._reqID = reqID;
  this._ApprovedCheck = "";

  const oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
  const that = this;

  oModelV2.read("/Requests", {
    urlParameters: {
      "$filter": `reqID eq '${reqID}'`,
      "$expand": "infraDtl/requirementDtl"
    },
    success: function (oData) {
      if (!oData.results.length) {
        sap.m.MessageToast.show("No data found for Req ID: " + reqID);
        return;
      }
      const result        = oData.results[0];
      const infra         = result.infraDtl || {};
      const refNoattahcmet = result.refNo;
      const reqidNo = result.reqID;
      const atts          = result.attachments.results || [];
      const reqDetailsNav = result.infraDtl.requirementDtl.results || [];
      const status        = result.status;
      const subType       = (infra.subType || "").toLowerCase();

      const keyMap = { frs:"FRS", crs:"CRS", srs:"SRS", wdrs:"WDRS" };
      const modelKey = keyMap[subType];
      if (!modelKey) {
        sap.m.MessageToast.show("Unsupported subType: " + infra.subType);
        return;
      }

      // Transform and include requirementDtl
      let payload = {};
      switch (modelKey) {
        case "FRS":
          const locationMap = { "MRV": 0, "CE": 1, "OMSPT": 2 };
          payload = {
            requesteridFRS:     infra.initiator || "",
            slipNumberFRS:      result.refNo        || "",
            costCodeFRS:        infra.costCenter    || "",
            locationIndexFRS:  locationMap[infra.loc] ?? -1,        
            wbsCodeFRS:         infra.WBSCode       || "",
            departmentNameFRS:  infra.dept          || "",
            approverFRS:        infra.approver      || "",
            initiationDateFRS:  infra.initiationDt  || "",
            VehicleDetailsPayload: reqDetailsNav.map(d => ({
              VehicleNoFRS:           d.vehicleNo || "",
              ProjectNoFRS:           d.projectNo || "",
              ProductDescriptionFRS:  d.productDesc || "",
              UOMFRS:                 d.UOM || "",
              RequestedQtyFRS:        d.requestedQty || "",
              ApprovedQtyFRS:         d.approvedQty || ""
            }))
          };
          break;

        case "CRS":
          payload = {
            slipNumberCRS:          result.refNo || "",
    RequesterTokenIDCRS:    infra.initiator || "",
    RequesterDepartmentCRS: infra.dept || "",
    InitiationDateCRS:      infra.initiationDt || "",
    LocationCRS:            infra.loc || "",
    wbsCodeCRS:             infra.WBSCode || "",
    costCodeCRS:            infra.costCenter || "",
    HodCRS:                 infra.approver || "",
    PartDetailsCRS:         reqDetailsNav.map(d => ({
      PartDescriptionCRS: d.partDesc || "",
      PartNumberCRS:      d.partNo || "",
      BinNumberCRS:       d.binNo || "",
      PriceCRS:           d.price || "",
      RequestedQtyCRS:    d.requestedQty || "",
      ApprovedQtyCRS:     d.approvedQty || "",
      IssuedQtyCRS:       d.issuedQty || ""

            }))
          };
          break;

        case "SRS":
          payload = {
            slipNumberSRS:          result.refNo || "",
    RequesterTokenIdSRS:    infra.initiator || "",
    RequesterDepartmentSRS: infra.dept || "",
    InitiationDateSRS:      infra.initiationDt || "",
    LocationSRS:            infra.loc || "",
    wbsCodeSRS:             infra.WBSCode || "",
    costCenterSRS:          infra.costCenter || "",
    HodSRS:                 infra.approver || "",
    PartDetailsSRS:         reqDetailsNav.map(d => ({
      PartDescriptionSRS: d.partDesc || "",
      PartNumberSRS:      d.partNo || "",
      BinNumberSRS:       d.binNo || "",
      PriceSRS:           d.price || "",
      RequestedQtySRS:    d.requestedQty || "",
      ApprovedQtySRS:     d.approvedQty || "",
      IssuedQtySRS:       d.issuedQty || ""

            }))
          };
          break;

        case "WDRS":
          payload = {
            slipNumberWDRS:          result.refNo || "",
    RequestorIDWDRS:         infra.initiator || "",
    RequesterDepartmentWDRS: infra.dept || "",
    InitiationDateWDRS:      infra.initiationDt || "",
    typeOfwasteWDRS:         infra.typeOfWaste || "",
    LocationWDRS:            infra.loc || "",
    wbsCodeWDRS:             infra.WBSCode || "",
    ApproverWDRS:            infra.approver || "",
    costCenterWDRS:          infra.costCenter || "",
    PartDetailsWDRS:         reqDetailsNav.map(d => ({
      PartDescriptionWDRS:  d.partDesc || "",
      PartNumberWDRS:       d.partNo || "",
      UOMWDRS:              d.UOM || "",
      TentativeWeightWDRS:  d.tentativeWt || "",
      WeighmentWeightWDRS:  d.weighmentWt || ""
            }))
          };
          break;
      }
      /*********************
       * fetchattachemt for wbrs
       ******************/
      that.onAttchmentDataFetch(reqidNo);
      that.onFetchTimelinessData(reqidNo);

      // 1. Request model
      let oReqModel = that.getOwnerComponent().getModel("Requestservicemodel");
      if (!oReqModel) {
        oReqModel = new sap.ui.model.json.JSONModel();
        that.getOwnerComponent().setModel(oReqModel, "Requestservicemodel");
      }
      oReqModel.setData({ [modelKey]: payload });

       

      // 3. View flags
      const isDraft = !status || status === "Draft" || status === "Send Back";
      const oViewModel = that.getView().getModel("viewenableddatacheck");

      oViewModel.setProperty("/isApproverOrApproved", false); 
      oViewModel.setProperty("/WDRSapprovebuttonvisiblity", false);
      oViewModel.setProperty("/WDRSapprovebuttonvisiblityedit", false);


      if (status === "Draft" || !status || status === "Send Back") {
        oViewModel.setProperty("/enableRowActions", true); //for whole page
        oViewModel.setProperty("/approvebuttonvisiblity", false);
        oViewModel.setProperty("/enableRowActionsNOT", false);  
         

        oViewModel.setProperty("/forpanelrowandbuttoninputbox", true); //2 no know
        oViewModel.setProperty("/approvebuttonvisiblityForStoreTask", false); //1

    } else if (status === "Pending" || status === "Pending At HOD") {
        oViewModel.setProperty("/enableRowActions", false); //whloe page
        oViewModel.setProperty("/approvebuttonvisiblity", false); 
        oViewModel.setProperty("/enableRowActionsNOT", false);  
        oViewModel.setProperty("/forpanelrowandbuttoninputbox", false);
        oViewModel.setProperty("/approvebuttonvisiblityForStoreTask", false);
        
        

    } else if (status === "Approved") {
        oViewModel.setProperty("/enableRowActions", false);
        oViewModel.setProperty("/approvebuttonvisiblity", false); 
        oViewModel.setProperty("/enableRowActionsNOT", false);  
        oViewModel.setProperty("/forpanelrowandbuttoninputbox", false);
        oViewModel.setProperty("/approvebuttonvisiblityForStoreTask", false); 



        if(subType == "frs"){
          oViewModel.setProperty("/isApproverOrApproved", true); 
          oViewModel.setProperty("/whenapprovedisApproverOrApproved", false); 
          
        }
        if(subType == "crs" || subType == "srs"){
          oViewModel.setProperty("/isApproverOrApproved", true); 
        }
        else if(subType == "wdrs"){
          oViewModel.setProperty("/WDRSapprovebuttonvisiblity", true);
          oViewModel.setProperty("/WDRSapprovebuttonvisiblityedit", false);
    
        }
        

    // Conditional visibility based on subtype
    // if (subType === "wdrs") {
    //     oViewModel.setProperty("/approvebuttonvisiblity", true);  
    // } else if (["crs", "srs"].includes(subType)) {
    //     oViewModel.setProperty("/approvebuttonvisiblityForStoreTask", true); // Show Issued Qty
    // } else if (subType === "frs") {
    //     oViewModel.setProperty("/approvebuttonvisiblity", true); // Show Approved Qty
    // }
    }

      // 4. Header labels
      that.ISRFormRouteMatched({ getParameter: () => ({ type: subType }) });

      // 5. Subtype fetchers
      switch (modelKey) {
        case "FRS":
          that.onFetchApproverFRS();
          that.onProductDescriptionDataFetchFRS();
          that.onUOMFetchFRS();
          break;
        case "CRS":
          that.onLocationDataFetchCRS();
          that.onFetchHODCRS();
          break;
        case "SRS":
          that.onLocationDataFetchSRS();
          that.onFetchHODSRS();
          break;
        case "WDRS":
          that.onTypeOfWasteWDRS();
          that.onFetchApproverWDRS();
          that.onFetchUOMWDRS();
          break;
      }

      setTimeout(() => window.scrollTo(0, 0), 100);
    },
    error: function (oError) {
      sap.m.MessageToast.show("Failed to load request data.");
      console.error("InfraREF Read Error:", oError);
    }
  });
},

/************************
 * _onRouteMatchedInfraApproved
 ****************************/
 _onRouteMatchedInfraApproved: function (oEvent) {
  const oArgs = oEvent.getParameter("arguments");

  const approvalContext = oArgs.approved;             // From route
  const subTypeFromRoute = oArgs.type?.toLowerCase(); // frs, crs, srs, wdrs
  const reqID = oArgs.reqID;

  this._SanctionfdNameUI = subTypeFromRoute;
  this._reqIDData = reqID;
  this._ApprovedCheck = approvalContext;

  const oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
  const that = this;

  const keyMap = { frs: "FRS", crs: "CRS", srs: "SRS", wdrs: "WDRS" };
  const modelKey = keyMap[subTypeFromRoute];

  if (!modelKey) {
    sap.m.MessageToast.show("Unsupported subType: " + subTypeFromRoute);
    return;
  }

  sap.ui.core.BusyIndicator.show(0);

  oModelV2.read("/Requests", {
    urlParameters: {
      "$filter": `reqID eq '${reqID}'`,
      "$expand": "infraDtl/requirementDtl"
    },
    success: function (oData) {
      sap.ui.core.BusyIndicator.hide();

      if (!oData?.results?.length) {
        sap.m.MessageToast.show("No data found for Req ID: " + reqID);
        return;
      }

      const result = oData.results[0];
      const infra = result.infraDtl || {};
      const refNoattahcmet = result.refNo;
      const reqidNo = result.reqID;
      const reqDetailsNav = result.infraDtl.requirementDtl?.results || [];
      const status = result.status;
      const subType  = (infra.subType || "").toLowerCase();
      const stage = result.stage;
      const attachments = result.attachments?.results || [];

      // 1. Build payload per modelKey
      let payload = {};
      switch (modelKey) {
        case "FRS":
          const locationMap = { "MRV": 0, "CE": 1, "OMSPT": 2 };
          payload = {
            requesteridFRS: infra.initiator || "",
            slipNumberFRS: result.refNo || "",
            costCodeFRS: infra.costCenter || "",
            locationIndexFRS: locationMap[infra.loc] ?? -1,
            wbsCodeFRS: infra.WBSCode || "",
            departmentNameFRS: infra.dept || "",
            approverFRS: infra.approver || "",
            initiationDateFRS: infra.initiationDt || "",
            VehicleDetailsPayload: reqDetailsNav.map(d => ({
              VehicleNoFRS: d.vehicleNo || "",
              ProjectNoFRS: d.projectNo || "",
              ProductDescriptionFRS: d.productDesc || "",
              UOMFRS: d.UOM || "",
              RequestedQtyFRS: d.requestedQty || "",
              ApprovedQtyFRS: d.approvedQty || ""
            }))
          };
          break;

        case "CRS":
          payload = {
            slipNumberCRS: result.refNo || "",
            RequesterTokenIDCRS: infra.initiator || "",
            RequesterDepartmentCRS: infra.dept || "",
            InitiationDateCRS: infra.initiationDt || "",
            LocationCRS: infra.loc || "",
            wbsCodeCRS: infra.WBSCode || "",
            costCodeCRS: infra.costCenter || "",
            HodCRS: infra.approver || "",
            PartDetailsCRS: reqDetailsNav.map(d => ({
              PartDescriptionCRS: d.partDesc || "",
              PartNumberCRS: d.partNo || "",
              BinNumberCRS: d.binNo || "",
              PriceCRS: d.price || "",
              RequestedQtyCRS: d.requestedQty || "",
              ApprovedQtyCRS: d.approvedQty || "",
              IssuedQtyCRS: d.issuedQty || ""
            }))
          };
          break;

        case "SRS":
          payload = {
            slipNumberSRS: result.refNo || "",
            RequesterTokenIdSRS: infra.initiator || "",
            RequesterDepartmentSRS: infra.dept || "",
            InitiationDateSRS: infra.initiationDt || "",
            LocationSRS: infra.loc || "",
            wbsCodeSRS: infra.WBSCode || "",
            costCenterSRS: infra.costCenter || "",
            HodSRS: infra.approver || "",
            PartDetailsSRS: reqDetailsNav.map(d => ({
              PartDescriptionSRS: d.partDesc || "",
              PartNumberSRS: d.partNo || "",
              BinNumberSRS: d.binNo || "",
              PriceSRS: d.price || "",
              RequestedQtySRS: d.requestedQty || "",
              ApprovedQtySRS: d.approvedQty || "",
              IssuedQtySRS: d.issuedQty || ""
            }))
          };
          break;

        case "WDRS":
          payload = {
            slipNumberWDRS: result.refNo || "",
            RequestorIDWDRS: infra.initiator || "",
            RequesterDepartmentWDRS: infra.dept || "",
            InitiationDateWDRS: infra.initiationDt || "",
            typeOfwasteWDRS: infra.typeOfWaste || "",
            LocationWDRS: infra.loc || "",
            wbsCodeWDRS: infra.WBSCode || "",
            ApproverWDRS: infra.approver || "",
            costCenterWDRS: infra.costCenter || "",
            PartDetailsWDRS: reqDetailsNav.map(d => ({
              PartDescriptionWDRS: d.partDesc || "",
              PartNumberWDRS: d.partNo || "",
              UOMWDRS: d.UOM || "",
              TentativeWeightWDRS: d.tentativeWt || "",
              WeighmentWeightWDRS: d.weighmentWt || ""
            }))
          };
          break;
      }

      /*********************
       * fetchattachemt for wbrs
       ******************/
      that.onAttchmentDataFetch(reqidNo);
      that.onFetchTimelinessData(reqidNo);

      // 2. Set payload to model
      const reqModel = that.getOwnerComponent().getModel("Requestservicemodel") || new sap.ui.model.json.JSONModel();
      that.getOwnerComponent().setModel(reqModel, "Requestservicemodel");
      reqModel.setData({ [modelKey]: payload });

      // 3. Set attachment model
      const attachModel = new sap.ui.model.json.JSONModel({ attachments });
      that.getView().setModel(attachModel, "UploadDocSrvTabDataWDRS");

      // 4. Set View Flags based on status
      const oViewModel = that.getView().getModel("viewenableddatacheck");
      oViewModel.setProperty("/enableRowActions", false);
      oViewModel.setProperty("/approvebuttonvisiblity", false);
      oViewModel.setProperty("/enableRowActionsNOT", false); 

      oViewModel.setProperty("/sendbackbuttonvisiblity", false);
      oViewModel.setProperty("/approvebuttonvisiblityForStoreTask", false);
      oViewModel.setProperty("/tableModeWDRS", "None");
      oViewModel.setProperty("/isApproverScreen", false);
      oViewModel.setProperty("/enableRowActionsapproval", false);

      oViewModel.setProperty("/Forcrsandsrsapprovebuttonvisiblity", false);
      oViewModel.setProperty("/WDRSapprovebuttonvisiblity", false);
        oViewModel.setProperty("/WDRSapprovebuttonvisiblityedit", false);

      // Approver logic
      if (that._ApprovedCheck === "Approved" && (status === "Pending" )) {
        oViewModel.setProperty("/approvebuttonvisiblity", true); //hod
        oViewModel.setProperty("/sendbackbuttonvisiblity", true); 

        oViewModel.setProperty("/isApproverScreen", true);
        oViewModel.setProperty("/enableRowActionsapproval", true);
      }

      if(that._ApprovedCheck === "Approved" && (status === "Pending") && stage === "HOD"){
        oViewModel.setProperty("/approvebuttonvisiblity", true); //hod
        oViewModel.setProperty("/sendbackbuttonvisiblity", true); 
        oViewModel.setProperty("/isApproverScreen", true);
        oViewModel.setProperty("/enableRowActionsapproval", true);
        oViewModel.setProperty("/approvebuttonvisiblityForStoreTask", false);
        oViewModel.setProperty("/Forcrsandsrsapprovebuttonvisiblity", true);
        
      }

      if(that._ApprovedCheck === "Approved" && (status === "Pending") && stage === "Stores"){
        oViewModel.setProperty("/approvebuttonvisiblity", true); //hod
        oViewModel.setProperty("/sendbackbuttonvisiblity", true); 
        oViewModel.setProperty("/isApproverScreen", true);
        oViewModel.setProperty("/enableRowActionsapproval", true); 

        oViewModel.setProperty("/Forcrsandsrsapprovebuttonvisiblity", false);

        oViewModel.setProperty("/approvebuttonvisiblityForStoreTask", true);
        
      }

      // Store approver case (WDRS only)
      if (that._ApprovedCheck === "Approved"  && status === "Pending" && stage === "ScrapYard") {
        oViewModel.setProperty("/approvebuttonvisiblityForStoreTask", true);
        oViewModel.setProperty("/isApproverScreen", true);
        oViewModel.setProperty("/enableRowActionsapproval", true);
        oViewModel.setProperty("/WDRSapprovebuttonvisiblity", true);
        oViewModel.setProperty("/WDRSapprovebuttonvisiblityedit", true);
  
      }

      // 5. Fetch dropdowns and metadata
      that.ISRFormRouteMatched({ getParameter: () => ({ type: subTypeFromRoute }) });

      switch (modelKey) {
        case "FRS":
          that.onFetchApproverFRS?.();
          that.onProductDescriptionDataFetchFRS?.();
          that.onUOMFetchFRS?.();
          break;
        case "CRS":
          that.onLocationDataFetchCRS?.();
          that.onFetchHODCRS?.();
          break;
        case "SRS":
          that.onLocationDataFetchSRS?.();
          that.onFetchHODSRS?.();
          break;
        case "WDRS":
          that.onTypeOfWasteWDRS?.();
          that.onFetchApproverWDRS?.();
          that.onFetchUOMWDRS?.();
          break;
      }

      

      setTimeout(() => window.scrollTo(0, 0), 100);
    },
    error: function (oError) {
      sap.ui.core.BusyIndicator.hide();
      sap.m.MessageToast.show("Failed to load request data.");
      console.error("Infra Approved Read Error:", oError);
    }
  });
},

/***********************
 * Approvebuttonapprove
 ************************/
onApprovedInFRAAllform: function () {
  var oView = this.getView();
  var oViewModel = oView.getModel("viewenableddatacheck");
  var oRequestModel = this.getOwnerComponent().getModel("Requestservicemodel");
  var subType = this._SanctionfdNameUI; // frs, crs, srs, wdrs
  var modelKeyMap = { frs: "FRS", crs: "CRS", srs: "SRS", wdrs: "WDRS" };
  var modelKey = modelKeyMap[subType];

  if (!modelKey) {
    sap.m.MessageToast.show("Invalid form type.");
    return;
  }

  var oData = oRequestModel.getProperty("/" + modelKey);
  var isValid = true;
  var errorMessage = "";

  // helper to set red border if mismatch
  const highlightMismatch = function (tableId, rowIndex, bindingKey) {
    const table = oView.byId(tableId);
    const row = table.getItems()[rowIndex];
    if (row) {
      const cells = row.getCells();
      const inputField = cells.find(cell =>
        cell.getBindingPath?.("value")?.includes(bindingKey)
      );
      if (inputField) {
        inputField.setValueState("Error");
        inputField.setValueStateText("Approved Qty differs from Requested Qty");
      }
    }
  };

  switch (modelKey) {
    case "FRS":
      oData.VehicleDetailsPayload.forEach((item, idx) => {
        const req = parseFloat(item.RequestedQtyFRS);
        const appr = parseFloat(item.ApprovedQtyFRS);
        if (isNaN(appr) || appr <= 0) {
          isValid = false;
          errorMessage = `Row ${idx + 1}: Approved Quantity must be greater than 0.`;
          return;
        }
        if (req !== appr) {
          isValid = false;
          errorMessage = "Approved Qty is different than Requested Qty.";
          highlightMismatch("VehicleTableInitiateFRS", idx, "ApprovedQtyFRS");
        }
      });
      break;

    case "CRS":
      const crsRows = oData.PartDetailsCRS || [];
      if (oViewModel.getProperty("/approvebuttonvisiblity")) {
        crsRows.forEach((item, idx) => {
          const req = parseFloat(item.RequestedQtyCRS);
          const appr = parseFloat(item.ApprovedQtyCRS);
          if (isNaN(appr) || appr <= 0) {
            isValid = false;
            errorMessage = `Row ${idx + 1}: Approved Quantity must be greater than 0.`;
            return;
          }
          if (req !== appr) {
            isValid = false;
            errorMessage = "Approved Qty is different than Requested Qty.";
            highlightMismatch("partDetailsTableInitiateCRS", idx, "ApprovedQtyCRS");
          }
        });
      }
      break;

    case "SRS":
      const srsRows = oData.PartDetailsSRS || [];
      if (oViewModel.getProperty("/approvebuttonvisiblity")) {
        srsRows.forEach((item, idx) => {
          const req = parseFloat(item.RequestedQtySRS);
          const appr = parseFloat(item.ApprovedQtySRS);
          if (isNaN(appr) || appr <= 0) {
            isValid = false;
            errorMessage = `Row ${idx + 1}: Approved Quantity must be greater than 0.`;
            return;
          }
          if (req !== appr) {
            isValid = false;
            errorMessage = "Approved Qty is different than Requested Qty.";
            highlightMismatch("tblPartDetailsInitiateSRS", idx, "ApprovedQtySRS");
          }
        });
      }
      break;

    case "WDRS":
      if (oViewModel.getProperty("/WDRSapprovebuttonvisiblity")) {
        const rowsWDRS = oData.PartDetailsWDRS || [];
        rowsWDRS.forEach((item, idx) => {
          const weight = parseFloat(item.WeighmentWeightWDRS);
          if (isNaN(weight) || weight <= 0) {
            isValid = false;
            errorMessage = `Row ${idx + 1}: Weighment Weight must be greater than 0.`;
          }
        });
      }
      break;
  }


  if (!isValid) {
    sap.m.MessageBox.error(errorMessage);
    return;
  }

  // Proceed only if all validation passed
  oViewModel.setProperty("/remarkModel", "");
  oViewModel.setProperty("/approvebuttonfragment", true);
  oViewModel.setProperty("/rejetedbuttonfragmnet", false);
  oViewModel.setProperty("/enableRowActions", false);
  oViewModel.setProperty("/sendbackbuttonvisiblity", false);
  oViewModel.setProperty("/approvebuttonvisiblityData", true);
  oViewModel.setProperty("/approverRequiredVisible", true);

  if (this.remarksDialog) {
    this.remarksDialog.open();
  } else {
    sap.m.MessageToast.show("Remarks dialog not found.");
  }
}
,

 
onLiveChangeQty: function (oEvent) {
  const oInput = oEvent.getSource();
  const sNewValue = parseFloat(oEvent.getParameter("value"));
  const oContext = oInput.getBindingContext("Requestservicemodel");
  const sPath = oContext.getPath();
  const oModel = oContext.getModel();

  const oRowData = oModel.getProperty(sPath);

  let requestedQty = null;

  if (sPath.includes("FRS")) {
    requestedQty = parseFloat(oRowData.RequestedQtyFRS);
  } else if (sPath.includes("CRS")) {
    requestedQty = parseFloat(oRowData.RequestedQtyCRS);
  } else if (sPath.includes("SRS")) {
    requestedQty = parseFloat(oRowData.RequestedQtySRS);
  }

  if (!isNaN(requestedQty) && !isNaN(sNewValue)) {
    if (requestedQty === sNewValue) {
      oInput.setValueState("None");
      oInput.setValueStateText("");
    } else {
      oInput.setValueState("Error");
      oInput.setValueStateText("Approved Qty differs from Requested Qty.");
    }
  } else {
    oInput.setValueState("None"); // Don't block if empty
    oInput.setValueStateText("");
  }
} ,

 


// *************************
/**Approveddataremkarksapprovebuttonall
 ****************************************/
onApprovedData: function() {
  var oView = this.getView();
  var reqid = this._reqIDData;
  var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
  if (!remarkInput) {
    MessageBox.information("Please provide a remark before Approve.");
    return;
}
sap.ui.core.BusyIndicator.show(0);

  var oView = this.getView();
  var oViewModel = oView.getModel("viewenableddatacheck");
  var oRequestModel = this.getOwnerComponent().getModel("Requestservicemodel");
  var subType = this._SanctionfdNameUI; // frs, crs, srs, wdrs
  var modelKeyMap = { frs: "FRS", crs: "CRS", srs: "SRS", wdrs: "WDRS" };
  var modelKey = modelKeyMap[subType];

  if (!modelKey) {
    sap.m.MessageToast.show("Invalid form type.");
    return;
  }

  var oData = oRequestModel.getProperty("/" + modelKey);
  const oInfraPayload = this._buildUnifiedPayload(modelKey);

  const oSubmitPayload = { 
    type: "ISR",
    remarks: remarkInput,
    infraDtl: oInfraPayload
  };

  var oModel = this.getOwnerComponent().getModel("approvalservicev2");
  var that = this;

  if (!reqid) {
    oModel.create("/Requests", oSubmitPayload, {
        success: function(oData) {
            that._reqIDData = oData.reqID;
            sap.ui.core.BusyIndicator.hide();
            that.approverdatacheckApproved(oData.reqID);
        },
        error: function(oError) {
            sap.ui.core.BusyIndicator.hide();
            sap.m.MessageBox.error(
              "A technical error has occurred while approving the request.\nPlease contact your system administrator.", {
                title: "Approval Error",
                styleClass: "sapUiSizeCompact"
              }
            );
        }
    });
}else {
  oModel.update("/Requests('" + reqid + "')", oSubmitPayload, {
      success: function() {
          sap.ui.core.BusyIndicator.hide();
          that.approverdatacheckApproved(reqid);
      },
      error: function(oError) {
        sap.ui.core.BusyIndicator.hide();
        sap.m.MessageBox.error(
          "A technical error has occurred while approving the request.\nPlease contact your system administrator.", {
            title: "Approval Error",
            styleClass: "sapUiSizeCompact"
          }
        );   
      }
  });
}
},
approverdatacheckApproved: function(reqid) {
  var oModel = this.getOwnerComponent().getModel("approvalservicev2");
  var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
  var oApprovedPayload = {
      reqID: reqid,
      action: "APPROVE",
      remarks: remarkInput
  };
  var that = this;
  sap.ui.core.BusyIndicator.show(0);

  oModel.create("/ISRApproval", oApprovedPayload, {
      success: function(oData) {
          MessageBox.success(oData.ISRApproval?.message || "Request Approved Successfully!", {
              onClose: function() {
                  if (that._ApprovedCheck === "Approved") {
                      sap.ui.core.BusyIndicator.hide();
                      that.getOwnerComponent().getRouter().navTo("approverdashboard");
                  }
              }
          });
      },
      error: function(oError) {
        sap.ui.core.BusyIndicator.hide();
        sap.m.MessageBox.error(
          "A technical error has occurred while approving the request.\nPlease contact your system administrator.", {
            title: "Approval Error",
            styleClass: "sapUiSizeCompact"
          }
        ); 
      }
  });
},

/******************************
 * SendBACKallsendback
 ******************************/
onRejectDataINFRAAllForm: function () {
  const oView = this.getView();
  const oViewModel = oView.getModel("viewenableddatacheck");

  var oRequestModel = this.getOwnerComponent().getModel("Requestservicemodel");
  var subType = this._SanctionfdNameUI; // frs, crs, srs, wdrs
  var modelKeyMap = { frs: "FRS", crs: "CRS", srs: "SRS", wdrs: "WDRS" };
  var modelKey = modelKeyMap[subType];

  if (!modelKey) {
    sap.m.MessageToast.show("Invalid form type.");
    return;
  }

  var oData = oRequestModel.getProperty("/" + modelKey);
  var isValid = true;
  var errorMessage = "";

  switch (modelKey) {
    case "FRS":
      oData.VehicleDetailsPayload.forEach((item, idx) => {
        const qty = parseFloat(item.ApprovedQtyFRS);
        if (isNaN(qty) || qty <= 0) {
          isValid = false;
          errorMessage = `Row ${idx + 1}: Approved Quantity must be greater than 0.`;
        }
      });    
      break;

    case "CRS":
      const partRows = oData.PartDetailsCRS || [];
if (oViewModel.getProperty("/approvebuttonvisiblity")) {
  for (let i = 0; i < partRows.length; i++) {
    const qty = parseFloat(partRows[i].ApprovedQtyCRS);
    if (isNaN(qty) || qty <= 0) {
      isValid = false;
      errorMessage = `Row ${i + 1}: Approved Quantity (CRS) must be greater than 0.`;
      break;
    }
  }
} else if (oViewModel.getProperty("/approvebuttonvisiblityForStoreTask")) {
  for (let i = 0; i < partRows.length; i++) {
    const qty = parseFloat(partRows[i].IssuedQtyCRS);
    if (isNaN(qty) || qty <= 0) {
      isValid = false;
      errorMessage = `Row ${i + 1}: Issued Quantity (CRS) must be greater than 0.`;
      break;
    }
  }
}
      break;

    case "SRS":
      const rowsSRS = oData.PartDetailsSRS || [];
      if (oViewModel.getProperty("/approvebuttonvisiblity")) {
        for (let i = 0; i < rowsSRS.length; i++) {
          const qty = parseFloat(rowsSRS[i].ApprovedQtySRS);
          if (isNaN(qty) || qty <= 0) {
            isValid = false;
            errorMessage = `Row ${i + 1}: Approved Quantity (SRS) must be greater than 0.`;
            break;
          }
        }
      } else if (oViewModel.getProperty("/approvebuttonvisiblityForStoreTask")) {
        for (let i = 0; i < rowsSRS.length; i++) {
          const qty = parseFloat(rowsSRS[i].IssuedQtySRS);
          if (isNaN(qty) || qty <= 0) {
            isValid = false;
            errorMessage = `Row ${i + 1}: Issued Quantity (SRS) must be greater than 0.`;
            break;
          }
        }
      }
      break;

    case "WDRS":
      const rowsWDRS = oData.PartDetailsWDRS || [];
for (let i = 0; i < rowsWDRS.length; i++) {
  const qty = parseFloat(rowsWDRS[i].WeighmentWeightWDRS);
  if (isNaN(qty) || qty <= 0) {
    isValid = false;
    errorMessage = `Row ${i + 1}: Weighment Weight (WDRS) must be greater than 0.`;
    break;
  }
}

      break;
  }

  if (!isValid) {
    sap.m.MessageBox.error(errorMessage);
    return;
  }

  // Reset remarks
  oViewModel.setProperty("/remarkModel", "");

  // Set sendback UI flags
  oViewModel.setProperty("/sendbackbuttonvisiblity", true);
  oViewModel.setProperty("/approvebuttonvisiblityData", false);
  oViewModel.setProperty("/approverRequiredVisible", true);
  oViewModel.setProperty("/approvebuttonfragment", false);
  oViewModel.setProperty("/rejetedbuttonfragmnet", true);
  oViewModel.setProperty("/enableRowActions", false);

  // Open remarks dialog 
  if (this.remarksDialog) {
    this.remarksDialog.open();
  } else {
    sap.m.MessageToast.show("Remarks dialog not found.");
  }
   
},

onSendbackData: function () {
  const oView = this.getView();
  const oViewModel = oView.getModel("viewenableddatacheck");
  const reqid = this._reqIDData;
  const remarkInput = oViewModel.getProperty("/remarkModel");

  if (!remarkInput || !remarkInput.trim()) {
    sap.m.MessageBox.information("Please provide a remark before sending back.");
    return;
  }

  sap.ui.core.BusyIndicator.show(0);

  const oRequestModel = this.getOwnerComponent().getModel("Requestservicemodel");
  const subType = this._SanctionfdNameUI; // frs, crs, srs, wdrs
  const modelKeyMap = { frs: "FRS", crs: "CRS", srs: "SRS", wdrs: "WDRS" };
  const modelKey = modelKeyMap[subType];

  if (!modelKey) {
    sap.m.MessageToast.show("Invalid form type.");
    sap.ui.core.BusyIndicator.hide();
    return;
  }

  const oData = oRequestModel.getProperty("/" + modelKey);
  const oInfraPayload = this._buildUnifiedPayload(modelKey);

  const oSubmitPayload = {
    type: "ISR",
    remarks: remarkInput,
    infraDtl: oInfraPayload
  };

  const oModel = this.getOwnerComponent().getModel("approvalservicev2");
  const that = this;

  if (!reqid) {
    // Create + SendBack (new request scenario)
    oModel.create("/Requests", oSubmitPayload, {
      success: function (oData) {
        that._reqIDData = oData.reqID;
        that.sendbackdatacheckApproved(oData.reqID);
        sap.ui.core.BusyIndicator.hide();
      },
      error: function (oError) {
        sap.ui.core.BusyIndicator.hide();
        sap.m.MessageBox.error(
          "A technical error has occurred while sending back the request.\nPlease contact your system administrator.",
          {
            title: "Send Back Error",
            styleClass: "sapUiSizeCompact"
          }
        );
      }
    });
  } else {
    // Update + SendBack (existing request scenario)
    oModel.update("/Requests('" + reqid + "')", oSubmitPayload, {
      success: function () {
        that.sendbackdatacheckApproved(reqid);
        sap.ui.core.BusyIndicator.hide();
      },
      error: function (oError) {
        sap.ui.core.BusyIndicator.hide();
        sap.m.MessageBox.error(
          "A technical error has occurred while sending back the request.\nPlease contact your system administrator.",
          {
            title: "Send Back Error",
            styleClass: "sapUiSizeCompact"
          }
        );
      }
    });
  }
},



sendbackdatacheckApproved: function (reqid) {
  var oModel = this.getOwnerComponent().getModel("approvalservicev2");
  var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");

  if (!remarkInput || !remarkInput.trim()) {
    sap.m.MessageBox.information("Please provide a remark before sending back.");
    return;
  }

  var oPayload = {
    reqID: reqid,
    action: "SEND BACK",
    remarks: remarkInput
  };

  var that = this;
  sap.ui.core.BusyIndicator.show(0);

  oModel.create("/ISRApproval", oPayload, {
    success: function (oData) {
      sap.ui.core.BusyIndicator.hide();
      sap.m.MessageBox.success(oData.ISRApproval?.message || "Request send back successfully.", {
        onClose: function () {
          if (that._ApprovedCheck === "Approved") {
            that.getOwnerComponent().getRouter().navTo("approverdashboard");
          }
        }
      });
    },
    error: function (oError) {
      sap.ui.core.BusyIndicator.hide();
      sap.m.MessageBox.error(
        "A technical error has occurred while sending back the request.\nPlease contact your system administrator.",
        {
          title: "Send Back Error",
          styleClass: "sapUiSizeCompact"
        }
      );
    }
  });
},






// ***********************************************************
//onnavback 
onDashboardui: function() {
  var oRouter = this.getOwnerComponent().getRouter();
  if (this._ApprovedCheck === "Approved") {
      oRouter.navTo("approverdashboard", {});
  } else if (this._SanctionfdNameUI === "INFRA") {
      oRouter.navTo("DashboardUI", { Name: "INFRA" });
  }
},

//remarks close
onCloseReamrksFrag: function() {
  this.remarksDialog.close();
},

//Common mass upload check 
getColumnConfigByType: function (type) {
  switch (type) {
      case "WDRS":
          return [
              { label: "Part Description", property: "PartDescription", type: EdmType.String },
              { label: "Part Number", property: "PartNumber", type: EdmType.String },
              { label: "UOM", property: "UOM", type: EdmType.String },
              { label: "Tentative Weight", property: "TentativeWeight", type: EdmType.String },
          ];
      case "CRS":
      case "SRS":
          return [
              { label: "Part Description", property: "PartDescription", type: EdmType.String },
              { label: "Part Number", property: "PartNumber", type: EdmType.String },
              { label: "Bin Number", property: "BinNumber", type: EdmType.String },
              { label: "Price", property: "Price", type: EdmType.String },
              { label: "Requested Qty", property: "RequestedQty", type: EdmType.String },
          ];
      default:
          return [];
  }
},
_processUploadedFileCommon: function (file, type) {
  let that = this;
  if (!file) {
      MessageToast.show("No file selected.");
      return;
  }

  sap.ui.core.BusyIndicator.show(0);

  let reader = new FileReader();
  reader.onload = function (e) {
      let data = new Uint8Array(e.target.result);
      let workbook = XLSX.read(data, { type: 'array' });
      let worksheet = workbook.Sheets[workbook.SheetNames[0]];
      let aParsedData = XLSX.utils.sheet_to_json(worksheet, { defval: "" });

      let config = that.getColumnConfigByType(type);
      let expectedCols = config.map(col => col.label);
      let actualCols = Object.keys(aParsedData[0] || {});
      let missingCols = expectedCols.filter(c => !actualCols.includes(c));

      if (missingCols.length > 0) {
          sap.ui.core.BusyIndicator.hide();
          MessageBox.error(`Invalid format. Missing columns: ${missingCols.join(", ")}.\nPlease use the correct template.`);
          return;
      }

      that.validateAndSubmitMassUpload(type, aParsedData);
  };

  reader.readAsArrayBuffer(file);
},

validateAndSubmitMassUpload: function (type, aData) {
  const that = this;
  const oModel = this.getOwnerComponent().getModel("approvalservicev2");

  sap.ui.core.BusyIndicator.show(0);

  // Load all /PartDetails data for department filter
  oModel.read("/PartDetails", {
    success: function (oData) {
      const aPartDetails = oData.results.filter(item => item.department === type);

      const result = that._validateRows(aData, type, aPartDetails);
      that._pushResultsToModel(type, result.valid, result.invalid);
    },
    error: function () {
      sap.m.MessageToast.show("Failed to load part master data.");
      sap.ui.core.BusyIndicator.hide();
    }
  });
},
 

_validateRows: function (aData, type, aPartDetails) {
  const oModel = this.getOwnerComponent().getModel("Requestservicemodel");
  const existingData = oModel.getProperty(`/${type}/PartDetails${type}`) || [];

  const getTrimmedValue = value => (value != null ? String(value).trim() : "");

  let valid = [], invalid = [];
  const uploadedKeys = new Set();

  // Existing keys (to prevent duplicates)
  const existingKeys = new Set(existingData.map(d => {
    return type === "WDRS"
      ? `${d.PartNumberWDRS}_${d.UOMWDRS}`
      : `${d.partNumber}_${d.binNumber}`;
  }));

  aData.forEach(row => {
    const pd = getTrimmedValue(row["Part Description"]);
    const pn = getTrimmedValue(row["Part Number"]);

    let key, matched;

    if (type === "WDRS") {
      const uom = getTrimmedValue(row["UOM"]);
      const qty = parseFloat(row["Tentative Weight"]);

      key = `${pn}_${uom}`;
      matched = aPartDetails.find(d =>
        d.partNo === pn &&
        d.partDesc === pd &&
        d.department === type
      );

      if (!pd || !pn || !uom || isNaN(qty)) {
        invalid.push({ ...row, validationError: "Missing or invalid values" });
      } else if (!matched) {
        invalid.push({ ...row, validationError: "No matching backend part" });
      } else if (uploadedKeys.has(key)) {
        invalid.push({ ...row, validationError: "Duplicate in upload" });
      } else if (!existingKeys.has(key)) {
        valid.push({
          PartDescriptionWDRS: pd,
          PartNumberWDRS: pn,
          UOMWDRS: uom,
          TentativeWeightWDRS: qty
        });
        uploadedKeys.add(key);
      }

    } else {
      const bin = getTrimmedValue(row["Bin Number"]);
      const price = parseFloat(row["Price"]);
      const qty = parseFloat(row["Requested Qty"]);

      key = `${pn}_${bin}`;
      matched = aPartDetails.find(d =>
        d.partNo === pn &&
        d.partDesc === pd &&
        d.binNo === bin &&
        d.department === type
      );

      if (!pd || !pn || !bin || isNaN(price) || isNaN(qty)) {
        invalid.push({ ...row, validationError: "Missing or invalid values" });
      } else if (!matched) {
        invalid.push({ ...row, validationError: "No matching backend part" });
      } else if (uploadedKeys.has(key)) {
        invalid.push({ ...row, validationError: "Duplicate in upload" });
      } else if (!existingKeys.has(key)) {
        valid.push({
          partDescription: pd,
          partNumber: pn,
          binNumber: bin,
          price: price,
          requestedQty: qty
        });
        uploadedKeys.add(key);
      }
    }
  });

  return { valid, invalid };
}
,


_compareWithBackend: function (excelRows, backendParts, type) {
  const getTrimmedValue = function (value) {
    return value != null ? String(value).trim() : "";
  };

  const valid = [];
  const invalid = [];

  excelRows.forEach(row => {
//     const partNo = getTrimmedValue(row["Part Number"]);
// const partDesc = getTrimmedValue(row["Part Description"]);
// const binNo = getTrimmedValue(row["Bin Number"]);
// const uom = getTrimmedValue(row["UOM"]);

    const partNo = row["Part Number"]?.trim();
    const partDesc = row["Part Description"]?.trim();
    const binNo = row["Bin Number"]?.trim();
    const uom = row["UOM"]?.trim();
    const price = row["Price"];
    const qty = row["Requested Qty"];
    const wt = row["Tentative Weight"];

    const match = backendParts.find(p =>
      p.department === type &&
      p.partNo === partNo &&
      p.partDesc === partDesc
    );

    if (!match) {
      row.validationError = "Not found in backend for dept/part.";
      invalid.push(row);
      return;
    }

    if (type === "WDRS") {
      if (!uom || !wt || isNaN(Number(wt))) {
        row.validationError = "Missing/invalid UOM or Weight.";
        invalid.push(row);
      } else {
        valid.push({
          partNumber: partNo,
          partDescription: partDesc,
          uom: uom,
          tentativeWeight: parseFloat(wt),
          department: type
        });
      }
    } else {
      if (!binNo || !price || !qty || isNaN(Number(price)) || isNaN(Number(qty))) {
        row.validationError = "Missing/invalid Bin, Price or Qty.";
        invalid.push(row);
      } else {
        valid.push({
          partNumber: partNo,
          partDescription: partDesc,
          binNumber: binNo,
          price: parseFloat(price),
          requestedQty: parseFloat(qty),
          department: type
        });
      }
    }
  });

  return { valid, invalid };
},
 
_pushResultsToModel: function (type, valid, invalid) {
  const oModel = this.getOwnerComponent().getModel("Requestservicemodel");
  const path = `/${type}/PartDetails${type}`;
  let existingData = oModel.getProperty(path);

  if (!existingData) {
    oModel.setProperty(`/${type}`, {}); // ensure path exists
    existingData = [];
  }

  let transformedValid = [];

  if (type === "WDRS") {
    // WDRS already has keys in required format — no transformation needed
    transformedValid = valid.map(item => ({
      PartDescriptionWDRS: item.PartDescriptionWDRS,
      PartNumberWDRS: item.PartNumberWDRS,
      UOMWDRS: item.UOMWDRS,
      TentativeWeightWDRS: item.TentativeWeightWDRS
    }));
  } else {
    // Transformation map: raw key -> model key suffix
    const keyMap = {
      partDescription: `PartDescription${type}`,
      partNumber: `PartNumber${type}`,
      binNumber: `BinNumber${type}`,
      price: `Price${type}`,
      requestedQty: `RequestedQty${type}`
    };

    // Transform raw valid records to match view model keys
    transformedValid = valid.map(item => {
      const transformed = {};
      for (const rawKey in keyMap) {
        if (item.hasOwnProperty(rawKey)) {
          // transformed[keyMap[rawKey]] = item[rawKey];
          transformed[keyMap[rawKey]] = String(item[rawKey] ?? "");

        }
      }
      return transformed;
    });
  }

  // Merge and set to model
  const updatedData = existingData.concat(transformedValid);
  oModel.setProperty(path, updatedData);

  // Notify user
  if (transformedValid.length > 0) {
    MessageToast.show(`${transformedValid.length} valid records uploaded.`);
  }

  if (invalid.length > 0) {
    this.getView().setModel(new sap.ui.model.json.JSONModel(invalid), "wrongDataModel");

    MessageBox.information(`${transformedValid.length} valid, ${invalid.length} invalid rows.`, {
      actions: ["Download Invalid Records", MessageBox.Action.OK],
      onClose: function (action) {
        if (action === "Download Invalid Records") {
          this._exportInvalidRecords(type, invalid);
        }
        if (this._oUploadDialog) this._oUploadDialog.close();
      }.bind(this)
    });
  } else if (this._oUploadDialog) {
    this._oUploadDialog.close();
  }

  sap.ui.core.BusyIndicator.hide();
},
  

 
_validateRow: function (row, type, aPartDetails) {
  let missing = [], key = "", cleanedRow = {};
  let partDeptMatched = false;

  switch (type) {
    case "WDRS": {
      let pd = row["Part Description"]?.trim();
      let pn = row["Part Number"]?.trim();
      let uom = row["UOM"]?.trim();
      let wt = row["Tentative Weight"];

      if (!pd) missing.push("Part Description");
      if (!pn) missing.push("Part Number");
      if (!uom) missing.push("UOM");
      if (wt === undefined || wt === "") missing.push("Tentative Weight");

      // Convert weight to number
      let numWt = parseFloat(wt);
      if (isNaN(numWt)) {
        missing.push("Tentative Weight (must be number)");
      }

      // Match with Department logic (example assumes 'Department' exists in row)
      const department = row["Department"]?.trim();
      if (!department) {
        missing.push("Department");
      } else {
        partDeptMatched = aPartDetails.some(d => d.department === department);
        if (!partDeptMatched) missing.push("Invalid Department");
      }

      key = `${pn}_${uom}_${numWt}`;
      cleanedRow = {
        partDescription: pd,
        partNumber: pn,
        uom: uom,
        tentativeWeight: numWt,
        department: department
      };
      break;
    }

    case "CRS":
    case "SRS": {
      let pd = row["Part Description"]?.trim();
      let pn = row["Part Number"]?.trim();
      let bin = row["Bin Number"]?.trim();
      let price = row["Price"];
      let qty = row["Requested Qty"];
      let department = row["Department"]?.trim();

      if (!pd) missing.push("Part Description");
      if (!pn) missing.push("Part Number");
      if (!bin) missing.push("Bin Number");
      if (price === undefined || price === "") missing.push("Price");
      if (qty === undefined || qty === "") missing.push("Requested Qty");
      if (!department) missing.push("Department");

      // Number conversion
      let numPrice = parseFloat(price);
      let numQty = parseFloat(qty);
      if (isNaN(numPrice)) missing.push("Price (must be number)");
      if (isNaN(numQty)) missing.push("Requested Qty (must be number)");

      // Department match
      partDeptMatched = aPartDetails.some(d => d.department === department);
      if (!partDeptMatched) missing.push("Invalid Department");

      key = `${pn}_${bin}_${numQty}`;
      cleanedRow = {
        partDescription: pd,
        partNumber: pn,
        binNumber: bin,
        price: numPrice,
        requestedQty: numQty,
        department: department
      };
      break;
    }
  }

  return { missingFields: missing, key: key, cleanedRow: cleanedRow };
},




_exportInvalidRecords: function (type, aInvalidEntries) {
  let headers, fields;

  switch (type) {
      case "WDRS":
          headers = ["Part Description", "Part Number", "UOM", "Tentative Weight", "Validation Error"];
          fields = ["Part Description", "Part Number", "UOM", "Tentative Weight", "validationError"];
          break;
      case "CRS":
      case "SRS":
          headers = ["Part Description", "Part Number", "Bin Number", "Price", "Requested Qty", "Validation Error"];
          fields = ["Part Description", "Part Number", "Bin Number", "Price", "Requested Qty", "validationError"];
          break;
      default:
          return;
  }

  let aData = [headers];
  aInvalidEntries.forEach(entry => {
      aData.push(fields.map(f => entry[f] || ""));
  });

  let ws = XLSX.utils.aoa_to_sheet(aData);
  ws['!cols'] = headers.map((_, i) => ({
      wch: Math.max(...aData.map(r => (r[i]?.length || 10))) + 2
  }));

  let wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Invalid Records");
  XLSX.writeFile(wb, `Invalid_${type}_Records.xlsx`);
},


/***************************
 * commonsubmitvalidationcheckinputbox
 ******************************/
onSubmitINFRAform: function () {
  const oView = this.getView();
  // const sType = this._type; // should be one of: 'frs', 'crs', 'srs', 'wdrs'
  const oSharedModel = this.getOwnerComponent().getModel("shared");
const sApprovalKey = oSharedModel.getProperty("/initiationKey") || "";
let sType = "";

switch (sApprovalKey) {
  case "Initiate FRS": sType = "frs"; break;
  case "Initiate CRS": sType = "crs"; break;
  case "Initiate SRS": sType = "srs"; break;
  case "Initiate WDRS": sType = "wdrs"; break;
  default:
    sap.m.MessageBox.error("Unable to determine request type.");
    return;
}


  const oModel = this.getOwnerComponent().getModel("Requestservicemodel");
  const oCheckModel = oView.getModel("viewenableddatacheck");
  let bValid = true;
  let aMissingFields = [];

  const validationMap = {
      frs: [
          { id: "WBSInputInitiateFRS", label: "WBS Code" },
          { id: "CostCenterInputInitiateFRS", label: "Cost Center" },
          { id: "ApproverInputInitiateFRS", label: "Approver", isComboBox: true }
      ],
      crs: [
        { id: "locationComboInitiateCRS", label: "Location", isComboBox: true },
          { id: "wbsCodeInputInitiateCRS", label: "WBS Code" },
          { id: "costCenterInputInitiateCRS", label: "Cost Center" },
          { id: "hodComboInitiateCRS", label: "HOD", isComboBox: true }
      ],
      srs: [
        { id: "cmbLocationInitiateSRS", label: "Location", isComboBox: true },
          { id: "inpWBSCodeInitiateSRS", label: "WBS Code" },
          { id: "cmbCostCenterInitiateSRS", label: "Cost Center" },
          { id: "cmbHODInitiateSRS", label: "HOD", isComboBox: true }
      ],
      wdrs: [
        { id: "cmbLocationInitiateWDRS", label: "Type of Waste", isComboBox: true },
          { id: "inpWbsCodeInitiateWDRS", label: "WBS Code" },
          { id: "cmbCostCenterInitiateWDRS", label: "Cost Center" },
          { id: "cmbHodInitiateWDRS", label: "Approver", isComboBox: true }
      ]
  };

  const fieldsToValidate = validationMap[sType] || [];

  fieldsToValidate.forEach(field => {
      const oControl = oView.byId(field.id);
      let value;

      if (field.isComboBox) {
          value = oControl.getSelectedKey();
      } else {
          value = oControl.getValue();
      }

      if (!value || value.trim() === "") {
          oControl.setValueState("Error");
          oControl.setValueStateText(field.label + " is required.");
          bValid = false;
          aMissingFields.push(field.label);
      } else {
          oControl.setValueState("None");
      }
  });

  const tableRowPaths = {
    frs: "/FRS/VehicleDetailsPayload",
    crs: "/CRS/PartDetailsCRS",
    srs: "/SRS/PartDetailsSRS",
    wdrs: "/WDRS/PartDetailsWDRS"
  };

  const aRows = oModel.getProperty(tableRowPaths[sType]) || [];
  if (aRows.length === 0) {
    sap.m.MessageBox.error("Please add at least one item in the table.");
    return;
  }

  let requestedQtyProp = "";
switch (sType) {
  case "frs": requestedQtyProp = "RequestedQtyFRS"; break;
  case "crs": requestedQtyProp = "RequestedQtyCRS"; break;
  case "srs": requestedQtyProp = "RequestedQtySRS"; break;
  case "wdrs": requestedQtyProp = "TentativeWeightWDRS"; break;
}

for (let i = 0; i < aRows.length; i++) {
  const qty = parseFloat(aRows[i][requestedQtyProp]);
  if (isNaN(qty) || qty <= 0) {
    sap.m.MessageBox.error(`Row ${i + 1}: ${requestedQtyProp.replace(/([A-Z])/g, ' $1')} must be greater than 0.`);
    return;
  }
}


  if (!bValid) {
      sap.m.MessageBox.error("Please fill the following required field(s):\n" + aMissingFields.join(", "));
      return;
  }

  // Set reqId if available
  const modelKeyMap = {
      frs: "FRS",
      crs: "CRS",
      srs: "SRS",
      wdrs: "WDRS"
  };
  const oData = oModel.getProperty("/" + modelKeyMap[sType]) || {};
  this._currentSubmitReqId = oData.reqid || "";



  // Reset view flags
  oCheckModel.setProperty("/remarkModel", "");
  oCheckModel.setProperty("/approvebuttonfragment", false);
  oCheckModel.setProperty("/rejetedbuttonfragmnet", false);
  oCheckModel.setProperty("/enableRowActions", true);
  oCheckModel.setProperty("/sendbackbuttonvisiblity", false);
  oCheckModel.setProperty("/approvebuttonvisiblityData", false);
  oCheckModel.setProperty("/approverRequiredVisible", this._ApprovedCheck === "Approved");

  // Open remark dialog
  this.remarksDialog.open();
},


/**********************************
 * commonsavefor all
 ********************************/
onSaveINFRAForm: function () {
  // var oView = this.getView();
  const oModel = this.getOwnerComponent().getModel("approvalservicev2");
  const oRequestModel = this.getOwnerComponent().getModel("Requestservicemodel");
  const oSharedModel = this.getOwnerComponent().getModel("shared");
  const sRequestType = this._reqID || "";
  
  const sApprovalType = oSharedModel.getProperty("/approvalType") || "";
  // const sStatus = (this.statusData === "Pending") ? "Pending" : "Draft";
  var statusData = this.status || "Draft";
  var satauscheckdata = statusData === "Pending" ? "Pending" : "Draft";
  if (statusData === "Send Back") {
     satauscheckdata = "Send Back";
  }

  const sKey = sApprovalType.includes("Fuel") ? "FRS" :
               sApprovalType.includes("Consumable") ? "CRS" :
               sApprovalType.includes("Stationary") ? "SRS" :
               sApprovalType.includes("Waste") ? "WDRS" : "";

  if (!sKey) {
    sap.m.MessageToast.show("Invalid approval type");
    return;
  }
 
  const oInfraPayload = this._buildUnifiedPayload(sKey);  

  
   
   

  const oSavePayload = {
    // pendingWith: sPendingWith,
    stage: "Initiator",
    status: satauscheckdata,
     
    type: "ISR",
    // pendingWithName: sPendingWithName,
    remarks: "",
    infraDtl: oInfraPayload
  };

  const that = this;
  sap.ui.core.BusyIndicator.show(0);

  if (!sRequestType) {
    // CREATE
    oModel.create("/Requests", oSavePayload, {
      success: function (oData) {
        sap.ui.core.BusyIndicator.hide();
        var reqIdData = oData.refNo; 
      var message = "";
      that._reqID = oData.reqID;
        var actualreqid = oData.reqID;
      if (oData?.refNo) {
        if (sKey === "FRS") {
          oRequestModel.setProperty("/FRS/slipNumberFRS", reqIdData);
          // this.byId("frsSlipnumber").setValue(reqIdData);
        } else if (sKey === "CRS") {
          oRequestModel.setProperty("/CRS/slipNumberCRS", reqIdData);
        } else if (sKey === "SRS") {
          oRequestModel.setProperty("/SRS/slipNumberSRS", reqIdData);
        } else if (sKey === "WDRS") {
          oRequestModel.setProperty("/WDRS/slipNumberWDRS", reqIdData);
          that.attachmentuploadFilesData(oData.reqID);
        } 
         const existingData = oRequestModel.getData() || {};
          const subType = oData?.infraDtl?.subType;
          if (subType) {
            existingData[subType] = {
              ...(existingData[subType] || {}),
              ...oData.infraDtl
            };
            oRequestModel.setData(existingData);
          }

        that.infraDtlforallDataFetch(actualreqid);
        // message = "Request " + reqIdData + " saved successfully.";
      } else {
        // message = "Request saved successfully.";
      }

      sap.m.MessageBox.success("Request " + reqIdData + " saved successfully.", {
        title: "Success",
        actions: [sap.m.MessageBox.Action.OK]
      });

      },
      error: function () {
        sap.ui.core.BusyIndicator.hide();
        var messageerror = `Failed to save Request.\nA technical error has occurred. Please contact the administrator`;
        sap.m.MessageBox.error(messageerror);
      }
    });
  } else {
    // UPDATE
    oModel.update("/Requests('" + sRequestType + "')", oSavePayload, {
      success: function (oData) {
        sap.ui.core.BusyIndicator.hide();
        var uactualreqid = oData.reqID;
        that.infraDtlforallDataFetch(uactualreqid);
         if (sKey === "WDRS") { 
          that.attachmentuploadFilesData(oData.reqID);
        }
        sap.m.MessageBox.success("Request " + sRequestType + " updated successfully.", {
          title: "Success",
          actions: [sap.m.MessageBox.Action.OK]
        });
        
      },
      error: function () {
        sap.ui.core.BusyIndicator.hide();
        sap.m.MessageBox.error("Failed to Update Request. A technical error has occurred.\n Please contact the administrator");
      }
    });
  }
},

infraDtlforallDataFetch: function (reqID) {
  const oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
  const oRequestModel = this.getOwnerComponent().getModel("Requestservicemodel");
  const that = this;

  sap.ui.core.BusyIndicator.show(0);

  oModelV2.read("/ReqFormISR('" + reqID + "')", {
    success: function (oData) {
      const currentData = oRequestModel.getData() || {};
      const newInfraData = oData || {};
      const subType = newInfraData.subType;

      if (!subType) {
        console.warn("No subType found in infraDtl");
        sap.ui.core.BusyIndicator.hide();
        return;
      }

      // Safely update only the relevant subType section
      currentData[subType] = {
        ...(currentData[subType] || {}),
        ...newInfraData
      };

      oRequestModel.setData(currentData);
      sap.ui.core.BusyIndicator.hide();
    },
    error: function (oError) {
      sap.ui.core.BusyIndicator.hide();
      console.error("Error fetching ISR data:", oError);
    }
  });
},

attachmentuploadFilesData: function(reqid) {
  var oModelTabdata = this.getView().getModel("UploadDocSrvTabDataWDRS");
  var aFilesData = oModelTabdata.getProperty("/attachments") || [];
  var oModel = this.getOwnerComponent().getModel("approvalservicev2");
  sap.ui.core.BusyIndicator.show(0);

  aFilesData.forEach(function(file) {
      if (!file.fileName || file.uploaded) return;

      if (file.content && typeof file.content === "string" && file.content.includes(',')) {
          var base64Content = file.content.split(',')[1];
          var payload = {
              fileName: file.fileName,
              content: base64Content,
              mediaType: file.mimeType || "text/plain",
              reqID: reqid
          };

          oModel.create("/ReqAttachments", payload, {
              success: function() {
                  file.uploaded = true;
                  oModelTabdata.refresh(true);
                  sap.ui.core.BusyIndicator.hide();
              },
              error: function(oError) {
                  sap.m.MessageToast.show("Error uploading attachment: " + file.fileName, { position: "bottom center" });
                  console.error("Error uploading attachment:", oError);
                  sap.ui.core.BusyIndicator.hide();
              }
          });
      }
  });
},

//attachment fetch
onAttchmentDataFetch: function(refNo) {
  var reqid = refNo;
  var oView = this.getView();
  var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

  var that = this;
  oModelV2.read("/ReqAttachments", {
      filters: [
          new sap.ui.model.Filter("reqID", sap.ui.model.FilterOperator.EQ, reqid)
      ],
      success: function(oData) {
          if (oData && oData.results) {
              var oJSONModel = new JSONModel({
                  attachments: oData.results
              });
              that.getView().setModel(oJSONModel, "UploadDocSrvTabDataWDRS");
          }
      },
      error: function(oError) {
          sap.m.MessageToast.show("Failed to load attachment data.", { position: "bottom center" });
          console.error("Error fetching attachment data:", oError);
      }
  });
},



//livechangewbscode
onWBSCodeChange: function(oEvent) {
  var sValue = oEvent.getParameter("value");
  var oInput = oEvent.getSource();

  // Allow only if the string contains at least one letter or number
  var hasAlphanumeric = /[a-zA-Z0-9]/.test(sValue);
  var hasOnlySpecialChars = /^[^a-zA-Z0-9]+$/.test(sValue);

  if (sValue === "" || hasAlphanumeric) {
      // Input is empty or valid (contains letters or numbers)
      oInput.setValueState("None");
      oInput.setValueStateText("");
  } else if (hasOnlySpecialChars) {
      // Input contains only special characters
      oInput.setValueState("Error");
      oInput.setValueStateText("Special characters alone are not allowed.");
  }
}
,


  })
});