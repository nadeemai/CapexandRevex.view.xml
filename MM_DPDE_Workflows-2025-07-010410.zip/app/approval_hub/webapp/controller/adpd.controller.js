
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/core/Fragment",
    "sap/ui/core/format/FileSizeFormat",
    "sap/ui/Device",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/util/Export",
    "sap/ui/core/util/ExportTypeCSV"
], function (Controller, JSONModel, MessageToast, MessageBox, Fragment, FileSizeFormat, Device, Filter, FilterOperator, Export, ExportTypeCSV) {
    "use strict";

    return Controller.extend("com.mmapprovalhub.approvalhub.controller.adpd", {
        onInit: function () {

            this.getView().setModel(new JSONModel({
                showNatureoFExpense: true,
                showTransfertype: true,
                showForum: true,
                showSopDate: true,
                showRadioBtn: true,
                showAdpdTable: false,
                showFregNrtCode: true,
                showNatureoFApproval: false,
                showInvestment: true,
                showEstimatedCost: true,
                showFinancial: true,
                showWBS: true,
                showFregLevel: true,
                showBalanceTable: true,
                showContNrtCode: true,
                showContLevel: true,
                checkbothcasesdata: true,
                showRevenueTotalCol: true,
                ApproverSecRole: true,
                showApproverSearchLabel: true,
                showWBsCode: true,
                showVolumesBreakup: false,
                enableRowActions: true,
                approvebuttonvisiblity: false,
                approvebuttonfragment: false,
                rejetedbuttonfragmnet: false,
                enableIRR: false,
                financestageRemarks: false,
                financestageRemarkseditable: false,
                materialcostTable: false,
                materialcostTableCon: false


            }), "viewModel");

            var oWbsModel = new sap.ui.model.json.JSONModel({
                rows: []
            });
            this.getView().setModel(oWbsModel, "wbsModel");

            var oWbsModel = new sap.ui.model.json.JSONModel({
                modelData: []
            });
            this.getView().setModel(oWbsModel, "contBalanceModel");
            var oModelVolume = new sap.ui.model.json.JSONModel({
                FinancialDatacheck: [
                    { variantYear: "", Total: "" }
                ]
            });
            this.getView().setModel(oModelVolume, "FinancialModel");
            var oDataMaterial = {
                matcostDtl: [] 
            };
            var oModel = new sap.ui.model.json.JSONModel(oDataMaterial);
            this.getView().setModel(oModel, "materialcostData");
            // this.getView().setModel(new JSONModel({ modelData: [] }), "contBalanceModel");

            //this.getView().setModel(new JSONModel({ rows: [] }), "WbsModel");
            // this.getView().setModel(new JSONModel({ modelData: [] }), "ContBalanceModel");
            this.getView().setModel(new JSONModel({
                showRecommendationTable: false,
                recommendations: []
            }), "InterlineModel");
            this.getView().setModel(new JSONModel({
                attachments: [],
                deleteTabVisible: true
            }), "UploadDocSrvTabData");

            var oFormModel = new JSONModel({
                fromWBSCode: "",
                fromWBSLevel: "",
                fromWBSLoc: "",
                toWBSCode: "",
                toWBSLevel: "",
                toWBSLoc: "",
                capexNRT: "",
                capexLanded: "",
                revenueNRT: "",
                revenueLanded: "",
                totalNRT: "",
                totalLanded: "",
                remarks: ""
            });
            this.getView().setModel(oFormModel,  "WbsformDataBinding");
            this.addFragment = new sap.ui.xmlfragment("com/mmapprovalhub/approvalhub/Fragments/WBSForm", this);
            this.getView().addDependent(this.addFragment);
            this._oInvestmentFragment = sap.ui.core.Fragment.load({
                name: "com/mmapprovalhub/approvalhub/Fragments/InvestmentFragment",
                controller: this
            }).then(function (oDialog) {
                this.getView().addDependent(oDialog);
                return oDialog;
            }.bind(this));

            var oViewModel = new JSONModel({
                enableRowActions: true,
                approvebuttonvisiblity: false,
                approvebuttonfragment: false,
                rejetedbuttonfragmnet: false,
                enableIRR: false,
                remarkModel: "",
                HeadCaseData: false,
                HeadCaseDataVis:false,
                selfDecFlag : false
            });
            this.getView().setModel(oViewModel, "viewenableddatacheck");



            // Initialize combo box data models
            this.getView().setModel(new JSONModel({ results: [] }), "NatureOfExpenseModel");
            this.getView().setModel(new JSONModel({ results: [] }), "PlatformsDataModel");
            this.getView().setModel(new JSONModel({ results: [] }), "TransferTypeModel");
            this.getView().setModel(new JSONModel({ results: [] }), "ADPDProjModel");
            this.getView().setModel(new JSONModel({ results: [] }), "ForumModel");
            this.getView().setModel(new JSONModel({ selectedFinHead: "", finHeadOptions: [] }), "FinanceHeadModel");
            this.getView().setModel(new JSONModel({ investmentData: [] }), "InvestmentModel");

            this.getView().setModel(new JSONModel({ financialData: [] }), "FinancialModel");
            var oModel = new sap.ui.model.json.JSONModel({
                volumeBreakupData: []
            });
            this.getView().setModel(oModel, "localModel");
            this.getView().setModel(new JSONModel({ results: [] }), "FromWBSCodeModel");
            this.getView().setModel(new JSONModel({ results: [] }), "ToWBSCodeModel");
            this.getView().setModel(new JSONModel({ results: [] }), "FromWBSLevelModel");
            this.getView().setModel(new JSONModel({ results: [] }), "ToWBSLevelModel");
            this.getView().setModel(new JSONModel({ results: [] }), "FromWBSLocModel");
            this.getView().setModel(new JSONModel({ results: [] }), "ToWBSLocModel");

            // Initialize fragments
            this._oWbsFragment = null;
            // this._oRemarksFragment = Fragment.load({
            //     id: this.getView().getId(),
            //     name: "com.mmapprovalhub.approvalhub.Fragments.remarks",
            //     controller: this
            // }).then(function (oDialog) {
            //     this.getView().addDependent(oDialog);
            //     this._oRemarksFragment = oDialog;
            //     return oDialog;
            // }.bind(this));

            this._recommendationCounter = 0;
            this._oTable = this.byId("AdpdWbsTable");


            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.getRoute("adpd").attachPatternMatched(this._onRouteAdpdController, this);
            oRouter.getRoute("adpdReqID").attachPatternMatched(this._onRouteAdpdReqIdController, this);
            oRouter.getRoute("adpdReqIDApproved").attachPatternMatched(this._onRouteAdpdApproved, this);


            var oFormModel = new JSONModel({
                fromWbsCode: "",
                fromWbsLevel: "",
                fromWbsLocation: "",
                WBSCode: "",
                priorBalance: "",
                transfAmountCurrApproval: "",
                balancePostTransfer: "",
                capexNrt: "",
                capexLanded: "",
                revenueNRT: "",
                level: "",
                revenueLanded: "",
                totalNrt: "",
                totalLanded: "",
                remarks: "",
                _rowPath: null,
                wbsCodes: [],
                wbsLevels: [],
                wbsLocations: [],
                nrtCodes: [],
                level: []
            });
            this.getView().setModel(oFormModel, "formModel");

            this._oWbsFragment = Fragment.load({
                id: this.getView().getId(),
                name: "com.mmapprovalhub.approvalhub.Fragments.ContingencyBalanceForm",
                controller: this
            }).then(function (oFragment) {
                this.getView().addDependent(oFragment);
                return oFragment;

            }.bind(this));

            this._oContBalanceFragment = Fragment.load({
                id: this.getView().getId(),
                name: "com.mmapprovalhub.approvalhub.Fragments.ContingencyBalanceTab",
                controller: this
            }).then(function (oFragment) {
                this.getView().addDependent(oFragment);
                return oFragment;
            }.bind(this));


            this._remarkFragment = Fragment.load({
                id: this.getView().getId(),
                name: "com.mmapprovalhub.approvalhub.Fragments.remarks",
                controller: this
            }).then(function (rFragment) {
                this.getView().addDependent(rFragment);
                return rFragment;
            }.bind(this));
        },

        // onAfterRendering: function () {
        //     var oView = this.getView();

        //     var aComboBoxes = oView.findAggregatedObjects(true, function (oControl) {
        //         return oControl.isA("sap.m.ComboBox");
        //     });

        //     aComboBoxes.forEach(function (oComboBox) {
        //         var oDomRef = oComboBox.getDomRef("inner");

        //         if (oDomRef) {

        //             if (oComboBox._focusOutListener) {
        //                 oDomRef.removeEventListener("focusout", oComboBox._focusOutListener);
        //             }

        //             oComboBox._focusOutListener = function () {
        //                 var sValue = oComboBox.getValue();
        //                 var aItems = oComboBox.getItems();

        //                 var bValid = aItems.some(function (oItem) {
        //                     return oItem.getText() === sValue || oItem.getKey() === sValue;
        //                 });

        //                 if (!bValid) {
        //                     oComboBox.setValue("");
        //                     oComboBox.setSelectedKey("");
        //                     oComboBox.setValueState("None");
        //                 }
        //             };

        //             oDomRef.addEventListener("focusout", oComboBox._focusOutListener);
        //         }
        //     });
        // },
        
        onFetchTimelinessData: function () {
            var reqid = this._reqIDData;
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
       
            oModelV2.read("/ProcessLogs", {
                filters: [
                    new sap.ui.model.Filter("reqID", sap.ui.model.FilterOperator.EQ, reqid)
                ],
                success: function (oData) {
                    if (oData && oData.results) {
                        oData.results.sort(function (a, b) {
                            return new Date(a.receivedDt) - new Date(b.receivedDt);
                        });
                        var aProcessedData = oData.results.map(function (oLog) {
                            return {
                                createdAt: oLog.createdAt,
                                role: oLog.stage ? "[" + oLog.stage + "]" : "[N/A]",
                                userName: oLog.userName || "Unknown User",
                                userEmail: oLog.userEmail || "N/A",
                                userPicture: "",
                                // remarks: oLog.remarks || "No remarks provided"
                            };
                        });
                
                        var oJSONModel = new sap.ui.model.json.JSONModel({
                            results: aProcessedData
                        });
                        oView.setModel(oJSONModel, "timelinesslogdata");
                    }
                },
                error: function (oError) {
                    sap.m.MessageToast.show("Failed to load attachment data.");
                    console.error(oError);
                }
            });
        },
       
        formatTimelineTitle: function (role, userName, userEmail) {
            return role + " " + userName + " (" + userEmail + ")";
        },
        _onRouteAdpdApproved: function (oEvent) {
            this._ApprovedCheck = "";
            var oArgs = oEvent.getParameter("arguments");
            this._adpdNameUI = oArgs.basedNameUIadpd;
            var reqID = oArgs.reqID;
            this._reqIDData = reqID;
            this._ApprovedCheck = oArgs.approved;
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;

            oModelV2.read("/Requests", {
                urlParameters: {
                    "$filter": "reqID eq '" + reqID + "'",
                     "$expand": "adpdDtl,ssfdDtl,ipmDtl,newdtl,recomApprovers,processLogs,attachments"
                },
                success: function (oData) {
                    if (oData && oData.results.length > 0) {
                        let oRequestServiceModel = that.getOwnerComponent().getModel("Requestservicemodel");
                        // that.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
                        if (!oRequestServiceModel) {
                            oRequestServiceModel = new sap.ui.model.json.JSONModel();
                            that.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
                        }

                        oRequestServiceModel.setData(oData.results[0]);
                        var statusDatacheck = oData.results[0].status;
                        that.statusData = oData.results[0].status;
                        var sType  =  oData.results[0].adpdDtl.subType;
                        that._subTypeDataforui = sType
                      var resultreqdata =  oData.results[0].reqID
                        that._loadExpenseDtl(resultreqdata);
                        that._loadFinanceDataTable(resultreqdata);
                        that._loadMaterialCostData(resultreqdata);
                        that._loadparkedSDtl(resultreqdata);
                        that._loadinvestDtlData(resultreqdata);
                        let IntiateValueData = oData.results[0].adpdDtl.InitiationFlag;
                        var sPlatformDesc = oData.results[0].adpdDtl.Platform;
                        that._platformDataVisiblity(sPlatformDesc);
                        that.byId("AdpdCphInput").setValue(oData.results[0].adpdDtl.CPH) || "";
                        that.byId("AdpdPehInput").setValue(oData.results[0].adpdDtl.PEH) || "";
                         that.byId("AdpdPpmInput").setValue(oData.results[0].adpdDtl.PPM) || "";
                         that.byId("AdpdPnhInput").setValue(oData.results[0].adpdDtl.PNH) || "";
                          that.byId("AdpdPphInput").setValue(oData.results[0].adpdDtl.PPH) || "";
                          that.byId("AdpdPfhInput").setValue(oData.results[0].adpdDtl.PFH) || "";
                          that.byId("AdpdSrGmCombo").setValue(oData.results[0].adpdDtl.SrGM) || "";
                        that.byId("AdpdSrVpCombo").setValue(oData.results[0].adpdDtl.SrVP) || "";
                          that.byId("AdpdFinanceInput").setValue(oData.results[0].adpdDtl.finMember) || "";
                        var oRadioGroup = that.byId("AdpdMaterialCostRadioGroup");
                        var ImpactOnMatFlag = oData.results[0].adpdDtl.ImpactOnMatFlag;
                        
                        var ImpactOnMatFlagCon = oData.results[0].adpdDtl.ContingIOM;
                        var FinancedataFlag = oData.results[0].adpdDtl.onBehalfFlag;

                        var selfDecFlag = oData.results[0].adpdDtl.selfDecFlag;
                        var oRadioGroupCon = that.byId("AdpdNewMaterialCostRadioConten");
                        var oRadioFinanceData = that.byId("financeheadData");

                        that._onTableVisiblityCheck(sType);
                        var StagefinanceData = oData.results[0].stage;
                        
                        var oView = that.getView();
                        oView.byId("AdpdForumMultiSelect").setSelectedKey(oData.results[0].adpdDtl.Forum);
                        // that.statusData = statusDatacheck;
                        that.stagesData = oData.results[0].stage;

                        var aViewModel = that.getView().getModel("viewenableddatacheck");
                        if (statusDatacheck === "Draft" || !statusDatacheck) {
                            aViewModel.setProperty("/enableRowActions", false);
                            aViewModel.setProperty("/approvebuttonvisiblity", false);
                        } else if (statusDatacheck === "Pending" || statusDatacheck === "Pending At HOD" || statusDatacheck === "Pending") {
                            aViewModel.setProperty("/enableRowActions", false);
                            aViewModel.setProperty("/approvebuttonvisiblity", false);
                        } else {
                            aViewModel.setProperty("/enableRowActions", false);
                            aViewModel.setProperty("/approvebuttonvisiblity", false);
                        }

                        if (that._ApprovedCheck === "Approved" && (statusDatacheck === "Pending")) {
                            aViewModel.setProperty("/enableRowActions", false);
                            aViewModel.setProperty("/approvebuttonvisiblity", true);
                        } else {
                            aViewModel.setProperty("/enableRowActions", false);
                            aViewModel.setProperty("/approvebuttonvisiblity", false);
                        }


                        var oObjectPage = that.byId("AdpdObjectPageLayout");
                        if (oObjectPage) {
                            setTimeout(function () {
                                var aSections = oObjectPage.getSections();
                                if (aSections && aSections.length > 0) {
                                    var sSectionId = aSections[0].getId();
                                    oObjectPage.scrollToSection(sSectionId);
                                }
                            }, 300);
                        }
                      //  that._resetCompleteForm();
                        that.onTransferTypeDataFetch();
                        that.onNaturofExpensiveDataFetch();
                        that.onplatformDataFetch();
                        that.onForumDataFetch();
                        that.onADPDProjDataFetch();
                        that.onRespectiveInition(oEvent);
                        that.onApproverdatapropetyfetchFinaceData();
                        that.onFetchTimelinessData();
                        that.onAttchmentDataFetch();
                        that.onRecomendedDatFetchData(reqID);
                        that._onIntiateFOrumVisiblity(IntiateValueData);
                        that.getView().getModel("viewenableddatacheck").setProperty("/HeadCaseDataVis", true);
                        if(StagefinanceData === "Initiator" || StagefinanceData === "" || StagefinanceData === null){
                            that.getView().getModel("viewModel").setProperty("/financestageRemarkseditable", false);
                            that.getView().getModel("viewModel").setProperty("/financestageRemarks", false);
                         
                        }else if(StagefinanceData === "Finance"){
                            that.getView().getModel("viewModel").setProperty("/financestageRemarks", true);
                            that.getView().getModel("viewModel").setProperty("/financestageRemarkseditable", true);
    
                        }else{
                            that.getView().getModel("viewModel").setProperty("/financestageRemarkseditable", false);
                            that.getView().getModel("viewModel").setProperty("/financestageRemarks", true);
                        }
                        if (ImpactOnMatFlag === true) {
                            oRadioGroup.setSelectedIndex(0);
                            that.getView().getModel("viewModel").setProperty("/materialcostTable", true);
    
                        } else if (ImpactOnMatFlag === false) {
                            oRadioGroup.setSelectedIndex(1); 
                            that.getView().getModel("viewModel").setProperty("/materialcostTable", false);
                        } else {
                            oRadioGroup.setSelectedIndex(-1); 
                            that.getView().getModel("viewModel").setProperty("/materialcostTable", false);
                        }
                        var MaterialcostTabledataCon =  that.byId("MaterialcostTabledataCon").getVisible();
                        if(MaterialcostTabledataCon === true){
                        if (ImpactOnMatFlagCon === true) {
                            oRadioGroupCon.setSelectedIndex(0);
                            that.getView().getModel("viewModel").setProperty("/materialcostTableCon", true);
    
                        } else if (ImpactOnMatFlagCon === false) {
                            oRadioGroupCon.setSelectedIndex(1); 
                            that.getView().getModel("viewModel").setProperty("/materialcostTableCon", false);
                        } else {
                            oRadioGroupCon.setSelectedIndex(-1); 
                            that.getView().getModel("viewModel").setProperty("/materialcostTableCon", false);
                        }
                    }
                    if (FinancedataFlag === true) {
                        oRadioFinanceData.setSelectedIndex(0);
                    } else if (FinancedataFlag === false) {
                        oRadioFinanceData.setSelectedIndex(1); 
                    } else {
                        oRadioFinanceData.setSelectedIndex(-1); 
                    }
                    
                    if(StagefinanceData === "Head"){
                        that.getView().getModel("viewenableddatacheck").setProperty("/HeadCaseData", true);
                    }else{
                        that.getView().getModel("viewenableddatacheck").setProperty("/HeadCaseData", false);
                    }
                    if(selfDecFlag === true){
                        that.getView().getModel("viewenableddatacheck").setProperty("/selfDecFlag", true);
                    }else{
                        that.getView().getModel("viewenableddatacheck").setProperty("/selfDecFlag", false);
                    }

                    } else {
                        MessageToast.show("No data found for Req ID: " + reqID, { position: "bottom center" });
                    }
                    that.byId("AdpdPlatformSelect").setValue(oData.results[0].adpdDtl.Platform) || "";
                    that.byId("AdpdNatureExpSelect").setValue(oData.results[0].adpdDtl.natureOfExpense) || "";
                    that.byId("AdpdProjectFinHeadCombo").setValue(oData.results[0].adpdDtl.projFinHead);

                },
                error: function (oError) {
                    MessageToast.show("Failed to load request data.", { position: "bottom center" });
                    console.error("Error fetching request data:", oError);
                }
            });
        },


        _onRouteAdpdReqIdController: function (oEvent) {
            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            var oArgs = oEvent.getParameter("arguments");
            this._adpdNameUI = oArgs.basedNameUIadpd;
            var sType = oArgs.basedNameUIadpd;
            // var reqID = sType.reqID;
            // var sType = oArgs.basedNameUIadpd;
            // this._sReqID = sType.reqID;
            //this._sReqID = reqID;
            var oView = this.getView();
            
            var reqID = oArgs.reqID;
            this._reqIDData = reqID;
            this._ApprovedCheck = "";
            var oView = this.getView();

            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;
            oModelV2.read("/Requests", {
                urlParameters: {
                    "$filter": "reqID eq '" + reqID + "'",
                   "$expand": "adpdDtl,ssfdDtl,ipmDtl,newdtl,recomApprovers,processLogs,attachments"
                },
                success: function (oData) {
                    if (oData && oData.results.length > 0) {
                        let oRequestServiceModel = that.getOwnerComponent().getModel("Requestservicemodel");
                        if (!oRequestServiceModel) {
                            oRequestServiceModel = new sap.ui.model.json.JSONModel();
                            that.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
                        }
                        oRequestServiceModel.setData(oData.results[0]);

                        // let oWbsModel = that.getOwnerComponent().getModel("wbsModel");
                        // if (!oWbsModel) {
                        //     oWbsModel = new sap.ui.model.json.JSONModel();
                        //     that.getOwnerComponent().setModel(oWbsModel, "wbsModel");
                        // }
                        // oWbsModel.setProperty("/rows", oMainData.expenseDtl.results);



                        var statusDatacheck = oData.results[0].status;
                       var sType  =  oData.results[0].adpdDtl.subType;
                       that._subTypeDataforui = sType
                    
                     var resultreqdata =  oData.results[0].reqID
                       that._loadExpenseDtl(resultreqdata);
                       that._loadFinanceDataTable(resultreqdata);
                       that._loadparkedSDtl(resultreqdata);
                       that._loadinvestDtlData(resultreqdata);
                       that._loadMaterialCostData(resultreqdata);
                      let IntiateValueData = oData.results[0].adpdDtl.InitiationFlag;
                      var oRadioGroup = that.byId("AdpdMaterialCostRadioGroup");
                      var oRadioGroupCon = that.byId("AdpdNewMaterialCostRadioConten");
                      var ImpactOnMatFlag = oData.results[0].adpdDtl.ImpactOnMatFlag;
                      var ImpactOnMatFlagCon = oData.results[0].adpdDtl.ContingIOM;
                      var sPlatformDesc = oData.results[0].adpdDtl.Platform;
                      var selfDecFlag = oData.results[0].adpdDtl.selfDecFlag;
                   that._platformDataVisiblity(sPlatformDesc);
                   var StagefinanceData = oData.results[0].stage;
                  
              

                    
                        that._onTableVisiblityCheck(sType);
                        that._onIntiateFOrumVisiblity(IntiateValueData);
                        if (oView.byId("AdpdForumMultiSelect") && oData.adpdDtl?.Forum) {
                            oView.byId("AdpdForumMultiSelect").setSelectedKey(oData.adpdDtl.Forum);
                        }
                        that.statusData = oData.results[0].status;
                        if (statusDatacheck === "Draft" || statusDatacheck === null || statusDatacheck === "" || statusDatacheck === "Send Back") {
                            that.getView().getModel("viewenableddatacheck").setProperty("/enableRowActions", true);
                            that.getView().getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblity", false);
                            that.getView().getModel("viewenableddatacheck").setProperty("/HeadCaseDataVis", false);
                        } else if (statusDatacheck === "Pending" || statusDatacheck === "Pending With") {
                            that.getView().getModel("viewenableddatacheck").setProperty("/enableRowActions", false);
                            that.getView().getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblity", false);
                            that.getView().getModel("viewenableddatacheck").setProperty("/HeadCaseDataVis", true);
                        } else if (statusDatacheck === "Approved") {
                            that.getView().getModel("viewenableddatacheck").setProperty("/enableRowActions", false);
                            that.getView().getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblity", false);
                            that.getView().getModel("viewenableddatacheck").setProperty("/HeadCaseDataVis", true);
                        }else{
                            that.getView().getModel("viewenableddatacheck").setProperty("/HeadCaseDataVis", true);
                            that.getView().getModel("viewenableddatacheck").setProperty("/enableRowActions", false);
                            that.getView().getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblity", false);
                        }
                        that.onAttchmentDataFetch();
                     

                    } else {
                        sap.m.MessageToast.show("No data found for Req ID: " + reqID);
                    }
                    if(StagefinanceData === "Initiator" || StagefinanceData === "" || StagefinanceData === null){
                        that.getView().getModel("viewModel").setProperty("/financestageRemarkseditable", false);
                        that.getView().getModel("viewModel").setProperty("/financestageRemarks", false);
                     
                    }else{
                        that.getView().getModel("viewModel").setProperty("/financestageRemarks", true);
                        that.getView().getModel("viewModel").setProperty("/financestageRemarkseditable", false);

                    }
                    if (ImpactOnMatFlag === true) {
                        oRadioGroup.setSelectedIndex(0);
                        that.getView().getModel("viewModel").setProperty("/materialcostTable", true);

                    } else if (ImpactOnMatFlag === false) {
                        oRadioGroup.setSelectedIndex(1); 
                        that.getView().getModel("viewModel").setProperty("/materialcostTable", false);
                    } else {
                        oRadioGroup.setSelectedIndex(-1); 
                        that.getView().getModel("viewModel").setProperty("/materialcostTable", false);
                    }
                    var MaterialcostTabledataCon =  that.byId("MaterialcostTabledataCon").getVisible();
                    if(MaterialcostTabledataCon === true){
                        if (ImpactOnMatFlagCon === true) {
                            oRadioGroupCon.setSelectedIndex(0);
                            that.getView().getModel("viewModel").setProperty("/materialcostTableCon", true);
    
                        } else if (ImpactOnMatFlagCon === false) {
                            oRadioGroupCon.setSelectedIndex(1); 
                            that.getView().getModel("viewModel").setProperty("/materialcostTableCon", false);
                        } else {
                            oRadioGroupCon.setSelectedIndex(-1); 
                            that.getView().getModel("viewModel").setProperty("/materialcostTableCon", false);
                        }
                    }
                    that.getView().getModel("viewenableddatacheck").setProperty("/HeadCaseData", false);
                    oView.byId("AdpdProjectFinHeadCombo").setValue(sPlatformDesc);
                    oView.byId("AdpdProjectSelect").setValue(oData.results[0].adpdDtl.Project);
                    if(selfDecFlag === true){
                        that.getView().getModel("viewenableddatacheck").setProperty("/selfDecFlag", true);
                    }else{
                        that.getView().getModel("viewenableddatacheck").setProperty("/selfDecFlag", false);
                    }
                    that.byId("AdpdPlatformSelect").setValue(oData.results[0].adpdDtl.Platform) || "";
                    that.byId("AdpdNatureExpSelect").setValue(oData.results[0].adpdDtl.natureOfExpense) || "";
                    that.byId("AdpdCphInput").setValue(oData.results[0].adpdDtl.CPH) || "";
                    that.byId("AdpdPehInput").setValue(oData.results[0].adpdDtl.PEH) || "";
                     that.byId("AdpdPpmInput").setValue(oData.results[0].adpdDtl.PPM) || "";
                     that.byId("AdpdPnhInput").setValue(oData.results[0].adpdDtl.PNH) || "";
                      that.byId("AdpdPphInput").setValue(oData.results[0].adpdDtl.PPH) || "";
                      that.byId("AdpdPfhInput").setValue(oData.results[0].adpdDtl.PFH) || "";
                      that.byId("AdpdSrGmCombo").setValue(oData.results[0].adpdDtl.SrGM) || "";
                    that.byId("AdpdSrVpCombo").setValue(oData.results[0].adpdDtl.SrVP) || "";
                      that.byId("AdpdFinanceInput").setValue(oData.results[0].adpdDtl.finMember) || "";
                      that.byId("AdpdProjectFinHeadCombo").setValue(oData.results[0].adpdDtl.projFinHead);

                },
                error: function (oError) {
                    sap.m.MessageToast.show("Failed to load HOD data.");
                }
            });

            const oComponent = that.getOwnerComponent();
            const oSharedModel = oComponent.getModel("shared");
            const sApprovalType = oSharedModel?.getProperty("/approvalType") || "";



            const oViewModel = that.getView().getModel("viewModel");

            if (oViewModel) {
                oViewModel.setProperty("/showForum", sApprovalType === "Note Approval");
            }

            var oObjectPage = that.byId("AdpdObjectPageLayout");
            if (oObjectPage) {
                setTimeout(function () {
                    oObjectPage.scrollToSection(oObjectPage.getSections()[0].getId());
                    //oObjectPage.scrollToTop();
                }, 300);
            }
            const oPage = that.byId("AdpdInitialPage");
            if (oPage && oPage.scrollTo) {
                oPage.scrollTo(0);
            }
            that.onAttchmentDataFetch();
            that.onTransferTypeDataFetch();
            that.onNaturofExpensiveDataFetch();
            that.onplatformDataFetch();
            that.onForumDataFetch();
            that.onADPDProjDataFetch();
            that.sApprovalData = sApprovalType;
            that.onApproveDataFetch();
            that.onApproveDataFetchRecommended();
            that.onRespectiveInition(oEvent, sApprovalType);
            that.onApproverdatapropetyfetchFinaceData();
            that.onFetchTimelinessData();
            that.onRecomendedDatFetchData(reqID);
        },
        onAddMaterialCostDataCOn: function () {
            var oTable = this.byId("MaterialcostTabledata");
            var oModel = this.getView().getModel("materialcostData");
            var aRows = oModel.getProperty("/matcostDtl") || [];
            var iInsertIndex = aRows.length;
            var aSelectedIndices = oTable.getSelectedIndices();
            if (aSelectedIndices.length > 0) {
                var iSelectedIndex = aSelectedIndices[0];
                var oContext = oTable.getContextByIndex(iSelectedIndex);
                var sPath = oContext.getPath(); 
                var iModelIndex = parseInt(sPath.split("/").pop());
                iInsertIndex = iModelIndex + 1;
            }
            var oNewRow = {
                item: "",
                vehicleLevel: "",
                ptdLevel: "",
                totalLevel: ""
            };
            aRows.splice(iInsertIndex, 0, oNewRow);
            oModel.setProperty("/matcostDtl", aRows);
            oTable.clearSelection();
        },  
        onAddMaterialCostData: function () {
            var oTable = this.byId("MaterialcostTabledata");
            var oModel = this.getView().getModel("materialcostData");
            var aRows = oModel.getProperty("/matcostDtl") || [];
            var iInsertIndex = aRows.length;
            var aSelectedIndices = oTable.getSelectedIndices();
            if (aSelectedIndices.length > 0) {
                var iSelectedIndex = aSelectedIndices[0];
                var oContext = oTable.getContextByIndex(iSelectedIndex);
                var sPath = oContext.getPath(); 
                var iModelIndex = parseInt(sPath.split("/").pop());
                iInsertIndex = iModelIndex + 1;
            }
            var oNewRow = {
                item: "",
                vehicleLevel: "",
                ptdLevel: "",
                totalLevel: ""
            };
            aRows.splice(iInsertIndex, 0, oNewRow);
            oModel.setProperty("/matcostDtl", aRows);
            oTable.clearSelection();
        },  
        onMaterialCostChange: function (oEvent) {
            var oInput = oEvent.getSource();
            var oContext = oInput.getBindingContext("materialcostData");
            if (!oContext) return;
            var oRowData = oContext.getObject();
            var sPath = oContext.getPath();
            var oModel = oContext.getModel();
            var fVehicle = parseFloat(oRowData.vehicleLevel) || 0;
            var fPTD = parseFloat(oRowData.ptdLevel) || 0;
            var fTotal = fVehicle + fPTD;
            oModel.setProperty(sPath + "/totalLevel", fTotal.toFixed(2));
        },                        
        onRadioSelectVisiblity: function(oEvent){
            var sSelectedIndex = oEvent.getParameter("selectedIndex");
            var bShowTable = sSelectedIndex === 0; 
            var oViewModel = this.getView().getModel("viewModel");
            oViewModel.setProperty("/materialcostTable", bShowTable);
        },
        onRadioContingencyCheckTableVisiblity: function(oEvent){
            var sSelectedIndex = oEvent.getParameter("selectedIndex");
            var bShowTable = sSelectedIndex === 0; 
            var oViewModel = this.getView().getModel("viewModel");
            oViewModel.setProperty("/materialcostTableCon", bShowTable);
        },
      
        onRecomendedDatFetchData: function(reqID){
            var oModelV2Recc = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;
            oModelV2Recc.read("/Requests('" + reqID + "')/recomApprovers", {
                success: function(oData) {
                    var oJSONModel = new sap.ui.model.json.JSONModel();
                    oJSONModel.setData({ recommendations: oData.results });
                    that.getView().setModel(oJSONModel, "InterlineModel");  
                },
                error: function(oError) {
                    sap.m.MessageToast.show("Failed to load ExpenseDtl data.");
                }
            });
        },
        _loadinvestDtlData: function(reqID) {
            var oModelV2expenseDtl = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;
            oModelV2expenseDtl.read("/ReqFormAP_Transfer('" + reqID + "')/investDtl", {
                success: function(oData) {
                    var oExpenseModel = that.getView().getModel("InvestmentModel");
                    oExpenseModel.setProperty("/investmentData", oData.results);   
                    that.PreProjectInvestment();      
                },
                error: function(oError) {
                    sap.m.MessageToast.show("Failed to load ExpenseDtl data.");
                }
            });
        },
        _loadparkedSDtl: function(reqID) {
            var oModelV2expenseDtl = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;
            oModelV2expenseDtl.read("/ReqFormAP_Transfer('" + reqID + "')/parkedSDtl", {
                success: function(oData) {
                    var oExpenseModel = that.getView().getModel("contBalanceModel");
                    oExpenseModel.setProperty("/modelData", oData.results);  
                    that.calculateParkCon();     
                },
                error: function(oError) {
                    sap.m.MessageToast.show("Failed to load ExpenseDtl data.");
                }
            });
        },  
        _loadFinanceDataTable: function(reqID) {
            var oModelV2expenseDtl = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;
            oModelV2expenseDtl.read("/ReqFormAP_Transfer('" + reqID + "')/ProjCostDtl", {
                success: function(oData) {
                    var oExpenseModel = that.getView().getModel("FinancialModel");
                    oExpenseModel.setProperty("/rows", oData.results);        
                },
                error: function(oError) {
                    sap.m.MessageToast.show("Failed to load Finance data.");
                }
            });
        },
        _loadExpenseDtl: function(reqID) {
            var oModelV2expenseDtl = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;
            oModelV2expenseDtl.read("/ReqFormAP_Transfer('" + reqID + "')/expenseDtl", {
                success: function(oData) {
                    var oExpenseModel = that.getView().getModel("wbsModel");
                    oExpenseModel.setProperty("/rows", oData.results);   
                    that.calculateWbsTotals(); 
                    that.calculateWbsTotalsCont();
                },
                error: function(oError) {
                    sap.m.MessageToast.show("Failed to load ExpenseDtl data.");
                }
            });
        }, 
        
        _loadMaterialCostData: function(reqID) {
            var oModelV2expenseDtl = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;
            oModelV2expenseDtl.read("/ReqFormAP_Transfer('" + reqID + "')/matcostDtl", {
                success: function(oData) {
                    var oExpenseModel = that.getView().getModel("materialcostData");
                    oExpenseModel.setProperty("/matcostDtl", oData.results);        
                },
                error: function(oError) {
                    sap.m.MessageToast.show("Failed to load ExpenseDtl data.");
                }
            });
        }, 

        _onRouteAdpdController: function (oEvent) {
            var oArgs = oEvent.getParameter("arguments");
            var sType = oArgs.basedNameUIadpd;
            let sApprovalTypeDataApprover = this.getOwnerComponent().getModel("shared").getProperty("/approvalType");
            this._sApprovalDataInitiate = sApprovalTypeDataApprover
            this._subTypeDataforui = oArgs.basedNameUIadpd;
            var oRadioGroup = this.byId("AdpdMaterialCostRadioGroup");
            oRadioGroup.setSelectedIndex(-1);
            var oRadioGroupCOn = this.byId("AdpdNewMaterialCostRadioConten");
            oRadioGroupCOn.setSelectedIndex(-1);
            var oFinanceData = this.byId("financeheadData");
            oFinanceData.setSelectedIndex(-1);
            var sTypeDataCheck = "";
            switch(sType) {
                case "ADPD":
                    sTypeDataCheck = "IIIT";
                    break;
                case "ContingencyBudgetUtil":
                    sTypeDataCheck = "CBU";
                    break;
                case "ParkedSaving":
                    sTypeDataCheck = "PS";
                    break;
                case "preProBud":
                    sTypeDataCheck = "PPBA";
                    break;
                case "Exigency":
                    sTypeDataCheck = "EXIG";
                    break;
                case "BudgetAd":
                    sTypeDataCheck = "BA";
                    break;
                case "CostOverrun":
                    sTypeDataCheck = "CO";
                    break;
                default:
                    sTypeDataCheck = ""; 
            }
            this._subTypeDataforui = sTypeDataCheck;
            this._reqIDData = ""
            this._adpdNameUI = sType;

            var statusDatacheck = "";

            if (statusDatacheck === "Draft" || statusDatacheck === null || statusDatacheck === "") {
                this.getView().getModel("viewenableddatacheck").setProperty("/enableRowActions", true);
                this.getView().getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblity", false);
            } else if (statusDatacheck === "Pending" || statusDatacheck === "Pending With") {
                this.getView().getModel("viewenableddatacheck").setProperty("/enableRowActions", false);
                this.getView().getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblity", false);

            } else if (statusDatacheck === "Approved") {
                this.getView().getModel("viewenableddatacheck").setProperty("/enableRowActions", false);
                this.getView().getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblity", false);
            }else{
                this.getView().getModel("viewenableddatacheck").setProperty("/enableRowActions", false);
                this.getView().getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblity", false);
            }
            this.getView().byId("AdpdPlatformSelect").setValue("");
            this.getView().byId("AdpdNatureExpSelect").setValue("");
            const oComponent = this.getOwnerComponent();
            const oSharedModel = oComponent.getModel("shared");
            const sApprovalType = oSharedModel?.getProperty("/approvalType") || "";
            var oRequestServiceModel = this.getOwnerComponent().getModel("Requestservicemodel");
            if (!oRequestServiceModel) {
                oRequestServiceModel = new sap.ui.model.json.JSONModel();
                this.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
            }
            var oEmptyData = {
                reqID: "",
                refNo: "",

                adpdDtl: []
            };
            oRequestServiceModel.setData(oEmptyData);
            const oViewModel = this.getView().getModel("viewModel");
            if (oViewModel) {
                oViewModel.setProperty("/showForum", sApprovalType === "Note Approval");
            }
            var oObjectPage = this.byId("AdpdObjectPageLayout");
            if (oObjectPage) {
                setTimeout(function () {
                    oObjectPage.scrollToSection(oObjectPage.getSections()[0].getId());
                    // oObjectPage.scrollToTop();
                }, 300);
            }
            const oPage = this.byId("AdpdInitialPage");
            if (oPage && oPage.scrollTo) {
                oPage.scrollTo(0);
            }

            this.onTransferTypeDataFetch();
            this.onNaturofExpensiveDataFetch();
            this.onplatformDataFetch();
            this.onForumDataFetch();
            this.onADPDProjDataFetch();
            this.onApproveDataFetch();
            this.onApproveDataFetchRecommended();
            var sPlatformDesc = "";
            this._platformDataVisiblity(sPlatformDesc);
            // approverdata
            this.onApproverdatapropetyfetchFinaceData();
            this._onTableVisiblityCheck(sTypeDataCheck);
            this.onRespectiveInition(oEvent, sApprovalType);
            this.getView().getModel("viewModel").setProperty("/financestageRemarks", false);
            this.getView().getModel("viewModel").setProperty("/financestageRemarkseditable", false);
            this.getView().getModel("viewModel").setProperty("/materialcostTable", false);
            this.getView().getModel("viewModel").setProperty("/materialcostTableCon", false);

            this.getView().getModel("viewenableddatacheck").setProperty("/HeadCaseDataVis", false);
            this.getView().getModel("viewenableddatacheck").setProperty("/selfDecFlag", false);
            this.calculateWbsTotals();
            this.calculateWbsTotalsCont();
            this.calculateParkCon();
            this.PreProjectInvestment();   
        },
     
        onApproverdatapropetyfetchFinaceData: function(){
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oView = this.getView(); 
            var aFilters = [
                new sap.ui.model.Filter("department", sap.ui.model.FilterOperator.EQ, "ADPD"),
                new sap.ui.model.Filter("role", sap.ui.model.FilterOperator.EQ, "FIN")
            ];
            oModelV2.read("/Approvers", {
                filters: aFilters,
                success: function (oData) {
                    if (oData ) {
                        var oApproversModel = new sap.ui.model.json.JSONModel(oData); 
                        oView.setModel(oApproversModel, "RecommendedApproverDataFinance");
                    }
                },
                error: function (oError) {
                    console.error("Failed to load Approvers data:", oError);
                }
            });
        },        
           
        _onIntiateFOrumVisiblity: function(IntiateValueData){
            var IntiateValueData = IntiateValueData;
            var oViewModel = this.getView().getModel("viewModel");
            if(IntiateValueData === "Note Approval"){
                // oVisibility.showForum = false;
                oViewModel.setProperty("/showForum", false);
            }else{
                oViewModel.setProperty("/showForum", true);
            }
        },
        _onTableVisiblityCheck: function( sType){
            var sApprovalType  = this.sApprovalData
            // var oArgs = oEvent.getParameter("arguments");
            var sType = sType;
            var oBundle = this.getResourceBundle();
            var _IntiateValueData =  this._IntiateValueData;
            let sPageTitle = "";
            let sTableTitle = "";
            let sObjectSect = "";
            let oVisibility = {
                showSopDate: true,
                showInvestment: true,
                showEstimatedCost: true,
                showFinancial: true,
                showWBS: true,
                showRadioBtn: true,
                showBalanceTable: true,
                showContNrtCode: true,
                showContLevel: true,
                checkbothcasesdata: true,
                showFregLevel: true,
                ApproverSecRole: true,
                showForum: true,
                showTransfertype: true,
                showNatureoFExpense: true,
                showAdpdTable: false,
                showWBsCode: true,
                showNatureoFApproval: false,
                showFregNrtCode: true,
                showApproverSearchLabel: true,
                showRevenueTotalCol: true,
                showVolumesBreakup: false
            };

            switch (sType) {
                case "IIIT":
                    sPageTitle = oBundle.getText("titleADPD");
                    oVisibility.showWBS = false;
                    oVisibility.showInvestment = false;
                    oVisibility.showEstimatedCost = false;
                    oVisibility.showAdpdTable = true;
                    oVisibility.showSopDate = false;
                    // oVisibility.showForum= true,
                    if (sApprovalType === "Note Approval" ) {

                        oVisibility.showForum = false;

                    } else {

                        oVisibility.showForum = true;

                    }
                    oVisibility.showFinancial = false;
                    oVisibility.showFormControls = false;
                    oVisibility.showVolumesBreakup = false;
                    oVisibility.showApproverSearchLabel = false;
                    break;
                case "CBU":
                    sPageTitle = oBundle.getText("titleContingencyBudgetUtil");
                    sTableTitle = oBundle.getText("contingencyBalanceTitle");
                    //sObjectSect=oBundle.getText("ContingencyBudget");
                    oVisibility.showInvestment = false;
                    oVisibility.showEstimatedCost = false;
                    oVisibility.showWBS = true;
                    oVisibility.showFregLevel = false;
                    oVisibility.showSopDate = false;
                    // oVisibility.ApproverSecRole = false;
                    oVisibility.showFinancial = false;
                    // oVisibility.showForum = false;
                    if (sApprovalType === "Note Approval") {

                        oVisibility.showForum = false;

                    } else {

                        oVisibility.showForum = true;

                    }
                    oVisibility.showAdpdTable = false;
                    oVisibility.showTransfertype = false;
                    oVisibility.showNatureoFExpense = false;
                    oVisibility.showVolumesBreakup = false;
                    oVisibility.showContLevel = false;
                    oVisibility.checkbothcasesdata = true;
                    oVisibility.showRevenueTotalCol = false;
                    break;
                case "PS":
                    sPageTitle = oBundle.getText("titleParkedSaving");
                    sTableTitle = oBundle.getText("tableParkedSavings");
                    sObjectSect = oBundle.getText("Budget Saving");

                    oVisibility.showInvestment = false;
                    oVisibility.showEstimatedCost = false;
                    // oVisibility.ApproverSecRole = false;
                    oVisibility.showSopDate = false;
                    oVisibility.showFinancial = false;
                    // oVisibility.showForum = false;
                    if (sApprovalType === "Note Approval" ) {

                        oVisibility.showForum = false;

                    } else {

                        oVisibility.showForum = true;

                    }
                    oVisibility.showVolumesBreakup = false;
                    oVisibility.showContNrtCode = false;
                    oVisibility.showTransfertype = false;
                    oVisibility.showNatureoFExpense = false;
                    oVisibility.showRevenueTotalCol = false;
                    oVisibility.showFregNrtCode = false;
                    oVisibility.checkbothcasesdata = true;
                    break;
                case "PPBA":
                    sPageTitle = oBundle.getText("titlePreProBud");
                    //  sTableTitle = oBundle.getText("tablePreProjectBudget");
                    oVisibility.showWBS = false;
                    //  oVisibility.ApproverSecRole = false;
                    oVisibility.showFinancial = false;
                    // oVisibility.showForum = false;
                    if (sApprovalType === "Note Approval" ) {

                        oVisibility.showForum = false;

                    } else {

                        oVisibility.showForum = true;

                    }
                    oVisibility.showTransfertype = false;
                    oVisibility.showNatureoFExpense = false;
                    oVisibility.showBalanceTable = false;
                    oVisibility.showVolumesBreakup = false;
                    break;
                case "EXIG":
                    sPageTitle = oBundle.getText("titleExigency");
                    //  sTableTitle = oBundle.getText("tableExigencyBalance");
                    oVisibility.showInvestment = false;
                    oVisibility.showEstimatedCost = false;
                    oVisibility.showFinancial = false;
                    oVisibility.showNatureoFApproval = true;
                    oVisibility.checkbothcasesdata = false;
                    // oVisibility.showForum = false;
                    if (sApprovalType === "Note Approval") {

                        oVisibility.showForum = false;

                    } else {

                        oVisibility.showForum = true;

                    }
                    oVisibility.showTransfertype = false;
                    //  oVisibility.ApproverSecRole = false;
                    oVisibility.showRevenueTotalCol = true;
                    oVisibility.showWBsCode = false;
                    oVisibility.showBalanceTable = false;
                    oVisibility.showVolumesBreakup = true;
                    break;
                case "BA":
                    sPageTitle = oBundle.getText("titleBudgetAd");
                    // sTableTitle = oBundle.getText("tableBudgetAdvancement");
                    oVisibility.showInvestment = false;
                    oVisibility.showRadioBtn = false;
                    oVisibility.showEstimatedCost = false;
                    oVisibility.showRevenueTotalCol = true;
                    oVisibility.showFinancial = false;
                    oVisibility.showNatureoFExpense = false;
                    //  oVisibility.ApproverSecRole = false;
                    // oVisibility.showForum = false;
                    oVisibility.checkbothcasesdata = false;

                    if (sApprovalType === "Note Approval" ) {

                        oVisibility.showForum = false;

                    } else {

                        oVisibility.showForum = true;

                    }
                    oVisibility.showTransfertype = false;
                    oVisibility.showBalanceTable = false;
                    oVisibility.showVolumesBreakup = false;
                    break;
                case "CO":
                    sPageTitle = oBundle.getText("titleCostOverrun");
                    // sTableTitle = oBundle.getText("tableCostOverrun");
                    oVisibility.showInvestment = false;
                    oVisibility.showEstimatedCost = false;
                    // oVisibility.ApproverSecRole = false;
                    oVisibility.showRevenueTotalCol = true;
                    oVisibility.showFinancial = true;
                    oVisibility.checkbothcasesdata = false;
                    // oVisibility.showForum = false;
                    if (sApprovalType === "Note Approval") {

                        oVisibility.showForum = false;

                    } else {

                        oVisibility.showForum = true;

                    }
                    oVisibility.showBalanceTable = false;
                    oVisibility.showVolumesBreakup = false;
                    oVisibility.showTransfertype = false;
                    oVisibility.showNatureoFExpense = false;
                    break;
                default:
                    MessageBox.error(oBundle.getText("msgInvalidType", [sType]));
                    return;
            }

            // Update page and table titles
            this.byId("AdpdInitialPage").setTitle(sPageTitle);
            this.byId("AdpdTitleContBalance").setText(sTableTitle);
            //this.byId("AdpdContingencyBudgetWbsSection").setText(sObjectSect);
            // Update visibility in the view model
            this.getView().getModel("viewModel").setData(oVisibility);

        },
        onRespectiveInition: function (oEvent, sApprovalType) {
            var oArgs = oEvent.getParameter("arguments");
            var sType = oArgs.basedNameUIadpd;
            var oBundle = this.getResourceBundle();

            let sPageTitle = "";
            let sTableTitle = "";
            let sObjectSect = "";
            let oVisibility = {
                showSopDate: true,
                showInvestment: true,
                showEstimatedCost: true,
                showFinancial: true,
                showWBS: true,
                showRadioBtn: true,
                showBalanceTable: true,
                showContNrtCode: true,
                showContLevel: true,
                checkbothcasesdata: true,
                showFregLevel: true,
                ApproverSecRole: true,
                showForum: true,
                showTransfertype: true,
                showNatureoFExpense: true,
                showAdpdTable: false,
                showWBsCode: true,
                showNatureoFApproval: false,
                showFregNrtCode: true,
                showApproverSearchLabel: true,
                showRevenueTotalCol: true,
                showVolumesBreakup: false
            };

            switch (sType) {
                case "ADPD":
                    sPageTitle = oBundle.getText("titleADPD");
                    oVisibility.showWBS = false;
                    oVisibility.showInvestment = false;
                    oVisibility.showEstimatedCost = false;
                    oVisibility.showAdpdTable = true;
                    oVisibility.showSopDate = false;
                    // oVisibility.showForum= true,
                    if (sApprovalType === "Note Approval") {

                        oVisibility.showForum = false;

                    } else {

                        oVisibility.showForum = true;

                    }
                    oVisibility.showFinancial = false;
                    oVisibility.showFormControls = false;
                    oVisibility.showVolumesBreakup = false;
                    oVisibility.showApproverSearchLabel = false;
                    break;
                case "ContingencyBudgetUtil":
                    sPageTitle = oBundle.getText("titleContingencyBudgetUtil");
                    sTableTitle = oBundle.getText("contingencyBalanceTitle");
                    //sObjectSect=oBundle.getText("ContingencyBudget");
                    oVisibility.showInvestment = false;
                    oVisibility.showEstimatedCost = false;
                    oVisibility.showWBS = true;
                    oVisibility.showFregLevel = false;
                    oVisibility.showSopDate = false;
                    // oVisibility.ApproverSecRole = false;
                    oVisibility.showFinancial = false;
                    // oVisibility.showForum = false;
                    if (sApprovalType === "Note Approval") {

                        oVisibility.showForum = false;

                    } else {

                        oVisibility.showForum = true;

                    }
                    oVisibility.showAdpdTable = false;
                    oVisibility.showTransfertype = false;
                    oVisibility.showNatureoFExpense = false;
                    oVisibility.showVolumesBreakup = false;
                    oVisibility.showContLevel = false;
                    oVisibility.checkbothcasesdata = true;
                    oVisibility.showRevenueTotalCol = false;
                    break;
                case "ParkedSaving":
                    sPageTitle = oBundle.getText("titleParkedSaving");
                    sTableTitle = oBundle.getText("tableParkedSavings");
                    sObjectSect = oBundle.getText("Budget Saving");

                    oVisibility.showInvestment = false;
                    oVisibility.showEstimatedCost = false;
                    // oVisibility.ApproverSecRole = false;
                    oVisibility.showSopDate = false;
                    oVisibility.showFinancial = false;
                    // oVisibility.showForum = false;
                    if (sApprovalType === "Note Approval") {

                        oVisibility.showForum = false;

                    } else {

                        oVisibility.showForum = true;

                    }
                    oVisibility.showVolumesBreakup = false;
                    oVisibility.showContNrtCode = false;
                    oVisibility.showTransfertype = false;
                    oVisibility.showNatureoFExpense = false;
                    oVisibility.showRevenueTotalCol = false;
                    oVisibility.showFregNrtCode = false;
                    oVisibility.checkbothcasesdata = true;
                    break;
                case "preProBud":
                    sPageTitle = oBundle.getText("titlePreProBud");
                    //  sTableTitle = oBundle.getText("tablePreProjectBudget");
                    oVisibility.showWBS = false;
                    //  oVisibility.ApproverSecRole = false;
                    oVisibility.showFinancial = false;
                    // oVisibility.showForum = false;
                    if (sApprovalType === "Note Approval") {

                        oVisibility.showForum = false;

                    } else {

                        oVisibility.showForum = true;

                    }
                    oVisibility.showTransfertype = false;
                    oVisibility.showNatureoFExpense = false;
                    oVisibility.showBalanceTable = false;
                    oVisibility.showVolumesBreakup = false;
                    break;
                case "Exigency":
                    sPageTitle = oBundle.getText("titleExigency");
                    //  sTableTitle = oBundle.getText("tableExigencyBalance");
                    oVisibility.showInvestment = false;
                    oVisibility.showEstimatedCost = false;
                    oVisibility.showFinancial = false;
                    oVisibility.showNatureoFApproval = true;
                    // oVisibility.showForum = false;
                    if (sApprovalType === "Note Approval") {

                        oVisibility.showForum = false;

                    } else {

                        oVisibility.showForum = true;

                    }
                    oVisibility.showTransfertype = false;
                    //  oVisibility.ApproverSecRole = false;
                    oVisibility.checkbothcasesdata = false;
                    oVisibility.showRevenueTotalCol = true;
                    oVisibility.showWBsCode = false;
                    oVisibility.showBalanceTable = false;
                    oVisibility.showVolumesBreakup = true;
                    oVisibility.showNatureoFExpense = true;
                    break;
                case "BudgetAd":
                    sPageTitle = oBundle.getText("titleBudgetAd");
                    // sTableTitle = oBundle.getText("tableBudgetAdvancement");
                    oVisibility.showInvestment = false;
                    oVisibility.showRadioBtn = false;
                    oVisibility.showEstimatedCost = false;
                    oVisibility.showRevenueTotalCol = true;
                    oVisibility.showFinancial = false;
                    oVisibility.showNatureoFExpense = false;
                    //  oVisibility.ApproverSecRole = false;
                    // oVisibility.showForum = false;
                    oVisibility.checkbothcasesdata = false;

                    if (sApprovalType === "Note Approval") {

                        oVisibility.showForum = false;

                    } else {

                        oVisibility.showForum = true;

                    }
                    oVisibility.showTransfertype = false;
                    oVisibility.showBalanceTable = false;
                    oVisibility.showVolumesBreakup = false;
                    break;
                case "CostOverrun":
                    sPageTitle = oBundle.getText("titleCostOverrun");
                    // sTableTitle = oBundle.getText("tableCostOverrun");
                    oVisibility.showInvestment = false;
                    oVisibility.showEstimatedCost = false;
                    // oVisibility.ApproverSecRole = false;
                    oVisibility.showRevenueTotalCol = true;
                    oVisibility.showFinancial = true;
                    oVisibility.checkbothcasesdata = false;
                    // oVisibility.showForum = false;
                    if (sApprovalType === "Note Approval") {

                        oVisibility.showForum = false;

                    } else {

                        oVisibility.showForum = true;

                    }
                    oVisibility.showBalanceTable = false;
                    oVisibility.showVolumesBreakup = false;
                    oVisibility.showTransfertype = false;
                    oVisibility.showNatureoFExpense = false;
                    break;
                default:
                    MessageBox.error(oBundle.getText("msgInvalidType", [sType]));
                    return;
            }

            // Update page and table titles
            this.byId("AdpdInitialPage").setTitle(sPageTitle);
            this.byId("AdpdTitleContBalance").setText(sTableTitle);
            //this.byId("AdpdContingencyBudgetWbsSection").setText(sObjectSect);
            // Update visibility in the view model
            this.getView().getModel("viewModel").setData(oVisibility);
        },

        onForumDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();

            oView.setBusy(true);
            oModelV2.read("/ControlValues", {
                urlParameters: { "$filter": "category eq 'Forum'" },
                success: function (oData) {
                    oView.setBusy(false);
                    if (Array.isArray(oData.results)) {
                        oView.setModel(new JSONModel({ results: oData.results }), "ForumModel");
                    }
                },
                error: function (oError) {
                    oView.setBusy(false);
                    //MessageToast.show(oBundle.getText("msgFailedForumData"));
                    console.error("Forum data loading error:", oError);
                }
            });
        },

        onADPDProjDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();

            oView.setBusy(true);
            oModelV2.read("/ControlValues", {
                urlParameters: { "$filter": "category eq 'ADPD_PROJ'" },
                success: function (oData) {
                    oView.setBusy(false);
                    if (Array.isArray(oData.results)) {
                        oView.setModel(new JSONModel({ results: oData.results }), "ADPDProjModel");
                    }
                },
                error: function (oError) {
                    oView.setBusy(false);
                    // MessageToast.show(oBundle.getText("msgFailedADPDProjData"));
                    console.error("ADPD_PROJ load error:", oError);
                }
            });
        },
        
        onApproveDataFetchRecommended: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();

            // Combine department and role filters
            var aFilters = [
                new sap.ui.model.Filter("department", sap.ui.model.FilterOperator.EQ, "ADPD"),
                new sap.ui.model.Filter("role", sap.ui.model.FilterOperator.EQ, "R")
            ];

            oModelV2.read("/Approvers", {
                filters: aFilters,
                success: function (oData) {
                    if (oData && oData.results) {
                        // Set to local JSON model
                        var oApproversModel = new sap.ui.model.json.JSONModel({ results: oData.results });
                        oView.setModel(oApproversModel, "RecommendedDataCheck");
                    }
                },
                error: function (oError) {
                    console.error("Failed to load Approvers data:", oError);
                    // MessageToast.show(oBundle.getText("msgFailedApproversData"));
                }
            });
        },
        onApproveDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();

            // Combine department and role filters
            var aFilters = [
                new sap.ui.model.Filter("department", sap.ui.model.FilterOperator.EQ, "ADPD"),
                new sap.ui.model.Filter("role", sap.ui.model.FilterOperator.EQ, "PFH")
            ];

            oModelV2.read("/Approvers", {
                filters: aFilters,
                success: function (oData) {
                    if (oData && oData.results) {
                        // Set to local JSON model
                        var oApproversModel = new sap.ui.model.json.JSONModel({ results: oData.results });
                        oView.setModel(oApproversModel, "ApproversLocalModel");
                    }
                },
                error: function (oError) {
                    console.error("Failed to load Approvers data:", oError);
                    // MessageToast.show(oBundle.getText("msgFailedApproversData"));
                }
            });
        },

        onplatformDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();

            oModelV2.read("/Platforms", {
                success: function (oData) {
                    if (oData && oData.results) {
                        var seen = new Set();
                        var uniqueResults = oData.results.filter(function (item) {
                            if (!seen.has(item.PlatformDesc)) {
                                seen.add(item.PlatformDesc);
                                return true;
                            }
                            return false;
                        });
                        oView.setModel(new JSONModel({ results: uniqueResults }), "Platformsdataadpd");
                    }
                },
                error: function (oError) {
                    //MessageToast.show(oBundle.getText("msgFailedPlatformData"));
                    console.error("Platform loading error:", oError);
                }
            });
        },

        handleChange: function (oEvent) {
            var oValidatedComboBox = oEvent.getSource(),
                sSelectedKey = oValidatedComboBox.getSelectedKey(),
                sValue = oValidatedComboBox.getValue();

            if (!sSelectedKey && sValue) {
                oValidatedComboBox.setValueState(ValueState.Error);
                oValidatedComboBox.setValueStateText("Please enter a valid value!");
            } else {
                oValidatedComboBox.setValueState(ValueState.None);
            }
        },
        handleLiveChange: function (oEvent) {
            var oTextArea = oEvent.getSource(),
                iValueLength = oTextArea.getValue().length,
                iMaxLength = oTextArea.getMaxLength(),
                sState = iValueLength > iMaxLength ? ValueState.Warning : ValueState.None;

            oTextArea.setValueState(sState);
        },
        onComboBoxonMarketSenca: function(){
            
            var sPlatformDesc = this.getView().byId("AdpdPlatformSelect").getSelectedKey();
            this._platformDataVisiblity(sPlatformDesc);
        },
        _platformDataVisiblity: function (sPlatformDesc) {
            // Get the OData V2 model
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
        
            // Mapping of roles to respective Label and ComboBox IDs
            var aRoleMap = [
                { role: "AP_CPH", label: "AdpdCphText", combo: "AdpdCphInput" },
                { role: "AP_PEH", label: "AdpdPehText", combo: "AdpdPehInput" },
                { role: "AP_PPM", label: "AdpdPpmText", combo: "AdpdPpmInput" },
                { role: "AP_PMH", label: "AdpdPnhText", combo: "AdpdPnhInput" },
                { role: "AP_PPH", label: "AdpdPphText", combo: "AdpdPphInput" },
                { role: "AP_PFH", label: "AdpdPfhText", combo: "AdpdPfhInput" },
                { role: "AP_FM", label: "AdpdFinanceText", combo: "AdpdFinanceInput" },
                { role: "AP_SR_GM", label: "AdpdRoleGrid3GmColLab", combo: "AdpdSrGmCombo" },
                { role: "AP_SR_VP", label: "AdpdRoleGrid3VpColLab", combo: "AdpdSrVpCombo" }
            ];
        
            // If platform description is empty or undefined
            if (!sPlatformDesc) {
                aRoleMap.forEach(function (o) {
                    var oLabel = this.getView().byId(o.label);
                    var oCombo = this.getView().byId(o.combo);
        
                    // Only show Finance label and combo if no platform selected
                    var bVisible = (o.role === "AP_FM");
                    if (oLabel) oLabel.setVisible(bVisible);
                    if (oCombo) oCombo.setVisible(bVisible);
                }.bind(this));
                return;
            }
        
            // Prepare filters to get data for the selected PlatformDesc
            var aFilters = [
                new sap.ui.model.Filter("PlatformDesc", sap.ui.model.FilterOperator.EQ, sPlatformDesc)
            ];
        
            // Read data from OData service
            oModelV2.read("/Platforms", {
                filters: aFilters,
                success: function (oData) {
                    if (oData && oData.results && oData.results.length > 0) {
                        var aResults = oData.results;
        
                        aRoleMap.forEach(function (o) {
                            var bVisible = aResults.some(function (item) {
                                return item.Role === o.role;
                            });
                            if (o.role === "AP_FM") {
                                bVisible = true;
                            }
                            var oLabel = this.getView().byId(o.label);
                            var oCombo = this.getView().byId(o.combo);
                            if (oLabel) oLabel.setVisible(bVisible);
                            if (oCombo) oCombo.setVisible(bVisible);
                            if (bVisible && oCombo) {
                                var aUserData = aResults
                                    .filter(function (item) {
                                        return item.Role === o.role;
                                    })
                                    .map(function (item) {
                                        return {
                                            UserId: item.UserId,
                                            Name: item.Name 
                                        };
                                    });
                                var oComboModel = new sap.ui.model.json.JSONModel({
                                    results: aUserData
                                });
                                oCombo.setModel(oComboModel, "comboModel");
        
                            }
                        }.bind(this));
                    }
                }.bind(this),
                error: function (oError) {
                    console.error("Failed to load platform approver data:", oError);
                }
            });
        },        
        onMarketSenca: function (oEvent) {
            var oSelectedItem = oEvent.getParameter("selectedItem");
            if (!oSelectedItem) return;
            var sPlatformDesc = oSelectedItem.getKey();
            this._platformDataVisiblity(sPlatformDesc);
            // var aAllData = this.getView().getModel("Platformsdataadpd").getProperty("/results");
            
            // var aFilteredPlatform = aAllData.filter(item => item.PlatformDesc === sPlatformDesc);
            // if (aFilteredPlatform.length === 0) return;
            
            // var oRoleData = {
            //     CPH: [], PEH: [], PPM: [], PNH: [], PPH: [],
            //     PFH: [], Finance: [], SR_GM: [], SR_VP: []
            // };
        
            // aFilteredPlatform.forEach(function (entry) {
            //     switch (entry.Role) {
            //         case "AP_CPH": oRoleData.CPH.push(entry.UserId); break;
            //         case "AP_PEH": oRoleData.PEH.push(entry.UserId); break;
            //         case "AP_PPM": oRoleData.PPM.push(entry.UserId); break;
            //         case "AP_PMH": oRoleData.PNH.push(entry.UserId); break;
            //         case "AP_PPH": oRoleData.PPH.push(entry.UserId); break;
            //         case "AP_PFH": oRoleData.PFH.push(entry.UserId); break;
            //         case "AP_FM": oRoleData.Finance.push(entry.UserId); break;
            //         case "AP_SR_GM": oRoleData.SR_GM.push(entry.UserId); break;
            //         case "AP_SR_VP": oRoleData.SR_VP.push(entry.UserId); break;
            //     }
            // });
        
            // this.getView().setModel(new sap.ui.model.json.JSONModel(oRoleData), "RoleUsersModel");
        
            // var aRoleMap = [
            //     { role: "CPH", label: "AdpdCphText", combo: "AdpdCphInput" },
            //     { role: "PEH", label: "AdpdPehText", combo: "AdpdPehInput" },
            //     { role: "PPM", label: "AdpdPpmText", combo: "AdpdPpmInput" },
            //     { role: "PNH", label: "AdpdPnhText", combo: "AdpdPnhInput" },
            //     { role: "PPH", label: "AdpdPphText", combo: "AdpdPphInput" },
            //     { role: "PFH", label: "AdpdPfhText", combo: "AdpdPfhInput" },
            //     { role: "Finance", label: "AdpdFinanceText", combo: "AdpdFinanceInput" },
            //     { role: "SR_GM", label: "AdpdRoleGrid3GmColLab", combo: "AdpdSrGmCombo" },
            //     { role: "SR_VP", label: "AdpdRoleGrid3VpColLab", combo: "AdpdSrVpCombo" }
            // ];
        
            // aRoleMap.forEach(function (o) {
            //     var alwaysVisibleRoles = ["Finance"];
            //     var bVisible = alwaysVisibleRoles.includes(o.role) ||
            //         (Array.isArray(oRoleData[o.role]) && oRoleData[o.role].length > 0);
        
            //     var oLabel = this.getView().byId(o.label);
            //     var oCombo = this.getView().byId(o.combo);
        
            //     if (oLabel) oLabel.setVisible(bVisible);
            //     if (oCombo) oCombo.setVisible(bVisible);
        
            //     if (bVisible && oCombo) {
            //         oCombo.setModel(new sap.ui.model.json.JSONModel(oRoleData[o.role]), "comboModel");
            //     }
            // }.bind(this));
        },
                      

        onTransferTypeDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();

            oModelV2.read("/ControlValues", {
                urlParameters: { "$filter": "category eq 'TransferType'" },
                success: function (oData) {
                    if (oData && oData.results) {
                        oView.setModel(new JSONModel({ results: oData.results }), "Tansfertypeadpd");
                    }
                },
                error: function (oError) {
                    MessageToast.show(oBundle.getText("msgFailedTransferTypeData"));
                    console.error("TransferType load error:", oError);
                }
            });
        },

        onNaturofExpensiveDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();

            oModelV2.read("/ControlValues", {
                urlParameters: { "$filter": "category eq 'NatureOfExpense'" },
                success: function (oData) {
                    if (oData && oData.results) {
                        oView.setModel(new JSONModel({ results: oData.results }), "NatureOfExpenseadpd");
                    }
                },
                error: function (oError) {
                    MessageToast.show(oBundle.getText("msgFailedNatureOfExpenseData"));
                    console.error("NatureOfExpense load error:", oError);
                }
            });
        },

        onFromWBSCodeDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();

            oModelV2.read("/ControlValues", {
                urlParameters: { "$filter": "category eq 'FromWBSCode'" },
                success: function (oData) {
                    if (oData && oData.results) {
                        oView.setModel(new JSONModel({ results: oData.results }), "FromWBSCodeModel");
                    }
                },
                error: function (oError) {
                    MessageToast.show(oBundle.getText("msgFailedFromWBSCodeData"));
                    console.error("FromWBSCode load error:", oError);
                }
            });
        },

        onToWBSCodeDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();

            oModelV2.read("/ControlValues", {
                urlParameters: { "$filter": "category eq 'ToWBSCode'" },
                success: function (oData) {
                    if (oData && oData.results) {
                        oView.setModel(new JSONModel({ results: oData.results }), "ToWBSCodeModel");
                    }
                },
                error: function (oError) {
                    MessageToast.show(oBundle.getText("msgFailedToWBSCodeData"));
                    console.error("ToWBSCode load error:", oError);
                }
            });
        },

        onFromWBSLevelDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();

            oModelV2.read("/ControlValues", {
                urlParameters: { "$filter": "category eq 'FromWBSLevel'" },
                success: function (oData) {
                    if (oData && oData.results) {
                        oView.setModel(new JSONModel({ results: oData.results }), "FromWBSLevelModel");
                    }
                },
                error: function (oError) {
                    MessageToast.show(oBundle.getText("msgFailedFromWBSLevelData"));
                    console.error("FromWBSLevel load error:", oError);
                }
            });
        },

        onToWBSLevelDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();

            oModelV2.read("/ControlValues", {
                urlParameters: { "$filter": "category eq 'ToWBSLevel'" },
                success: function (oData) {
                    if (oData && oData.results) {
                        oView.setModel(new JSONModel({ results: oData.results }), "ToWBSLevelModel");
                    }
                },
                error: function (oError) {
                    MessageToast.show(oBundle.getText("msgFailedToWBSLevelData"));
                    console.error("ToWBSLevel load error:", oError);
                }
            });
        },

        onFromWBSLocDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();

            oModelV2.read("/ControlValues", {
                urlParameters: { "$filter": "category eq 'FromWBSLoc'" },
                success: function (oData) {
                    if (oData && oData.results) {
                        oView.setModel(new JSONModel({ results: oData.results }), "FromWBSLocModel");
                    }
                },
                error: function (oError) {
                    //MessageToast.show(oBundle.getText("msgFailedFromWBSLocData"));
                    console.error("FromWBSLoc load error:", oError);
                }
            });
        },

        onCancel: function () {
            var Approved = this._ApprovedCheck;
            if (Approved === "Approved") {
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("approverdashboard", {

                });
            } else {
                var Name = this._adpdNameUI;
                //if (Name === "ADPD") {
                this._resetCompleteForm();
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("DashboardUI", {
                    Name: "ADPD"
                });

            }

        },
        onNavBack: function () {
            var Approved = this._ApprovedCheck;
            var materialcostData = this.getView().getModel("materialcostData");
            materialcostData.setProperty("/matcostDtl") || [];
            var FinancialModel = this.getView().getModel("FinancialModel");
            FinancialModel.setProperty("/rows") || [];
            var wbsModel = this.getView().getModel("wbsModel");
            wbsModel.setProperty("/rows") || [];

            if (Approved === "Approved") {

                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("approverdashboard", {

                });
            } else {
                var Name = this._adpdNameUI;
                //if (Name === "ADPD") {
                this._resetCompleteForm();
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("DashboardUI", {
                    Name: "ADPD"
                });
            }


        },

        onToWBSLocDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();

            oModelV2.read("/ControlValues", {
                urlParameters: { "$filter": "category eq 'ToWBSLoc'" },
                success: function (oData) {
                    if (oData && oData.results) {
                        oView.setModel(new JSONModel({ results: oData.results }), "ToWBSLocModel");
                    }
                },
                error: function (oError) {
                    MessageToast.show(oBundle.getText("msgFailedToWBSLocData"));
                    console.error("ToWBSLoc load error:", oError);
                }
            });
        },

        onProjectSelectionChange: function (oEvent) {
            var oComboBox = oEvent.getSource();
            var sSelectedKey = oComboBox.getSelectedKey();
            var oView = this.getView();
            var oModel = oView.getModel("ADPDProjModel");
            var aData = oModel.getProperty("/results");
            var oBundle = this.getResourceBundle();

            var sDescription = "";
            if (aData && aData.length > 0) {
                var oSelectedItem = aData.find(function (item) {
                    return item.Id === sSelectedKey;
                });
                if (oSelectedItem) {
                    sDescription = oSelectedItem.description || "";
                }
            }

            oView.byId("AdpdProjectDescInp").setValue(sDescription);
            // this.validateComboBoxValue();
            // MessageToast.show(oBundle.getText("msgSelected", [sSelectedKey]));
        },

        onMarketSelectionChange: function (oEvent) {
            var sSelectedKey = oEvent.getSource().getSelectedKey();
            var oBundle = this.getResourceBundle();
            MessageToast.show(oBundle.getText("msgSelected", [sSelectedKey]));
        },

        validateComboBoxValue: function (oComboBox, sFieldLabel) {
            var sEnteredValue = oComboBox.getValue();
            var aItems = oComboBox.getItems();
            var bIsValid = aItems.some(function (item) {
                return item.getText() === sEnteredValue || item.getKey() === sEnteredValue;
            });

            if (!bIsValid && sEnteredValue !== "") {
                oComboBox.setValueState(sap.ui.core.ValueState.Error);
                oComboBox.setValueStateText("Please select a valid " + sFieldLabel + " from the list.");
            } else {
                oComboBox.setValueState(sap.ui.core.ValueState.None);
            }
        },

        onSuggestToWbsCode: function (oEvent) {
            let sValue = oEvent.getParameter("suggestValue");
            let oInput = oEvent.getSource();
            let oBinding = oInput.getBinding("suggestionItems");

            if (!oBinding) {
                return;
            }

            if (!sValue || sValue.length === 0) {

                oBinding.filter([]);
                return;
            }

            let oFilter = new sap.ui.model.Filter({
                path: "description",
                operator: sap.ui.model.FilterOperator.Contains,
                value1: sValue,
                caseSensitive: false
            });

            oBinding.filter([oFilter]);
        },

        onSuggest: function (oEvent) {
            let sValue = oEvent.getParameter("suggestValue");
            let oInput = oEvent.getSource();
            let oBinding = oInput.getBinding("suggestionItems");

            if (!oBinding) {
                return;
            }

            if (!sValue || sValue.length === 0) {
                oBinding.filter([]);
                return;
            }

            let oFilter = new sap.ui.model.Filter({
                path: "description",
                operator: sap.ui.model.FilterOperator.Contains,
                value1: sValue,
                caseSensitive: false
            });

            oBinding.filter([oFilter]);
        },

        onDashboardui: function () {
            var oBundle = this.getResourceBundle();
            if (this._adpdNameUI === sType) {
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("DashboardUI", { Name: "ADPD" });
            } else {
                oRouter.navTo("Cordys_DashboardUi");
            }
            MessageToast.show(oBundle.getText("msgNavToDashboard"));
        },


        onFromWBSCodeDataFetchCB: function () {
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            oModelV2.read("/ControlValues", {
                urlParameters: { "$filter": "category eq 'FromWBSCode'" },
                success: function (oData) {
                    if (oData?.results) {
                        var oFormModel = this.getView().getModel("formModel");
                        oFormModel.setProperty("/wbsCodes", oData.results.map(item => ({
                            key: item.Id,
                            text: item.description
                        })));
                    }
                }.bind(this),
                error: function () {
                    MessageToast.show("Failed to load WBS Code data.");
                }
            });
        },

        onFromWBSLevelDataFetchCB: function () {
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            oModelV2.read("/ControlValues", {
                urlParameters: { "$filter": "category eq 'FromWBSLevel'" },
                success: function (oData) {
                    if (oData?.results) {
                        var oFormModel = this.getView().getModel("formModel");
                        oFormModel.setProperty("/wbsLevels", oData.results.map(item => ({
                            key: item.Id,
                            text: item.description
                        })));
                    }
                }.bind(this),
                error: function () {
                    MessageToast.show("Failed to load WBS Level data.");
                }
            });
        },

        onFromWBSLocDataFetchCB: function () {
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            oModelV2.read("/ControlValues", {
                urlParameters: { "$filter": "category eq 'FromWBSLoc'" },
                success: function (oData) {
                    if (oData?.results) {
                        var oFormModel = this.getView().getModel("formModel");
                        oFormModel.setProperty("/wbsLocations", oData.results.map(item => ({
                            key: item.Id,
                            text: item.description
                        })));
                    }
                }.bind(this),
                error: function () {
                    MessageToast.show("Failed to load WBS Location data.");
                }
            });
        },

        onAddWBSRow: function () {
            this.onFromWBSCodeDataFetch();
            this.onToWBSCodeDataFetch();
            this.onToWBSLevelDataFetch();
            this.onFromWBSLevelDataFetch();
            this.onFromWBSLocDataFetch();
            this.onToWBSLocDataFetch();
            var oFormModel = this.getView().getModel("WbsformDataBinding");
            oFormModel.setProperty("/capexNRT", "");
            oFormModel.setProperty("/capexLanded", "");
            oFormModel.setProperty("/revenueNRT", "");
            oFormModel.setProperty("/revenueLanded", "");
            oFormModel.setProperty("/remarks", "");

            this.addFragment.open();
        },
        onFromWBSCodeDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

            oModelV2.read("/ControlValues", {
                urlParameters: {

                    "$filter": "category eq '" + "FromWBSCode" + "'"
                },
                success: function (oData) {
                    if (oData && oData.results) {
                        var oJSONModel = new sap.ui.model.json.JSONModel({ results: oData.results });
                        oView.setModel(oJSONModel, "FormWBSCodeModel");
                    }
                },
                error: function (oError) {
                    sap.m.MessageToast.show("Failed to load FromWBSCode data.");
                    console.error("FromWBSCode load error:", oError);
                }
            });
        },
        onSuggestionItemSelectedFromWbsCode: function (oEvent) {
            var oSelectedItem = oEvent.getParameter("selectedItem");
            if (oSelectedItem) {
                var sSelectedKey = oSelectedItem.getKey();
                var oFormModel = this.getView().getModel("formModel");

                oFormModel.setProperty("/fromWbsCode", sSelectedKey);
            }
        },
        onToWBSCodeDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

            oModelV2.read("/ControlValues", {
                urlParameters: {
                    "$filter": "category eq 'ToWBSCode'"
                },
                success: function (oData) {
                    if (oData && oData.results) {
                        var oJSONModel = new sap.ui.model.json.JSONModel({ results: oData.results });
                        oView.setModel(oJSONModel, "ToWBSCodeModel");
                    }
                },
                error: function (oError) {
                    sap.m.MessageToast.show("Failed to load ToWBSCode data.");
                    console.error("ToWBSCode load error:", oError);
                }
            });
        },


        onFromWBSLevelDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

            oModelV2.read("/ControlValues", {
                urlParameters: {
                    "$filter": "category eq 'FromWBSLevel'"
                },
                success: function (oData) {
                    if (oData && oData.results) {
                        var oJSONModel = new sap.ui.model.json.JSONModel({ results: oData.results });
                        oView.setModel(oJSONModel, "FromWBSLevelModel");
                    }
                },
                error: function (oError) {
                    sap.m.MessageToast.show("Failed to load FromWBSLevel data.");
                    console.error("FromWBSLevel load error:", oError);
                }
            });
        },

        onFromWBSLocDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

            oModelV2.read("/ControlValues", {
                urlParameters: {
                    "$filter": "category eq 'FromWBSLoc'"
                },
                success: function (oData) {
                    if (oData && oData.results) {
                        var oJSONModel = new sap.ui.model.json.JSONModel({ results: oData.results });
                        oView.setModel(oJSONModel, "FromWBSLocModel");
                    }
                },
                error: function (oError) {
                    sap.m.MessageToast.show("Failed to load FromWBSLoc data.");
                    console.error("FromWBSLoc load error:", oError);
                }
            });
        },
        onToWBSLocDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

            oModelV2.read("/ControlValues", {
                urlParameters: {
                    "$filter": "category eq 'ToWBSLoc'"
                },
                success: function (oData) {
                    if (oData && oData.results) {
                        var oJSONModel = new sap.ui.model.json.JSONModel({ results: oData.results });
                        oView.setModel(oJSONModel, "ToWBSLocModel");
                    }
                },
                error: function (oError) {
                    sap.m.MessageToast.show("Failed to load ToWBSLoc data.");
                    console.error("ToWBSLoc load error:", oError);
                }
            });
        },


        onToWBSLevelDataFetch: function () {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

            oModelV2.read("/ControlValues", {
                urlParameters: {
                    "$filter": "category eq 'ToWBSLevel'"
                },
                success: function (oData) {
                    if (oData && oData.results) {
                        var oJSONModel = new sap.ui.model.json.JSONModel({ results: oData.results });
                        oView.setModel(oJSONModel, "ToWBSLevelModel");
                    }
                },
                error: function (oError) {
                    sap.m.MessageToast.show("Failed to load ToWBSLevel data.");
                    console.error("ToWBSLevel load error:", oError);
                }
            });
        },

        onDashboardui: function () {
            var Name = this._adpdNameUI;
            if (Name === "ADPD") {
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("DashboardUI", {
                    Name: "ADPD"
                });
            }
        },

        onCreateWBSRow: function () {
            var oFormModel = this.getView().getModel("WbsformDataBinding");
            var oWbsModel = this.getView().getModel("wbsModel");

            var sFromWbsCode = sap.ui.getCore().byId("inpFromWbsCode")?.getValue() || "";
            var sFromWbsLevel = sap.ui.getCore().byId("inpFromWbsLevel")?.getSelectedKey() || "";
            var sFromWbsLoc = sap.ui.getCore().byId("inpFromWbsLoc")?.getSelectedKey() || "";
            var sToWbsCode = sap.ui.getCore().byId("inpToWbsCode")?.getValue() || "";
            var sToWbsLevel = sap.ui.getCore().byId("inpToWbsLevel")?.getSelectedKey() || "";
            var sToWbsLoc = sap.ui.getCore().byId("inpToWbsLoc")?.getSelectedKey() || "";

            var capexNrt = parseFloat(oFormModel.getProperty("/capexNRT")) || "";
            var capexLanded = parseFloat(oFormModel.getProperty("/capexLanded")) || "";
            var revenueNrt = parseFloat(oFormModel.getProperty("/revenueNRT")) || "";
            var revenueLanded = parseFloat(oFormModel.getProperty("/revenueLanded")) || "";
            var oFormModel = this.getView().getModel("WbsformDataBinding");
            var remarksData = oFormModel.getProperty("/remarks") || ""
            oFormModel.setProperty("/capexNRT", "");
            oFormModel.setProperty("/capexLanded", "");
            oFormModel.setProperty("/revenueNRT", "");
            oFormModel.setProperty("/revenueLanded", "");
            oFormModel.setProperty("/remarks", "");
            var stotalNrt = capexNrt + revenueNrt;
            var stotalLanded = capexLanded + revenueLanded;

            var oNewRow = {
                fromWBSCode: sFromWbsCode,
                fromWBSLevel: sFromWbsLevel,
                fromWBSLoc: sFromWbsLoc,
                toWBSCode: sToWbsCode,
                toWBSLevel: sToWbsLevel,
                toWBSLoc: sToWbsLoc,
                capexNRT: capexNrt,
                capexLanded: capexLanded,
                revenueNRT: revenueNrt,
                revenueLanded: revenueLanded,
                totalNRT: stotalNrt,
                totalLanded: stotalLanded,
                remarks: remarksData
            };

            if (!oNewRow.fromWBSCode || !oNewRow.toWBSCode) {
                sap.m.MessageToast.show("From and To WBS Code are required.");
                return;
            }

            var aNumericFields = ["capexNRT", "capexLanded", "revenueNRT", "revenueLanded"];
            for (var field of aNumericFields) {
                if (isNaN(oNewRow[field])) {
                    sap.m.MessageToast.show(`Invalid value for ${field}. Please enter a valid number.`);
                    return;
                }
            }

            var aRows = oWbsModel.getProperty("/rows") || [];
            aRows.push(oNewRow);
            oWbsModel.setProperty("/rows", aRows);
            this._resetWBSForm();
            this.calculateWbsTotals();

            if (this.addFragment) {
                this.addFragment.close();
            }

            sap.m.MessageToast.show("WBS Row added successfully.");
        },

        calculateWbsTotals: function () {
            var oModel = this.getView().getModel("wbsModel");
            var aRows = oModel.getProperty("/rows") || [];
        
            var totalNRT = 0;
            var totalLanded = 0;
        
            aRows.forEach(function (row) {
                totalNRT += Number(row.totalNRT || "");
                totalLanded += Number(row.totalLanded || "");
            });
            var oTotalsModel = new sap.ui.model.json.JSONModel({
                totalNRT: totalNRT,
                totalLanded: totalLanded
            });
            var sTotalText = "Total NRT (" + totalNRT + " Lacs), Total Landed (" + totalLanded + " Lacs)";
            this.byId("totalText").setText("Total (In Lacs) -");
            this.byId("NrtTotaldata").setText("NRT: " + totalNRT);
            this.byId("landedtotalData").setText("Landed: " + totalLanded);      
          },
          PreProjectInvestment: function () {
            var oModel = this.getView().getModel("InvestmentModel");
            var aRows = oModel.getProperty("/investmentData") || [];
        
            var capex = 0;
            var revenue = 0;
            var total = 0;

            aRows.forEach(function (row) {
                capex += Number(row.capex || "");
                revenue += Number(row.revenue || "");
                total += Number(row.total || "");

            });
            var oTotalsModel = new sap.ui.model.json.JSONModel({
                capex: capex,
                revenue: revenue,
                total: total
            });
            this.byId("PreProject_text").setText("Total (In Lacs) -");
            this.byId("PreProject_Capex").setText("Capex: " + capex);
            this.byId("PreProject_revenue").setText("Revenue: " + revenue); 
            this.byId("PreProject_totaldata").setText("Total:  " + total);      
     
          },
          calculateParkCon: function () {
            var oModel = this.getView().getModel("contBalanceModel");
            var aRows = oModel.getProperty("/modelData") || [];
        
            var priorBalance = 0;
            var transfAmountCurrApproval = 0;
            var balancePostTransfer = 0;

            aRows.forEach(function (row) {
                priorBalance += Number(row.priorBalance || "");
                transfAmountCurrApproval += Number(row.transfAmountCurrApproval || "");
                balancePostTransfer += Number(row.balancePostTransfer || "");

            });
            var oTotalsModel = new sap.ui.model.json.JSONModel({
                priorBalance: priorBalance,
                transfAmountCurrApproval: transfAmountCurrApproval,
                balancePostTransfer: balancePostTransfer
            });
            this.byId("totalTextCOnPark").setText("Total (In Lacs) -");
            this.byId("BalanacePriorAmou").setText("Balanace Prior to this transfer: " + priorBalance);
            this.byId("Amounttotransf").setText("Amount to be transferred in the current Approval: " + transfAmountCurrApproval); 
            this.byId("balanceposttrans").setText("Balance post this transfer:  " + balancePostTransfer);      
     
          },
          calculateWbsTotalsCont: function () {
            var oModel = this.getView().getModel("wbsModel");
            var aRows = oModel.getProperty("/rows") || [];
        
            var totalNRT = 0;
            var totalLanded = 0;
        
            aRows.forEach(function (row) {
                totalNRT += Number(row.totalNRT || "");
                totalLanded += Number(row.totalLanded || "0");
            });
            var oTotalsModel = new sap.ui.model.json.JSONModel({
                totalNRT: totalNRT,
                totalLanded: totalLanded
            });
            var sTotalText = "Total NRT (" + totalNRT + " Lacs), Total Landed (" + totalLanded + " Lacs)";
            this.byId("totalTextCont").setText("Total (In Lacs) -");
            this.byId("NrtTotaldataCont").setText("NRT: " + totalNRT);
            this.byId("landedtotalDataCont").setText("Landed: " + totalLanded);      
          },

        onCancelWBSForm: function () {
            var materialcostData = this.getView().getModel("materialcostData");
            materialcostData.setProperty("/matcostDtl") || [];
            var FinancialModel = this.getView().getModel("FinancialModel");
            FinancialModel.setProperty("/rows") || [];
            var wbsModel = this.getView().getModel("wbsModel");
            wbsModel.setProperty("/rows") || [];
            this._resetWBSForm();
            //  var oDialog = sap.ui.getCore().byId("wbsFormDialog");
            if (this.addFragment) {
                this.addFragment.close();
            }
        },
        deleteBtnWBSTableSelect: function (oEvent) {
            var oModel = this.getView().getModel("wbsModel");
            var oServiceModel = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();
            var oContext = oEvent.getSource().getBindingContext("wbsModel");
            var sPath = oContext.getPath();
            var that = this;
            var aRows = oModel.getProperty("/rows");
            var iIndex = parseInt(sPath.split("/").pop(), 10);
            var oDeletedItem = aRows[iIndex];
            MessageBox.confirm("Are you sure you want to delete this row?", {
                onClose: function (sAction) {
                    if (sAction === MessageBox.Action.OK) {
                        if (oDeletedItem.__metadata && oDeletedItem.__metadata.uri) {
                            var oUri = new URL(oDeletedItem.__metadata.uri);
                            var sRelativePath = oUri.pathname.replace("/odata/v2/approval-hub", "");
                            oServiceModel.remove(sRelativePath, {
                                success: function () {
                                    aRows.splice(iIndex, 1);
                                    oModel.setProperty("/rows", aRows);
                                    MessageToast.show("Row deleted successfully.");
                                    that.calculateWbsTotals();    
                                },
                                error: function (oError) {
                                    console.error("Delete error:", oError);
                                    MessageToast.show("Failed to delete from service.");
                                }
                            });
                        } else {
                            aRows.splice(iIndex, 1);
                            oModel.setProperty("/rows", aRows);
                            MessageToast.show("Row deleted successfully .");
                            that.calculateWbsTotals();  
                        }
                    }
                }
            });
            
        },        

        handleLiveChange: function (oEvent) {
            var oTextArea = oEvent.getSource(),
                iValueLength = oTextArea.getValue().length,
                iMaxLength = oTextArea.getMaxLength(),
                sState = iValueLength > iMaxLength ? ValueState.Warning : ValueState.None;

            oTextArea.setValueState(sState);
        },

        onComboBoxChange: function(oEvent) {
            var oComboBox = oEvent.getSource();
            var sValue = oEvent.getParameter("newValue") || oComboBox.getValue();
            var aItems = oComboBox.getItems();
            var bValid = aItems.some(function(oItem) {
                return oItem.getKey() === sValue || oItem.getText() === sValue;
            });

            oComboBox.setValueState(bValid ? "None" : "Error");
            if (!bValid) {
                // MessageToast.show("Please select a valid option from the dropdown.", { position: "bottom center" });
            }
        },
        onNumberInputLiveChange: function (oEvent) {
            var oInput = oEvent.getSource();
            var sValue = oEvent.getParameter("value");

            var sFiltered = sValue.replace(/[^\d]/g, "");
            if (sFiltered !== sValue) {
                oInput.setValue(sFiltered);
            }
        },

        getResourceBundle: function () {
            return this.getOwnerComponent().getModel("i18n").getResourceBundle();
        },
        onEditWBSRow: function (oEvent) {
            const oContext = oEvent.getSource().getBindingContext("wbsModel");
            const oSelectedRow = oContext.getObject();
            const sPath = oContext.getPath();
            const oFormModel = this.getView().getModel("WbsformDataBinding");
            this.onFromWBSLevelDataFetch();
            this.onFromWBSLocDataFetch();
            this.onToWBSLocDataFetch();
            this.onToWBSCodeDataFetch();
            this.onToWBSLevelDataFetch();
            oFormModel.setData({
                fromWBSCode: oSelectedRow.fromWBSCode || "",
                fromWBSLevel: oSelectedRow.fromWBSLevel || "",
                fromWBSLoc: oSelectedRow.fromWBSLoc || "",
                toWBSCode: oSelectedRow.toWBSCode || "",
                toWBSLevel: oSelectedRow.toWBSLevel || "",
                toWBSLoc: oSelectedRow.toWBSLoc || "",
                capexNRT: oSelectedRow.capexNRT?.toString() || "",
                capexLanded: oSelectedRow.capexLanded?.toString() || "",
                revenueNRT: oSelectedRow.revenueNRT?.toString() || "",
                revenueLanded: oSelectedRow.revenueLanded?.toString() || "",
                totalNRT: oSelectedRow.totalNRT?.toString() || "",
                totalLanded: oSelectedRow.totalLanded?.toString() || "",
                remarks: oSelectedRow.remarks || "",
                _rowPath: sPath
            });

            if (!this._oWbsFormDialog) {
                this._oWbsFormDialog = sap.ui.getCore().byId("wbsFormDialog1");
                if (!this._oWbsFormDialog) {
                    //sap.m.MessageToast.show("Dialog not found.");
                    return;
                }
            }

            this._oWbsFormDialog.setTitle("Edit WBS Entry");

            const oBeginButton = this._oWbsFormDialog.getBeginButton();
            if (oBeginButton) {
                oBeginButton.destroy();
            }

            const oUpdateBtn = new sap.m.Button({
                id: "btnUpdateWBS",
                text: "Update",
                type: "Accept",
                press: this.onUpdateWBSRow.bind(this)
            });
            this._oWbsFormDialog.setBeginButton(oUpdateBtn);
            this._oWbsFormDialog.open();
        },

        onUpdateWBSRow: function () {
            var oFormModel = this.getView().getModel("WbsformDataBinding");
            var oWbsModel = this.getView().getModel("wbsModel");

            var sRowPath = oFormModel.getProperty("/_rowPath");
            if (!sRowPath) {
                sap.m.MessageToast.show("No row selected for update.");
                return;
            }

            var capexNrt = parseFloat(oFormModel.getProperty("/capexNRT")) || "";
            var capexLanded = parseFloat(oFormModel.getProperty("/capexLanded")) || "";
            var revenueNrt = parseFloat(oFormModel.getProperty("/revenueNRT")) || "";
            var revenueLanded = parseFloat(oFormModel.getProperty("/revenueLanded")) || "";
            var totalNrt = capexNrt + revenueNrt;
            var totalLanded = capexLanded + revenueLanded;

            var oUpdatedRow = {
                fromWBSCode: sap.ui.getCore().byId("inpFromWbsCode")?.getValue() || "",
                fromWBSLevel: sap.ui.getCore().byId("inpFromWbsLevel")?.getSelectedKey() || "",
                fromWBSLoc: sap.ui.getCore().byId("inpFromWbsLoc")?.getSelectedKey() || "",
                toWBSCode: sap.ui.getCore().byId("inpToWbsCode")?.getValue() || "",
                toWBSLevel: sap.ui.getCore().byId("inpToWbsLevel")?.getSelectedKey() || "",
                toWBSLoc: sap.ui.getCore().byId("inpToWbsLoc")?.getSelectedKey() || "",
                capexNRT: capexNrt,
                capexLanded: capexLanded,
                revenueNRT: revenueNrt,
                revenueLanded: revenueLanded,
                totalNRT: totalNrt,
                totalLanded: totalLanded,
                remarks: oFormModel.getProperty("/remarks")?.trim() || ""
            };

            if (!oUpdatedRow.fromWBSCode || !oUpdatedRow.toWBSCode) {
                sap.m.MessageToast.show("Please enter both From WBS Code and To WBS Code.");
                return;
            }

            var aNumericFields = ["capexNRT", "capexLanded", "revenueNRT", "revenueLanded"];
            for (var field of aNumericFields) {
                if (isNaN(oUpdatedRow[field])) {
                    sap.m.MessageToast.show(`Invalid value for ${field}. Please enter a valid number.`);
                    return;
                }
            }

            oWbsModel.setProperty(sRowPath, oUpdatedRow);
            this._resetWBSForm();
            if (this._oWbsFormDialog) {
                this._oWbsFormDialog.close();
            }

            sap.m.MessageToast.show("Row Updated Successfully.");
        },

        onResetWBSDialog: function () {
            if (!this._oWbsFormDialog) {
                this._oWbsFormDialog = sap.ui.getCore().byId("wbsFormDialog");
                if (!this._oWbsFormDialog) {
                    //  sap.m.MessageToast.show("Dialog not found.");
                    return;
                }
            }

            this._oWbsFormDialog.setTitle("Add WBS Entry");
            const oCurrentBtn = this._oWbsFormDialog.getBeginButton();
            if (oCurrentBtn) {
                oCurrentBtn.destroy();
            }

            const oAddBtn = new sap.m.Button({
                id: "btnAddWBS",
                text: "Add",
                type: "Accept",
                press: this.onCreateWBSRow.bind(this)
            });
            this._oWbsFormDialog.setBeginButton(oAddBtn);

            const oCancelBtn = this._oWbsFormDialog.getEndButton();
            if (oCancelBtn) {
                oCancelBtn.setText("Cancel");
                oCancelBtn.detachPress();
                oCancelBtn.attachPress(() => this._oWbsFormDialog.close());
            }

            this._resetWBSForm();
        },
        _resetWBSForm: function () {

            const oFormModel = this.getView().getModel("formModel");
            if (oFormModel) {
                oFormModel.setData({
                    fromWbsCode: "",
                    fromWbsLevel: "",
                    fromWbsLocation: "",
                    toWbsCode: "",
                    toWbsLevel: "",
                    toWbsLocation: "",
                    capexNrt: 0,
                    capexLanded: 0,
                    revenueNrt: 0,
                    revenueLanded: 0,
                    totalNrt: 0,
                    totalLanded: 0,
                    remarks: "",
                    _rowPath: null,
                });
            }

            const aComboBoxIds = [
                "inpFromWbsCode",
                "inpFromWbsLevel",
                "inpFromWbsLoc",
                "inpToWbsCode",
                "inpToWbsLevel",
                "inpToWbsLoc"
            ];
            aComboBoxIds.forEach(id => {
                const oComboBox = sap.ui.getCore().byId(id);
                if (oComboBox) {
                    oComboBox.setSelectedKey("");
                }
            });
        },


        onAddWBSRowCB: function () {
            this.onFromWBSCodeDataFetchCB();
            this.onFromWBSLevelDataFetchCB();
            this.onFromWBSLocDataFetchCB();
            this.onToWBSLevelDataFetch();
            this.onFromWBSLocDataFetch();
           

            // this.byId("inpCapexLanded").setValue("")
            this._oWbsFragment.then(function (oDialog) {
                oDialog.setTitle(this.getView().getModel("i18n").getResourceBundle().getText("wbsDialogTitleAdd"));
                oDialog.setBeginButton(new sap.m.Button({
                    id: "",
                    text: this.getView().getModel("i18n").getResourceBundle().getText("wbsActionAddButtonText"),
                    type: "Accept",
                    press: this.onCreateWBSRowCB.bind(this)
                }));
                oDialog.setEndButton(new sap.m.Button({
                    text: this.getView().getModel("i18n").getResourceBundle().getText("cancelButtonText"),
                    press: this.onCancelWBSFormCB.bind(this)
                }));
                this._resetWBSForm();
                var oFormModel = this.getView().getModel("formModel");
                oFormModel.setProperty("/capexNRT", "");
                oFormModel.setProperty("/capexLanded", "");
                oFormModel.setProperty("/revenueNRT", "");
                oFormModel.setProperty("/revenueLanded", "");
                oFormModel.setProperty("/remarks", "");
                oFormModel.setProperty("/totalLanded", "");

                oDialog.open();
            }.bind(this));
        },

        onCreateWBSRowCB: function () {
            this._oWbsFragment.then(function (oDialog) {
                var oFormModel = this.getView().getModel("formModel");
                var oWbsModel = this.getView().getModel("wbsModel");

                var sFromWbsCode = this.byId("inpWbsCode")?.getValue() || "";
                var sFromWbsLevel = this.byId("inpWbsLevel")?.getValue() || "";
                var sFromWbsLoc = this.byId("inpWbsLoc")?.getValue() || "";

                var capexNrt = parseFloat(oFormModel.getProperty("/capexNRT")) || "";
                var capexLanded = parseFloat(oFormModel.getProperty("/capexLanded")) || "";
                var revenueNrt = parseFloat(oFormModel.getProperty("/revenueNRT")) || "";
                var revenueLanded = parseFloat(oFormModel.getProperty("/revenueLanded")) || "";

                var stotalNrt = capexNrt + revenueNrt;
                var stotalLanded = capexLanded + revenueLanded;

                var oNewRow = {
                    fromWBSCode: sFromWbsCode,
                    fromWBSLevel: sFromWbsLevel,
                    fromWBSLoc: sFromWbsLoc,
                    capexNRT: capexNrt,
                    capexLanded: capexLanded,
                    revenueNRT: revenueNrt,
                    revenueLanded: revenueLanded,
                    totalNRT: stotalNrt,
                    totalLanded: stotalLanded,

                    remarks: oFormModel.getProperty("/remarks")?.trim() || ""
                };

                if (!oNewRow.fromWBSCode) {
                    MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("wbsCodeRequired"));
                    return;
                }

                var aNumericFields = ["capexNRT", "capexLanded"];
                for (var field of aNumericFields) {
                    if (isNaN(oNewRow[field])) {
                        MessageToast.show(`Invalid value for ${field}. Please enter a valid number.`);
                        return;
                    }
                }

                var aRows = oWbsModel.getProperty("/rows") || [];
                oWbsModel.setProperty("/rows", [...aRows, oNewRow]);
                this.calculateWbsTotalsCont();
                //this._resetWBSForm();
                oDialog.close();
                MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("wbsAdded"));
            }.bind(this));
        },

        onEditWBSRowCB: function (oEvent) {
            this.onToWBSLevelDataFetch();
            this.onFromWBSLocDataFetch();
            var oContext = oEvent.getSource().getBindingContext("wbsModel");
            var oSelectedRow = oContext.getObject();
            var sPath = oContext.getPath();
            var oFormModel = this.getView().getModel("formModel");
            this.onFromWBSLevelDataFetch();
            this.onFromWBSLocDataFetch();
            this.onToWBSLocDataFetch();
            this.onToWBSCodeDataFetch();
            this.onToWBSLevelDataFetch();
            oFormModel.setData({
                fromWBSCode: oSelectedRow.fromWBSCode || "",
                fromWBSLevel: oSelectedRow.fromWBSLevel || "",
                fromWBSLoc: oSelectedRow.fromWBSLoc || "",
                capexNRT: oSelectedRow.capexNRT?.toString() || "",
                capexLanded: oSelectedRow.capexLanded?.toString() || "",
                revenueNRT: oSelectedRow.revenueNRT?.toString() || "",
                revenueLanded: oSelectedRow.revenueLanded?.toString() || "",
                totalNRT: oSelectedRow.totalNRT?.toString() || "",
                totalLanded: oSelectedRow.totalLanded?.toString() || "",
                remarks: oSelectedRow.remarks || "",
                _rowPath: sPath,
                wbsCodes: oFormModel.getProperty("/wbsCodes"),
                wbsLevels: oFormModel.getProperty("/wbsLevels"),
                wbsLocations: oFormModel.getProperty("/wbsLocations")
            });

            this._oWbsFragment.then(function (oDialog) {
                oDialog.setTitle(this.getView().getModel("i18n").getResourceBundle().getText("wbsDialogTitleEdit"));
                oDialog.setBeginButton(new sap.m.Button({
                    id: "",
                    text: this.getView().getModel("i18n").getResourceBundle().getText("wbsActionEditButtonText"),
                    type: "Accept",
                    press: this.onUpdateWBSRowCB.bind(this)
                }));
                oDialog.setEndButton(new sap.m.Button({
                    text: this.getView().getModel("i18n").getResourceBundle().getText("cancelButtonText"),
                    press: this.onCancelWBSFormCB.bind(this)
                }));
                oDialog.open();
            }.bind(this));
        },
        onCopyContingencyBalanceRow: function (oEvent) {
            var oContext = oEvent.getSource().getBindingContext("contBalanceModel");
            var oData = Object.assign({}, oContext.getObject());
            var oModel = this.getView().getModel("contBalanceModel");
            var aData = oModel.getProperty("/modelData");
            var oBundle = this.getResourceBundle();
            aData.push(oData);
            oModel.setProperty("/modelData", aData);
            MessageToast.show(oBundle.getText("Row Copied"));
            this.calculateParkCon();
        },

        onCopyWBSRowCB: function (oEvent) {
            var oContext = oEvent.getSource().getBindingContext("wbsModel");
            var oData = Object.assign({}, oContext.getObject());
            var oModel = this.getView().getModel("wbsModel");
            var aData = oModel.getProperty("/rows");
            var oBundle = this.getResourceBundle();
            aData.push(oData);
            oModel.setProperty("/rows", aData);
            this.calculateWbsTotalsCont();
            MessageToast.show(oBundle.getText("msgRowCopied"));
        },
        onCopyWBSRow: function (oEvent) {
            var oContext = oEvent.getSource().getBindingContext("wbsModel");
            var oData = Object.assign({}, oContext.getObject());
            var oModel = this.getView().getModel("wbsModel");
            var aData = oModel.getProperty("/rows");
            var oBundle = this.getResourceBundle();
            aData.push(oData);
            oModel.setProperty("/rows", aData);
            MessageToast.show(oBundle.getText("msgRowCopied"));
            this.calculateWbsTotals();    
        },


        onUpdateWBSRowCB: function () {
            this._oWbsFragment.then(function (oDialog) {
                var oFormModel = this.getView().getModel("formModel");
                var oWbsModel = this.getView().getModel("wbsModel");

                var sRowPath = oFormModel.getProperty("/_rowPath");
                if (!sRowPath) {
                    MessageToast.show("No row selected for update.");
                    return;
                }

                var sFromWbsCode = this.byId("inpWbsCode")?.getValue() || "";
                var sFromWbsLevel = this.byId("inpWbsLevel")?.getValue() || "";
                var sFromWbsLoc = this.byId("inpWbsLoc")?.getValue() || "";
                var capexNrt = parseFloat(oFormModel.getProperty("/capexNRT")) || "";
                var capexLanded = parseFloat(oFormModel.getProperty("/capexLanded")) || "";
                var revenueNrt = parseFloat(oFormModel.getProperty("/revenueNRT")) || "";
                var revenueLanded = parseFloat(oFormModel.getProperty("/revenueLanded")) || "";

                var stotalNrt = capexNrt + revenueNrt;
                var stotalLanded = capexLanded + revenueLanded;

                var oUpdatedRow = {
                    fromWBSCode: sFromWbsCode,
                    fromWBSLevel: sFromWbsLevel,
                    fromWBSLoc: sFromWbsLoc,
                    capexNRT: capexNrt,
                    capexLanded: capexLanded,
                    revenueNRT: revenueNrt,
                    revenueLanded: revenueLanded,
                    totalNRT: stotalNrt,
                    totalLanded: stotalLanded,

                    remarks: oFormModel.getProperty("/remarks")?.trim() || ""
                };

                if (!oUpdatedRow.fromWBSCode) {
                    MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("wbsCodeRequired"));
                    return;
                }

                var aNumericFields = ["capexNRT", "capexLanded"];
                for (var field of aNumericFields) {
                    if (isNaN(oUpdatedRow[field])) {
                        MessageToast.show(`Invalid value for ${field}. Please enter a valid number.`);
                        return;
                    }
                }

                oWbsModel.setProperty(sRowPath, oUpdatedRow);
                // this._resetWBSForm();
                this.calculateWbsTotalsCont();
                oDialog.close();
                MessageToast.show(this.getView().getModel("i18n").getResourceBundle().getText("wbsUpdated"));
            }.bind(this));
        },

        onCancelWBSFormCB: function () {
            this._oWbsFragment.then(function (oDialog) {
                // this._resetWBSForm();
                oDialog.close();
            }.bind(this));
        },
        deleteBtnWBSTableSelectCB: function (oEvent) {
            var oContext = oEvent.getSource().getBindingContext("wbsModel");
            var sPath = oContext.getPath();
            var oModel = this.getView().getModel("wbsModel");
            var oServiceModel = this.getOwnerComponent().getModel("approvalservicev2");
            var iIndex = parseInt(sPath.split("/").pop(), 10);
            var aRows = oModel.getProperty("/rows");
            var oDeletedItem = aRows[iIndex];
        var that = this;
            // Check if it's already saved in backend
            if (oDeletedItem.__metadata && oDeletedItem.__metadata.uri) {
                var oUri = new URL(oDeletedItem.__metadata.uri);
                var sRelativePath = oUri.pathname.replace("/odata/v2/approval-hub", "");
        
                oServiceModel.remove(sRelativePath, {
                    success: function () {
                        aRows.splice(iIndex, 1);
                        oModel.setProperty("/rows", aRows);
                        sap.m.MessageToast.show("WBS row deleted successfully.");
                        that.calculateWbsTotalsCont();
                    },
                    error: function (oError) {
                        console.error("Backend delete failed:", oError);
                        sap.m.MessageToast.show("Error while deleting WBS row from backend.");
                    }
                });
            } else {
                // Local-only row
                aRows.splice(iIndex, 1);
                oModel.setProperty("/rows", aRows);
                that.calculateWbsTotalsCont();
                sap.m.MessageToast.show("WBS row deleted successfully.");
            }
        },        

        onDeleteWBSCB: function () {
            var oTable = this.byId("AdpdContingencyBudgetWbsTable");
            var aSelectedIndices = oTable.getSelectedIndices();
            var oModel = this.getView().getModel("wbsModel");

            if (!aSelectedIndices.length) {
                MessageToast.show("Please select at least one row.");
                return;
            }

            var aRows = oModel.getProperty("/rows") || [];
            var aIndices = aSelectedIndices
                .filter(iIndex => iIndex >= 0 && iIndex < aRows.length)
                .sort((a, b) => b - a);

            aIndices.forEach(iIndex => aRows.splice(iIndex, 1));
            oModel.setProperty("/rows", aRows);
            oTable.removeSelections(true);
            this.byId("contingency_budget_delete_wbs_button").setVisible(false);
            MessageToast.show("Selected rows deleted successfully.");
        },

        onAddContingencyBalanceRow: function () {
            var AdpdTitleContBalanceText = this.byId("AdpdTitleContBalance").getText();
            var sDialogTitle = "Add Contingency Balance Entry"; 
            if (AdpdTitleContBalanceText === "Contingency Balance (NRT)") {
                sDialogTitle = "Add Contingency Balance Entry (NRT)";
            } else if (AdpdTitleContBalanceText === "Parked Saving(NRT)") {
                sDialogTitle = "Add Parked Saving Entry (NRT)";
            }
            
            this._oContBalanceFragment.then(function (oDialog) {
                oDialog.setTitle(sDialogTitle);
                
                oDialog.setBeginButton(new sap.m.Button({
                    id: "",
                    text: this.getView().getModel("i18n").getResourceBundle().getText("addButtonText") || "Add",
                    type: "Accept",
                    press: this.onCreateContingencyBalanceRow.bind(this)
                }));
        
                oDialog.setEndButton(new sap.m.Button({
                    text: this.getView().getModel("i18n").getResourceBundle().getText("cancelButtonText") || "Cancel",
                    press: this.onCancelContBalanceForm.bind(this)
                }));
        
                this._resetContBalanceForm();
                oDialog.open();
            }.bind(this));
        },        

        onCreateContingencyBalanceRow: function () {
            this._oContBalanceFragment.then(function (oDialog) {
                var oFormModel = this.getView().getModel("formModel");
                var oContBalanceModel = this.getView().getModel("contBalanceModel");
                var oNewRow = {
                    level: parseFloat(oFormModel.getProperty("/level")) || "",
                    WBSCode: parseFloat(oFormModel.getProperty("/WBSCode")) || "",
                    priorBalance: parseFloat(oFormModel.getProperty("/priorBalance")) || "",
                    transfAmountCurrApproval: parseFloat(oFormModel.getProperty("/transfAmountCurrApproval")) || "",
                    balancePostTransfer: parseFloat(oFormModel.getProperty("/balancePostTransfer")) || "",
                    remarks: oFormModel.getProperty("/remarks")?.trim() || ""
                };
                // if (!oNewRow.nrtCode) {
                //     MessageToast.show("Please fill required field: NRT Code.");
                //     return;
                // }

                var aNumericFields = ["priorBalance", "transfAmountCurrApproval", "balancePostTransfer", "level", "WBSCode"];
                for (var field of aNumericFields) {
                    if (isNaN(oNewRow[field])) {
                        MessageToast.show(`Invalid value for ${field}. Please enter a valid number.`);
                        return;
                    }
                    oNewRow[field] = oNewRow[field].toString();

                }

                var aRows = oContBalanceModel.getProperty("/modelData") || [];
                oContBalanceModel.setProperty("/modelData", [...aRows, oNewRow]);
                this._resetContBalanceForm();
                this.calculateParkCon();
                oDialog.close();
                MessageToast.show("Row added successfully.");
            }.bind(this));
        },

        onEditContingencyBalanceRow: function (oEvent) {
            var oContext = oEvent.getSource().getBindingContext("contBalanceModel");
            var oSelectedRow = oContext.getObject();
            var sPath = oContext.getPath();
            var oFormModel = this.getView().getModel("formModel");
        
            // Prepare form data
            oFormModel.setData({
                WBSCode: oSelectedRow.WBSCode?.toString() || "",
                priorBalance: oSelectedRow.priorBalance?.toString() || "",
                transfAmountCurrApproval: oSelectedRow.transfAmountCurrApproval?.toString() || "",
                balancePostTransfer: oSelectedRow.balancePostTransfer?.toString() || "",
                remarks: oSelectedRow.remarks || "",
                level: oSelectedRow.level?.toString() || "",
                _rowPath: sPath,
                nrtCodes: oFormModel.getProperty("/nrtCodes")
            });
            var AdpdTitleContBalanceText = this.byId("AdpdTitleContBalance").getText();
            var sDialogTitle = "Edit Entry";
        
            if (AdpdTitleContBalanceText === "Contingency Balance (NRT)") {
                sDialogTitle = "Edit Contingency Balance Entry";
            } else if (AdpdTitleContBalanceText === "Parked Saving(NRT)") {
                sDialogTitle = "Edit Parked Saving Entry";
            }
            this._oContBalanceFragment.then(function (oDialog) {
                oDialog.setTitle(sDialogTitle);
                oDialog.setBeginButton(new sap.m.Button({
                    text: "Update",
                    type: "Accept",
                    press: this.onUpdateContingencyBalanceRow.bind(this)
                }));
                oDialog.setEndButton(new sap.m.Button({
                    text: "Cancel",
                    press: this.onCancelContBalanceForm.bind(this)
                }));
                oDialog.open();
            }.bind(this));
        },        

        onUpdateContingencyBalanceRow: function () {
            this._oContBalanceFragment.then(function (oDialog) {
                var oFormModel = this.getView().getModel("formModel");
                var oContBalanceModel = this.getView().getModel("contBalanceModel");

                var sRowPath = oFormModel.getProperty("/_rowPath");
                if (!sRowPath) {
                    MessageToast.show("No row selected for update.");
                    return;
                }

                var oUpdatedRow = {
                    level: parseFloat(oFormModel.getProperty("/level")) || "",
                    WBSCode: parseFloat(oFormModel.getProperty("/WBSCode")) || "",
                    priorBalance: parseFloat(oFormModel.getProperty("/priorBalance")) || "",
                    transfAmountCurrApproval: parseFloat(oFormModel.getProperty("/transfAmountCurrApproval")) || "",
                    balancePostTransfer: parseFloat(oFormModel.getProperty("/balancePostTransfer")) || "",
                    remarks: oFormModel.getProperty("/remarks")?.trim() || ""
                };
               var AdpdTitleContBalanceText =  this.byId("AdpdTitleContBalance").getText();
               if(AdpdTitleContBalanceText === "Contingency Balance (NRT)"){
                if (!oUpdatedRow.WBSCode) {
                    MessageToast.show("Please fill required field: WBS Code.");
                    return;
                }
               }else if(AdpdTitleContBalanceText === "Parked Saving(NRT)"){
                if (!oUpdatedRow.level) {
                    MessageToast.show("Please fill required field: Level.");
                    return;
                }
            }
                

                var aNumericFields = ["priorBalance", "transfAmountCurrApproval", "balancePostTransfer"];
                for (var field of aNumericFields) {
                    if (isNaN(oUpdatedRow[field])) {
                        MessageToast.show(`Invalid value for ${field}. Please enter a valid number.`);
                        return;
                    }
                }

                oContBalanceModel.setProperty(sRowPath, oUpdatedRow);
                this.calculateParkCon(); 
                this._resetContBalanceForm();
                oDialog.close();
                MessageToast.show("Row updated successfully.");
            }.bind(this));
        },

        onCancelContBalanceForm: function () {
            this._oContBalanceFragment.then(function (oDialog) {
                this._resetContBalanceForm();
                oDialog.close();
            }.bind(this));
        },
        _resetContBalanceForm: function () {
            var oFormModel = this.getView().getModel("formModel");
            oFormModel.setData({
                level: "",
                nrtCode: "",
                balancePrior: "",
                amountToTransfer: "",
                balancePost: "",
                remarks: "",
                _rowPath: ""
            });
        },




        onDeleteWBS: function () {
            var oTable = this.byId("AdpdWbsTable");
            var aSelectedIndices = oTable.getSelectedIndices();
            var oModel = this.getView().getModel("wbsModel");
            var aRows = oModel.getProperty("/rows") || [];
            var oBundle = this.getResourceBundle();

            if (!aSelectedIndices.length) {
                MessageToast.show(oBundle.getText("msgSelectRowToDelete"));
                return;
            }

            MessageBox.confirm(oBundle.getText("msgConfirmDeleteRows"), {
                onClose: function (sAction) {
                    if (sAction === MessageBox.Action.OK) {
                        aSelectedIndices.sort((a, b) => b - a).forEach(i => aRows.splice(i, 1));
                        oModel.setProperty("/rows", aRows);
                        oTable.clearSelection();
                        this.byId("AdpdDeleteWBSButton").setVisible(false);
                        MessageToast.show(oBundle.getText("msgRowsDeleted"));
                    }
                }.bind(this)
            });
        },

        onWBSChangeContingencyBal: function (oEvent) {
            var oTable = this.byId("AdpdContingencyBalanceTable");
            var oDeleteBtn = this.byId("AdpdContingencyBalanceDeleteButton");
            var bHasSelection = oTable.getSelectedIndices().length > 0;
            if (oDeleteBtn) {
                oDeleteBtn.setVisible(bHasSelection);
            }
        },
        onWBSChangeFinance: function (oEvent) {
            var oTable = this.byId("AdpdFinancialDetailsTable");
            var oDeleteBtn = this.byId("AdpdFinancialDeleteWBSButton");
            var bHasSelection = oTable.getSelectedIndices().length > 0;
            if (oDeleteBtn) {
                oDeleteBtn.setVisible(bHasSelection);
            }
        },
        onWBSInvetmentChange: function (oEvent) {
            var oTable = this.byId("AdpdInvestmentTable");
            var oDeleteBtn = this.byId("AdpdInvestDeleteWBSButton");
            var bHasSelection = oTable.getSelectedIndices().length > 0;
            if (oDeleteBtn) {
                oDeleteBtn.setVisible(bHasSelection);
            }
        },

        onWBSChangeContingency: function (oEvent) {
            var oTable = this.byId("AdpdContingencyBudgetWbsTable");
            var oDeleteBtn = this.byId("AdpdContingencyBudgetDeleteWbsButton");
            var bHasSelection = oTable.getSelectedIndices().length > 0;
            if (oDeleteBtn) {
                oDeleteBtn.setVisible(bHasSelection);
            }
        },
        onWBSSelectionChange: function (oEvent) {
            var oTable = this.byId("AdpdWbsTable");
            var oDeleteBtn = this.byId("AdpdDeleteWBSButton");
            var bHasSelection = oTable.getSelectedIndices().length > 0;
            if (oDeleteBtn) {
                oDeleteBtn.setVisible(bHasSelection);
            }
        },


        onAddRecommendation: function () {
            this._openRecommendationFragment("Add");
        },
        onAddPortion: function () {
            var oInterlineModel = this.getView().getModel("InterlineModel");
            var oRecommendedModel = this.getView().getModel("RecommendedDataCheck");
            var sSelectedKey = this.byId("AdpdRecommendSearch").getSelectedKey(); 
            var oBundle = this.getResourceBundle();
            if (!sSelectedKey) {
                MessageToast.show("Please select a correct Recommended User ID");
                return;
            }
            var aRecommendedData = oRecommendedModel.getProperty("/results");
            var oSelectedData = aRecommendedData.find(function(oItem) {
                return oItem.userID === sSelectedKey; 
            });
            if (!oSelectedData) {
                MessageToast.show("Selected user not found in the data");
                return;
            }
            var aRecommendations = oInterlineModel.getProperty("/recommendations") || [];
            var bIsDuplicate = aRecommendations.some(function(oItem) {
                return oItem.userId.toLowerCase() === oSelectedData.userID.toLowerCase();
            });
            if (bIsDuplicate) {
                MessageBox.information("You are trying to add a duplicate Recommended Data.");
                return; 
            }
            var oSelectedDataCopy = {
                userId: oSelectedData.userID.toLowerCase(),
                name: oSelectedData.name,
                email: oSelectedData.email,
            };
            aRecommendations.push(oSelectedDataCopy);
            oInterlineModel.setProperty("/recommendations", aRecommendations);
            oInterlineModel.setProperty("/showRecommendationTable", true);
            this.byId("AdpdRecommendSearch").setSelectedKey("");
            MessageToast.show(oBundle.getText("msgRecommendationAdded", [oSelectedDataCopy.userId, oSelectedDataCopy.name]));
        },
                 

        onDeleteRow: function (oEvent) {
            var oModel = this.getView().getModel("InterlineModel");
            var oServiceModel = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();
        
            oServiceModel.setUseBatch(false); 
            var oContext = oEvent.getSource().getParent().getBindingContext("InterlineModel");
            var sPath = oContext.getPath();
            var iIndex = parseInt(sPath.split("/").pop(), 10);
            var aRecommendations = oModel.getProperty("/recommendations");
            var oDeletedItem = aRecommendations[iIndex];
            MessageBox.confirm(oBundle.getText("msgConfirmDeleteRecommendation"), {
                onClose: function (sAction) {
                    if (sAction === MessageBox.Action.OK) {
                        if (oDeletedItem.__metadata && oDeletedItem.__metadata.uri) {
                            var oUri = new URL(oDeletedItem.__metadata.uri);
                            var sRelativePath = oUri.pathname.replace("/odata/v2/approval-hub", "");
                            oServiceModel.remove(sRelativePath, {
                                success: function () {
                                    aRecommendations.splice(iIndex, 1);
                                    oModel.setProperty("/recommendations", aRecommendations);
                                    oModel.setProperty("/showRecommendationTable", aRecommendations.length > 0);
                                    MessageToast.show(oBundle.getText("msgRecommendationDeleted"));
                                },
                                error: function (oError) {
                                    console.error("Delete error:", oError);
                                    MessageToast.show(oBundle.getText("msgErrorDeleteRecommendation"));
                                }
                            });
                        } else {
                            aRecommendations.splice(iIndex, 1);
                            oModel.setProperty("/recommendations", aRecommendations);
                            oModel.setProperty("/showRecommendationTable", aRecommendations.length > 0);
                            MessageToast.show(oBundle.getText("msgRecommendationDeleted"));
                        }
                    }
                }
            });
        },                   
        // Attachment Handlers
        onAttchmentDataFetch: function () {
            var reqid = this._reqIDData;
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oBundle = this.getResourceBundle();

            oModelV2.read("/ReqAttachments", {
                filters: [new Filter("reqID", FilterOperator.EQ, reqid)],
                success: function (oData) {
                    if (oData && oData.results) {
                        oView.getModel("UploadDocSrvTabData").setProperty("/attachments", oData.results);
                    }
                },
                error: function (oError) {
                    //MessageToast.show(oBundle.getText("msgFailedAttachmentData"));
                    console.error("Attachment load error:", oError);
                }
            });
        },

        attachmentuploadFilesData: function (reqid) {
            var oModelTabdata = this.getView().getModel("UploadDocSrvTabData");
            var aFilesData = oModelTabdata.getProperty("/attachments");
            var aFilesToUpload = [];
            var oModel = this.getOwnerComponent().getModel("approvalservicev2");

            if (aFilesData) {
                aFilesData.forEach(function (file) {
                    if (!file.fileName) return;

                    var fileCopy = Object.assign({}, file);
                    delete fileCopy.ID;
                    if (fileCopy.content && typeof fileCopy.content === "string" && fileCopy.content.includes(',')) {
                        var base64Content = fileCopy.content.split(',')[1];
                        aFilesToUpload.push({
                            fileName: fileCopy.fileName,
                            content: base64Content,
                            mediaType: fileCopy.mimeType || "text/plain",
                            reqID: reqid,
                        });
                    } else {
                        // console.warn("Invalid file content for file:", fileCopy.fileName);
                    }
                });
                aFilesToUpload.forEach(function (attachmentData) {
                    oModel.create("/ReqAttachments", attachmentData, {
                        success: function () {
                        },
                        error: function () {
                        }
                    });
                });
            }
        },

        onUploadTabAttachment: function (oEvent) {
            var oFileUploader = oEvent.getSource();
            var aFiles = oEvent.getParameter("files");
            var oModel = this.getView().getModel("UploadDocSrvTabData");
            var aAttachments = oModel.getProperty("/attachments") || [];
            var oBundle = this.getResourceBundle();
            var reqID = this._reqIDData || "";

            if (!aFiles || aFiles.length === 0) {
                MessageToast.show("No Files Selected");
                return;
            }

            for (let i = 0; i < aFiles.length; i++) {
                const file = aFiles[i];
                const reader = new FileReader();

                reader.onload = (e) => {
                    const base64Content = e.target.result.split(',')[1];

                    const attachment = {
                        fileName: file.name,
                        mediaType: file.type,
                        content: e.target.result,
                        reqID: reqID,
                        // deleteTabVisible: true
                    };

                    aAttachments.push(attachment);
                    oModel.setProperty("/attachments", aAttachments);
                    oModel.refresh(true);

                    if (i === aFiles.length - 1) {
                        MessageToast.show(oBundle.getText("File Uploaded Successfully", [aFiles.length]));
                        oFileUploader.setValue("");
                    }
                };

                reader.onerror = () => {
                    MessageToast.show(oBundle.getText("Error In File Uploading", [file.name]));
                    if (i === aFiles.length - 1) {
                        oFileUploader.setValue("");
                    }
                };

                reader.readAsDataURL(file);
            }
        },


        onUploadTabAttachment: function (oEvent) {
            var oFileUploader = oEvent.getSource();
            var aFiles = oEvent.getParameter("files");
            var oModel = this.getView().getModel("UploadDocSrvTabData");
            var aAttachments = oModel.getProperty("/attachments") || [];
            var oBundle = this.getResourceBundle();
            var reqID = this._reqIDData || "";

            if (!aFiles || aFiles.length === 0) {
                MessageToast.show("No File selected");
                return;
            }

            for (let i = 0; i < aFiles.length; i++) {
                const file = aFiles[i];
                const reader = new FileReader();

                reader.onload = (e) => {
                    const content = e.target.result;
                    const attachment = {
                        ID: "local-" + Date.now() + "-" + i,
                        fileName: file.name,
                        mediaType: file.type,
                        content: content,
                        reqID: reqID,
                        //deleteTabVisible: true
                    };

                    aAttachments.push(attachment);
                    oModel.setProperty("/attachments", aAttachments);
                    oModel.refresh(true);

                    if (i === aFiles.length - 1) {
                        MessageToast.show(oBundle.getText("File Uploaded Successfully", [aFiles.length]));
                        oFileUploader.setValue("");
                    }
                };

                reader.onerror = () => {
                    MessageToast.show(oBundle.getText("msgErrorReadFile", [file.name]));
                    if (i === aFiles.length - 1) {
                        oFileUploader.setValue("");
                    }
                };

                reader.readAsDataURL(file);
            }
        },

        onDownloadTabAttachment: function (oEvent) {
            const oButton = oEvent.getSource();
            const aCustomData = oButton.getCustomData();
            const sID = aCustomData.find(oData => oData.getKey() === "ID")?.getValue();
            const sFileName = aCustomData.find(oData => oData.getKey() === "fileName")?.getValue();
            const oBundle = this.getResourceBundle();
            const oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

            if (!sID || !sFileName) {
                MessageToast.show(oBundle.getText("msgInvalidAttachment"));
                return;
            }

            const sUrl = oModelV2.sServiceUrl + `/ReqAttachments(guid'${sID}')/$value`;

            const oLink = document.createElement("a");
            oLink.href = sUrl;
            oLink.download = sFileName;
            oLink.target = "_blank";
            document.body.appendChild(oLink);
            oLink.click();
            document.body.removeChild(oLink);

            MessageToast.show(oBundle.getText("Downloading File", [sFileName]));
        },

        onDownloadbtn: function () {
            var oTable = this.byId("AdpdAttachmentTable");
            var aSelectedItems = oTable.getSelectedItems();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var sServiceUrl = oModelV2.sServiceUrl;
            var oBundle = this.getResourceBundle();

            if (aSelectedItems.length === 0) {
                MessageToast.show("Please Select File To Download");
                return;
            }

            var delay = 0;
            aSelectedItems.forEach(function (oItem) {
                var oAttachment = oItem.getBindingContext("UploadDocSrvTabData").getObject();
                var sID = oAttachment.ID;
                var sFileName = oAttachment.fileName;

                if (!sID || !sFileName) {
                    MessageToast.show("Invalid Attachment");
                    return;
                }

                var sDownloadUrl = `${sServiceUrl}/ReqAttachments(guid'${sID}')/$value`;

                setTimeout(function () {
                    var link = document.createElement("a");
                    link.href = sDownloadUrl;
                    link.download = sFileName;
                    link.target = "_blank";
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);

                    MessageToast.show(oBundle.getText("Downloading File", [sFileName]));
                }, delay);

                delay += 1500;
            });
        },

        onDeleteTabAttchment: function (oEvent) {
            var oButton = oEvent.getSource();
            var oModel = this.getView().getModel("UploadDocSrvTabData");
            var aAttachments = oModel.getProperty("/attachments");
            var sID = oButton.getCustomData().find(oData => oData.getKey() === "ID").getValue();
            var iIndex = aAttachments.findIndex(o => o.ID === sID);
            var sFileName = aAttachments[iIndex]?.fileName || "File";
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var sPath = `/ReqAttachments(guid'${sID}')`;
            var that = this;

            MessageBox.confirm(`Are you sure you want to delete the file '${sFileName}'?`, {
                title: "Confirm Deletion",
                onClose: function (oAction) {
                    if (oAction === MessageBox.Action.OK) {
                        oModelV2.remove(sPath, {
                            success: function () {
                                that._removeAttachmentFromLocal(oModel, sID, sFileName);
                            },
                            error: function () {
                                MessageToast.show(`Failed to delete file '${sFileName}' from server.`);
                                that._removeAttachmentFromLocal(oModel, sID, sFileName);
                            }
                        });
                    }
                }
            });
        },

        _removeAttachmentFromLocal: function (oModel, sID, sFileName) {
            var aAttachments = oModel.getProperty("/attachments");
            var iIndex = aAttachments.findIndex(o => o.ID === sID);
            if (iIndex !== -1) {
                aAttachments.splice(iIndex, 1);
                oModel.setProperty("/attachments", aAttachments);
                oModel.refresh(true);
                MessageToast.show("File '" + sFileName + "' deleted successfully.");
            }
        },

        _downloadLocalAttachment: function (oAttachment, sFileName) {
            if (!oAttachment || !oAttachment.content) {
                MessageToast.show("No file content available for download.");
                return;
            }
            this._downloadBase64(oAttachment.content, sFileName);
        },

        _downloadBase64: function (sBase64Content, sFileName) {
            try {
                var sBase64Data = sBase64Content.split(',')[1];
                var sMimeType = sBase64Content.split(';')[0].split(':')[1];
                var byteCharacters = atob(sBase64Data);
                var byteNumbers = new Array(byteCharacters.length);
                for (var i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                var byteArray = new Uint8Array(byteNumbers);
                var blob = new Blob([byteArray], { type: sMimeType });
                var url = URL.createObjectURL(blob);

                var link = document.createElement("a");
                link.href = url;
                link.download = sFileName;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                URL.revokeObjectURL(url);

                MessageToast.show("Downloading " + sFileName);
            } catch (e) {
                MessageBox.error("Error while downloading " + sFileName);
            }
        },




        nDownloadTabAttachment: function (oEvent) {
            var oButton = oEvent.getSource();
            var sID = oButton.getCustomData().find(function (oData) {
                return oData.getKey() === "ID";
            }).getValue();
            var sFileName = oButton.getCustomData().find(function (oData) {
                return oData.getKey() === "fileName";
            }).getValue();
            var oModel = this.getView().getModel("UploadDocSrvTabData");
            var aAttachments = oModel.getProperty("/attachments") || [];
            var oAttachment = aAttachments.find(o => o.ID === sID);
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var sPath = "/ReqAttachments(guid'" + sID + "')";
            var oBundle = this.getResourceBundle();
            var that = this;

            oModelV2.read(sPath, {
                success: function (oData) {
                    if (oData && oData.__metadata && oData.__metadata.media) {
                        var oLink = document.createElement("src");
                        oLink.href = oData.__metadata.media;
                        oLink.download = sFileName;
                        document.body.appendChild(oLink);
                        oLink.click();
                        document.body.removeChild(oLink);
                        MessageToast.show(oBundle.getText("Downloading File", [sFileName]));
                    } else {
                        that._downloadLocalAttachment(oAttachment, sFileName);
                    }
                },
                error: function () {
                    that._downloadLocalAttachment(oAttachment, sFileName);
                }
            });
        },


        _openWBSFragment: function (sMode, oData, sPath) {
            if (!this._oWbsFragment) {
                Fragment.load({
                    id: this.getView().getId(),
                    name: "com.mmapprovalhub.approvalhub.Fragments.WBSFragment",
                    controller: this
                }).then(function (oDialog) {
                    this._oWBSFragment = oDialog;
                    this.getView().addDependent(oDialog);
                    this._openWBSFragmentDialog(sMode, oData, sPath);
                }.bind(this));
            } else {
                this._openWBSFragmentDialog(sMode, oData, sPath);
            }
        },

        _openWBSFragmentDialog: function (sMode, oData, sPath) {
            var oModel = new JSONModel({
                mode: sMode,
                data: oData || {
                    fromWbsCode: "",
                    fromWbsLevel: "",
                    fromWbsLocation: "",
                    toWbsCode: "",
                    toWbsLevel: "",
                    toWbsLocation: "",
                    capexNrt: "",
                    capexLanded: "",
                    revenueNrt: "",
                    revenueLanded: "",
                    totalNrt: "",
                    totalLanded: "",
                    remarks: ""
                },
                _rowPath: sPath || ""
            });
            this._oWBSFragment.setModel(oModel, "WBSFragmentModel");
            this._oWBSFragment.open();
        },

        onSaveWBSFragment: function () {
            var oFragmentModel = this._oWBSFragment.getModel("WBSFragmentModel");
            var oData = oFragmentModel.getProperty("/data");
            var sMode = oFragmentModel.getProperty("/mode");
            var sRowPath = oFragmentModel.getProperty("/_rowPath");
            var oWbsModel = this.getView().getModel("WbsModel");
            var aRows = oWbsModel.getProperty("/rows") || [];
            var oBundle = this.getResourceBundle();

            if (!oData.fromWbsCode || !oData.toWbsCode) {
                MessageToast.show(oBundle.getText("msgRequiredFields"));
                return;
            }

            var aNumericFields = ["capexNrt", "capexLanded", "revenueNrt", "revenueLanded"];
            for (var field of aNumericFields) {
                if (isNaN(parseFloat(oData[field]))) {
                    MessageToast.show(oBundle.getText("Invalid Field", [field]));
                    return;
                }
                oData[field] = parseFloat(oData[field]) || 0;
            }

            if (sMode === "Add") {
                aRows.push(oData);
            } else if (sMode === "Edit" && sRowPath) {
                oWbsModel.setProperty(sRowPath, oData);
            }

            oWbsModel.setProperty("/rows", aRows);
            this._oWBSFragment.close();
            this._resetWBSForm();
            MessageToast.show(oBundle.getText(sMode === "Add" ? "msgWBSRowAdded" : "msgWBSRowUpdated"));
        },

        onCancelWBSFragment: function () {
            this._resetWBSForm();
            this._oWBSFragment.close();
        },


        handleChange: function (oEvent) {
            var oComboBox = oEvent.getSource();
            var sSelectedKey = oComboBox.getSelectedKey();
            var sValue = oComboBox.getValue();

            var oRegex = /^[a-zA-Z\s]+$/; // Only allows letters and spaces
            if (!oRegex.test(sValue)) {
                oComboBox.setValue("");
                oComboBox.setSelectedKey("");
                oComboBox.setValueState(ValueState.Error);
                oComboBox.setValueStateText("Only alphabetic characters are allowed!");
            } else if (!sSelectedKey || sSelectedKey !== sValue) {
                oComboBox.setValue("");
                oComboBox.setSelectedKey("");
                oComboBox.setValueState(ValueState.Error);
                oComboBox.setValueStateText("Please select a valid option from the list!");
            } else {
                oComboBox.setValueState(ValueState.None);
            }
        },


        /***********************
         * Investment Section  
         ***********************/
        onAddInvestmentRow: function () {
            this._oInvestmentFragment.then(function (oDialog) {
                oDialog.setTitle(this.getView().getModel("i18n").getResourceBundle().getText("titleInvestmentFragmentCreate") || "Add Investment Details");
                oDialog.setModel(new sap.ui.model.json.JSONModel({
                    mode: "Create",
                    natureOfExpense: "",
                    level: "",
                    capex: "",
                    revenue: "",
                    total: "",
                    remarks: ""
                }), "idInvestmentFragmentModel");

                oDialog.setBeginButton(new sap.m.Button({
                    text: this.getView().getModel("i18n").getResourceBundle().getText("btnSave") || "Save",
                    type: "Emphasized",
                    press: this.onSaveInvestmentFragment.bind(this)
                }));
                oDialog.setEndButton(new sap.m.Button({
                    text: this.getView().getModel("i18n").getResourceBundle().getText("btnCancel") || "Cancel",
                    press: function () {
                        oDialog.close();
                    }
                }));

                oDialog.open();
            }.bind(this));
        },


        onEditInvestmentRow: function (oEvent) {
            var oContext = oEvent.getSource().getBindingContext("InvestmentModel");
            var oSelectedRow = oContext.getObject();

            this._oInvestmentFragment.then(function (oDialog) {
                oDialog.setTitle(this.getView().getModel("i18n").getResourceBundle().getText("titleInvestmentFragmentEdit") || "Edit Investment Details");

                oDialog.setModel(new sap.ui.model.json.JSONModel({
                    mode: "Edit",
                    natureOfExpense: oSelectedRow.natureOfExpense,
                    level: oSelectedRow.level,
                    capex: oSelectedRow.capex,
                    revenue: oSelectedRow.revenue,
                    total: oSelectedRow.total,
                    remarks: oSelectedRow.remarks,
                    _rowPath: oContext.getPath()
                }), "idInvestmentFragmentModel");

                oDialog.setBeginButton(new sap.m.Button({
                    text: this.getView().getModel("i18n").getResourceBundle().getText("Update") || "Update",
                    type: "Emphasized",
                    press: this.onUpdateInvestmentFragment.bind(this)
                }));
                oDialog.setEndButton(new sap.m.Button({
                    text: this.getView().getModel("i18n").getResourceBundle().getText("btnCancel") || "Cancel",
                    press: function () {
                        oDialog.close();
                    }
                }));

                oDialog.open();
            }.bind(this));
        },
        onSaveInvestmentFragment: function () {
            this._oInvestmentFragment.then(function (oDialog) {
                var oModel = this.getView().getModel("InvestmentModel");
                var oFormModel = oDialog.getModel("idInvestmentFragmentModel");

                const capexVal = parseFloat(oFormModel.getProperty("/capex")) || "";
                const revenueVal = parseFloat(oFormModel.getProperty("/revenue")) || "";

                const oNewEntry = {
                    natureOfExpense: oFormModel.getProperty("/natureOfExpense")?.trim() || "",
                    level: oFormModel.getProperty("/level")?.trim() || "",
                    capex: capexVal,
                    revenue: revenueVal,
                    total: capexVal + revenueVal,
                    remarks: oFormModel.getProperty("/remarks")?.trim() || ""
                };


                if (!oNewEntry.natureOfExpense) {
                    sap.m.MessageToast.show("Description is required.");
                    return;
                }

                var aData = oModel.getProperty("/investmentData") || [];
                aData.push(oNewEntry);
                oModel.setProperty("/investmentData", aData);
                this.PreProjectInvestment();   

                oDialog.close();
                sap.m.MessageToast.show("Investment entry added successfully.");
            }.bind(this));
        },
        onUpdateInvestmentFragment: function () {
            this._oInvestmentFragment.then(function (oDialog) {
                var oModel = this.getView().getModel("InvestmentModel");
                var oFormModel = oDialog.getModel("idInvestmentFragmentModel");

                var sPath = oFormModel.getProperty("/_rowPath");
                if (!sPath) {
                    sap.m.MessageToast.show("No investment selected for update.");
                    return;
                }
                const capexVal = parseFloat(oFormModel.getProperty("/capex")) || "";
                const revenueVal = parseFloat(oFormModel.getProperty("/revenue")) || "";


                var oUpdatedEntry = {
                    natureOfExpense: oFormModel.getProperty("/natureOfExpense")?.trim() || "",
                    level: oFormModel.getProperty("/level")?.trim() || "",
                    capex: capexVal,
                    revenue: revenueVal,
                    total: capexVal + revenueVal,
                    remarks: oFormModel.getProperty("/remarks")?.trim() || ""
                };

                if (!oUpdatedEntry.natureOfExpense) {
                    sap.m.MessageToast.show("Description is required.");
                    return;
                }

                oModel.setProperty(sPath, oUpdatedEntry);
                this.PreProjectInvestment();   
                oDialog.close();
                sap.m.MessageToast.show("Investment entry updated successfully.");
            }.bind(this));
        },



        onCopyInvestmentRow: function (oEvent) {
            var oContext = oEvent.getSource().getBindingContext("InvestmentModel");
            var oData = Object.assign({}, oContext.getObject());
            var oModel = this.getView().getModel("InvestmentModel");
            var aData = oModel.getProperty("/investmentData");
            var oBundle = this.getResourceBundle();
            aData.push(oData);
            oModel.setProperty("/investmentData", aData);
            MessageToast.show(oBundle.getText("msgRowCopied"));
            this.PreProjectInvestment();   
                
        },

        onDeleteInvestmentRow: function (oEvent) {
            var oContext = oEvent.getSource().getBindingContext("InvestmentModel");
            var sPath = oContext.getPath();
            var oModel = this.getView().getModel("InvestmentModel");
            var oServiceModel = this.getOwnerComponent().getModel("approvalservicev2");
            var iIndex = parseInt(sPath.split("/").pop(), 10);
            var aRows = oModel.getProperty("/investmentData");
            var oDeletedItem = aRows[iIndex];
        var that = this;
            // Check if the row is already saved in the backend
            if (oDeletedItem.__metadata && oDeletedItem.__metadata.uri) {
                var oUri = new URL(oDeletedItem.__metadata.uri);
                var sRelativePath = oUri.pathname.replace("/odata/v2/approval-hub", "");
        
                oServiceModel.remove(sRelativePath, {
                    success: function () {
                        aRows.splice(iIndex, 1);
                        oModel.setProperty("/investmentData", aRows);
                        sap.m.MessageToast.show("Investment row deleted successfully.");
                        that.PreProjectInvestment();   
                    },
                    error: function (oError) {
                        console.error("Backend delete failed:", oError);
                        sap.m.MessageToast.show("Error while deleting Investment row from backend.");
                    }
                });
            } else {
                // Local-only row
                aRows.splice(iIndex, 1);
                oModel.setProperty("/investmentData", aRows);
                sap.m.MessageToast.show("Investment row deleted successfully.");
                that.PreProjectInvestment();   
            }
        },        

        onDeleteSelectedInvestmentRows: function () {
            var oTable = this.byId("AdpdInvestmentTable");
            var aSelectedIndices = oTable.getSelectedIndices();
            var oModel = this.getView().getModel("InvestmentModel");

            if (!aSelectedIndices.length) {
                MessageToast.show("Please select at least one row.");
                return;
            }

            var aRows = oModel.getProperty("/investmentData") || [];

            var aIndices = aSelectedIndices
                .filter(iIndex => iIndex >= 0 && iIndex < aRows.length)
                .sort((a, b) => b - a);

            aIndices.forEach(iIndex => aRows.splice(iIndex, 1));

            oModel.setProperty("/investmentData", aRows);
            oTable.removeSelections(true);

            this.byId("investment_delete_button").setVisible(false);

            MessageToast.show("Selected investment rows deleted successfully.");
        },

        onInvestmentTotalChange: function (oEvent) {
            var oContext = oEvent.getSource().getBindingContext("InvestmentModel");
            var oData = oContext.getObject();
            oData.totalNrt = (parseFloat(oData.capexNrt || 0) + parseFloat(oData.revenueNrt || 0)).toFixed(2);
            oContext.getModel().refresh();
        },

        _openFinancialFragment: function (sMode, oSelectedRow) {
            var oResourceBundle = this.getResourceBundle();

            if (!this._oFinancialDialog) {
                this._oFinancialDialog = sap.ui.getCore().byId("idFinancialFragmentDialog");
                if (!this._oFinancialDialog) {

                    this._oFinancialDialog = sap.ui.xmlfragment(
                        "com.mmapprovalhub.approvalhub.Fragments.FinancialFragment",
                        this
                    );
                    this.getView().addDependent(this._oFinancialDialog);

                    this._oFinancialDialog.setModel(
                        new JSONModel({
                            mode: "Add",
                            data: {
                                capex: "",
                                revenue: "",
                                totalProjectCost: "",
                                percentageTotalProjectCost: "",
                                _rowPath: ""
                            }
                        }),
                        "idFinancialFragmentModel"
                    );
                }
            }

            this._resetFinancialForm();
            var oFragmentModel = this._oFinancialDialog.getModel("idFinancialFragmentModel");
            if (sMode === "Edit" && oSelectedRow) {
                oFragmentModel.setData({
                    mode: "Edit",
                    data: {
                        capex: oSelectedRow.capex?.toString() || "",
                        revenue: oSelectedRow.revenue?.toString() || "",
                        // totalProjectCost: oSelectedRow.totalProjectCost?.toString() || "",
                        //percentageTotalProjectCost: oSelectedRow.percentageTotalProjectCost?.toString() || "",
                        _rowPath: oSelectedRow._rowPath || oFragmentModel.getProperty("/data/_rowPath") || ""
                    }
                });
                this._oFinancialDialog.setTitle("Financial Form");

                var oBeginButton = this._oFinancialDialog.getBeginButton();
                if (oBeginButton) {
                    oBeginButton.destroy();
                }
                this._oFinancialDialog.setBeginButton(new sap.m.Button({
                    id: "idUpdateFinancialButton",
                    text: oResourceBundle.getText("Update"),
                    type: "Emphasized",
                    press: this.onUpdateFinancialFragment.bind(this)
                }));
            } else {

                oFragmentModel.setData({
                    mode: sMode === "Copy" ? "Copy" : "Add",
                    data: {
                        capex: oSelectedRow ? oSelectedRow.capex?.toString() || "" : "",
                        revenue: oSelectedRow ? oSelectedRow.revenue?.toString() || "" : "",
                        totalProjectCost: oSelectedRow ? oSelectedRow.totalProjectCost?.toString() || "" : "",
                        percentageTotalProjectCost: oSelectedRow ? oSelectedRow.percentageTotalProjectCost?.toString() || "" : "",
                        _rowPath: ""
                    }
                });
                this._oFinancialDialog.setTitle(oResourceBundle.getText(sMode === "Copy" ? "titleFinancialFragmentCopy" : "Financial Form"));

                var oBeginButton = this._oFinancialDialog.getBeginButton();
                if (oBeginButton && oBeginButton.getId() !== "idSaveFinancialButton") {
                    oBeginButton.destroy();
                    this._oFinancialDialog.setBeginButton(new sap.m.Button({
                        id: "idSaveFinancialButton",
                        text: oResourceBundle.getText("Save"),
                        type: "Emphasized",
                        press: this.onSaveFinancialFragment.bind(this)
                    }));
                }
            }

            this._oFinancialDialog.open();
        },
        onAddFinancialRow: function () {
            this._openFinancialFragment("Add");
        },
        onCancelFinancialFragment: function () {
            this._oFinancialDialog.close();
        },

        onEditFinancialRow: function (oEvent) {
            var oContext = oEvent.getSource().getBindingContext("FinancialModel");
            var sPath = oContext.getPath();
            var oSelectedRow = oContext.getObject();
            oSelectedRow._rowPath = sPath;
            this._openFinancialFragment("Edit", oSelectedRow);
        },


        onSaveFinancialFragment: function () {
            var oFinancialModel = this.getView().getModel("FinancialModel");
            var oResourceBundle = this.getResourceBundle();
            var capex = parseFloat(sap.ui.getCore().byId("idCapexInput")?.getValue()) || "";
            var revenue = parseFloat(sap.ui.getCore().byId("idRevenueInput")?.getValue()) || "";

            var totalProjCost = capex + revenue;
            var tenPercentOfTotalCost = (totalProjCost * 0.1).toFixed(2);

            var oNewEntry = {
                capex: capex.toFixed(2),
                revenue: revenue.toFixed(2),
                totalProjCost: totalProjCost.toFixed(2),
                tenPercentOfTotalCost: tenPercentOfTotalCost
            };

            var aNumericFields = ["capex", "revenue"];
            for (var sField of aNumericFields) {
                if (isNaN(oNewEntry[sField]) || oNewEntry[sField] <= 0) {
                    MessageToast.show(oResourceBundle.getText(sField + "Required"));
                    return;
                }
            }

            var aRows = oFinancialModel.getProperty("/rows") || [];
            aRows.push(oNewEntry);
            oFinancialModel.setProperty("/rows", aRows);
            this._resetFinancialForm();
            this._oFinancialDialog.close();
            MessageToast.show(oResourceBundle.getText("Financial Data Added"));
        },

        onUpdateFinancialFragment: function () {
            var oFragmentModel = this._oFinancialDialog.getModel("idFinancialFragmentModel");
            var oFinancialModel = this.getView().getModel("FinancialModel");
            var oResourceBundle = this.getResourceBundle();

            var sRowPath = oFragmentModel.getProperty("/data/_rowPath");
            if (!sRowPath) {
                MessageToast.show(oResourceBundle.getText("noRowSelected"));
                return;
            }

            var capex = parseFloat(sap.ui.getCore().byId("idCapexInput")?.getValue()) || "";
            var revenue = parseFloat(sap.ui.getCore().byId("idRevenueInput")?.getValue()) || "";

            var totalProjCost = capex + revenue;
            var tenPercentOfTotalCost = (totalProjCost * 0.1).toFixed(2);

            var oUpdatedEntry = {
                capex: capex.toFixed(2),
                revenue: revenue.toFixed(2),
                totalProjCost: totalProjCost.toFixed(2),
                tenPercentOfTotalCost: tenPercentOfTotalCost
            };

            var aNumericFields = ["capex", "revenue"];
            for (var sField of aNumericFields) {
                if (isNaN(oUpdatedEntry[sField]) || oUpdatedEntry[sField] <= 0) {
                    MessageToast.show(oResourceBundle.getText(sField + "Required"));
                    return;
                }
            }
            oFinancialModel.setProperty(sRowPath, oUpdatedEntry);
            this._resetFinancialForm();
            this._oFinancialDialog.close();
            MessageToast.show(oResourceBundle.getText("Financial Data Updated"));
        },

        onCopyFinancialRow: function (oEvent) {
            var oContext = oEvent.getSource().getBindingContext("FinancialModel");
            var oData = Object.assign({}, oContext.getObject());
            var oModel = this.getView().getModel("FinancialModel");
            var aData = oModel.getProperty("/rows");
            var oBundle = this.getResourceBundle();
            aData.push(oData);
            oModel.setProperty("/rows", aData);
            MessageToast.show(oBundle.getText("msgRowCopied"));
        },
        onDeleteFinancialRow: function (oEvent) {
            let oButton = oEvent.getSource();
            let oContext = oButton.getBindingContext("FinancialModel");
            let sPath = oContext.getPath();
            let oModel = this.getView().getModel("FinancialModel");
            let oServiceModel = this.getOwnerComponent().getModel("approvalservicev2");
            let aRows = oModel.getProperty("/rows") || [];
            let iIndex = parseInt(sPath.split("/").pop(), 10);
            let oDeletedItem = aRows[iIndex];
            if (!isNaN(iIndex) && iIndex > -1) {
                if (oDeletedItem.__metadata && oDeletedItem.__metadata.uri) {
                    let oUri = new URL(oDeletedItem.__metadata.uri);
                    let sRelativePath = oUri.pathname.replace("/odata/v2/approval-hub", "");
                    oServiceModel.remove(sRelativePath, {
                        success: function () {
                            aRows.splice(iIndex, 1);
                            oModel.setProperty("/rows", aRows);
                            sap.m.MessageToast.show("Row deleted successfully.");
                        },
                        error: function (oError) {
                            console.error("Backend delete failed:", oError);
                            sap.m.MessageToast.show("Error while deleting Financial row from backend.");
                        }
                    });
                } else {
                    aRows.splice(iIndex, 1);
                    oModel.setProperty("/rows", aRows);
                    sap.m.MessageToast.show("Row deleted successfully.");
                }
            } else {
                sap.m.MessageToast.show("Error deleting row: invalid index.");
            }
        },        

        onDeleteSelectedFinancialRows: function (oEvent) {
            var oTable = this.byId("AdpdFinancialDetailsTable");
            var aSelectedIndices = oTable.getSelectedIndices();
            var oModel = this.getView().getModel("FinancialModel");

            if (!aSelectedIndices.length) {
                MessageToast.show("Please select at least one row.");
                return;
            }

            var aRows = oModel.getProperty("/rows") || [];
            var aIndices = aSelectedIndices
                .filter(iIndex => iIndex >= 0 && iIndex < aRows.length)
                .sort((a, b) => b - a);

            aIndices.forEach(iIndex => aRows.splice(iIndex, 1));
            oModel.setProperty("/rows", aRows);
            oTable.removeSelections(true);
            this.byId("AdpdFinancialDeleteWBSButton").setVisible(false);
            MessageToast.show("Selected rows deleted successfully.");
        },

        onFinancialTotalChange: function (oEvent) {
            var oContext = oEvent.getSource().getBindingContext("FinancialModel");
            var oData = oContext.getObject();
            oData.totalProjCost = (parseFloat(oData.capex || 0) + parseFloat(oData.revenue || 0)).toFixed(2);
            oData.tenPercentOfTotalCost = this._calculatePercentage(oData.totalProjCost);
            oContext.getModel().refresh();
        },

        _resetFinancialForm: function () {
            var oFragmentModel = this._oFinancialDialog?.getModel("idFinancialFragmentModel");
            if (oFragmentModel) {
                oFragmentModel.setData({
                    mode: "Add",
                    data: {
                        capex: "",
                        revenue: "",
                        totalProjCost: "",
                        tenPercentOfTotalCost: "",
                        _rowPath: ""
                    }
                });
            }

            var aInputIds = ["idCapexInput", "idRevenueInput", "idTotalProjectCostInput", "idPercentageTotalProjectCostInput"];
            aInputIds.forEach(function (sId) {
                var oControl = sap.ui.getCore().byId(sId);
                if (oControl) {
                    oControl.setValue("");
                }
            });

            var oResourceBundle = this.getResourceBundle();
            if (this._oFinancialDialog) {
                this._oFinancialDialog.setTitle(oResourceBundle.getText("titleFinancialFragmentAdd"));
            }

            var oBeginButton = this._oFinancialDialog?.getBeginButton();
            if (oBeginButton && oBeginButton.getId() !== "idSaveFinancialButton") {
                oBeginButton.destroy();
                this._oFinancialDialog.setBeginButton(new sap.m.Button({
                    id: "idSaveFinancialButton",
                    text: oResourceBundle.getText("btnSave"),
                    type: "Emphasized",
                    press: this.onSaveFinancialFragment.bind(this)
                }));
            }
        },


        /***********************
         * Contingency Balance Section
         ***********************/
        onDeleteContingencyBalance: function () {
            var oTable = this.byId("AdpdContingencyBalanceTable");
            var aSelectedIndices = oTable.getSelectedIndices();
            var oModel = this.getView().getModel("contBalanceModel");
            var aRows = oModel.getProperty("/modelData") || [];
            var oBundle = this.getResourceBundle();

            if (!aSelectedIndices.length) {
                MessageToast.show(oBundle.getText("Select Row To Delete"));
                return;
            }

            MessageBox.confirm(oBundle.getText("Confirm for Delete Rows"), {
                onClose: function (sAction) {
                    if (sAction === MessageBox.Action.OK) {
                        aSelectedIndices.sort((a, b) => b - a).forEach(i => aRows.splice(i, 1));
                        oModel.setProperty("/rows", aRows);
                        oTable.clearSelection();
                        this.byId("AdpdContingencyBalanceDeleteButton").setVisible(false);
                        MessageToast.show(oBundle.getText("Data Deleted"));
                    }
                }.bind(this)
            });

        },

        onDeleteContingencyBalanceRow: function (oEvent) {
            var oContext = oEvent.getSource().getBindingContext("contBalanceModel");
            var sPath = oContext.getPath();
            var iIndex = parseInt(sPath.split("/").pop(), 10);
            var oModel = this.getView().getModel("contBalanceModel");
            var aData = oModel.getProperty("/modelData");
            var oDeletedItem = aData[iIndex];
            var that = this;
            var oServiceModel = this.getOwnerComponent().getModel("approvalservicev2");
            if (oDeletedItem.__metadata && oDeletedItem.__metadata.uri) {
                var oUri = new URL(oDeletedItem.__metadata.uri);
                var sRelativePath = oUri.pathname.replace("/odata/v2/approval-hub", "");
        
                oServiceModel.remove(sRelativePath, {
                    success: function () {
                        aData.splice(iIndex, 1);
                        oModel.setProperty("/modelData", aData);
                        sap.m.MessageToast.show("Row deleted successfully.");
                        that.calculateParkCon(); 
                    },
                    error: function (oError) {
                        console.error("Failed to delete from backend:", oError);
                        sap.m.MessageToast.show("Error while deleting Contingency Balance row from backend.");
                    }
                });
            } else {
                aData.splice(iIndex, 1);
                oModel.setProperty("/modelData", aData);
                sap.m.MessageToast.show("Row deleted successfully.");
                that.calculateParkCon(); 
            }
        },        
        onDeleteSelectedContingencyBalanceRows: function () {

            var oTable = this.getView().byId("AdpdContingencyBalanceTable");
            var aSelectedIndices = oTable.getSelectedIndices();
            var oModel = this.getView().getModel("contBalanceModel");
            var aData = oModel.getProperty("/modelData");
            var oBundle = this.getResourceBundle();

            if (!aSelectedIndices.length) {
                MessageToast.show(oBundle.getText("msgSelectRowToDelete"));
                return;
            }

            MessageBox.confirm(oBundle.getText("msgConfirmDeleteRows"), {
                onClose: function (sAction) {
                    if (sAction === MessageBox.Action.OK) {
                        aSelectedIndices.sort((a, b) => b - a).forEach(i => aData.splice(i, 1));
                        oModel.setProperty("/modelData", aData);
                        oTable.clearSelection();
                        MessageToast.show(oBundle.getText("msgRowsDeleted"));
                    }
                }
            });
        },


        /***********************
         * Volume Breakup 
         ***********************/


        onAddVolumeRow: function () {
            const oModel = this.getView().getModel("localModel");
            const aData = oModel.getProperty("/volumeBreakupData") || [];

            aData.push({
                variantYear: "",
                totalValue: "",
                editable: true
            });

            oModel.setProperty("/volumeBreakupData", aData);
        },

        onEditVolumeRow: function (oEvent) {
            const oModel = this.getView().getModel("localModel");
            const oContext = oEvent.getSource().getBindingContext("localModel");
            oModel.setProperty(oContext.getPath() + "/editable", true);
        },

        onSaveVolumeRow: function () {
            const oModel = this.getView().getModel("localModel");
            let aData = oModel.getProperty("/volumeBreakupData");

            if (!Array.isArray(aData)) {
                console.error("volumeBreakupData is not an array");
                return;
            }

            aData.forEach(function (row, index) {
                if (row && typeof row === "object") {
                    row.editable = false;
                } else {
                    console.warn("Row at index", index, "is not a valid object", row);
                }
            });

            oModel.setProperty("/volumeBreakupData", aData);
            sap.m.MessageToast.show("All changes saved.");
        },


        onCopyVolumeRow: function (oEvent) {
            const oModel = this.getView().getModel("localModel");
            const aData = oModel.getProperty("/volumeBreakupData");
            const oContext = oEvent.getSource().getBindingContext("localModel");
            const oRow = oContext.getObject();

            const oNewRow = Object.assign({}, oRow);
            oNewRow.editable = true;

            aData.push(oNewRow);
            oModel.setProperty("/volumeBreakupData", aData);
        },

        onDeleteVolumeRow: function (oEvent) {
            const oModel = this.getView().getModel("localModel");
            let aData = oModel.getProperty("/volumeBreakupData");
            const oContext = oEvent.getSource().getBindingContext("localModel");
            const iIndex = parseInt(oContext.getPath().split("/").pop());

            aData.splice(iIndex, 1);
            oModel.setProperty("/volumeBreakupData", aData);
        },

        onDeleteVolumeSelectedRowsPress: function () {
            const oTable = this.byId("AdpdVolumeBreakupTable");
            const aSelectedItems = oTable.getSelectedItems();
            if (!aSelectedItems.length) {
                sap.m.MessageToast.show("Please select at least one row to delete.");
                return;
            }

            const oModel = this.getView().getModel("localModel");
            let aData = oModel.getProperty("/volumeBreakupData");
            const aIndexes = aSelectedItems.map(item =>
                parseInt(item.getBindingContext("localModel").getPath().split("/").pop())
            ).sort((a, b) => b - a);

            aIndexes.forEach(i => aData.splice(i, 1));

            oModel.setProperty("/volumeBreakupData", aData);
            oTable.removeSelections(true);
        },



        /***********************
         * onSave 
         ***********************/
        _openInvestmentFragment: function (sMode, oData) {
            if (!this._oInvestmentFragment) {
                Fragment.load({
                    id: this.getView().getId(),
                    name: "com.mmapprovalhub.approvalhub.Fragments.InvestmentFragment",
                    controller: this
                }).then(function (oDialog) {
                    this._oInvestmentFragment = oDialog;
                    this.getView().addDependent(oDialog);
                    this._openInvestmentFragmentDialog(sMode, oData);
                }.bind(this));
            } else {
                this._openInvestmentFragmentDialog(sMode, oData);
            }
        },

        _openInvestmentFragmentDialog: function (sMode, oData) {
            var oModel = new JSONModel({
                mode: sMode,
                data: oData || {
                    description: "",
                    level: "",
                    capex: "",
                    revenue: "",
                    total: "",
                    remarks: ""
                }
            });
            this._oInvestmentFragment.setModel(oModel, "InvestmentFragmentModel");
            this._oInvestmentFragment.open();
        },

        onCancelInvestmentFragment: function () {
            this._oInvestmentFragment.close();
        },


        /***********************
         * onSave 
         ***********************/
        _openContingencyBalanceFragment: function (sMode, oData) {
            if (!this._oContingencyBalanceFragment) {
                Fragment.load({
                    id: this.getView().getId(),
                    name: "com.mmapprovalhub.approvalhub.Fragments.ContingencyBalanceFragment",
                    controller: this
                }).then(function (oDialog) {
                    this._oContingencyBalanceFragment = oDialog;
                    this.getView().addDependent(oDialog);
                    this._openContingencyBalanceFragmentDialog(sMode, oData);
                }.bind(this));
            } else {
                this._openContingencyBalanceFragmentDialog(sMode, oData);
            }
        },

        _openContingencyBalanceFragmentDialog: function (sMode, oData) {
            var oModel = new JSONModel({
                mode: sMode,
                data: oData || {
                    nrtCode: "",
                    label: "",
                    balancePrior: "",
                    amountToTransfer: "",
                    balancePost: "",
                    remarks: ""
                }
            });
            this._oContingencyBalanceFragment.setModel(oModel, "ContingencyBalanceFragmentModel");
            this._oContingencyBalanceFragment.open();
        },

        onSaveContingencyBalanceFragment: function () {
            var oModel = this._oContingencyBalanceFragment.getModel("ContingencyBalanceFragmentModel");
            var oData = oModel.getProperty("/data");
            var sMode = oModel.getProperty("/mode");
            var oContBalanceModel = this.getView().getModel("ContBalanceModel");
            var aData = oContBalanceModel.getProperty("/modelData") || [];
            var oBundle = this.getResourceBundle();

            if (!oData.WBSCode || !oData.transfAmountCurrApproval) {
                MessageToast.show(oBundle.getText("msgRequiredFields"));
                return;
            }

            var aNumericFields = ["priorBalance", "transfAmountCurrApproval", "balancePostTransfer"];
            for (var field of aNumericFields) {
                if (isNaN(parseFloat(oData[field]))) {
                    MessageToast.show(oBundle.getText("msgInvalidField", [field]));
                    return;
                }
                oData[field] = parseFloat(oData[field]) || 0;
            }

            if (sMode === "Add") {
                aData.push(oData);
            } else {
                var iIndex = this._oContingencyBalanceFragment.getBindingContext("ContBalanceModel")?.getIndex();
                if (iIndex !== undefined) {
                    aData[iIndex] = oData;
                }
            }

            oContBalanceModel.setProperty("/modelData", aData);
            this._oContingencyBalanceFragment.close();
            MessageToast.show(oBundle.getText(sMode === "Add" ? "msgContingencyBalanceRowAdded" : "msgContingencyBalanceRowUpdated"));
        },

        onCancelContingencyBalanceFragment: function () {
            this._oContingencyBalanceFragment.close();
        },


        /***********************
         * onSave 
         ***********************/
        getResourceBundle: function () {
            return this.getOwnerComponent().getModel("i18n").getResourceBundle();
        },

        onExit: function () {
            if (this._oWbsFragment) {
                this._oWbsFragment.destroy();
                this._oWbsFragment = null;
            }
            if (this._oRemarksFragment) {
                this._oRemarksFragment.destroy();
                this._oRemarksFragment = null;
            }
            if (this._oRecommendationFragment) {
                this._oRecommendationFragment.destroy();
                this._oRecommendationFragment = null;
            }
            if (this._oInvestmentFragment) {
                this._oInvestmentFragment.destroy();
                this._oInvestmentFragment = null;
            }
            if (this._oEstimatedCostFragment) {
                this._oEstimatedCostFragment.destroy();
                this._oEstimatedCostFragment = null;
            }
            if (this._oFinancialFragment) {
                this._oFinancialFragment.destroy();
                this._oFinancialFragment = null;
            }
            if (this._oContingencyBalanceFragment) {
                this._oContingencyBalanceFragment.destroy();
                this._oContingencyBalanceFragment = null;
            }
        },

        /***********************
         * onSave 
         ***********************/


        /***********************
         * onSave 
         ***********************/
        _collectFormData: function () {
            const oView = this.getView();
            return {
                initiator: oView.byId("AdpdInitiatorInp").getValue(),
                date: oView.byId("AdpdDateInput").getValue(),
                natureOfExpense: oView.byId("AdpdNatureExpSelect").getSelectedKey(),
                platform: oView.byId("AdpdPlatformSelect").getSelectedKey(),
                project: oView.byId("AdpdProjectSelect").getSelectedKey(),
                transferType: oView.byId("AdpdTransferTypeSelect").getSelectedKey(),
                forum: oView.byId("AdpdForumMultiSelect").getSelectedKey(),
                sopDate: oView.byId("AdpdContingencyBudgetDatePicker").getValue(),
                projectDesc: oView.byId("AdpdProjectDescInp").getValue(),
                justification: oView.byId("AdpdJustificationTxtArea").getValue(),
                materialCostImpact: oView.byId("AdpdMaterialCostRadioGroup").getSelectedIndex() === 0 ? "Yes" : "No",
                wbsData: this.getView().getModel("wbsModel").getProperty("/rows"),
                investmentData: this.getView().getModel("investmentModel").getProperty("/investmentData"),
                estimatedCostData: this.getView().getModel("estimatedCostModel").getProperty("/estimatedCostData"),
                financialData: this.getView().getModel("financialModel").getProperty("/financialData"),
                contingencyBalanceData: this.getView().getModel("contBalanceModel").getProperty("/modelData"),
                volumeBreakupData: this.getView().getModel("localModel").getProperty("/volumeBreakupData"),
                recommendations: this.getView().getModel("interlineModel").getProperty("/recommendations"),
                attachments: this.getView().getModel("UploadDocSrvTabData").getProperty("/allUploadtABFilesDataCheck")
            };
        },
        onRejectDataADPDForm: function () {
            var isValid = true;
            var oView = this.getView();
            var sInitiator = oView.byId("AdpdInitiatorInp")?.getValue();
            var sDate = oView.byId("AdpdDateInput")?.getValue();
            var sJustification = oView.byId("AdpdJustificationTxtArea")?.getValue();
            var sProject = oView.byId("AdpdProjectSelect")?.getSelectedKey();
            var sProjectDesc = oView.byId("AdpdProjectDescInp")?.getValue();
            var sForum = oView.byId("AdpdForumMultiSelect")?.getSelectedKey();
            var sPlatform = oView.byId("AdpdPlatformSelect")?.getSelectedKey();
          
            var oView = this.getView();
            oView.getModel("viewenableddatacheck").setProperty("/remarkModel", "");

            // sap.ui.getCore().byId("RemarkInput").setValue("");
            oView.getModel("viewenableddatacheck").setProperty("/approvebuttonfragment", true);
            oView.getModel("viewenableddatacheck").setProperty("/rejetedbuttonfragmnet", true);
            oView.getModel("viewenableddatacheck").setProperty("/enableRowActions", false);
            oView.getModel("viewenableddatacheck").setProperty("/enableRowActions", false);

            oView.getModel("viewenableddatacheck").setProperty("/sendbackbuttonvisiblity", true);
            oView.getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblityData", false);
            this._remarkFragment.then(function (oDialog) {
                oDialog.open();
            });
        },
        onApprovedADPDform: function () {
            var isValid = true;
            var oView = this.getView();
            var sInitiator = oView.byId("AdpdInitiatorInp")?.getValue();
            var sDate = oView.byId("AdpdDateInput")?.getValue();
            var sJustification = oView.byId("AdpdJustificationTxtArea")?.getValue();
            var sProject = oView.byId("AdpdProjectSelect")?.getSelectedKey();
            var sProjectDesc = oView.byId("AdpdProjectDescInp")?.getValue();
            var sForum = oView.byId("AdpdForumMultiSelect")?.getSelectedKey();
            var sPlatform = oView.byId("AdpdPlatformSelect")?.getSelectedKey();
            // var aFieldsToValidate = [
            //     { id: "AdpdInitiatorInp", value: sInitiator },
            //     { id: "AdpdPlatformSelect", value: sPlatform },
            //     { id: "AdpdProjectSelect", value: sProject },
            //     { id: "AdpdProjectDescInp", value: sProjectDesc },
            //     { id: "AdpdJustificationTxtArea", value: sJustification }
            // ];

            // aFieldsToValidate.forEach(function (field) {
            //     var oInput = oView.byId(field.id);
            //     if (!field.value) {
            //         oInput.setValueState("Error");
            //         isValid = false;
            //     } else {
            //         oInput.setValueState("None");
            //     }
            // });

            // if (!isValid) {
            //     MessageToast.show("Please fill in all mandatory fields.");
            //     return;
            // }
            var oView = this.getView();
            oView.getModel("viewenableddatacheck").setProperty("/remarkModel", "");

           var stagesData =  this.stagesData;
           if(stagesData === "Head"){
            var oRadioGroup = this.byId("financeheadData");
            var iSelectedIndex = oRadioGroup.getSelectedIndex();
            if (iSelectedIndex === -1) {
                MessageBox.warning("Please select an option for 'Is Finance HOD approving on behalf of President/CFO/ED?'");
                return; 
            }
           }

            // sap.ui.getCore().byId("RemarkInput").setValue("");
            oView.getModel("viewenableddatacheck").setProperty("/approvebuttonfragment", true);
            oView.getModel("viewenableddatacheck").setProperty("/rejetedbuttonfragmnet", true);
            oView.getModel("viewenableddatacheck").setProperty("/enableRowActions", false);
            oView.getModel("viewenableddatacheck").setProperty("/enableRowActions", false);

            oView.getModel("viewenableddatacheck").setProperty("/sendbackbuttonvisiblity", false);
            oView.getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblityData", true);
            this._remarkFragment.then(function (oDialog) {
                oDialog.open();
            });
        },
        onLocationSenca: function(oEvent) {
            this.onComboBoxChange(oEvent);
        },
        onSubmitAdpd: function () {
            var isValid = true;
            var oView = this.getView();
            var subType = this._subTypeDataforui;
            if(subType === "IIIT"){
                var isValid = true;
                var oView = this.getView();
                var controls = [
                    { control: oView.byId("AdpdPlatformSelect"), field: "Platform" },
                    { control: oView.byId("AdpdProjectSelect"), field: "Project" },
                    { control: oView.byId("AdpdNatureExpSelect"), field: "Nature of Expense" },
                    { control: oView.byId("AdpdTransferTypeSelect"), field: "Transfer Type" },
                    { control: oView.byId("AdpdJustificationTxtArea"), field: "Justification" },
                    { control: oView.byId("AdpdProjectFinHeadCombo"), field: "Project Finance Head" },
                    { control: oView.byId("AdpdFinanceInput"), field: "Finance Member" },
                ];
                var missingFields = [];
                controls.forEach(function(item) {
                    item.control.setValueState("None"); 
                    var value = item.control.getValue ? item.control.getValue() : item.control.getValue(); 
                    if (!value) {
                        item.control.setValueState("Error");
                        if (item.control instanceof sap.m.TextArea) {
                            item.control.setValueStateText(item.field + " is required");
                        }
                        isValid = false;
                        missingFields.push(item.field);
                    } else if (item.control.getId().includes("inputHour")) {
                        var hours = parseFloat(value);
                        if (isNaN(hours) || hours <= 0) {
                            item.control.setValueState("Error");
                            if (item.control instanceof sap.m.TextArea) {
                                item.control.setValueStateText(item.field + " must be a positive number");
                            }
                            isValid = false;
                            missingFields.push(item.field + " (must be a positive number)");
                        }
                    }
                });
                if (!isValid) {
                    var errorMessage = "Please fill all required fields: " + missingFields.join(", ");
                    MessageBox.error(errorMessage);
                    return;
                }
            }else if(subType === "CBU" || subType === "PS"  || subType === "BA" || subType === "CO" || subType === "PPBA" ){
                var isValid = true;
                var oView = this.getView();
                var controls = [
                    { control: oView.byId("AdpdPlatformSelect"), field: "Platform" },
                    { control: oView.byId("AdpdProjectSelect"), field: "Project" },
                    { control: oView.byId("AdpdJustificationTxtArea"), field: "Justification" },
                    { control: oView.byId("AdpdProjectFinHeadCombo"), field: "Project Finance Head" },
                    { control: oView.byId("AdpdFinanceInput"), field: "Finance Member" },
                ];
                var missingFields = [];
                controls.forEach(function(item) {
                    item.control.setValueState("None"); 
                    var value = item.control.getValue ? item.control.getValue() : item.control.getValue(); 
                    if (!value) {
                        item.control.setValueState("Error");
                        if (item.control instanceof sap.m.TextArea) {
                            item.control.setValueStateText(item.field + " is required");
                        }
                        isValid = false;
                        missingFields.push(item.field);
                    } else if (item.control.getId().includes("inputHour")) {
                        var hours = parseFloat(value);
                        if (isNaN(hours) || hours <= 0) {
                            item.control.setValueState("Error");
                            if (item.control instanceof sap.m.TextArea) {
                                item.control.setValueStateText(item.field + " must be a positive number");
                            }
                            isValid = false;
                            missingFields.push(item.field + " (must be a positive number)");
                        }
                    }
                });
                if (!isValid) {
                    var errorMessage = "Please fill all required fields: " + missingFields.join(", ");
                    MessageBox.error(errorMessage);
                    return;
                }
            }else if(subType === "EXIG"){
                var isValid = true;
                var oView = this.getView();
                var controls = [
                    { control: oView.byId("AdpdPlatformSelect"), field: "Platform" },
                    { control: oView.byId("AdpdProjectSelect"), field: "Project" },
                    { control: oView.byId("AdpdNatureExpSelect"), field: "Nature of Expense" },
                    { control: oView.byId("AdpdJustificationTxtArea"), field: "Justification" },
                    { control: oView.byId("AdpdProjectFinHeadCombo"), field: "Project Finance Head" },
                    { control: oView.byId("AdpdFinanceInput"), field: "Finance Member" },
                ];
                var missingFields = [];
                controls.forEach(function(item) {
                    item.control.setValueState("None"); 
                    var value = item.control.getValue ? item.control.getValue() : item.control.getValue(); 
                    if (!value) {
                        item.control.setValueState("Error");
                        if (item.control instanceof sap.m.TextArea) {
                            item.control.setValueStateText(item.field + " is required");
                        }
                        isValid = false;
                        missingFields.push(item.field);
                    } else if (item.control.getId().includes("inputHour")) {
                        var hours = parseFloat(value);
                        if (isNaN(hours) || hours <= 0) {
                            item.control.setValueState("Error");
                            if (item.control instanceof sap.m.TextArea) {
                                item.control.setValueStateText(item.field + " must be a positive number");
                            }
                            isValid = false;
                            missingFields.push(item.field + " (must be a positive number)");
                        }
                    }
                });
                if (!isValid) {
                    var errorMessage = "Please fill all required fields: " + missingFields.join(", ");
                    MessageBox.error(errorMessage);
                    return;
                }
            }
            if(subType === "IIIT" || subType === "CBU" || subType === "PS" || subType === "EXIG" || subType === "BA" || subType === "CO" ){
                var aWbsRows = oView.getModel("wbsModel").getProperty("/rows");
                if (!aWbsRows || aWbsRows.length === 0) {
                    sap.m.MessageBox.warning("Budget Transfer Table must have at least one row.");
                    return;
                }
            }
          
            
            var sInitiator = oView.byId("AdpdInitiatorInp")?.getValue();
            var sDate = oView.byId("AdpdDateInput")?.getValue();
            var sJustification = oView.byId("AdpdJustificationTxtArea")?.getValue();
            var sProject = oView.byId("AdpdProjectSelect")?.getValue();
            var sProjectDesc = oView.byId("AdpdProjectDescInp")?.getValue();
            var sForum = oView.byId("AdpdForumMultiSelect")?.getValue();
            var sPlatform = oView.byId("AdpdPlatformSelect")?.getValue();
         
            var oView = this.getView();
            oView.getModel("viewenableddatacheck").setProperty("/remarkModel", "");

            // sap.ui.getCore().byId("RemarkInput").setValue("");
            oView.getModel("viewenableddatacheck").setProperty("/approvebuttonfragment", false);
            oView.getModel("viewenableddatacheck").setProperty("/rejetedbuttonfragmnet", false);
            oView.getModel("viewenableddatacheck").setProperty("/enableRowActions", true);
            oView.getModel("viewenableddatacheck").setProperty("/sendbackbuttonvisiblity", false);
            oView.getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblityData", false);
            this._remarkFragment.then(function (oDialog) {
                oDialog.open();
            });
        },
        _constructPayloadSubmit: function () {
            var oView = this.getView();
            var InitateDataVlaue =  this._sApprovalDataInitiate;
            // Extract field values
            var sInitiator = oView.byId("AdpdInitiatorInp")?.getValue() || "", // Set from session or user model
                sProject = oView.byId("AdpdProjectSelect")?.getValue() || "",
                sProjectDesc = oView.byId("AdpdProjectDescInp")?.getValue() || "",
                sJustification = oView.byId("AdpdJustificationTxtArea")?.getValue() || "",
                sTransType = oView.byId("AdpdTransferTypeSelect")?.getValue() || "",
                sNatureOfExpense = oView.byId("AdpdNatureExpSelect")?.getValue() || "",
                sNatureOfApproval = oView.byId("AdpdNatureOfApprovalInput")?.getValue() || "", // need to find
                sPlatform = oView.byId("AdpdPlatformSelect")?.getValue() || "",
                sForum = oView.byId("AdpdForumMultiSelect")?.getValue() || "",
                sProjFinHead = oView.byId("AdpdProjectFinHeadCombo")?.getValue() || "financehead@example.com",
                sSopDate = oView.byId("AdpdSopDateInput")?.getValue() || "",
                // sOnBehalfFlag = oView.byId("AdpdOnBehalfCheckBox")?.getSelected() ? "Yes" : "No",
                sFinalApprover1 = oView.byId("AdpdFinalApprover1")?.getValue() || "",
                sFinalApprover2 = oView.byId("AdpdFinalApprover2")?.getValue() || "",
                sFinalApprover3 = oView.byId("AdpdFinalApprover3")?.getValue() || "";
            var  finCaseImpact = oView.byId("finCaseImpactTextArea")?.getValue() || "";
            var sCPH = oView.byId("AdpdCphInput")?.getValue() || "";
            var sPEH = oView.byId("AdpdPehInput")?.getValue() || "";
            var sPPM = oView.byId("AdpdPpmInput")?.getValue() || "";
            var sPNH = oView.byId("AdpdPnhInput")?.getValue() || "";
            var sPPH = oView.byId("AdpdPphInput")?.getValue() || "";
            var sPFH = oView.byId("AdpdPfhInput")?.getValue() || "";
            var sSrGM = oView.byId("AdpdSrGmCombo")?.getValue() || "";
            var sSrVP = oView.byId("AdpdSrVpCombo")?.getValue() || "";
            var sFinMember = oView.byId("AdpdFinanceInput")?.getValue() || "";

            var oRadioGroup = oView.byId("AdpdMaterialCostRadioGroup");
            var iSelectedIndex = oRadioGroup.getSelectedIndex();
            var oButtons = oRadioGroup.getButtons();
            var sSelectedText = null;
            if (iSelectedIndex !== -1) {
                sSelectedText = oButtons[iSelectedIndex].getText(); 
            }
            var finalValue = null;
            if (sSelectedText === this.getView().getModel("i18n").getResourceBundle().getText("yesOption")) {
                finalValue = true;
            } else if (sSelectedText === this.getView().getModel("i18n").getResourceBundle().getText("noOption")) {
                finalValue = false;
            } else {
                finalValue = null; 
            }
            var oRadioGroupCon = oView.byId("AdpdNewMaterialCostRadioConten");
            var iSelectedIndexCon = oRadioGroupCon.getSelectedIndex();
            var oButtonsCon = oRadioGroup.getButtons();
            var sSelectedTextCon = null;
            if (iSelectedIndexCon !== -1) {
                sSelectedTextCon = oButtonsCon[iSelectedIndexCon].getText(); 
            }
            var finalValueCon = null;
            if (sSelectedTextCon === this.getView().getModel("i18n").getResourceBundle().getText("yesOption")) {
                finalValueCon = true;
            } else if (sSelectedTextCon === this.getView().getModel("i18n").getResourceBundle().getText("noOption")) {
                finalValueCon = false;
            } else {
                finalValueCon = null; 
            }

            var oRadioGroupFin = oView.byId("financeheadData");
            var iSelectedIndexFin = oRadioGroupFin.getSelectedIndex();
            var oButtonsFIn = oRadioGroupFin.getButtons();
            var sSelectedTextFIn = null;
            if (iSelectedIndexFin !== -1) {
                sSelectedTextFIn = oButtonsFIn[iSelectedIndexFin].getText(); 
            }
            var finalValueFin = null;
            if (sSelectedTextFIn === this.getView().getModel("i18n").getResourceBundle().getText("yesOption")) {
                finalValueFin = true;
            } else if (sSelectedTextFIn === this.getView().getModel("i18n").getResourceBundle().getText("noOption")) {
                finalValueFin = false;
            } else {
                finalValueFin = null; 
            }
            var selfDecFlag = this.getView().getModel("viewenableddatacheck").getProperty("/selfDecFlag");
            var oWbsModel = oView.getModel("wbsModel");
            var oMaterialCost = oView.getModel("materialcostData");
            var oFinanceData = oView.getModel("FinancialModel");
            var oParkedModel = oView.getModel("contBalanceModel");
            var oInvestModel = oView.getModel("InvestmentModel");
            var oAttachmentModel = oView.getModel("UploadDocSrvTabData");
            var oApproverModel = oView.getModel("ApproversLocalModel");
          var subtype =   this._subTypeDataforui
          var statusData = this.statusData;
          var satauscheckdata = this.statusData;
            if(statusData === "Sent Back"){
                satauscheckdata = "Sent Back"
            }
            var oPayload = {
                status: satauscheckdata,
                type: "ADPD",
                adpdDtl: {
                    subType: subtype, // Static or derived
                    Initiator: sInitiator,
                    Project: sProject,
                    projectDesc: sProjectDesc,
                    Justification: sJustification,
                    transType: sTransType,
                    natureOfExpense: sNatureOfExpense,
                    natureOfApproval: sNatureOfApproval,
                    Platform: sPlatform,
                    Forum: sForum,
                    selfDecFlag:selfDecFlag,
                    ImpactOnMatFlag  :finalValue,
                    ContingIOM: finalValueCon,
                    InitiationFlag  : InitateDataVlaue,
                    projFinHead: sProjFinHead,
                    sopDate: sSopDate,
                    onBehalfFlag: finalValueFin,
                    finCaseImpact:finCaseImpact,
                    CPH: sCPH,
                    PEH: sPEH,
                    PPM: sPPM,
                    PNH: sPNH,
                    PPH: sPPH,
                    PFH: sPFH,
                    finMember: sFinMember,
                    SrGM: sSrGM,
                    SrVP: sSrVP,
                    // onBehalfFlag: sOnBehalfFlag,
                    FinalApprover1: sFinalApprover1,
                    FinalApprover2: sFinalApprover2,
                    FinalApprover3: sFinalApprover3,

                    expenseDtl: (oWbsModel?.getProperty("/rows") || []).map(function (oRow) {
                        function toDecimal(val) {
                            return val && !isNaN(val) ? parseFloat(val).toFixed(2) : "0.00";
                        }
                        return {
                            fromWBSCode: oRow.fromWBSCode || "",
                            toWBSCode: oRow.toWBSCode || "",
                            fromWBSLoc: oRow.fromWBSLoc || "",
                            toWBSLoc: oRow.toWBSLoc || "",
                            fromWBSLevel: oRow.fromWBSLevel || "",
                            toWBSLevel: oRow.toWBSLevel || "",
                            capexNRT: toDecimal(oRow.capexNRT),
                            capexLanded: toDecimal(oRow.capexLanded),
                            revenueNRT: toDecimal(oRow.revenueNRT),
                            revenueLanded: toDecimal(oRow.revenueLanded),
                            totalNRT: toDecimal(oRow.totalNRT),
                            totalLanded: toDecimal(oRow.totalLanded),
                            remarks: oRow.remarks || "",
                            WBSCode: oRow.toWBSCode || "",
                            WBSLoc: oRow.toWBSLoc || "",
                            WBSLevel: oRow.toWBSLevel || ""
                        };
                    }),
                    matcostDtl: (oMaterialCost?.getProperty("/matcostDtl") || []).map(function (oRow) {
                        return {
                            item: oRow.item || "",
                            vehicleLevel: oRow.vehicleLevel || "",
                            ptdLevel: oRow.ptdLevel || "",
                            totalLevel: oRow.totalLevel || "",
                        };
                    }),
                    ProjCostDtl: (oFinanceData?.getProperty("/rows") || []).map(function (oRow) {
                        return {
                            capex: oRow.capex || "",
                            revenue: oRow.revenue || "",
                            totalProjCost: oRow.totalProjCost || "",
                            tenPercentOfTotalCost: oRow.tenPercentOfTotalCost || "",
                        };
                    }),
                   parkedSDtl: (oParkedModel?.getProperty("/modelData") || []).map(function (oRow) {
                        return {
                            level: String(oRow.level || ""),
                            WBSCode: String(oRow.WBSCode || ""),
                            priorBalance: String(oRow.priorBalance || "0"),
                            transfAmountCurrApproval: String(oRow.transfAmountCurrApproval || "0"),
                            balancePostTransfer: String(oRow.balancePostTransfer || "0"),
                            remarks: String(oRow.remarks || "")
                        };
                    }),

                    investDtl: (oInvestModel?.getProperty("/investmentData") || []).map(function (oRow) {
                        return {
                            natureOfExpense: String(oRow.natureOfExpense || ""),
                            level: String(oRow.level || ""),
                            capex: String(oRow.capex || "0"),
                            revenue: String(oRow.revenue || "0"),
                            total: String(oRow.total || "0"),
                            remarks: String(oRow.remarks || "")
                        };
                    })
                },

                // processLogs: [{
                //     role: "R1",
                //     status: "Pending",
                //     receivedDt: new Date().toISOString()
                // }],

                // recomApprovers: aRecomApprovers,

                attachments: oAttachmentModel?.getProperty("/attachments") || []
            };

            return oPayload;
        },
        _constructPayload: function () {
            var oView = this.getView();
            var InitateDataVlaue =  this._sApprovalDataInitiate
            // Extract field values
            var sInitiator = oView.byId("AdpdInitiatorInp")?.getValue() || "", // Set from session or user model
                sProject = oView.byId("AdpdProjectSelect")?.getValue() || "",
                sProjectDesc = oView.byId("AdpdProjectDescInp")?.getValue() || "",
                sJustification = oView.byId("AdpdJustificationTxtArea")?.getValue() || "",
                sTransType = oView.byId("AdpdTransferTypeSelect")?.getValue() || "",
                sNatureOfExpense = oView.byId("AdpdNatureExpSelect")?.getValue() || "",
                sNatureOfApproval = oView.byId("AdpdNatureOfApprovalInput")?.getValue() || "", // need to find
                sPlatform = oView.byId("AdpdPlatformSelect")?.getValue() || "",
                sForum = oView.byId("AdpdForumMultiSelect")?.getValue() || "",
                sProjFinHead = oView.byId("AdpdProjectFinHeadCombo")?.getValue() || "financehead@example.com",
                sSopDate = oView.byId("AdpdSopDateInput")?.getValue() || "",
               
                // sOnBehalfFlag = oView.byId("AdpdOnBehalfCheckBox")?.getSelected() ? "Yes" : "No",
                sFinalApprover1 = oView.byId("AdpdFinalApprover1")?.getValue() || "",
                sFinalApprover2 = oView.byId("AdpdFinalApprover2")?.getValue() || "",
                sFinalApprover3 = oView.byId("AdpdFinalApprover3")?.getValue() || "";
           var  finCaseImpact = oView.byId("finCaseImpactTextArea")?.getValue() || "";
            var sCPH = oView.byId("AdpdCphInput")?.getValue() || "";
            var sPEH = oView.byId("AdpdPehInput")?.getValue() || "";
            var sPPM = oView.byId("AdpdPpmInput")?.getValue() || "";
            var sPNH = oView.byId("AdpdPnhInput")?.getValue() || "";
            var sPPH = oView.byId("AdpdPphInput")?.getValue() || "";
            var sPFH = oView.byId("AdpdPfhInput")?.getValue() || "";
            var sSrGM = oView.byId("AdpdSrGmCombo")?.getValue() || "";
            var sSrVP = oView.byId("AdpdSrVpCombo")?.getValue() || "";
            var sFinMember = oView.byId("AdpdFinanceInput")?.getValue() || "";
            var oRadioGroup = oView.byId("AdpdMaterialCostRadioGroup");
            var iSelectedIndex = oRadioGroup.getSelectedIndex();
            var oButtons = oRadioGroup.getButtons();
            var sSelectedText = null;
            if (iSelectedIndex !== -1) {
                sSelectedText = oButtons[iSelectedIndex].getText(); 
            }
            var finalValue = null;
            if (sSelectedText === this.getView().getModel("i18n").getResourceBundle().getText("yesOption")) {
                finalValue = true;
            } else if (sSelectedText === this.getView().getModel("i18n").getResourceBundle().getText("noOption")) {
                finalValue = false;
            } else {
                finalValue = null; 
            }
            var oRadioGroupCon = oView.byId("AdpdNewMaterialCostRadioConten");
            var iSelectedIndexCon = oRadioGroupCon.getSelectedIndex();
            var oButtonsCon = oRadioGroup.getButtons();
            var sSelectedTextCon = null;
            if (iSelectedIndexCon !== -1) {
                sSelectedTextCon = oButtonsCon[iSelectedIndexCon].getText(); 
            }
            var finalValueCon = null;
            if (sSelectedTextCon === this.getView().getModel("i18n").getResourceBundle().getText("yesOption")) {
                finalValueCon = true;
            } else if (sSelectedTextCon === this.getView().getModel("i18n").getResourceBundle().getText("noOption")) {
                finalValueCon = false;
            } else {
                finalValueCon = null; 
            }


            var selfDecFlag = this.getView().getModel("viewenableddatacheck").getProperty("/selfDecFlag");

           
            var oWbsModel = oView.getModel("wbsModel");
            var oMaterialCost = oView.getModel("materialcostData");
            var oFinanceData = oView.getModel("FinancialModel");

            var oParkedModel = oView.getModel("contBalanceModel");
            var oInvestModel = oView.getModel("InvestmentModel");
            var oAttachmentModel = oView.getModel("UploadDocSrvTabData");
            var oApproverModel = oView.getModel("ApproversLocalModel");

            // Prepare recommended approvers
            // var aRecomApprovers = [];
            // if (oApproverModel) {
            //     var aApproverData = oApproverModel.getProperty("/results") || [];
            //     aRecomApprovers = aApproverData.map(function (item) {
            //         return {
            //             Role: item.role || "",
            //             Approvers: item.email || item.userId || "" // adjust based on available field
            //         };
            //     });
            // }
            var statusData = this.statusData || "Draft";
            var satauscheckdata = statusData === "Pending" ? "Pending" : "Draft";
            if(statusData === "Sent Back"){
                satauscheckdata = "Sent Back"
            }
          var subtype =   this._subTypeDataforui
            var oPayload = {
                stage: satauscheckdata,
                status: satauscheckdata,
                type: "ADPD",
                adpdDtl: {
                    subType: subtype, // Static or derived
                    Initiator: sInitiator,
                    Project: sProject,
                    projectDesc: sProjectDesc,
                    Justification: sJustification,
                    transType: sTransType,
                    natureOfExpense: sNatureOfExpense,
                    natureOfApproval: sNatureOfApproval,
                    Platform: sPlatform,
                    ImpactOnMatFlag  :finalValue,
                    ContingIOM: finalValueCon,
                    Forum: sForum,
                    selfDecFlag:selfDecFlag,
                    projFinHead: sProjFinHead,
                    sopDate: sSopDate,
                    InitiationFlag  : InitateDataVlaue,
                    finCaseImpact:finCaseImpact,
                    CPH: sCPH,
                    PEH: sPEH,
                    PPM: sPPM,
                    PNH: sPNH,
                    PPH: sPPH,
                    PFH: sPFH,
                    finMember: sFinMember,
                    SrGM: sSrGM,
                    SrVP: sSrVP,
                    // onBehalfFlag: sOnBehalfFlag,
                    FinalApprover1: sFinalApprover1,
                    FinalApprover2: sFinalApprover2,
                    FinalApprover3: sFinalApprover3,
                    expenseDtl: (oWbsModel?.getProperty("/rows") || []).map(function (oRow) {
                        function toDecimal(val) {
                            return val && !isNaN(val) ? parseFloat(val).toFixed(2) : "0.00";
                        }
                    
                        return {
                            fromWBSCode: oRow.fromWBSCode || "",
                            toWBSCode: oRow.toWBSCode || "",
                            fromWBSLoc: oRow.fromWBSLoc || "",
                            toWBSLoc: oRow.toWBSLoc || "",
                            fromWBSLevel: oRow.fromWBSLevel || "",
                            toWBSLevel: oRow.toWBSLevel || "",
                            capexNRT: toDecimal(oRow.capexNRT),
                            capexLanded: toDecimal(oRow.capexLanded),
                            revenueNRT: toDecimal(oRow.revenueNRT),
                            revenueLanded: toDecimal(oRow.revenueLanded),
                            totalNRT: toDecimal(oRow.totalNRT),
                            totalLanded: toDecimal(oRow.totalLanded),
                            remarks: oRow.remarks || "",
                            WBSCode: oRow.toWBSCode || "",
                            WBSLoc: oRow.toWBSLoc || "",
                            WBSLevel: oRow.toWBSLevel || ""
                        };
                    }),
                    matcostDtl: (oMaterialCost?.getProperty("/matcostDtl") || []).map(function (oRow) {
                        return {
                            item: oRow.item || "",
                            vehicleLevel: oRow.vehicleLevel || "",
                            ptdLevel: oRow.ptdLevel || "",
                            totalLevel: oRow.totalLevel || "",
                        };
                    }),
                    ProjCostDtl: (oFinanceData?.getProperty("/rows") || []).map(function (oRow) {
                        return {
                            capex: oRow.capex || "",
                            revenue: oRow.revenue || "",
                            totalProjCost: oRow.totalProjCost || "",
                            tenPercentOfTotalCost: oRow.tenPercentOfTotalCost || "",
                        };
                    }),

                    parkedSDtl: (oParkedModel?.getProperty("/modelData") || []).map(function (oRow) {
                        return {
                            level: String(oRow.level || ""),
                            WBSCode: String(oRow.WBSCode || ""),
                            priorBalance: String(oRow.priorBalance || "0"),
                            transfAmountCurrApproval: String(oRow.transfAmountCurrApproval || "0"),
                            balancePostTransfer: String(oRow.balancePostTransfer || "0"),
                            remarks: String(oRow.remarks || "")
                        };
                    }),
                    investDtl: (oInvestModel?.getProperty("/investmentData") || []).map(function (oRow) {
                        return {
                            natureOfExpense: String(oRow.natureOfExpense || ""),
                            level: String(oRow.level || ""),
                            capex: String(oRow.capex || "0"),
                            revenue: String(oRow.revenue || "0"),
                            total: String(oRow.total || "0"),
                            remarks: String(oRow.remarks || "")
                        };
                    })
                    
                },

              

                // recomApprovers: aRecomApprovers,

                attachments: oAttachmentModel?.getProperty("/attachments") || []
            };

            return oPayload;
        },
        _constructSaveAdpdPayload: function () {
            var oView = this.getView();
            var oWbsModel = oView.getModel("wbsModel");
            var oInterlineModel = oView.getModel("InterlineModel");
            var oPlatformRoleModel = oView.getModel("platformRoleModel");

            var sReqID = this.reqID;
            var sInitiator = oView.byId("AdpdInitiatorInp")?.getValue() || "";
            var sDate = oView.byId("AdpdDateInput")?.getValue() || "";
            var sJustification = oView.byId("AdpdJustificationTxtArea")?.getValue() || "";
            var sNatureOfExpense = oView.byId("AdpdNatureExpSelect")?.getSelectedKey() || "";
            var sProject = oView.byId("AdpdProjectSelect")?.getSelectedKey() || "";
            var sProjectDesc = oView.byId("AdpdProjectDescInp")?.getValue() || "";
            var sTransType = oView.byId("AdpdTransferTypeSelect")?.getSelectedKey() || "";
            var sForum = oView.byId("AdpdForumMultiSelect")?.getSelectedKey() || "";
            var sPlatform = oView.byId("AdpdPlatformSelect")?.getValue() || "";
            var sProjFinHead = oView.byId("AdpdProjectFinHeadCombo")?.getSelectedKey() || "financehead@example.com";

            var sCPH = oView.byId("AdpdCphInput")?.getSelectedKey() || "";
            var sPEH = oView.byId("AdpdPehInput")?.getSelectedKey() || "";
            var sPPM = oView.byId("AdpdPpmInput")?.getSelectedKey() || "";
            var sPNH = oView.byId("AdpdPnhInput")?.getSelectedKey() || "";
            var sPPH = oView.byId("AdpdPphInput")?.getSelectedKey() || "";
            var sPFH = oView.byId("AdpdPfhInput")?.getSelectedKey() || "";
            var sFinMember = oView.byId("AdpdFinanceInput")?.getValue() || "";
            var sSrGM = oView.byId("AdpdSrGmCombo")?.getValue() || "";
            var sSrVP = oView.byId("AdpdSrVpCombo")?.getValue() || "";

            var oAdpd = {
                // reqID: sReqID,
                Initiator: sInitiator,
                natureOfExpense: sNatureOfExpense,
                Project: sProject,
                projectDesc: sProjectDesc,
                transType: sTransType,
                Forum: sForum,
                Justification: sJustification,
                Platform: sPlatform,
                projFinHead: sProjFinHead,
                expenseDtl: (oWbsModel.getProperty("/rows") || []).map(function (oRow) {
                    return {
                        reqID: sReqID,
                        fromWBSCode: oRow.fromWbsCode || "",
                        toWBSCode: oRow.toWbsCode || "",
                        fromWBSLoc: oRow.fromWbsLocation || "",
                        toWBSLoc: oRow.toWbsLocation || "",
                        fromWBSLevel: oRow.fromWbsLevel || "",
                        toWBSLevel: oRow.toWbsLevel || "",
                        CPH: sCPH || oRow.CPH || "",
                        PEH: sPEH || oRow.PEH || "",
                        PPM: sPPM || oRow.PPM || "",
                        PNH: sPNH || oRow.PNH || "",
                        PPH: sPPH || oRow.PPH || "",
                        PFH: sPFH || oRow.PFH || "",
                        finMember: sFinMember || oRow.finMember || "",
                        SrGM: sSrGM || oRow.SrGM || "",
                        SrVP: sSrVP || oRow.SrVP || "",
                        capexNRT: oRow.capexNrt || "",
                        capexLanded: oRow.capexLanded || "",
                        revenueNRT: oRow.revenueNrt || "",
                        revenueLanded: oRow.revenueLanded || "",
                        totalNRT: oRow.totalNrt || "",
                        totalLanded: oRow.totalLanded || "",
                        Action: oRow.Action || "Initiated"
                    };
                })
            };

            // return oPayload;
        },
        onCloseReamrksFrag: function () {
            this._remarkFragment.then(function (oDialog) {
                oDialog.close();
            });
        },

        // onSubmitReamrksData: function () {
        //     var that = this;
        //     var reqid = this._reqIDData
        //     var statusData = this.statusData;
        //     var sRemarks = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
        //     if (sRemarks === "") {
        //         sap.m.MessageBox.information("Please provide a remark before submitting.");
        //         return;
        //     }
        //     var oPartialPayload = this._constructPayload();

        //     var oSubmitPayload = {
        //     // pendingWith: "",
        //         stage: "L1",
        //         status: "Pending",
        //         type: "ADPD",
        //         // currApprover: "approver@gmail.com",
        //         remarks: sRemarks,
        //         adpdDtl: oPartialPayload.adpdDtl,
        //         // recomApprovers: oPartialPayload.recomApprovers
        //     };


        //     // Compare with last submitted payload to prevent duplicates
        //     // var sCurrentPayloadHash = JSON.stringify(oSubmitPayload);
        //     // if (this._lastSubmittedPayload === sCurrentPayloadHash) {
        //     //     MessageBox.error("This request has already been submitted with the same data. Please modify the input before resubmitting.");
        //     //     return;
        //     // }

        //     var oModel = this.getOwnerComponent().getModel("approvalservicev2");
        //     var that = this;
        //     if (!this._reqIDData) {
        //         // oModel.create("/Requests", oSubmitPayload, {
        //         //     success: function (oData) {

        //         //         that._reqIDData = oData.reqID;
        //         //         // that._lastSubmittedPayload = sCurrentPayloadHash;
        //         //         var reqid = oData.reqID;
        //         //         that.attachmentuploadFilesData(reqid);

        //         //         if (oData) {
        //         //             var oComponent = that.getOwnerComponent();
        //         //             var oRequestServiceModel = oComponent.getModel("Requestservicemodel");
        //         //             if (!oRequestServiceModel) {
        //         //                 oRequestServiceModel = new sap.ui.model.json.JSONModel();
        //         //                 oComponent.setModel(oRequestServiceModel, "Requestservicemodel");
        //         //             }
        //         //             oRequestServiceModel.setData(oData);

        //         //         }
        //         //         that._remarkFragment.then(function (oDialog) {
        //         //             oDialog.close();
        //         //         });

        //         //         // that.attachmentuploadFilesData(oData.reqID);

        //         //         // MessageBox.success("Request " + oData.reqID + " has been created and submitted successfully!");
        //         //         MessageBox.success("Request " + oData.reqID + " has been created successfully!", {
        //         //             title: "Success",
        //         //             actions: [MessageBox.Action.OK],
        //         //             onClose: function (oAction) {
        //         //                 if (oAction === MessageBox.Action.OK) {
        //         //                     var oRouter = that.getOwnerComponent().getRouter();
        //         //                     oRouter.navTo("DashboardUI", {
        //         //                         Name: "ADPD"
        //         //                     });
        //         //                 }
        //         //             }
        //         //         });

        //         //     },
        //         //     error: function (oError) {
        //         //         MessageToast.show("Error creating request: " + oError.message);
        //         //     }
        //         oModel.create("/Requests", oSubmitPayload, {
        //             success: function (oData) {
        //                 that._reqIDData = oData.reqID;
        //                 var reqid = oData.reqID;
        //                 that.attachmentuploadFilesData(reqid);

        //                 if (oData) {
        //                     var oComponent = that.getOwnerComponent();
        //                     var oRequestServiceModel = oComponent.getModel("Requestservicemodel");
        //                     if (!oRequestServiceModel) {
        //                         oRequestServiceModel = new sap.ui.model.json.JSONModel();
        //                         oComponent.setModel(oRequestServiceModel, "Requestservicemodel");
        //                     }
        //                     oRequestServiceModel.setData(oData);

        //                 }

        //                 //Remark
        //                 //var sRemarks = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");

        //                 var oNestedPayload = 
        //                     {
        //                         reqID : oData.reqID,
        //                         action: "Submit",
        //                         remarks: "sRemarks"
        //                       };
        //                       var oViewModeldata = that.getView().getModel("viewenableddatacheck");
        //                       oViewModeldata.setData({
        //                         enableRowActions: false,            
        //                         approvebuttonvisiblity: true,      
        //                         approvebuttonfragment: true,        
        //                         rejetedbuttonfragmnet: true,        
        //                         enableIRR: true,                   
        //                         remarkModel: ""                     
        //                     });


        //                 oModel.create("/ADPDApproval", oNestedPayload, {
        //                     success: function (nestedData) {
        //                         console.log("Nested create successful:", nestedData);

        //                     },
        //                     error: function (nestedError) {
        //                         MessageToast.show("Nested request failed: " + nestedError.message);
        //                     }
        //                 });

        //                 that._remarkFragment.then(function (oDialog) {
        //                     oDialog.close();
        //                 });

        //                 MessageBox.success("Request " + oData.reqID + " has been created successfully!", {
        //                     title: "Success",
        //                     actions: [MessageBox.Action.OK],
        //                     onClose: function (oAction) {
        //                         if (oAction === MessageBox.Action.OK) {
        //                             var oRouter = that.getOwnerComponent().getRouter();
        //                             oRouter.navTo("DashboardUI", {
        //                                 Name: "ADPD"
        //                             });
        //                         }
        //                     }
        //                 });
        //             },
        //             error: function (oError) {
        //                 MessageToast.show("Error creating request: " + oError.message);
        //             }

        //         });
        //     } else {
        //         oModel.update("/Requests('" + this._reqIDData + "')", oSubmitPayload, {
        //             success: function (oData) {
        //                 // that._lastSubmittedPayload = sCurrentPayloadHash;

        //                 that._remarkFragment.then(function (oDialog) {
        //                     oDialog.close();
        //                 });

        //                 var reqid = oData.reqID;
        //                 that.attachmentuploadFilesData(reqid);


        //                 MessageBox.success("Request " + reqid + " has been updated successfully!", {
        //                     title: "Success",
        //                     actions: [MessageBox.Action.OK],
        //                     onClose: function (oAction) {
        //                         if (oAction === MessageBox.Action.OK) {
        //                             that._resetCompleteForm();

        //                             var oRouter = that.getOwnerComponent().getRouter();
        //                             oRouter.navTo("DashboardUI", {
        //                                 Name: "ADPD"
        //                             });
        //                         }
        //                     }
        //                 });

        //             },
        //             error: function (oError) {
        //                 MessageToast.show("Error updating request: " + oError.message);
        //             }
        //         });
        //     }
        // },
        onSubmitReamrksData: function () {
            var that = this;
            var oView = this.getView();
            var sReqID = this._reqIDData;

            var sRemarks = oView.getModel("viewenableddatacheck").getProperty("/remarkModel");
            if (!sRemarks || sRemarks.trim() === "") {
                sap.m.MessageBox.information("Please provide a remark before submitting.");
                return;
            }

            // Build the full structured payload
            var oSubmitPayload = this._constructPayloadSubmit();
            console.log(oSubmitPayload);
            // Add remark separately
            oSubmitPayload.remarks = sRemarks;

            var oModel = this.getOwnerComponent().getModel("approvalservicev2");

            // CREATE flow (new request)
            if (!sReqID) {
                oModel.create("/Requests", oSubmitPayload, {
                    success: function (oData) {
                        sap.ui.core.BusyIndicator.hide();
                        that._reqIDData = oData.reqID;
                        var reqid = oData.reqID;

                        that.attachmentuploadFilesData(reqid);
                        that.RecommendedDataPass(reqid);

                        // Save response to model
                        var oComponent = that.getOwnerComponent();
                        var oRequestServiceModel = oComponent.getModel("Requestservicemodel") || new sap.ui.model.json.JSONModel();
                        oComponent.setModel(oRequestServiceModel, "Requestservicemodel");
                        oRequestServiceModel.setData(oData);
                        that.approverdatacheck(reqid);

                       
                    },
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();

                        MessageToast.show("Error creating request: " + oError.message);
                    }
                });
            } else {
                // UPDATE flow (existing request)
                oModel.update("/Requests('" + sReqID + "')", oSubmitPayload, {
                    success: function (oData) {
                        sap.ui.core.BusyIndicator.hide();
                        that.attachmentuploadFilesData(sReqID);
                        that.RecommendedDataPass(sReqID);

                        that.approverdatacheck(sReqID);
                    },
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        MessageToast.show("Error updating request: " + oError.message);
                    }
                });
            }
        },
        sendbackdatacheckSend: function(reqid) {
            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            var oApprovedPayload = {
                reqID: reqid,
                action: "REJECT",
                remarks: remarkInput
            };
            var that = this;
            sap.ui.core.BusyIndicator.show(0);
            oModel.create("/ADPDApproval", oApprovedPayload, {
                success: function(oData) {
                    MessageBox.success(oData.ADPDApproval?.message || "Request submitted successfully!", {
                        onClose: function() {
                                sap.ui.core.BusyIndicator.hide();
                                that.getOwnerComponent().getRouter().navTo("approverdashboard");                            
                        }
                    });
                },
                error: function(oError) {
                    sap.ui.core.BusyIndicator.hide();
                    MessageToast.show("Error submitting request.", { position: "bottom center" });
                    console.error("Error submitting request:", oError);
                }
            });
        },
        approverdatacheckSend: function(reqid) {
            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            var oApprovedPayload = {
                reqID: reqid,
                action: "APPROVE",
                remarks: remarkInput
            };
            var that = this;
            sap.ui.core.BusyIndicator.show(0);

            oModel.create("/ADPDApproval", oApprovedPayload, {
                success: function(oData) {
                    MessageBox.success(oData.ADPDApproval?.message || "Request submitted successfully!", {
                        onClose: function() {
                                sap.ui.core.BusyIndicator.hide();
                                that.getOwnerComponent().getRouter().navTo("approverdashboard");                            
                        }
                    });
                },
                error: function(oError) {
                    sap.ui.core.BusyIndicator.hide();
                    MessageToast.show("Error submitting request.", { position: "bottom center" });
                    console.error("Error submitting request:", oError);
                }
            });
        },
        approverdatacheck: function(reqid) {
            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            var oApprovedPayload = {
                reqID: reqid,
                action: "SUBMIT",
                remarks: remarkInput
            };
            var that = this;
            sap.ui.core.BusyIndicator.show(0);

            oModel.create("/ADPDApproval", oApprovedPayload, {
                success: function(oData) {
                    MessageBox.success(oData.ADPDApproval?.message || "Request submitted successfully!", {
                        onClose: function() {
                                sap.ui.core.BusyIndicator.hide();
                                that.getOwnerComponent().getRouter().navTo("DashboardUI", { Name: "ADPD" });
                            
                        }
                    });
                },
                error: function(oError) {
                    sap.ui.core.BusyIndicator.hide();
                    MessageToast.show("Error submitting request.", { position: "bottom center" });
                    console.error("Error submitting request:", oError);
                }
            });
        },
      
        RecommendedDataPass: function(reqID) {
            var oView = this.getView();
            var oInterlineModel = oView.getModel("InterlineModel");
            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            var aTableData = oInterlineModel.getProperty("/recommendations");
            var aPayloadData = aTableData.map(function(oItem) {
                return {
                    userId: oItem.userId,
                    name: oItem.name,
                    email: oItem.email,
                    Role: "Recommended"
                };
            });
            if (!aPayloadData || aPayloadData.length === 0) {
                return;
            }
            var sPath = "/Requests('" + reqID + "')/recomApprovers";
            var that = this;
            oModel.read(sPath, {
                success: function(oData) {
                    var aExistingData = oData.results;
                    var aFilteredPayload = aPayloadData.filter(function(oNew) {
                        return !aExistingData.some(function(oExisting) {
                            return oExisting.userId === oNew.userId &&
                                   oExisting.name === oNew.name &&
                                   oExisting.Role === oNew.Role;
                        });
                    });
                    aFilteredPayload.forEach(function(oApprover) {
                        oModel.create(sPath, oApprover, {
                            success: function() {
                            },
                            error: function(oError) {
                            }
                        });
                    });
                },
                error: function(oError) {
                }
            });
        },                
        onSaveAdpd: function () {
            var that = this;
            var oView = this.getView();
        
            var reqid = this._reqIDData;
            // var statusData = this.statusData;
            // var satauscheckdata = (!statusData || statusData === "Draft") ? "Draft" : "Pending";
        

            var statusData = this.statusData || "Draft";
            var satauscheckdata = statusData === "Pending" ? "Pending" : "Draft";
            if(statusData === "Sent Back"){
                satauscheckdata = "Sent Back"
            }
            var oPayload = this._constructPayload();
        
            var oSavePayload = {
               
                type: "ADPD",
                remarks: "",
                adpdDtl: oPayload.adpdDtl
            };
     
            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
        
            if (!this._reqIDData) {
                oModel.create("/Requests", oSavePayload, {
                    success: function (oData) {
                        that._reqIDData = oData.reqID;
                        var oComponent = that.getOwnerComponent();
                        var oRequestServiceModel = oComponent.getModel("Requestservicemodel") || new sap.ui.model.json.JSONModel();
                        oComponent.setModel(oRequestServiceModel, "Requestservicemodel");
                        oRequestServiceModel.setData(oData);
                        that.attachmentuploadFilesData(oData.reqID);
                     that.RecommendedDataPass(oData.reqID);
                        MessageBox.success("Request " + oData.reqID + " has been saved.");
                    },
                    error: function (oError) {
                        MessageToast.show("Error saving draft: " + oError.message);
                    }
                });
            } else {
                oModel.update("/Requests('" + this._reqIDData + "')", oSavePayload, {
                    success: function (oData) {
                        that._reqIDData = oData.reqID;
                        that.attachmentuploadFilesData(oData.reqID);
                       that.RecommendedDataPass(oData.reqID);

                        MessageBox.success("Request " + oData.reqID + " has been updated successfully.");
                    },
                    error: function (oError) {
                        MessageToast.show("Error updating draft: " + oError.message);
                    }
                });
            }
        },        
        onSubmitApprovedformAdpd: function () {
            var oView = this.getView();

            var sRemarks = this.getView().getModel("viewenableddatacheck").setProperty("");
            oView.getModel("viewenableddatacheck").setProperty("/approvebuttonfragment", true);
            oView.getModel("viewenableddatacheck").setProperty("/rejetedbuttonfragmnet", false);
            oView.getModel("viewenableddatacheck").setProperty("/enableRowActions", false);
            oView.getModel("viewenableddatacheck").setProperty("/sendbackbuttonvisiblity", false);
            oView.getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblityData", true);
            this._remarkFragment.then(function (oDialog) {
                oDialog.open();
            });
        },

        onRejectformAdpd: function () {
            var oView = this.getView();


            var sRemarks = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            oView.getModel("viewenableddatacheck").setProperty("/enableRowActions", false);
            oView.getModel("viewenableddatacheck").setProperty("/sendbackbuttonvisiblity", true);
            oView.getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblityData", false);
            this._remarkFragment.then(function (oDialog) {
                oDialog.open();
            });
        },
        onSendbackData: function () {
            var that = this;
            var oView = this.getView();
            var sReqID = this._reqIDData;

            var sRemarks = oView.getModel("viewenableddatacheck").getProperty("/remarkModel");
            if (!sRemarks || sRemarks.trim() === "") {
                sap.m.MessageBox.information("Please provide a remark before submitting.");
                return;
            }

            // Build the full structured payload
            var oSubmitPayload = this._constructPayloadSubmit();

            // Add remark separately
            oSubmitPayload.remarks = sRemarks;

            var oModel = this.getOwnerComponent().getModel("approvalservicev2");

            // CREATE flow (new request)
            if (!sReqID) {
                oModel.create("/Requests", oSubmitPayload, {
                    success: function (oData) {
                        sap.ui.core.BusyIndicator.hide();
                        that._reqIDData = oData.reqID;
                        var reqid = oData.reqID;

                        that.attachmentuploadFilesData(reqid);

                        // Save response to model
                        var oComponent = that.getOwnerComponent();
                        var oRequestServiceModel = oComponent.getModel("Requestservicemodel") || new sap.ui.model.json.JSONModel();
                        oComponent.setModel(oRequestServiceModel, "Requestservicemodel");
                        oRequestServiceModel.setData(oData);
                        that.sendbackdatacheckSend(reqid);

                       
                    },
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();

                        MessageToast.show("Error creating request: " + oError.message);
                    }
                });
            } else {
                // UPDATE flow (existing request)
                oModel.update("/Requests('" + sReqID + "')", oSubmitPayload, {
                    success: function (oData) {
                        sap.ui.core.BusyIndicator.hide();
                        that.attachmentuploadFilesData(sReqID);
                        that.sendbackdatacheckSend(sReqID);
                    },
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        MessageToast.show("Error updating request: " + oError.message);
                    }
                });
            }
        },
        onApprovedData: function () {
            var that = this;
            var oView = this.getView();
            var sReqID = this._reqIDData;

            var sRemarks = oView.getModel("viewenableddatacheck").getProperty("/remarkModel");
            if (!sRemarks || sRemarks.trim() === "") {
                sap.m.MessageBox.information("Please provide a remark before submitting.");
                return;
            }

            // Build the full structured payload
            var oSubmitPayload = this._constructPayloadSubmit();
            // Add remark separately
            oSubmitPayload.remarks = sRemarks;

            var oModel = this.getOwnerComponent().getModel("approvalservicev2");

            // CREATE flow (new request)
            if (!sReqID) {
                oModel.create("/Requests", oSubmitPayload, {
                    success: function (oData) {
                        sap.ui.core.BusyIndicator.hide();
                        that._reqIDData = oData.reqID;
                        var reqid = oData.reqID;

                        that.attachmentuploadFilesData(reqid);

                        // Save response to model
                        var oComponent = that.getOwnerComponent();
                        var oRequestServiceModel = oComponent.getModel("Requestservicemodel") || new sap.ui.model.json.JSONModel();
                        oComponent.setModel(oRequestServiceModel, "Requestservicemodel");
                        oRequestServiceModel.setData(oData);
                        that.approverdatacheckSend(reqid);

                       
                    },
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();

                        MessageToast.show("Error creating request: " + oError.message);
                    }
                });
            } else {
                // UPDATE flow (existing request)
                oModel.update("/Requests('" + sReqID + "')", oSubmitPayload, {
                    success: function (oData) {
                        sap.ui.core.BusyIndicator.hide();
                        that.attachmentuploadFilesData(sReqID);
                        that.approverdatacheckSend(sReqID);
                    },
                    error: function (oError) {
                        sap.ui.core.BusyIndicator.hide();
                        MessageToast.show("Error updating request: " + oError.message);
                    }
                });
            }
        },

        onRejectedData: function () {
           
            // var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            // if (!remarkInput) {
            //     MessageBox.information("Please provide a remark before submitting.");
            //     return;
            // }

            // var oBasePayload = this._constructOTPayload();
            // var oSubmitPayload = {
            //     ...oBasePayload,
            //     stage: "Rejected",
            //     status: "Rejected",
            //     type: "ADPD",
            //     remarks: remarkInput
            // };

            // var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            // var that = this;
            // var reqid = this._reqIDData;

            var sRemarks = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            if (!sRemarks) {
                MessageBox.information("Please provide a remark before submitting.");
                return;
            }

           
            
            var oNestedPayload = {
                reqID: this._reqIDData,
                action: "Rejected",
                remarks: sRemarks
            };



            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;
            var reqid = this._reqIDData;

            if (!reqid) {
                // oModel.create("/Requests", oSubmitPayload, {
                //     success: function (oData) {
                //         that._reqIDData = oData.reqID;
                //         // that.rejecteddatacheckRejected(oData.reqID);
                //         if (oData) {
                //             var oComponent = that.getOwnerComponent();
                //             var oRequestServiceModel = oComponent.getModel("Requestservicemodel");
                //             if (!oRequestServiceModel) {
                //                 oRequestServiceModel = new sap.ui.model.json.JSONModel();
                //                 oComponent.setModel(oRequestServiceModel, "Requestservicemodel");
                //             }
                //             oRequestServiceModel.setData(oData);
                //         }
                //         MessageToast.show(" Created  Request for Rejection ");
                //     },
                //     error: function (oError) {
                //         MessageToast.show("Error saving request: " + oError.message, { position: "bottom center" });
                //         console.error("Error saving request:", oError);
                //     }
                // });
                oModel.create("/ADPDApproval", oNestedPayload, {
                    success: function (oData) {
                        that._reqIDData = oData.reqID;
                        if (oData) {
                            that._remarkFragment.then(function (oDialog) {
                                oDialog.close();
                            });
                            var oComponent = that.getOwnerComponent();
                            var oRequestServiceModel = oComponent.getModel("Requestservicemodel");
                            if (!oRequestServiceModel) {
                                oRequestServiceModel = new sap.ui.model.json.JSONModel();
                                oComponent.setModel(oRequestServiceModel, "Requestservicemodel");
                            }
                            oRequestServiceModel.setData(oData);
                        }
                        //that.approverdatacheckApproved(oData.reqID);
                        MessageToast.show(" Created  Request for Approval ");

                    },
                    error: function (oError) {
                        MessageToast.show("Error saving request: " + oError.message, { position: "bottom center" });
                        console.error("Error saving request:", oError);
                    }
                });

            } else {
                // oModel.update("/Requests('" + reqid + "')", oSubmitPayload, {
                //     success: function () {
                //         if (oData) {
                //             var oComponent = that.getOwnerComponent();
                //             var oRequestServiceModel = oComponent.getModel("Requestservicemodel");
                //             if (!oRequestServiceModel) {
                //                 oRequestServiceModel = new sap.ui.model.json.JSONModel();
                //                 oComponent.setModel(oRequestServiceModel, "Requestservicemodel");
                //             }
                //             oRequestServiceModel.setData(oData);
                //         }
                //         //that.rejecteddatacheckRejected(reqid);
                //         MessageToast.show(" Updated  Request for Rejection ");

                //     },
                //     error: function (oError) {
                //         MessageToast.show("Error updating request: " + oError.message, { position: "bottom center" });
                //         console.error("Error updating request:", oError);
                //     }
                // });
                oModel.create("/ADPDApproval", oNestedPayload, {
                    success: function (oData) {
                        that._reqIDData = oData.reqID;
                        if (oData) {
                            that._remarkFragment.then(function (oDialog) {
                                oDialog.close();
                            });
                            var oComponent = that.getOwnerComponent();
                            var oRequestServiceModel = oComponent.getModel("Requestservicemodel");
                            if (!oRequestServiceModel) {
                                oRequestServiceModel = new sap.ui.model.json.JSONModel();
                                oComponent.setModel(oRequestServiceModel, "Requestservicemodel");
                            }
                            oRequestServiceModel.setData(oData);
                        }
                        //that.approverdatacheckApproved(oData.reqID);
                        MessageToast.show(" Created  Request for Approval ");

                    },
                    error: function (oError) {
                        MessageToast.show("Error saving request: " + oError.message, { position: "bottom center" });
                        console.error("Error saving request:", oError);
                    }
                });

            }
        },

        // onSendbackData: function () {
        //     var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
        //     if (!remarkInput) {
        //         MessageBox.information("Please provide a remark before submitting.");
        //         return;
        //     }

        //     var oBasePayload = this._constructOTPayload();
        //     var oSubmitPayload = {
        //         ...oBasePayload,
        //         type: "ADPD",
        //         remarks: remarkInput,
        //         status: "Sent Back",
        //         stage: "Sent Back"
        //     };

        //     var oModel = this.getOwnerComponent().getModel("approvalservicev2");
        //     var that = this;
        //     var reqid = this._reqIDData;

        //     if (!reqid) {
        //         oModel.create("/Requests", oSubmitPayload, {
        //             success: function (oData) {
        //                 MessageToast.show(" Created SendBack Request ");
        //                 that._reqIDData = oData.reqID;
        //                 if (oData) {
        //                     var oComponent = that.getOwnerComponent();
        //                     var oRequestServiceModel = oComponent.getModel("Requestservicemodel");
        //                     if (!oRequestServiceModel) {
        //                         oRequestServiceModel = new sap.ui.model.json.JSONModel();
        //                         oComponent.setModel(oRequestServiceModel, "Requestservicemodel");
        //                     }
        //                     oRequestServiceModel.setData(oData);
        //                 }
        //                 //  that.sendbackdatacheckApproved(oData.reqID);
        //             },
        //             error: function (oError) {
        //                 MessageToast.show("Error saving request: " + oError.message, { position: "bottom center" });
        //                 console.error("Error saving request:", oError);
        //             }
        //         });
        //     } else {
        //         oModel.update("/Requests('" + reqid + "')", oSubmitPayload, {
        //             success: function () {
        //                 //  that.sendbackdatacheckApproved(reqid);
        //                 if (oData) {
        //                     var oComponent = that.getOwnerComponent();
        //                     var oRequestServiceModel = oComponent.getModel("Requestservicemodel");
        //                     if (!oRequestServiceModel) {
        //                         oRequestServiceModel = new sap.ui.model.json.JSONModel();
        //                         oComponent.setModel(oRequestServiceModel, "Requestservicemodel");
        //                     }
        //                     oRequestServiceModel.setData(oData);
        //                 }
        //                 MessageToast.show(" Updated SendBack Request ");
        //             },
        //             error: function (oError) {
        //                 MessageToast.show("Error updating request: " + oError.message, { position: "bottom center" });
        //                 console.error("Error updating request:", oError);
        //             }
        //         });
        //     }
        // },



        // _constructOTPayload: function () {
        //     var oView = this.getView();

        //     var oWbsModel = oView.getModel("wbsModel");
        //     var oInterlineModel = oView.getModel("InterlineModel");
        //     var oPlatformRoleModel = oView.getModel("platformRoleModel");

        //     var sReqID = this.reqID;
        //     var sInitiator = oView.byId("AdpdInitiatorInp")?.getValue() || "";
        //     var sDate = oView.byId("AdpdDateInput")?.getValue() || "";
        //     var sJustification = oView.byId("AdpdJustificationTxtArea")?.getValue() || "";
        //     var sNatureOfExpense = oView.byId("AdpdNatureExpSelect")?.getSelectedKey() || "";
        //     var sProject = oView.byId("AdpdProjectSelect")?.getSelectedKey() || "";
        //     var sProjectDesc = oView.byId("AdpdProjectDescInp")?.getValue() || "";
        //     var sTransType = oView.byId("AdpdTransferTypeSelect")?.getSelectedKey() || "";
        //     var sForum = oView.byId("AdpdForumMultiSelect")?.getSelectedKey() || "";
        //     var sPlatform = oView.byId("AdpdPlatformSelect")?.getSelectedKey() || "";
        //     var sProjFinHead = oView.byId("AdpdProjectFinHeadCombo")?.getSelectedKey() || "financehead@example.com";

        //     var sCPH = oView.byId("AdpdCphInput")?.getSelectedKey() || "";
        //     var sPEH = oView.byId("AdpdPehInput")?.getSelectedKey() || "";
        //     var sPPM = oView.byId("AdpdPpmInput")?.getSelectedKey() || "";
        //     var sPNH = oView.byId("AdpdPnhInput")?.getSelectedKey() || "";
        //     var sPPH = oView.byId("AdpdPphInput")?.getSelectedKey() || "";
        //     var sPFH = oView.byId("AdpdPfhInput")?.getSelectedKey() || "";
        //     var sFinMember = oView.byId("AdpdFinanceInput")?.getSelectedKey() || "";
        //     var sSrGM = oView.byId("srGmCombo")?.getSelectedKey() || "";
        //     var sSrVP = oView.byId("AdpdSrGmCombo")?.getSelectedKey() || "";

        //     var oAdpd = {
        //         reqID: sReqID,
        //         Initiator: sInitiator,
        //         natureOfExpense: sNatureOfExpense,
        //         Project: sProject,
        //         projectDesc: sProjectDesc,
        //         transType: sTransType,
        //         Justification: sJustification,
        //         Forum: sForum,
        //         Platform: sPlatform,
        //         projFinHead: sProjFinHead,
        //         expenseDtl: (oWbsModel.getProperty("/rows") || []).map(function (oRow) {
        //             return {
        //                 reqID: sReqID,
        //                 fromWBSCode: oRow.fromWbsCode || "",
        //                 toWBSCode: oRow.toWbsCode || "",
        //                 fromWBSLoc: oRow.fromWbsLocation || "",
        //                 toWBSLoc: oRow.toWbsLocation || "",
        //                 fromWBSLevel: oRow.fromWbsLevel || "",
        //                 toWBSLevel: oRow.toWbsLevel || "",
        //                 CPH: sCPH || oRow.CPH || "",
        //                 PEH: sPEH || oRow.PEH || "",
        //                 PPM: sPPM || oRow.PPM || "",
        //                 PNH: sPNH || oRow.PNH || "",
        //                 PPH: sPPH || oRow.PPH || "",
        //                 PFH: sPFH || oRow.PFH || "",
        //                 finMember: sFinMember || oRow.finMember || "",
        //                 SrGM: sSrGM || oRow.SrGM || "",
        //                 SrVP: sSrVP || oRow.SrVP || "",
        //                 capexNRT: oRow.capexNrt || 0,
        //                 capexLanded: oRow.capexLanded || 0,
        //                 revenueNRT: oRow.revenueNrt || 0,
        //                 revenueLanded: oRow.revenueLanded || 0,
        //                 totalNRT: oRow.totalNrt || 0,
        //                 totalLanded: oRow.totalLanded || 0,
        //                 Action: oRow.Action || "Initiated"
        //             };
        //         })
        //     };

        //     return {
        //         reqID: sReqID,
        //         adpdDtl: oAdpd,
        //         recomApprovers: (oInterlineModel.getProperty("/recommendations") || []).map(function (oRec) {
        //             return {
        //                 reqID: sReqID,
        //                 Role: oRec.id || "",
        //                 Approvers: oRec.name || ""
        //             };
        //         })
        //     };
        // },
        _constructOTPayload: function () {
            var oView = this.getView();
        
            // Models
            var oWbsModel = oView.getModel("wbsModel");
            var oParkedModel = oView.getModel("contBalanceModel");
            var oInvestModel = oView.getModel("InvestmentModel");
            var oAttachmentModel = oView.getModel("UploadDocSrvTabData");
            var oApproverModel = oView.getModel("ApproversLocalModel");
        
            // Field Values
            var sReqID = this.reqID;
            var sInitiator = oView.byId("AdpdInitiatorInp").getValue() || "";
            var sJustification = oView.byId("AdpdJustificationTxtArea").getValue() || "";
            var sNatureOfExpense = oView.byId("AdpdNatureExpSelect").getSelectedKey() || "";
            var sProject = oView.byId("AdpdProjectSelect").getSelectedKey() || "";
            var sProjectDesc = oView.byId("AdpdProjectDescInp").getValue() || "";
            var sTransType = oView.byId("AdpdTransferTypeSelect").getSelectedKey() || "";
            var sForum = oView.byId("AdpdForumMultiSelect").getValue() || "";
            var sPlatform = oView.byId("AdpdPlatformSelect").getValue() || "";
            var sProjFinHead = oView.byId("AdpdProjectFinHeadCombo").getSelectedKey() || "financehead@example.com";
            var sSopDate = oView.byId("AdpdSopDateInput").getValue() || "";
            var sOnBehalfFlag = "No";
        
            var sCPH = oView.byId("AdpdCphInput")?.getValue() || "";
            var sPEH = oView.byId("AdpdPehInput")?.getValue() || "";
            var sPPM = oView.byId("AdpdPpmInput")?.getValue() || "";
            var sPNH = oView.byId("AdpdPnhInput")?.getValue() || "";
            var sPPH = oView.byId("AdpdPphInput")?.getValue() || "";
            var sPFH = oView.byId("AdpdPfhInput")?.getValue() || "";
            var sFinMember = oView.byId("AdpdFinanceInput")?.getValue() || "";
            var sSrGM = oView.byId("AdpdSrGmCombo")?.getValue() || "";
            var sSrVP = oView.byId("AdpdSrVpCombo")?.getValue() || "";
            var sFinalApprover1 = "";
            var sFinalApprover2 = "";
            var sFinalApprover3 = "";
            var aAttachments = oAttachmentModel?.getProperty("/attachments") || [{}];
        
            var oAdpd = {
              
                adpdDtl: {
                    subType: "IIIT",
                    Initiator: sInitiator,
                    Project: sProject,
                    projectDesc: sProjectDesc,
                    Justification: sJustification,
                    transType: sTransType,
                    natureOfExpense: sNatureOfExpense,
                    natureOfApproval: "Emergency", // fixed for this payload
                    Platform: sPlatform,
                    Forum: sForum,
                    projFinHead: sProjFinHead,
                    sopDate: sSopDate,
                    CPH: sCPH,
                    PEH: sPEH,
                    PPM: sPPM,
                    PNH: sPNH,
                    PPH: sPPH,
                    PFH: sPFH,
                    finMember: sFinMember,
                    SrGM: sSrGM,
                    SrVP: sSrVP,
                    onBehalfFlag: sOnBehalfFlag,
                    FinalApprover1: sFinalApprover1,
                    FinalApprover2: sFinalApprover2,
                    FinalApprover3: sFinalApprover3,
        
                    expenseDtl: (oWbsModel.getProperty("/rows") || []).map(function (oRow) {
                        return {
                            fromWBSCode: oRow.fromWbsCode || "",
                            toWBSCode: oRow.toWbsCode || "",
                            fromWBSLoc: oRow.fromWbsLocation || "",
                            toWBSLoc: oRow.toWbsLocation || "",
                            fromWBSLevel: oRow.fromWbsLevel || "",
                            toWBSLevel: oRow.toWbsLevel || "",
                            capexNRT: parseFloat(oRow.capexNrt) || "",
                            capexLanded: parseFloat(oRow.capexLanded) || "",
                            revenueNRT: parseFloat(oRow.revenueNrt) || "",
                            revenueLanded: parseFloat(oRow.revenueLanded) || "",
                            totalNRT: parseFloat(oRow.totalNrt) || "",
                            totalLanded: parseFloat(oRow.totalLanded) || "",
                            remarks: oRow.remarks || "",
                            WBSCode: oRow.toWbsCode || "",
                            WBSLoc: oRow.toWbsLocation || "",
                            WBSLevel: oRow.toWbsLevel || ""
                        };
                    }),
        
                    parkedSDtl: (oParkedModel?.getProperty("/modelData") || []).map(function (oRow) {
                        return {
                            level: oRow.level || "",
                            WBSCode: oRow.wbsCode || "",
                            priorBalance: oRow.priorBalance || "0",
                            transfAmountCurrApproval: oRow.amountToTransfer || "0",
                            balancePostTransfer: oRow.balancePost || "0",
                            remarks: oRow.remarks || ""
                        };
                    }),
        
                    investDtl: (oInvestModel?.getProperty("/investmentData") || []).map(function (oRow) {
                        return {
                            natureOfExpense: oRow.natureOfExpense || "",
                            level: oRow.level || "",
                            capex: oRow.capex || "0",
                            revenue: oRow.revenue || "0",
                            total: oRow.total || "0",
                            remarks: oRow.remarks || ""
                        };
                    })
                },
        
                // processLogs: [
                //     {
                //         role: "R1",
                //         status: "Pending",
                //         receivedDt: new Date().toISOString()
                //     }
                // ],
        
                // recomApprovers: aRecomApprovers,
                attachments: aAttachments
            };
        
            return oAdpd;
        },        
        onDownlaodExcelMaterialcost: function () {
            var oModel = this.getView().getModel("materialcostData");
            var aData = oModel.getProperty("/matcostDtl");
        
            if (!aData || aData.length === 0) {
                sap.m.MessageToast.show("No data to export.");
                return;
            }
        
            var oExport = new sap.ui.core.util.Export({
                exportType: new sap.ui.core.util.ExportTypeCSV({
                    separatorChar: ","
                }),
                models: oModel,
                rows: {
                    path: "/matcostDtl"
                },
                columns: [
                    {
                        name: "Item",
                        template: { content: "{item}" }
                    },
                    {
                        name: "Vehicle Level (₹)",
                        template: { content: "{vehicleLevel}" }
                    },
                    {
                        name: "PTD Level (₹)",
                        template: { content: "{ptdLevel}" }
                    },
                    {
                        name: "Total Impact (₹)",
                        template: { content: "{totalLevel}" }
                    }
                ]
            });
        
            oExport.saveFile("Material_Cost_Data").catch(function (oError) {
                sap.m.MessageToast.show("Export error: " + oError.message);
            }).then(function () {
                oExport.destroy();
            });
        },  
        onDeleteMatreialCostData: function (oEvent) {
            var oButton = oEvent.getSource();
            var oContext = oButton.getBindingContext("materialcostData");
            var oModel = oContext.getModel();
            var sPath = oContext.getPath();
            var iIndex = parseInt(sPath.split("/").pop(), 10);
            var aData = oModel.getProperty("/matcostDtl");
            var oDeletedItem = aData[iIndex];
            var oServiceModel = this.getOwnerComponent().getModel("approvalservicev2");
        
            if (oDeletedItem.__metadata && oDeletedItem.__metadata.uri) {
                var oUri = new URL(oDeletedItem.__metadata.uri);
                var sRelativePath = oUri.pathname.replace("/odata/v2/approval-hub", "");
                oServiceModel.remove(sRelativePath, {
                    success: function () {
                        aData.splice(iIndex, 1);
                        oModel.setProperty("/matcostDtl", aData);
                        sap.m.MessageToast.show("Row deleted successfully.");
                    },
                    error: function (oError) {
                        console.error("Failed to delete from backend:", oError);
                        sap.m.MessageToast.show("Error while deleting the row.");
                    }
                });
            } else {
                aData.splice(iIndex, 1);
                oModel.setProperty("/matcostDtl", aData);
                sap.m.MessageToast.show("Row deleted successfully.");
            }
        },                  
        _resetCompleteForm: function () {
            this.getView().getModel("wbsModel").setData({ rows: [] });
            this.getView().getModel("InvestmentModel").setData({ investmentData: [] });
            // this.getView().getModel("estimatedCostModel").setData({ estimatedCostData: [] });
            this.getView().getModel("FinancialModel").setData({ financialData: [] });
            this.getView().getModel("contBalanceModel").setData({ modelData: [] });
            this.getView().getModel("localModel").setData({ volumeBreakupData: [] });
            this.getView().getModel("InterlineModel").setData({ showRecommendationTable: false, recommendations: [] });
            this.getView().getModel("UploadDocSrvTabData").setData({ attachments: [] });

            this.getView().getModel("formModel").setData({
                projectFinHead: "",
                revenueNrt: "",
                revenueLanded: "",
                totalNrt: "",
                totalLanded: ""
            });

            var oView = this.getView();
            //oView.byId("AdpdInitiatorInp").setValue("");
            // oView.byId("AdpdDateInput").setValue("");
            oView.byId("AdpdProjectDescInp").setValue("");
            oView.byId("AdpdJustificationTxtArea").setValue("");
            oView.byId("AdpdContingencyBudgetDatePicker").setValue("");
            oView.byId("AdpdNatureExpSelect").setSelectedKey("");
            oView.byId("AdpdPlatformSelect").setValue("");
            oView.byId("AdpdProjectSelect").setValue("");
            oView.byId("AdpdTransferTypeSelect").setSelectedKey("");
            oView.byId("AdpdForumMultiSelect").setSelectedKey("");
            oView.byId("AdpdProjectFinHeadCombo").setSelectedKey("");
            oView.byId("AdpdCphInput").setSelectedKey("");
            oView.byId("AdpdPehInput").setSelectedKey("");
            oView.byId("AdpdPpmInput").setSelectedKey("");
            oView.byId("AdpdPnhInput").setSelectedKey("");
            oView.byId("AdpdPphInput").setSelectedKey("");
            oView.byId("AdpdPfhInput").setSelectedKey("");
            oView.byId("AdpdFinanceInput").setSelectedKey("");
            oView.byId("AdpdSrGmCombo").setSelectedKey("");
            oView.byId("AdpdSrVpCombo").setSelectedKey("");

            oView.byId("AdpdMaterialCostRadioGroup").setSelectedIndex(-1);
            oView.byId("AdpdNewMaterialCostRadioConten").setSelectedIndex(-1);

            oView.byId("AdpdRecommendSearch").setValue("");
            oView.byId("AdpdBudgetSearchFieldApprover").setValue("");

            var oFileUploader = oView.byId("AdpdFileUploaderTabAttachment");
            oFileUploader.clear();

            oView.byId("AdpdWbsTable").getBinding("rows").refresh();
            oView.byId("AdpdInvestmentTable").getBinding("rows").refresh();
            // oView.byId("AdpdEstimatedCostTable").getBinding("rows").refresh();
            oView.byId("AdpdFinancialDetailsTable").getBinding("rows").refresh();
            oView.byId("AdpdContingencyBudgetWbsTable").getBinding("rows").refresh();
            oView.byId("AdpdContingencyBalanceTable").getBinding("rows").refresh();
            //  oView.byId("AdpdVolumeBreakupTable").getBinding("items").refresh();
            oView.byId("AdpdRecommendationTable").getBinding("items").refresh();
            oView.byId("AdpdAttachmentTable").getBinding("items").refresh();
            //window.location.reload();

            oView.findElements(true).forEach(function (oElement) {
                if (oElement.isA("sap.m.ComboBox") || oElement.isA("sap.m.TextArea")) {
                    oElement.setValueState("None");
                }
            });

        },
      
        onVarientlistopen: function (oEvent) { 
            var oButton = oEvent.getSource();
            var oView = this.getView();
        
            if (!this._oPopover) {
                this._oPopover = sap.ui.xmlfragment("com.mmapprovalhub.approvalhub.Fragments.Volumes_breaks", this);
                oView.addDependent(this._oPopover);
            }
        
            this._oPopover.openBy(oButton); // now works
        },        
      
        onVariantSelect: function (oEvent) {
            const aSelectedKeys = oEvent.getSource().getSelectedKeys(); 
            const oTable = this.byId("AdpdVolumeBreakupTable");
            const oModel = this.getView().getModel("FinancialModel");
            const aAllColumns = oTable.getColumns();
            const aStaticColumnLabels = ["Variant / Years", "Total", "Action"];
            const aCurrentDynamicColumns = [];
            aAllColumns.forEach((oCol, i) => {
                const sLabel = oCol.getLabel()?.getText?.();
                if (sLabel && !aStaticColumnLabels.includes(sLabel)) {
                    aCurrentDynamicColumns.push({ index: i, label: sLabel });
                }
            });
            aCurrentDynamicColumns.reverse().forEach((col) => {
                if (!aSelectedKeys.includes(col.label)) {
                    oTable.removeColumn(aAllColumns[col.index]);
                }
            });
            aSelectedKeys.forEach((sKey, i) => {
                const bExists = oTable.getColumns().some(col => col.getLabel()?.getText?.() === sKey);
                if (!bExists) {
                    const oNewColumn = new sap.ui.table.Column({
                        label: new sap.m.Label({ text: sKey }),
                        template: new sap.m.Input({
                            value: `{FinancialModel>${sKey}}`,
                            editable: "{viewenableddatacheck>/enableRowActions}"
                        }),
                        width: "8rem"
                    });
                    const insertAtIndex = 1 + i;
                    oTable.insertColumn(oNewColumn, insertAtIndex);
                }
            });
                    let aData = oModel.getProperty("/FinancialDatacheck") || [];
            aData.forEach((row) => {
                aSelectedKeys.forEach((sKey) => {
                    if (!(sKey in row)) {
                        row[sKey] = "";
                    }
                });
                        aCurrentDynamicColumns.forEach((col) => {
                    if (!aSelectedKeys.includes(col.label)) {
                        delete row[col.label];
                    }
                });
            });
            oModel.setProperty("/FinancialDatacheck", aData);
        },   
        onAddVolumesBreakData: function () {
            const oModel = this.getView().getModel("FinancialModel");
            const oTable = this.byId("AdpdVolumeBreakupTable");
            const aData = oModel.getProperty("/FinancialDatacheck") || [];
            const aColumnLabels = oTable.getColumns()
                .map(col => col.getLabel()?.getText?.())
                .filter(label => !!label && !["Variant / Years", "Total", "Action"].includes(label));
            const oNewRow = {
                variantYear: "",
                Total: ""
            };
            aColumnLabels.forEach((label) => {
                oNewRow[label] = "";
            });
        
            aData.push(oNewRow);
            oModel.setProperty("/FinancialDatacheck", aData);
        },                    
       
        
        
             
    });
});