sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/core/util/Export",
    "sap/ui/core/util/ExportTypeCSV",
    "com/mmapprovalhub/approvalhub/formatter/formatter"

], (Controller, MessageToast, MessageBox, Export, ExportTypeCSV, formatter) => {
    "use strict";

    return Controller.extend("com.mmapprovalhub.approvalhub.controller.approverdashboard", {
        formatter: formatter,

        onInit() {
            var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            oRouter.getRoute("approverdashboard").attachPatternMatched(this._onRouteapproverdashboardController, this);

            this.getView().byId("createRequestButton1_approval").setVisible(false);

        },
        _onRouteapproverdashboardController: async function (oEvent) {
            try {
                await this._loadDashboardData();
            } catch (error) {
                console.error("Error during data loading:", error);
                sap.m.MessageToast.show("Error loading dashboard data.");
            }
        },
        onInProgressPress: function () {
            var oTable = this.byId("pendingWithMeTableapproverdashboard");
            var oBinding = oTable.getBinding("items");
            var oFilter = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "Pending");
            oBinding.filter([oFilter]);
        },
        onSentBackPress: function () {
            var oTable = this.byId("pendingWithMeTableapproverdashboard");
            var oBinding = oTable.getBinding("items");
            var oFilter = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "Sent Back");
            oBinding.filter([oFilter]);
        },
        onAllRequestsPress: function () {
            var oTable = this.byId("pendingWithMeTableapproverdashboard");
            var oBinding = oTable.getBinding("items");
            oBinding.filter([]);
        },
        onApprovedPress: function () {
            var oTable = this.byId("pendingWithMeTableapproverdashboard");
            var oBinding = oTable.getBinding("items");
            var oFilter = new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, "Approved");
            oBinding.filter([oFilter]);
        },
        _loadDashboardData: function () {
            return new Promise((resolve, reject) => {
                var oView = this.getView();
                var oODataTablebinding = this.getOwnerComponent().getModel("approvalservicev2");

                oODataTablebinding.read("/RequestsAP", {
                   
                    success: function (oData) {
                        if (oData && oData.results) {
                            // Filter out Draft status entries
                            var aFilteredResults = oData.results.filter(function (item) {
                                return item.status !== "Draft";
                            });

                            // Set filtered results to dashboardtabledata model (used in the Table)
                            var oJSONModel = new sap.ui.model.json.JSONModel({ results: aFilteredResults });
                            oView.setModel(oJSONModel, "dashboardtabledata");

                            // Initialize counters (excluding Draft)
                            var counts = {
                                Draft: 0,            // still counted, just not in AllRequests
                                InProgress: 0,
                                SentBack: 0,
                                Approved: 0,
                                AllRequests: aFilteredResults.length // Total without Drafts
                            };

                            // Loop through filtered results only
                            aFilteredResults.forEach(function (item) {
                                switch (item.status) {
                                    case "Pending":
                                        counts.InProgress++;
                                        break;
                                    case "Sent Back":
                                        counts.SentBack++;
                                        break;
                                    case "Approved":
                                        counts.Approved++;
                                        break;
                                }
                            });

                            // Optional: if you still want to show how many were Draft (not displayed)
                            counts.Draft = oData.results.filter(function (item) {
                                return item.status === "Draft";
                            }).length;

                            // Set count model
                            var oCountModel = new sap.ui.model.json.JSONModel(counts);
                            oView.setModel(oCountModel, "dashboardCounts");

                            resolve();
                        } else {
                            reject("No data received from /Requests.");
                        }
                    },
                    error: function (oError) {
                        reject(oError);
                    }
                });
            });
        },
        onLiveSearchRefrence_Number: function () {
            let oTable = this.byId("pendingWithMeTableapproverdashboard");
            let oBinding = oTable.getBinding("items");
            let aFilters = [];
            let sRequestIDValue = this.byId("Refrence_Number_approval").getValue();
            if (sRequestIDValue) {
                aFilters.push(new sap.ui.model.Filter("refNo", sap.ui.model.FilterOperator.Contains, sRequestIDValue));
            }
            oBinding.filter(aFilters.length > 0 ? new sap.ui.model.Filter(aFilters, false) : []);
        },
        onLiveSearchpending_with: function () {
            let oTable = this.byId("pendingWithMeTableapproverdashboard");
            let oBinding = oTable.getBinding("items");
            let aFilters = [];
            let sRequestIDValue = this.byId("Pending_withsearcg_approval").getValue();
            if (sRequestIDValue) {
                aFilters.push(new sap.ui.model.Filter("pendingWith", sap.ui.model.FilterOperator.Contains, sRequestIDValue));
            }
            oBinding.filter(aFilters.length > 0 ? new sap.ui.model.Filter(aFilters, false) : []);
        },
        onLiveSearchcreatedby: function () {
            let oTable = this.byId("pendingWithMeTableapproverdashboard");
            let oBinding = oTable.getBinding("items");
            let aFilters = [];
            let sRequestIDValue = this.byId("Created_onDash_approval").getValue();
            if (sRequestIDValue) {
                aFilters.push(new sap.ui.model.Filter("createdAt", sap.ui.model.FilterOperator.Contains, sRequestIDValue));
            }
            oBinding.filter(aFilters.length > 0 ? new sap.ui.model.Filter(aFilters, false) : []);
        },
        onLiveSearchcreatedon: function () {
            let oTable = this.byId("pendingWithMeTableapproverdashboard");
            let oBinding = oTable.getBinding("items");
            let aFilters = [];

            let oDate = this.byId("Created_OnDash_approval").getDateValue();

            if (oDate) {
                let oStartDate = new Date(oDate);
                oStartDate.setHours(0, 0, 0, 0);
                let oEndDate = new Date(oDate);
                oEndDate.setHours(23, 59, 59, 999);
                aFilters.push(new sap.ui.model.Filter("createdAt", sap.ui.model.FilterOperator.BT, oStartDate, oEndDate));
            }

            oBinding.filter(aFilters.length > 0 ? new sap.ui.model.Filter(aFilters, false) : []);
        },
        onFilterStatusChange: function () {
            var that = this;
            var aSelectedStatuses = that.byId("dashboardfilterstatusid_approval").getSelectedKeys() || [];
            var aSelectedStages = that.byId("dashboardfilterStageid_approval").getSelectedKeys() || [];
            var oTable = this.byId("pendingWithMeTableapproverdashboard");
            if (!oTable) {
                console.error("Table not found!");
                return;
            }
            var oBinding = oTable.getBinding("items");
            if (!oBinding) {
                console.error("Table binding not found!");
                return;
            }
            var aFilters = [];

            if (aSelectedStages.length > 0) {
                var aStageFilters = aSelectedStages.map(function (sStage) {
                    return new sap.ui.model.Filter("stage", sap.ui.model.FilterOperator.EQ, sStage);
                });
                aFilters.push(new sap.ui.model.Filter(aStageFilters, false));
            }
            if (aSelectedStatuses.length > 0) {
                var aStatusFilters = aSelectedStatuses.map(function (sStatus) {
                    return new sap.ui.model.Filter("status", sap.ui.model.FilterOperator.EQ, sStatus);
                });
                aFilters.push(new sap.ui.model.Filter(aStatusFilters, false));
            }
            var oCombinedFilter = aFilters.length > 0 ? new sap.ui.model.Filter(aFilters, true) : null;
            oBinding.filter(oCombinedFilter);
        },
        onClearFilters: function () {
            let oView = this.getView();
            let aControlIds = [
                "Refrence_Number_approval",
                "Pending_withsearcg_approval",
                "Created_ByDash_approval",
                "dashboardfilterStageid_approval",
                "dashboardfilterstatusid_approval"
            ];
            aControlIds.forEach(function (sId) {
                var oControl = oView.byId(sId);
                if (oControl) {
                    if (oControl.setValue) {
                        oControl.setValue("");
                    }
                    if (oControl.setSelectedKeys) {
                        oControl.setSelectedKeys([]);
                    }
                }
            });
            var oTable = oView.byId("pendingWithMeTableapproverdashboard");
            var oBinding = oTable.getBinding("items");
            if (oBinding) {
                oBinding.filter([]);
            }
        },
        
        onSortRefrenceNumber: function (oEvent) {
            let oButton = oEvent.getSource();
            this.sortColumnByPath("refNo", oButton);
        },
        onSortPendingWith: function (oEvent) {
            let oButton = oEvent.getSource();
            this.sortColumnByPath("pendingWith", oButton);
        },
        onSortStatus: function (oEvent) {
            let oButton = oEvent.getSource();
            this.sortColumnByPath("status", oButton);
        },
        onSortStagesData: function (oEvent) {
            let oButton = oEvent.getSource();
            this.sortColumnByPath("stage", oButton);
        },
        onSortCreatedondata: function (oEvent) {
            let oButton = oEvent.getSource();
            this.sortColumnByPath("createdAt", oButton);
        },
        onSortCurrentApprover: function (oEvent) {
            let oButton = oEvent.getSource();
            this.sortColumnByPath("currApprover", oButton);
        },

        sortColumnByPath: function (sPath, oButton) {
            var oTable = this.getView().byId("pendingWithMeTableapproverdashboard");
            var oBinding = oTable.getBinding("items");
            this._mSortDescending = this._mSortDescending || {};
            var bDescending = !this._mSortDescending[sPath];
            this._mSortDescending[sPath] = bDescending;
            var oSorter = new sap.ui.model.Sorter(sPath, bDescending);
            if (oBinding) {
                oBinding.sort(oSorter);
            }
            if (oButton && typeof oButton.setIcon === "function") {
                var sIcon = bDescending ? "sap-icon://sort-descending" : "sap-icon://sort-ascending";
                oButton.setIcon(sIcon);
            }
            var oLabelMap = {
                refNo: "Reference Number",
                pendingWith: "Pending With",
                status: "Status",
                stage: "Stage",
                createdBy: "Created By",
                createdAt: "Created On",
                currApprover: "Current Approver"
            };
            var sLabel = oLabelMap[sPath] || sPath;
            sap.m.MessageToast.show(`Sorted by ${sLabel} in ${bDescending ? "Descending" : "Ascending"} order`);
        },

        onExportTableData: function () {
            var oTable = this.byId("pendingWithMeTableapproverdashboard");
            var aContexts = oTable.getBinding("items").getCurrentContexts();
            if (!aContexts || aContexts.length === 0) {
                sap.m.MessageToast.show("No data available for export.");
                return;
            }
            var aDataToExport = aContexts.map(function (oContext) {
                return oContext.getObject();
            });

            var oExport = new sap.ui.core.util.Export({
                exportType: new sap.ui.core.util.ExportTypeCSV({
                    separatorChar: ","
                }),
                models: new sap.ui.model.json.JSONModel(aDataToExport),
                rows: {
                    path: "/"
                },
                columns: [
                    { name: "Reference Number", template: { content: "{refNo}" } },
                    { name: "Status", template: { content: "{status}" } },
                    { name: "Stage", template: { content: "{stage}" } },
                    { name: "Pending With", template: { content: "{pendingWith}" } },
                    { name: "Created By", template: { content: "{createdBy}" } },
                    { name: "Created At", template: { content: "{createdAt}" } }
                ]
            });
            oExport.saveFile("Approval Dashboard Table Data")
                .catch(function (oError) {
                    sap.m.MessageBox.error("Export failed:\n" + oError);
                })
                .then(function () {
                    oExport.destroy();
                });
        },

        onListItemPress: function(oEvent){
            // let basedNameUI =    this._basedNameUI;
            var oSelectedItem = oEvent.getParameter("listItem");
            var oContext = oSelectedItem.getBindingContext("dashboardtabledata");
            var oData = oContext.getObject();
            var sRefNo = oData.reqID;
           var tupeofui =  oData.type;
           var subtype = oData.newdtl.subType;

           if(tupeofui === "ADPD"){
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("adpdReqIDApproved", {
                approved:"Approved",
                basedNameUIadpd: tupeofui,
                reqID: sRefNo 
            });
        }else if(tupeofui === "SSFD"){
                var oRouter = this.getOwnerComponent().getRouter(this);
                oRouter.navTo("SanctionfdRefApproved", {
                    approved:"Approved",
                    basedNameUISSFD: tupeofui,
                    reqID: sRefNo
                });
           
            }else if(tupeofui === "INTP"){
           
                var oRouter = this.getOwnerComponent().getRouter(this);
                oRouter.navTo("CapexandRevex", {
                    basedNameUI: "INTP"
                });
            }else if(tupeofui === "P24"){
                
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("CostApprovalReqIDApprover", {
                    approved:"Approved",
                    basedNameUICap: "Costapproval",
                    reqID: sRefNo
                    
                });
            }else if(tupeofui === "BR"){
            
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("NewBudgetRequestFormRefApproved", {
                    approved:"Approved",
                    basedNameUINBRF: tupeofui,
                    reqID: sRefNo 
                });
            }else if(tupeofui === "NAB"){
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("NewBudgetRequestFormRefApproved", {
                    approved:"Approved",
                    basedNameUINBRF: tupeofui,
                    reqID: sRefNo 
                });

        }   
        //INFRA
        else if (tupeofui === "ISR") {
            const oRouter = this.getOwnerComponent().getRouter();
            const refNo = oData.refNo || "";
            const subtype = refNo.split("-")[0].toLowerCase();
            const validSubtypes = ["frs", "crs", "srs", "wdrs"];
            if (!validSubtypes.includes(subtype)) {
                sap.m.MessageBox.error("Invalid subtype extracted from refNo.");
                sap.ui.core.BusyIndicator.hide();
                return;
            }
         
            const oSharedModel = this.getOwnerComponent().getModel("shared") || new sap.ui.model.json.JSONModel();
            oSharedModel.setProperty("/approvalType", subtype.toUpperCase());
            this.getOwnerComponent().setModel(oSharedModel, "shared");
       
            sap.ui.core.BusyIndicator.hide();
       
            oRouter.navTo("ISRFormRefApproved", {
                approved:"Approved",
                type: subtype,       // "frs", "wdrs"
                reqID: sRefNo        //  "REQ-IS-0001"
            });
        //    CAPEX AND REVEX
        }else if (tupeofui === "P25") {
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.navTo("CAPEX_AND_REVEXReqIDApprover", {
                approved: "Approved",
                basedNameUICap: "CAPEX_AND_REVEX", // or "REVEX" dynamically if needed
                reqID: sRefNo
            });
        } 
    },
 
        });
});