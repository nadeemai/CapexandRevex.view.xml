sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/ui/core/Fragment",
    "sap/m/MessageBox"
], function(Controller, JSONModel, MessageToast, Fragment, MessageBox) {
    "use strict";
    return Controller.extend ("com.mmapprovalhub.approvalhub.controller.Sanctionfd", {
        onInit: function() {
            // Initialize attachment model
            var oAttachmentData = {
                attachments: []
            };
            var oAttachmentModel = new JSONModel(oAttachmentData);
            this.getView().setModel(oAttachmentModel, "UploadDocSrvTabData");

            // Initialize router and route handlers
            var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            oRouter.getRoute("Sanctionfd").attachPatternMatched(this._onRouteSanctionfdController, this);
            oRouter.getRoute("SanctionfdRef").attachPatternMatched(this._onRouteSanctionfdwithRef, this);
            oRouter.getRoute("SanctionfdRefApproved").attachPatternMatched(this._onRouteSanctionfdApproved, this);

            // Initialize remarks dialog
            // this.remarksDialog = sap.ui.xmlfragment("com.mmapprovalhub.approvalhub.Fragments.remarks", this);
            // this.getView().addDependent(this.remarksDialog);

            this.remarksDialog = sap.ui.xmlfragment(this.getView().getId(), "com.mmapprovalhub.approvalhub.Fragments.remarks", this);
            this.getView().addDependent(this.remarksDialog);

            // Initialize view model
            var oViewModel = new JSONModel({
                enableRowActions: true,
                approvebuttonvisiblity: false,
                approvebuttonfragment: false,
                rejetedbuttonfragmnet: false,
                enableIRR: false,
                sendbackbuttonvisiblity: false,
                remarkModel: "",
                approverRequiredVisible: false, // New property for approver field visibility
                currentUserRole: ""
            });
            this.getView().setModel(oViewModel, "viewenableddatacheck");

            // Initialize timeline model
            var oTimelineData = {
                // timelineItems: [
                //     {
                //         dateTime: "7/22/2016 at 3:00 PM",
                //         title: "Ankit Pathak Created a Request",
                //         text: "Data Save",
                //         userName: "Ankit Pathak",
                //         userPicture: "https://ui-avatars.com/api/?name=Ankit+Rath"
                //     },
                //     {
                //         dateTime: "7/22/2016 at 6:00 PM",
                //         title: "Yugal Created a Request",
                //         text: "Data Submit",
                //         userName: "Yugal",
                //         userPicture: "https://ui-avatars.com/api/?name=Yugal"
                //     },
                //     {
                //         dateTime: "7/22/2016 at 3:00 PM",
                //         title: "Ayushi Mam added a note [Approved]",
                //         text: "Submitted.",
                //         userName: "Ayushi Mam",
                //         userPicture: "https://ui-avatars.com/api/?name=Ayushi"
                //     },
                //     {
                //         dateTime: "7/22/2016 at 3:00 PM",
                //         title: "Aakib Mohd added a note [Approved]",
                //         text: "Done.",
                //         userName: "Aakib Mohd",
                //         userPicture: "https://ui-avatars.com/api/?name=Aakib+Mohd"
                //     }
                // ]
            };
            var oTimelineModel = new JSONModel(oTimelineData);
            this.getView().setModel(oTimelineModel, "timelineModel");
            
        },

        _onRouteSanctionfdApproved: function(oEvent) {
            this._ApprovedCheck = "";
            var oArgs = oEvent.getParameter("arguments");
            this._SanctionfdNameUI = oArgs.basedNameUISSFD;
            var reqID = oArgs.reqID;
            this._reqIDData = reqID;
            this._ApprovedCheck = oArgs.approved;
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;

            oModelV2.read("/Requests", {
                urlParameters: {
                    "$filter": "reqID eq '" + reqID + "'",
                    "$expand": "ssfdDtl"
                },
                success: function(oData) {
                    if (oData && oData.results.length > 0) {
                        let oRequestServiceModel = that.getOwnerComponent().getModel("Requestservicemodel") || new JSONModel();
                        that.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
                        oRequestServiceModel.setData(oData.results[0]);
                        var statusDatacheck = oData.results[0].status;
                        that.statusData = statusDatacheck;
                        that.stagesData = oData.results[0].stage;

                        var oViewModel = that.getView().getModel("viewenableddatacheck");
                        if (statusDatacheck === "Draft" || !statusDatacheck) {
                            oViewModel.setProperty("/enableRowActions", false);
                            oViewModel.setProperty("/approvebuttonvisiblity", false);
                            oViewModel.setProperty("/approverRequiredVisible", false);
                             //forapproavl
                             oViewModel.setProperty("/isApproverScreen", false);
                             oViewModel.setProperty("/enableRowActionsapproval", false);  

                        } else if (statusDatacheck === "Pending" || statusDatacheck === "Pending At HOD") {
                            oViewModel.setProperty("/enableRowActions", false);
                            oViewModel.setProperty("/approvebuttonvisiblity", false);
                            oViewModel.setProperty("/approverRequiredVisible", that._ApprovedCheck === "Approved");
                             //forapproavl
                             oViewModel.setProperty("/isApproverScreen", false);
                             oViewModel.setProperty("/enableRowActionsapproval", false);  
                        } else {
                            oViewModel.setProperty("/enableRowActions", false);
                            oViewModel.setProperty("/approvebuttonvisiblity", false);
                            oViewModel.setProperty("/approverRequiredVisible", false);
                            //forapproavl
                            oViewModel.setProperty("/isApproverScreen", false);
                            oViewModel.setProperty("/enableRowActionsapproval", false);  
                            
                        }

                        if (that._ApprovedCheck === "Approved"  && (statusDatacheck === "Pending" || statusDatacheck === "Pending At HOD")) {
                            oViewModel.setProperty("/enableRowActions", false);
                            oViewModel.setProperty("/approvebuttonvisiblity", true);
                            oViewModel.setProperty("/approverRequiredVisible", true);
                            //for approval
                            var costoverrunShowApprover = oData.results[0].ssfdDtl.subType;
                            if(that.stagesData =="GM PMO" && costoverrunShowApprover == "COR"){
                                oViewModel.setProperty("/isApproverScreen", true);
                                oViewModel.setProperty("/enableRowActionsapproval", true); 
                            }else{
                                oViewModel.setProperty("/isApproverScreen", false);
                                oViewModel.setProperty("/enableRowActionsapproval", false); 
                            }
                        } else {
                            oViewModel.setProperty("/enableRowActions", false);
                            oViewModel.setProperty("/approvebuttonvisiblity", false);
                            oViewModel.setProperty("/approverRequiredVisible", false);
                            //forapproavl
                            oViewModel.setProperty("/isApproverScreen", false);
                            oViewModel.setProperty("/enableRowActionsapproval", false); 
                        }

                        that.onDepartmentDataFetch();
                        that.onMarketDataFetch();
                        that.onLocationDataFetch();
                        that.onHODDataFetch();
                        that.onFetchTimelinessData();
                        that.onAttchmentDataFetch();
                        that.onBudgetDetailDataFetch(reqID);
                    } else {
                        MessageToast.show("No data found for Req ID: " + reqID, { position: "bottom center" });
                    }
                },
                error: function(oError) {
                    MessageToast.show("Failed to load request data.", { position: "bottom center" });
                    console.error("Error fetching request data:", oError);
                }
            });
        },

        _onRouteSanctionfdwithRef: function(oEvent) {
            var oArgs = oEvent.getParameter("arguments");
            this._SanctionfdNameUI = oArgs.basedNameUISSFD;
            var reqID = oArgs.reqID;
            this._reqIDData = reqID;
            this._ApprovedCheck = "";
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;

            oModelV2.read("/Requests", {
                urlParameters: {
                    "$filter": "reqID eq '" + reqID + "'",
                    "$expand": "ssfdDtl"
                },
                success: function(oData) {
                    if (oData && oData.results.length > 0) {
                        let oRequestServiceModel = that.getOwnerComponent().getModel("Requestservicemodel") || new JSONModel();
                        that.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
                        oRequestServiceModel.setData(oData.results[0]);
                        var statusDatacheck = oData.results[0].status;
                        that.statusData = statusDatacheck;

                        var oViewModel = that.getView().getModel("viewenableddatacheck");
                        if (statusDatacheck === "Draft" || !statusDatacheck || statusDatacheck === "Send Back") {
                            oViewModel.setProperty("/enableRowActions", true);
                            oViewModel.setProperty("/approvebuttonvisiblity", false);
                            oViewModel.setProperty("/approverRequiredVisible", false);
                            //forapproavl
                            oViewModel.setProperty("/isApproverScreen", false);
                            oViewModel.setProperty("/enableRowActionsapproval", false);  
                        } else if (statusDatacheck === "Pending" || statusDatacheck === "Pending At HOD") {
                            oViewModel.setProperty("/enableRowActions", false);
                            oViewModel.setProperty("/approvebuttonvisiblity", false);
                            oViewModel.setProperty("/approverRequiredVisible", false);
                            //forapproavl
                            oViewModel.setProperty("/isApproverScreen", false);
                            oViewModel.setProperty("/enableRowActionsapproval", false);  
                        } else if (statusDatacheck === "Approved") {
                            oViewModel.setProperty("/enableRowActions", false);
                            oViewModel.setProperty("/approvebuttonvisiblity", false);
                            oViewModel.setProperty("/approverRequiredVisible", false);
                            //forapproavl
                            oViewModel.setProperty("/isApproverScreen", false);
                            oViewModel.setProperty("/enableRowActionsapproval", false);  
                        }

                        that.onDepartmentDataFetch();
                        that.onMarketDataFetch();
                        that.onLocationDataFetch();
                        that.onHODDataFetch();
                        that.onFetchTimelinessData();
                        that.onAttchmentDataFetch();
                        that.onBudgetDetailDataFetch(reqID);
                    } else {
                        MessageToast.show("No data found for Req ID: " + reqID, { position: "bottom center" });
                    }
                },
                error: function(oError) {
                    MessageToast.show("Failed to load HOD data.", { position: "bottom center" });
                    console.error("Error fetching HOD data:", oError);
                }
            });
        },

        _onRouteSanctionfdController: function(oEvent) {
            var oArgs = oEvent.getParameter("arguments");
            this._SanctionfdNameUI = oArgs.basedNameUISSFD;
            var onInitiateValue = localStorage.getItem("onInitiateValue");
            var onInitiateValueData = "";
            if (onInitiateValue === "New Requirement") {
                onInitiateValueData = "NR";
            } else if (onInitiateValue === "Contingency") {
                onInitiateValueData = "CON";
            } else if (onInitiateValue === "Interline Transfer") {
                onInitiateValueData = "ILT";
            } else if (onInitiateValue === "Budget Carry-Forward") {
                onInitiateValueData = "BCF";
            } else if (onInitiateValue === "Savings") {
                onInitiateValueData = "SAVING";
            } else if (onInitiateValue === "Interhead Transfer") {
                onInitiateValueData = "ITH";
            } else if (onInitiateValue === "Cost Over-Run") {
                onInitiateValueData = "COR";
            } else if (onInitiateValue === "Preproject Approval") {
                onInitiateValueData = "PPA";
            } else if (onInitiateValue === "Capex Budget Carry-Forward") {
                onInitiateValueData = "CBCF";
            } else if (onInitiateValue === "Others") {
                onInitiateValueData = "OTH";
            }
            this._onSubType = onInitiateValueData;
            this._reqIDData = "";
            this._ApprovedCheck = "";
            var oViewModel = this.getView().getModel("viewenableddatacheck");
            oViewModel.setProperty("/enableRowActions", true);
            oViewModel.setProperty("/enableIRR", false);
            oViewModel.setProperty("/approverRequiredVisible", false);
            //forapproavl
            oViewModel.setProperty("/isApproverScreen", false);
            oViewModel.setProperty("/enableRowActionsapproval", false);  
            //*** */

            var oBudgetData = {
                items: [
                    { nature: "Capital Budget", amount: 0, contingency: 0, total: 0 },
                    { nature: "Revenue Budget", amount: 0, contingency: 0, total: 0 },
                    { nature: "Personnel Cost", amount: 0, contingency: 0, total: 0 },
                    { nature: "Total", amount: 0, contingency: 0, total: 0 }
                ]
            };
            var oBudgetModel = new JSONModel(oBudgetData);
            this.getView().setModel(oBudgetModel, "budgetModel");
            var oRequestServiceModel = this.getOwnerComponent().getModel("Requestservicemodel") || new JSONModel();
            this.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
            var oEmptyData = {
                reqID: "",
                refNo: "",
                requesterName: "",
                department: "",
                market: "",
                location: "",
                hod: "",
                ssfdDtl: []
            };
            oRequestServiceModel.setData(oEmptyData);
            this.onDepartmentDataFetch();
            this.onMarketDataFetch();
            this.onLocationDataFetch();
            this.onHODDataFetch();
        },

        onBudgetDetailDataFetch: function(reqID) {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var oBudgetModel = oView.getModel("budgetModel");
            var that = this;
            sap.ui.core.BusyIndicator.show(0);

            oModelV2.read("/ReqFormFD('" + reqID + "')", {
                success: function(oData) {
                    var oJSONModel = new JSONModel(oData);
                    oView.setModel(oJSONModel, "budgetModel");
                    sap.ui.core.BusyIndicator.hide();
                },
                error: function(oError) {
                    sap.ui.core.BusyIndicator.hide();
                    console.error("Error fetching budget data:", oError);
                }
            });
        },

        _updateIRREnabledState: function(totalBudget) {
            var enableIRR = (totalBudget * 100000) > 30000000;
            this.getView().getModel("viewenableddatacheck").setProperty("/enableIRR", enableIRR);
            if (!enableIRR) {
                this.getView().byId("inputIRR").setValue("");
            }
        },

        onFetchTimelinessData: function() {
            var reqid = this._reqIDData;
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

            oModelV2.read("/ProcessLogs", {
                filters: [
                    new sap.ui.model.Filter("reqID", sap.ui.model.FilterOperator.EQ, reqid)
                ],
                urlParameters: {
                    "$orderby": "createdAt desc"
                },
                success: function(oData) {
                    if (oData && oData.results) {
                        var aProcessedData = oData.results.map(function(oLog) {
                            return {
                                createdAt: oLog.createdAt,
                                role: oLog.stage ? "[" + oLog.stage + "]" : "[N/A]",
                                userName: oLog.userName || "Unknown User",
                                userEmail: oLog.userEmail || "N/A",
                                remarks: oLog.remarks || "No remarks provided"
                            };
                        });

                        // Find and move Initiator to bottom
                        var initiatorIndex = aProcessedData.findIndex(function(item) {
                            return item.role.toLowerCase().includes("initiator");
                        });

                        if (initiatorIndex > -1) {
                            var initiatorEntry = aProcessedData.splice(initiatorIndex, 1)[0];
                            aProcessedData.push(initiatorEntry);
                        }

                        var oJSONModel = new sap.ui.model.json.JSONModel({
                            results: aProcessedData
                        });
                        oView.setModel(oJSONModel, "timelinesslogdata");
                    }
                },
                error: function(oError) {
                    sap.m.MessageToast.show("Failed to load process log data.", { position: "bottom center" });
                    console.error("Error fetching timeliness data:", oError);
                }
            });
        },

        formatTimelineTitle: function(role, userName, userEmail) {
            return role + " " + userName + " (" + userEmail + ")";
        },
      onAttchmentDataFetch: function() {
            var reqid = this._reqIDData;
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

            oModelV2.read("/ReqAttachments", {
                filters: [
                    new sap.ui.model.Filter("reqID", sap.ui.model.FilterOperator.EQ, reqid)
                ],
                success: function(oData) {
                    if (oData && oData.results) {
                        var oJSONModel = new JSONModel({
                            attachments: oData.results
                        });
                        oView.setModel(oJSONModel, "UploadDocSrvTabData");
                    }
                },
                error: function(oError) {
                    MessageToast.show("Failed to load attachment data.", { position: "bottom center" });
                    console.error("Error fetching attachment data:", oError);
                }
            });
        },

        onHODDataFetch: function() {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            oModelV2.read("/Approvers", {
                urlParameters: {
                    "$filter": "department eq 'SSFD' and role eq 'HOD'"
                  },
                success: function(oData) {
                    if (oData) {
                        var oJSONModel = new JSONModel(oData);
                        oView.setModel(oJSONModel, "SSHODDatafetchsanc");
                    }
                },
                error: function(oError) {
                    MessageToast.show("Failed to load HOD data.", { position: "bottom center" });
                    console.error("Error fetching HOD data:", oError);
                }
            });
        },

        onDepartmentDataFetch: function() {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            oModelV2.read("/ControlValues", {
                urlParameters: {
                    "$filter": "category eq 'SS_DEPARTMENT'"
                },
                success: function(oData) {
                    if (oData) {
                        var oJSONModel = new JSONModel(oData);
                        oView.setModel(oJSONModel, "SSDEPARTMENTData");
                    }
                },
                error: function(oError) {
                    MessageToast.show("Failed to load department data.", { position: "bottom center" });
                    console.error("Error fetching department data:", oError);
                }
            });
        },

        onMarketDataFetch: function() {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            oModelV2.read("/ControlValues", {
                urlParameters: {
                    "$filter": "category eq 'SS_MARKET'"
                },
                success: function(oData) {
                    if (oData) {
                        var oJSONModel = new JSONModel(oData);
                        oView.setModel(oJSONModel, "SSMARKETDataFetch");
                    }
                },
                error: function(oError) {
                    MessageToast.show("Failed to load market data.", { position: "bottom center" });
                    console.error("Error fetching market data:", oError);
                }
            });
        },

        onLocationDataFetch: function() {
            var oView = this.getView();
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            oModelV2.read("/ControlValues", {
                urlParameters: {
                    "$filter": "category eq 'SS_LOCATION'"
                },
                success: function(oData) {
                    if (oData) {
                        var oJSONModel = new JSONModel(oData);
                        oView.setModel(oJSONModel, "SSLOCATIONDataFetch");
                    }
                },
                error: function(oError) {
                    MessageToast.show("Failed to load location data.", { position: "bottom center" });
                    console.error("Error fetching location data:", oError);
                }
            });
        },

        onDashboardui: function() {
            var oRouter = this.getOwnerComponent().getRouter();
            if (this._ApprovedCheck === "Approved") {
                oRouter.navTo("approverdashboard", {});
            } else if (this._SanctionfdNameUI === "SSFD") {
                oRouter.navTo("DashboardUI", { Name: "SSFD" });
            }
        },

        onCancelSanctionform: function() {
            var oRouter = this.getOwnerComponent().getRouter();
            MessageToast.show("Navigating back to dashboard...", { position: "bottom center" });
            if (this._ApprovedCheck === "Approved") {
                oRouter.navTo("approverdashboard", {});
            } else {
                oRouter.navTo("DashboardUI", { Name: this._SanctionfdNameUI });
            }
        },

        attachmentuploadFilesData: function(reqid) {
            var oModelTabdata = this.getView().getModel("UploadDocSrvTabData");
            var aFilesData = oModelTabdata.getProperty("/attachments") || [];
            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            sap.ui.core.BusyIndicator.show(0);

            aFilesData.forEach(function(file) {
                if (!file.fileName || file.uploaded) return;

                if (file.content && typeof file.content === "string" && file.content.includes(',')) {
                    var base64Content = file.content.split(',')[1];
                    var payload = {
                        fileName: file.fileName,
                        content: base64Content,
                        mediaType: file.mimeType || "text/plain",
                        reqID: reqid
                    };

                    oModel.create("/ReqAttachments", payload, {
                        success: function() {
                            file.uploaded = true;
                            oModelTabdata.refresh(true);
                            sap.ui.core.BusyIndicator.hide();
                        },
                        error: function(oError) {
                            MessageToast.show("Error uploading attachment: " + file.fileName, { position: "bottom center" });
                            console.error("Error uploading attachment:", oError);
                            sap.ui.core.BusyIndicator.hide();
                        }
                    });
                }
            });
        },

        onSaveSanctionform: function() {
            var oView = this.getView();
            var aBudgetItems = oView.getModel("budgetModel").getProperty("/items");
            var reqid = this._reqIDData;
            var statusData = this.statusData || "Draft";
            var satauscheckdata = statusData === "Pending" ? "Pending" : "Draft";
            if (statusData === "Sent Back") {
                satauscheckdata = "Sent Back";
            }
            var oSsfdDtl = {
                division: oView.byId("division").getSelectedKey(),
                puDept: oView.byId("department_sensce").getSelectedKey(),
                hod: oView.byId("Hod_SanctionData").getSelectedKey(),
                loc: oView.byId("comboLocation_Senca").getSelectedKey(),
                projName: oView.byId("inputProjectName").getValue(),
                itemRequiredDesc: oView.byId("inputItemRequired").getValue(),
                budgetRequired: parseFloat(oView.byId("BudgetValue").getValue()) || 0,
                irr: oView.byId("inputIRR").getValue(),
                market: oView.byId("comboMarket_Senca").getSelectedKey(),
                implDt: oView.byId("dateImplement").getDateValue(),
                enggHours: oView.byId("inputHour").getValue(),
                remarks: "",
                background: oView.byId("_IDGenTextArea").getValue(),
                justification: oView.byId("_IDGenTextArea1").getValue(),
                deliverables: oView.byId("_IDGenTextArea2").getValue(),
                capitalBudget: aBudgetItems.find(item => item.nature === "Capital Budget")?.amount || 0,
                revenueBudget: aBudgetItems.find(item => item.nature === "Revenue Budget")?.amount || 0,
                personnelCost: aBudgetItems.find(item => item.nature === "Personnel Cost")?.amount || 0,
                selectedApprover: this._ApprovedCheck === "Approved" ? oView.byId("approverRequiredFrom").getSelectedKey() : ""
            };

            var oSavePayload = {
                stage: "Initiator",
                status: satauscheckdata,
                type: "SSFD",
                remarks: "",
                ssfdDtl: oSsfdDtl
            };

            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;
            if (!reqid) {
                oModel.create("/Requests", oSavePayload, {
                    success: function(oData) {
                        that._reqIDData = oData.reqID;
                        var reqID = oData.reqID;
                        that.attachmentuploadFilesData(oData.reqID);
                        var oRequestServiceModel = that.getOwnerComponent().getModel("Requestservicemodel") || new JSONModel();
                        that.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
                        oRequestServiceModel.setData(oData);
                        MessageBox.success("Request saved successfully!");
                        that.onBudgetDetailDataFetch(reqID);
                    },
                    error: function(oError) {
                        MessageToast.show("Error saving request: " + oError.message, { position: "bottom center" });
                        console.error("Error saving request:", oError);
                    }
                });
            } else {
                oModel.update("/Requests('" + reqid + "')", oSavePayload, {
                    success: function() {
                        that.attachmentuploadFilesData(reqid);
                        var reqID = reqid;
                        that.onBudgetDetailDataFetch(reqID);
                        MessageBox.success("Request updated successfully!");
                    },
                    error: function(oError) {
                        MessageToast.show("Error updating request: " + oError.message, { position: "bottom center" });
                        console.error("Error updating request:", oError);
                    }
                });
            }
        },

        onConfirmSave: function() {
            var oView = this.getView();
            var oFormData = {
                location: oView.byId("comboLocation_Senca").getSelectedKey(),
                budget: oView.byId("BudgetValue").getValue(),
                implementDate: oView.byId("dateImplement").getValue(),
                division: oView.byId("division").getSelectedKey(),
                projectName: oView.byId("inputProjectName").getValue(),
                irr: oView.byId("inputIRR").getValue(),
                department: oView.byId("department_sensce").getSelectedKey(),
                itemRequired: oView.byId("inputItemRequired").getValue(),
                market: oView.byId("comboMarket_Senca").getSelectedKey(),
                hod: oView.byId("Hod_SanctionData").getSelectedKey(),
                date: oView.byId("dateField").getValue(),
                hour: oView.byId("inputHour").getValue(),
                background: oView.byId("_IDGenTextArea").getValue(),
                justification: oView.byId("_IDGenTextArea1").getValue(),
                deliverables: oView.byId("_IDGenTextArea2").getValue(),
                attachments: oView.getModel("UploadDocSrvTabData").getProperty("/attachments"),
                selectedApprover: this._ApprovedCheck === "Approved" ? oView.byId("approverRequiredFrom").getSelectedKey() : ""
            };
            MessageToast.show("Form data and attachments saved.", { position: "bottom center" });
            this._oSaveDialog.close();
        },

        onCancelSave: function() {
            this._oSaveDialog.close();
            MessageToast.show("Save action canceled.", { position: "bottom center" });
        },

        onSubmitSanctionform: function() {
            var isValid = true;
            var oView = this.getView();
            var controls = [
                { control: oView.byId("comboLocation_Senca"), field: "Location" },
                { control: oView.byId("department_sensce"), field: "Department" },
                { control: oView.byId("comboMarket_Senca"), field: "Market" },
                { control: oView.byId("Hod_SanctionData"), field: "HOD" },
                { control: oView.byId("inputHour"), field: "Engineering Hours" }
            ];

            var missingFields = [];

            controls.forEach(function(item) {
                item.control.setValueState("None");
                var value = item.control.getSelectedKey() || item.control.getValue();
                if (!value) {
                    item.control.setValueState("Error");
                    isValid = false;
                    missingFields.push(item.field);
                } else if (item.control.getId().includes("inputHour")) {
                    var hours = parseFloat(value);
                    if (isNaN(hours) || hours <= 0) {
                        item.control.setValueState("Error");
                        isValid = false;
                        missingFields.push(item.field + " (must be a positive number)");
                    }
                }
            });

            if (!isValid) {
                var errorMessage = "Please fill all required fields: " + missingFields.join(", ");
                MessageBox.error(errorMessage);
                return;
            }

            this.getView().getModel("viewenableddatacheck").setProperty("/remarkModel", "");
            oView.getModel("viewenableddatacheck").setProperty("/approvebuttonfragment", false);
            oView.getModel("viewenableddatacheck").setProperty("/rejetedbuttonfragmnet", false);
            oView.getModel("viewenableddatacheck").setProperty("/enableRowActions", true);
            oView.getModel("viewenableddatacheck").setProperty("/sendbackbuttonvisiblity", false);
            oView.getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblityData", false);
            oView.getModel("viewenableddatacheck").setProperty("/approverRequiredVisible", this._ApprovedCheck === "Approved");
            this.remarksDialog.open();
        },

        onComboBoxChange: function(oEvent) {
            var oComboBox = oEvent.getSource();
            var sValue = oEvent.getParameter("newValue") || oComboBox.getValue();
            var aItems = oComboBox.getItems();
            var bValid = aItems.some(function(oItem) {
                return oItem.getKey() === sValue || oItem.getText() === sValue;
            });

            oComboBox.setValueState(bValid ? "None" : "Error");
            if (!bValid) {
                MessageToast.show("Please select a valid option from the dropdown.", { position: "bottom center" });
            }
        },

        onBudgetAmountChange: function(oEvent) {
            var oInput = oEvent.getSource();
            var sNewValue = oEvent.getParameter("value");
            var fValue = parseFloat(sNewValue);
            var oModel = this.getView().getModel("budgetModel");
            var sPath = oInput.getBinding("value").getPath();
            var oContext = oInput.getBindingContext("budgetModel");
            var iIndex = parseInt(oContext.getPath().split("/").pop());
            var aItems = oModel.getProperty("/items");

            if (isNaN(fValue) || fValue < 0) {
                oInput.setValueState("Error");
                MessageToast.show("Budget amount cannot be negative.", { position: "bottom center" });
                return;
            }
            oInput.setValueState("None");

            aItems[iIndex].amount = fValue || 0;
            aItems[iIndex].contingency = aItems[iIndex].nature === "Capital Budget" ? Number((aItems[iIndex].amount * 0.05).toFixed(2)) : 0;
            aItems[iIndex].total = Number((aItems[iIndex].amount + aItems[iIndex].contingency).toFixed(2));

            var iTotalAmount = 0;
            var iTotalContingency = 0;
            for (var i = 0; i < aItems.length - 1; i++) {
                iTotalAmount += aItems[i].amount || 0;
                iTotalContingency += aItems[i].contingency || 0;
            }

            aItems[3].amount = Number(iTotalAmount.toFixed(2));
            aItems[3].contingency = Number(iTotalContingency.toFixed(2));
            aItems[3].total = Number((iTotalAmount + iTotalContingency).toFixed(2));

            oModel.setProperty("/items", aItems);
            oModel.refresh(true);
            this.getView().byId("BudgetValue").setValue(aItems[3].total.toString());
            this._updateIRREnabledState(aItems[3].total);
        },

        onHoursChange: function(oEvent) {
            var oInput = oEvent.getSource();
            var value = oEvent.getParameter("value");
            oInput.setValueState("None");

            if (!value || isNaN(parseFloat(value)) || parseFloat(value) <= 0) {
                oInput.setValueState("Error");
                MessageToast.show("Engineering Hours must be a positive number.", { position: "bottom center" });
            }
        },

        onHodSanctionChange: function(oEvent) {
            this.onComboBoxChange(oEvent);
        },

        onDepartmentSanctionChange: function(oEvent) {
            this.onComboBoxChange(oEvent);
        },

        onMarketSenca: function(oEvent) {
            this.onComboBoxChange(oEvent);
        },

        onLocationSenca: function(oEvent) {
            this.onComboBoxChange(oEvent);
        },

        onApprovedSanctionform: function() {
            var oView = this.getView();
            var hours = oView.byId("inputHour");
            hours.setValueState("None");

            if (!hours.getValue() || isNaN(parseFloat(hours.getValue())) || parseFloat(hours.getValue()) <= 0) {
                hours.setValueState("Error");
                MessageBox.error("Please enter valid Engineering Hours (must be a positive number).");
                return;
            }

            this.getView().getModel("viewenableddatacheck").setProperty("/remarkModel", "");
            oView.getModel("viewenableddatacheck").setProperty("/approvebuttonfragment", true);
            oView.getModel("viewenableddatacheck").setProperty("/rejetedbuttonfragmnet", false);
            oView.getModel("viewenableddatacheck").setProperty("/enableRowActions", false);
            oView.getModel("viewenableddatacheck").setProperty("/sendbackbuttonvisiblity", false);
            oView.getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblityData", true);
            oView.getModel("viewenableddatacheck").setProperty("/approverRequiredVisible", true);
            this.remarksDialog.open();
        },

        onRejectDataSanctionForm: function() {
            var oView = this.getView();
            var hours = oView.byId("inputHour");
            hours.setValueState("None");

            if (!hours.getValue() || isNaN(parseFloat(hours.getValue())) || parseFloat(hours.getValue()) <= 0) {
                hours.setValueState("Error");
                MessageBox.error("Please enter valid Engineering Hours (must be a positive number).");
                return;
            }

            this.getView().getModel("viewenableddatacheck").setProperty("/remarkModel", "");
            oView.getModel("viewenableddatacheck").setProperty("/enableRowActions", false);
            oView.getModel("viewenableddatacheck").setProperty("/sendbackbuttonvisiblity", true);
            oView.getModel("viewenableddatacheck").setProperty("/approvebuttonvisiblityData", false);
            oView.getModel("viewenableddatacheck").setProperty("/approverRequiredVisible", true);
            this.remarksDialog.open();
        },

        onCloseReamrksFrag: function() {
            this.remarksDialog.close();
        },

        onRejectedData: function() {
            var oView = this.getView();
            var reqid = this._reqIDData;
            var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            if (!remarkInput) {
                MessageBox.information("Please provide a remark before Reject.");
                return;
            }
            sap.ui.core.BusyIndicator.show(0);

            var aBudgetItems = oView.getModel("budgetModel").getProperty("/items");
            var oSsfdDtl = {
                division: oView.byId("division").getSelectedKey(),
                puDept: oView.byId("department_sensce").getSelectedKey(),
                hod: oView.byId("Hod_SanctionData").getSelectedKey(),
                loc: oView.byId("comboLocation_Senca").getSelectedKey(),
                projName: oView.byId("inputProjectName").getValue(),
                itemRequiredDesc: oView.byId("inputItemRequired").getValue(),
                budgetRequired: parseFloat(oView.byId("BudgetValue").getValue()) || 0,
                irr: oView.byId("inputIRR").getValue(),
                market: oView.byId("comboMarket_Senca").getSelectedKey(),
                implDt: oView.byId("dateImplement").getDateValue(),
                enggHours: oView.byId("inputHour").getValue(),
                remarks: remarkInput,
                background: oView.byId("_IDGenTextArea").getValue(),
                justification: oView.byId("_IDGenTextArea1").getValue(),
                deliverables: oView.byId("_IDGenTextArea2").getValue(),
                capitalBudget: aBudgetItems.find(item => item.nature === "Capital Budget")?.amount || 0,
                revenueBudget: aBudgetItems.find(item => item.nature === "Revenue Budget")?.amount || 0,
                personnelCost: aBudgetItems.find(item => item.nature === "Personnel Cost")?.amount || 0,
                selectedApprover: this._ApprovedCheck === "Approved" ? oView.byId("approverRequiredFrom").getSelectedKey() : ""
            };

            var oSubmitPayload = {
                stage: "Rejected",
                status: "Rejected",
                type: "SSFD",
                remarks: remarkInput,
                ssfdDtl: oSsfdDtl
            };

            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;

            if (!reqid) {
                oModel.create("/Requests", oSubmitPayload, {
                    success: function(oData) {
                        sap.ui.core.BusyIndicator.hide();
                        that._reqIDData = oData.reqID;
                        that.rejecteddatacheckRejected(oData.reqID);
                    },
                    error: function(oError) {
                        sap.ui.core.BusyIndicator.hide();
                        MessageToast.show("Error saving request: " + oError.message, { position: "bottom center" });
                        console.error("Error saving request:", oError);
                    }
                });
            } else {
                oModel.update("/Requests('" + reqid + "')", oSubmitPayload, {
                    success: function() {
                        sap.ui.core.BusyIndicator.hide();
                        that.rejecteddatacheckRejected(reqid);
                    },
                    error: function(oError) {
                        sap.ui.core.BusyIndicator.hide();
                        MessageToast.show("Error updating request: " + oError.message, { position: "bottom center" });
                        console.error("Error updating request:", oError);
                    }
                });
            }
        },

        rejecteddatacheckRejected: function(reqid) {
            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            var oApprovedPayload = {
                reqID: reqid,
                action: "REJECT",
                remarks: remarkInput
            };
            var that = this;

            oModel.create("/SSFDApproval", oApprovedPayload, {
                success: function() {
                    MessageBox.success("Request rejected successfully!", {
                        onClose: function() {
                            if (that._ApprovedCheck === "Approved") {
                                that.getOwnerComponent().getRouter().navTo("approverdashboard");
                            }
                        }
                    });
                },
                error: function(oError) {
                    MessageToast.show("Error rejecting request.", { position: "bottom center" });
                    console.error("Error rejecting request:", oError);
                }
            });
        },

        onSendbackData: function() {
            var oView = this.getView();
            var reqid = this._reqIDData;
            var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            if (!remarkInput) {
                MessageBox.information("Please provide a remark before submitting.");
                return;
            }

            var aBudgetItems = oView.getModel("budgetModel").getProperty("/items");
            var oSsfdDtl = {
                division: oView.byId("division").getSelectedKey(),
                puDept: oView.byId("department_sensce").getSelectedKey(),
                hod: oView.byId("Hod_SanctionData").getSelectedKey(),
                loc: oView.byId("comboLocation_Senca").getSelectedKey(),
                projName: oView.byId("inputProjectName").getValue(),
                itemRequiredDesc: oView.byId("inputItemRequired").getValue(),
                budgetRequired: parseFloat(oView.byId("BudgetValue").getValue()) || 0,
                irr: oView.byId("inputIRR").getValue(),
                market: oView.byId("comboMarket_Senca").getSelectedKey(),
                implDt: oView.byId("dateImplement").getDateValue(),
                enggHours: oView.byId("inputHour").getValue(),
                remarks: remarkInput,
                background: oView.byId("_IDGenTextArea").getValue(),
                justification: oView.byId("_IDGenTextArea1").getValue(),
                deliverables: oView.byId("_IDGenTextArea2").getValue(),
                capitalBudget: aBudgetItems.find(item => item.nature === "Capital Budget")?.amount || 0,
                revenueBudget: aBudgetItems.find(item => item.nature === "Revenue Budget")?.amount || 0,
                personnelCost: aBudgetItems.find(item => item.nature === "Personnel Cost")?.amount || 0,
                selectedApprover: this._ApprovedCheck === "Approved" ? oView.byId("approverRequiredFrom").getSelectedKey() : ""
            };

            var oSubmitPayload = {
                type: "SSFD",
                remarks: remarkInput,
                ssfdDtl: oSsfdDtl
            };

            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;

            if (!reqid) {
                oModel.create("/Requests", oSubmitPayload, {
                    success: function(oData) {
                        that._reqIDData = oData.reqID;
                        that.sendbackdatacheckApproved(oData.reqID);
                    },
                    error: function(oError) {
                        MessageToast.show("Error saving request: " + oError.message, { position: "bottom center" });
                        console.error("Error saving request:", oError);
                    }
                });
            } else {
                oModel.update("/Requests('" + reqid + "')", oSubmitPayload, {
                    success: function() {
                        that.sendbackdatacheckApproved(reqid);
                    },
                    error: function(oError) {
                        MessageToast.show("Error updating request: " + oError.message, { position: "bottom center" });
                        console.error("Error updating request:", oError);
                    }
                });
            }
        },

        onApprovedData: function() {
            var oView = this.getView();
            var reqid = this._reqIDData;
            var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            if (!remarkInput) {
                MessageBox.information("Please provide a remark before Approve.");
                return;
            }
            sap.ui.core.BusyIndicator.show(0);

            var aBudgetItems = oView.getModel("budgetModel").getProperty("/items");
            var oSsfdDtl = {
                division: oView.byId("division").getSelectedKey(),
                puDept: oView.byId("department_sensce").getSelectedKey(),
                hod: oView.byId("Hod_SanctionData").getSelectedKey(),
                loc: oView.byId("comboLocation_Senca").getSelectedKey(),
                projName: oView.byId("inputProjectName").getValue(),
                itemRequiredDesc: oView.byId("inputItemRequired").getValue(),
                budgetRequired: parseFloat(oView.byId("BudgetValue").getValue()) || 0,
                irr: oView.byId("inputIRR").getValue(),
                market: oView.byId("comboMarket_Senca").getSelectedKey(),
                implDt: oView.byId("dateImplement").getDateValue(),
                enggHours: oView.byId("inputHour").getValue(),
                remarks: remarkInput,
                background: oView.byId("_IDGenTextArea").getValue(),
                justification: oView.byId("_IDGenTextArea1").getValue(),
                deliverables: oView.byId("_IDGenTextArea2").getValue(),
                capitalBudget: aBudgetItems.find(item => item.nature === "Capital Budget")?.amount || 0,
                revenueBudget: aBudgetItems.find(item => item.nature === "Revenue Budget")?.amount || 0,
                personnelCost: aBudgetItems.find(item => item.nature === "Personnel Cost")?.amount || 0,
                selectedApprover: this._ApprovedCheck === "Approved" ? oView.byId("approverRequiredFrom").getSelectedKey() : ""
            };

            var oSubmitPayload = {
                type: "SSFD",
                remarks: remarkInput,
                ssfdDtl: oSsfdDtl
            };

            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;

            if (!reqid) {
                oModel.create("/Requests", oSubmitPayload, {
                    success: function(oData) {
                        that._reqIDData = oData.reqID;
                        sap.ui.core.BusyIndicator.hide();
                        that.approverdatacheckApproved(oData.reqID);
                    },
                    error: function(oError) {
                        sap.ui.core.BusyIndicator.hide();
                        MessageToast.show("Error saving request: " + oError.message, { position: "bottom center" });
                        console.error("Error saving request:", oError);
                    }
                });
            } else {
                oModel.update("/Requests('" + reqid + "')", oSubmitPayload, {
                    success: function() {
                        sap.ui.core.BusyIndicator.hide();
                        that.approverdatacheckApproved(reqid);
                    },
                    error: function(oError) {
                        MessageToast.show("Error updating request: " + oError.message, { position: "bottom center" });
                        console.error("Error updating request:", oError);
                        sap.ui.core.BusyIndicator.hide();
                    }
                });
            }
        },

        onSubmitReamrksData: function() {
            var oView = this.getView();
            var reqid = this._reqIDData;
            var subtypedata = this._onSubType;
            var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            if (!remarkInput) {
                MessageBox.information("Please provide a remark before submitting.");
                return;
            }
            sap.ui.core.BusyIndicator.show(0);

            var aBudgetItems = oView.getModel("budgetModel").getProperty("/items");
            var oSsfdDtl = {
                division: oView.byId("division").getSelectedKey(),
                puDept: oView.byId("department_sensce").getSelectedKey(),
                hod: oView.byId("Hod_SanctionData").getSelectedKey(),
                loc: oView.byId("comboLocation_Senca").getSelectedKey(),
                projName: oView.byId("inputProjectName").getValue(),
                itemRequiredDesc: oView.byId("inputItemRequired").getValue(),
                budgetRequired: parseFloat(oView.byId("BudgetValue").getValue()) || 0,
                irr: oView.byId("inputIRR").getValue(),
                market: oView.byId("comboMarket_Senca").getSelectedKey(),
                implDt: oView.byId("dateImplement").getDateValue(),
                enggHours: oView.byId("inputHour").getValue(),
                remarks: remarkInput,
                subType: subtypedata,
                background: oView.byId("_IDGenTextArea").getValue(),
                justification: oView.byId("_IDGenTextArea1").getValue(),
                deliverables: oView.byId("_IDGenTextArea2").getValue(),
                capitalBudget: aBudgetItems.find(item => item.nature === "Capital Budget")?.amount || 0,
                revenueBudget: aBudgetItems.find(item => item.nature === "Revenue Budget")?.amount || 0,
                personnelCost: aBudgetItems.find(item => item.nature === "Personnel Cost")?.amount || 0,
                selectedApprover: this._ApprovedCheck === "Approved" ? oView.byId("approverRequiredFrom").getSelectedKey() : ""
            };

            var oSubmitPayload = {
                stage: "HOD",
                status: "Pending",
                type: "SSFD",
                remarks: remarkInput,
                ssfdDtl: oSsfdDtl
            };

            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            var that = this;

            if (!reqid) {
                oModel.create("/Requests", oSubmitPayload, {
                    success: function(oData) {
                        sap.ui.core.BusyIndicator.hide();
                        that._reqIDData = oData.reqID;
                        that.attachmentuploadFilesData(oData.reqID);
                        var reqID = oData.reqID;
                        that.approverdatacheck(oData.reqID);
                        var oRequestServiceModel = that.getOwnerComponent().getModel("Requestservicemodel") || new JSONModel();
                        that.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
                        oRequestServiceModel.setData(oData);
                        that.onBudgetDetailDataFetch(reqID);
                    },
                    error: function(oError) {
                        sap.ui.core.BusyIndicator.hide();
                        MessageToast.show("Error saving request: " + oError.message, { position: "bottom center" });
                        console.error("Error saving request:", oError);
                    }
                });
            } else {
                oModel.update("/Requests('" + reqid + "')", oSubmitPayload, {
                    success: function() {
                        sap.ui.core.BusyIndicator.hide();
                        that.attachmentuploadFilesData(reqid);
                        that.approverdatacheck(reqid);
                        var reqID = reqid;
                        that.onBudgetDetailDataFetch(reqID);
                    },
                    error: function(oError) {
                        sap.ui.core.BusyIndicator.hide();
                        MessageToast.show("Error updating request: " + oError.message, { position: "bottom center" });
                        console.error("Error updating request:", oError);
                    }
                });
            }
        },

        sendbackdatacheckApproved: function(reqid) {
            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            var oApprovedPayload = {
                reqID: reqid,
                action: "SENT BACK",
                remarks: remarkInput
            };
            var that = this;

            oModel.create("/SSFDApproval", oApprovedPayload, {
                success: function() {
                    MessageBox.success("Request Sent Back successfully!", {
                        onClose: function() {
                            if (that._ApprovedCheck === "Approved") {
                                that.getOwnerComponent().getRouter().navTo("approverdashboard");
                            }
                        }
                    });
                },
                error: function(oError) {
                    console.error("Error approving request:", oError);
                }
            });
        },

        approverdatacheckApproved: function(reqid) {
            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            var oApprovedPayload = {
                reqID: reqid,
                action: "APPROVE",
                remarks: remarkInput
            };
            var that = this;
            sap.ui.core.BusyIndicator.show(0);

            oModel.create("/SSFDApproval", oApprovedPayload, {
                success: function() {
                    MessageBox.success("Request approved successfully!", {
                        onClose: function() {
                            if (that._ApprovedCheck === "Approved") {
                                sap.ui.core.BusyIndicator.hide();
                                that.getOwnerComponent().getRouter().navTo("approverdashboard");
                            }
                        }
                    });
                },
                error: function(oError) {
                    console.error("Error approving request:", oError);
                }
            });
        },

        approverdatacheck: function(reqid) {
            var oModel = this.getOwnerComponent().getModel("approvalservicev2");
            var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            var oApprovedPayload = {
                reqID: reqid,
                action: "SUBMIT",
                remarks: remarkInput
            };
            var that = this;
            sap.ui.core.BusyIndicator.show(0);

            oModel.create("/SSFDApproval", oApprovedPayload, {
                success: function(oData) {
                    MessageBox.success(oData.SSFDApproval?.message || "Request submitted successfully!", {
                        onClose: function() {
                            if (that._SanctionfdNameUI === "SSFD") {
                                sap.ui.core.BusyIndicator.hide();
                                that.getOwnerComponent().getRouter().navTo("DashboardUI", { Name: "SSFD" });
                            }
                        }
                    });
                },
                error: function(oError) {
                    sap.ui.core.BusyIndicator.hide();
                    MessageToast.show("Error submitting request.", { position: "bottom center" });
                    console.error("Error submitting request:", oError);
                }
            });
        },

        onUploadTabAttchmment: function(oEvent) {
            var oFileUploader = oEvent.getSource();
            var aFiles = oEvent.getParameter("files");
            if (!aFiles || aFiles.length === 0) {
                MessageToast.show("No files selected.", { position: "bottom center" });
                return;
            }

            var oModel = this.getView().getModel("UploadDocSrvTabData");
            var aAttachments = oModel.getProperty("/attachments") || [];
            var sUploadedOn = new Date().toISOString().split("T")[0];

            for (var i = 0; i < aFiles.length; i++) {
                (function(file, index) {
                    var oReader = new FileReader();
                    oReader.onload = function(e) {
                        var sBase64Data = e.target.result;
                        aAttachments.push({
                            ID: new Date().getTime().toString() + index,
                            fileName: file.name,
                            mimeType: file.type,
                            content: sBase64Data,
                            uploadedBy: "Current User",
                            uploadedOn: sUploadedOn,
                            deleteTabVisible: true
                        });

                        if (index === aFiles.length - 1) {
                            oModel.setProperty("/attachments", aAttachments);
                            oModel.refresh(true);
                            MessageToast.show("Files uploaded: " + aFiles.length, { position: "bottom center" });
                            oFileUploader.setValue("");
                        }
                    };
                    oReader.onerror = function() {
                        MessageToast.show("Error reading file: " + file.name, { position: "bottom center" });
                    };
                    oReader.readAsDataURL(file);
                })(aFiles[i], i);
            }
        },

        onUploadPress: function() {
            var oFileUploader = this.byId("fileUploaderTabAttchment");
            var aFiles = oFileUploader.getDomRef().files;

            if (!aFiles || aFiles.length === 0) {
                MessageToast.show("Please select at least one file first.", { position: "bottom center" });
                return;
            }

            var oModel = this.getView().getModel("UploadDocSrvTabData");
            var aAttachments = oModel.getProperty("/attachments") || [];
            var sUploadedOn = new Date().toISOString().split("T")[0];

            aAttachments = aAttachments.filter(function(item) {
                return !item.temp;
            });

            for (var i = 0; i < aFiles.length; i++) {
                (function(file, index) {
                    var oReader = new FileReader();
                    oReader.onload = function(e) {
                        var sBase64Data = e.target.result;
                        aAttachments.push({
                            ID: new Date().getTime().toString() + index,
                            fileName: file.name,
                            uploadedBy: "Current User",
                            uploadedOn: sUploadedOn,
                            deleteTabVisible: true,
                            content: sBase64Data
                        });

                        if (index === aFiles.length - 1) {
                            oModel.setProperty("/attachments", aAttachments);
                            oModel.refresh(true);
                            MessageToast.show("Uploaded " + aFiles.length + " file(s) successfully!", { position: "bottom center" });
                            oFileUploader.setValue("");
                        }
                    };
                    oReader.onerror = function() {
                        MessageToast.show("Error reading file: " + file.name, { position: "bottom center" });
                    };
                    oReader.readAsDataURL(file);
                })(aFiles[i], i);
            }
        },

        onDownloadTabAttachemnt: function(oEvent) {
            var oButton = oEvent.getSource();
            var sID = oButton.getCustomData().find(function(oData) {
                return oData.getKey() === "ID";
            }).getValue();
            var sFileName = oButton.getCustomData().find(function(oData) {
                return oData.getKey() === "fileName";
            }).getValue();

            var oModel = this.getView().getModel("UploadDocSrvTabData");
            var aAttachments = oModel.getProperty("/attachments") || [];
            var oAttachment = aAttachments.find(function(oItem) {
                return oItem.ID === sID;
            });

            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var sPath = "/ReqAttachments(guid'" + sID + "')";
            var that = this;

            oModelV2.read(sPath, {
                success: function(oData) {
                    if (oData && oData.__metadata && oData.__metadata.media_src) {
                        var oLink = document.createElement("a");
                        oLink.href = oData.__metadata.media_src;
                        oLink.download = sFileName;
                        document.body.appendChild(oLink);
                        oLink.click();
                        document.body.removeChild(oLink);
                        MessageToast.show("Downloading file from server: " + sFileName, { position: "bottom center" });
                    } else {
                        that._downloadLocalAttachment(oAttachment, sFileName);
                    }
                },
                error: function() {
                    that._downloadLocalAttachment(oAttachment, sFileName);
                }
            });
        },

        _downloadBase64File: function(sBase64Content, sFileName) {
            try {
                var sBase64Data = sBase64Content.split(',')[1];
                var sMimeType = sBase64Content.split(';')[0].split(':')[1];
                var byteCharacters = atob(sBase64Data);
                var byteNumbers = new Array(byteCharacters.length);
                for (var i = 0; i < byteCharacters.length; i++) {
                    byteNumbers[i] = byteCharacters.charCodeAt(i);
                }
                var byteArray = new Uint8Array(byteNumbers);
                var oBlob = new Blob([byteArray], { type: sMimeType });
                var sUrl = URL.createObjectURL(oBlob);

                var oLink = document.createElement("a");
                oLink.href = sUrl;
                oLink.download = sFileName;
                document.body.appendChild(oLink);
                oLink.click();
                document.body.removeChild(oLink);
                URL.revokeObjectURL(sUrl);
                MessageToast.show("Downloading file: " + sFileName, { position: "bottom center" });
            } catch (e) {
                MessageToast.show("Error downloading file: " + sFileName, { position: "bottom center" });
                console.error("Error downloading file:", e);
            }
        },

        _downloadLocalAttachment: function(oAttachment, sFileName) {
            if (!oAttachment || !oAttachment.content) {
                MessageToast.show("Local file content not found for: " + sFileName, { position: "bottom center" });
                return;
            }
            this._downloadBase64File(oAttachment.content, sFileName);
        },        
            
        

        onDeleteTabAttchment: function(oEvent) {
            var oButton = oEvent.getSource();
            var oModel = this.getView().getModel("UploadDocSrvTabData");
            var aAttachments = oModel.getProperty("/attachments");
            var sID = oButton.getCustomData().find(function(oData) {
                return oData.getKey() === "ID";
            }).getValue();
            var iIndex = aAttachments.findIndex(function(oItem) {
                return oItem.ID === sID;
            });
            if (iIndex === -1) return;

            var sFileName = aAttachments[iIndex].fileName;
            var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
            var sPath = "/ReqAttachments(guid'" + sID + "')";
            var that = this;

            oModelV2.remove(sPath, {
                success: function() {
                    that._removeAttachmentFromLocalModel(oModel, aAttachments, iIndex, sFileName);
                    MessageToast.show("Deleted " + sFileName, { position: "bottom center" });
                },
                error: function(oError) {
                    that._removeAttachmentFromLocalModel(oModel, aAttachments, iIndex, sFileName);
                    MessageToast.show("Deleted " + sFileName, { position: "bottom center" });
                    console.error("Error deleting attachment:", oError);
                }
            });
        },

        _removeAttachmentFromLocalModel: function(oModel, aAttachments, iIndex, sFileName) {
            aAttachments.splice(iIndex, 1);
            oModel.setProperty("/attachments", aAttachments);
            oModel.refresh(true);
        },

        handleLiveChange: function(oEvent) {
            var oTextArea = oEvent.getSource();
            oTextArea.setValueState("None");
        }
    });
});
