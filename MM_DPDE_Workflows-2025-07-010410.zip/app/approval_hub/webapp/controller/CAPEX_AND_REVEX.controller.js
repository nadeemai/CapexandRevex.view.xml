sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/core/routing/History",
    "sap/ui/core/format/DateFormat",
    "sap/ui/core/Fragment"
], function (Controller, JSONModel, MessageToast, MessageBox, History, DateFormat, Fragment) {
    "use strict";

    return Controller.extend("com.mmapprovalhub.approvalhub.controller.CAPEX_AND_REVEX", {
        // Formatter functions
        formatInvoiceLabel: function (sPaymentOption, sPoNonPo) {
            if (sPaymentOption === "Advance Payment") {
                return "Proforma Number";
            }
            return "Invoice Number";
        },

        formatTimelineTitle: function (sRole, sUserName, sUserEmail) {
            return sRole ? `${sRole}: ${sUserName} (${sUserEmail})` : `${sUserName} (${sUserEmail})`;
        },

        // Lifecycle method: Initialize models and bindings
        onInit: function () {
            var oView = this.getView();

            // Initialize router
            this._oRouter = this.getOwnerComponent().getRouter();

            // Initialize models (excluding timeline model)
            var oPortalModel = new JSONModel({
                reqNo: this._generateNewRequestNumber(),
                paymentOption: "",
                paymentType: "",
                poNonPo: "",
                paymentDate: new Date().toISOString().substring(0, 10),
                accountingDocNumber: "",
                po: "",
                vendorCode: "",
                costCenter: "",
                wbs: "",
                totalAmount: "",
                vendorName: "",
                invoiceNumber: "",
                baseAmount: "",
                gst: "",
                tds: "",
                buyerRequester: "",
                buyerHod: "",
                buyerRequesterKey: "",
                buyerHodKey: "",
                paymentTerms: "",
                remarks: "",
            });

            var oFieldEnablementModel = new JSONModel({
                submitFieldsEnabled: true,
                fieldsEnabled: true,
                poEnabled: true
            });

            var oViewEnabledModel = new JSONModel({
                enableRowActions: true,
                remarkModel: "",
                approveButtonVisibility: false,
                sendBackButtonVisibility: false
            });

            var oSearchModel = new JSONModel({
                requestors: [
                    { name: "Requestor 1", key: "req1" },
                    { name: "Requestor 2", key: "req2" }
                ],
                hods: [
                    { name: "HOD 1", key: "hod1" },
                    { name: "HOD 2", key: "hod2" }
                ],
            });

            var oRequestServiceModel = new JSONModel({
                refNo: "REF" + Date.now(),
                ssfdDtl: {
                    background: "",
                    justification: "",
                    deliverables: ""
                }
            });

            var oBudgetModel = new JSONModel({
                items: [
                    { nature: "Item 1", amount: 0, contingency: 0, total: 0 },
                    { nature: "Item 2", amount: 0, contingency: 0, total: 0 },
                    { nature: "Total", amount: 0, contingency: 0, total: 0 }
                ]
            });

            var oUploadDocModel = new JSONModel({
                attachments: []
            });

            // Set models (excluding timeline model)
            oView.setModel(oPortalModel, "portalModel");
            oView.setModel(oFieldEnablementModel, "fieldEnablement");
            oView.setModel(oViewEnabledModel, "viewenableddatacheck");
            oView.setModel(oSearchModel, "searchModel");
            oView.setModel(oRequestServiceModel, "Requestservicemodel");
            oView.setModel(oBudgetModel, "budgetModel");
            oView.setModel(oUploadDocModel, "UploadDocSrvTabData");

            this._updateFieldEnablement();

            // Attach live change event handlers for real-time validation
            var aInputIds = ["cbPaymentOptieon", "cbPaymentTyepe", "cbPoNonePo", "dpPaymentDaete", "inpAccDocNumberer", "inpCostCenterer", 
                            "inpWBSes", "inpVendorCodeee", "inpVendorNameee", "inpBaseAmouneta", "inpInvoiceee", "po", "gst", 
                            "tds", "paymentTerms", "totalAmount"];
            aInputIds.forEach(function(id) {
                var oControl = oView.byId(id);
                if (oControl && oControl.attachLiveChange) {
                    oControl.attachLiveChange(this._handleLiveValidation.bind(this));
                }
            }.bind(this));
        },

        // Route matched handler
        _onRouteMatched: function (oEvent) {
            // Handle route parameters if needed
        },

        // Handle payment option change
        onPaymentOptionChange: function (oEvent) {
            this._updateFieldEnablement();
        },

        // Handle PO/Non-PO change
        onPoNonPoChange: function (oEvent) {
            this._updateFieldEnablement();
        },

        // Update field enablement
        _updateFieldEnablement: function () {
            var oPortalModel = this.getView().getModel("portalModel");
            var oFieldEnablementModel = this.getView().getModel("fieldEnablement");
            var sPaymentOption = oPortalModel.getProperty("/paymentOption");
            var sPoNonPo = oPortalModel.getProperty("/poNonPo");
        
            // Initialize all enablement flags
            var bFieldsEnabled = false; // Controls TDS, GST, Payment Terms, Total Amount
            var bPoEnabled = false;     // Controls PO field
            var bWbsEnabled = true;    // Controls WBS field (new separate property)
        
            // Apply enablement rules based on payment option and PO/Non-PO selection
            if (sPaymentOption === "Advance Payment") {
                if (sPoNonPo === "po") {
                    // Advance Payment with PO Based
                    bPoEnabled = true; // PO should be editable
                    bWbsEnabled = true; // WBS should be editable
                    bFieldsEnabled = false; // TDS, GST, Payment Terms, Total Amount non-editable
                } else if (sPoNonPo === "nonpo") {
                    // Advance Payment with Non-PO
                    bPoEnabled = false; // PO non-editable
                    bWbsEnabled = true; // WBS should be editable
                    bFieldsEnabled = false; // TDS, GST, Payment Terms, Total Amount non-editable
                }
            } else if (sPaymentOption === "Regular Payment") {
                if (sPoNonPo === "po") {
                    // Regular Payment with PO Based
                    bPoEnabled = true;
                    bWbsEnabled = true;
                    bFieldsEnabled = true; // TDS, GST, Payment Terms, Total Amount editable
                } else if (sPoNonPo === "nonpo") {
                    // Regular Payment with Non-PO
                    bPoEnabled = false;
                    bWbsEnabled = true;
                    bFieldsEnabled = true; // TDS, GST, Payment Terms, Total Amount editable
                }
            }
        
            // Update field enablement model with new properties
            oFieldEnablementModel.setProperty("/fieldsEnabled", bFieldsEnabled);
            oFieldEnablementModel.setProperty("/poEnabled", bPoEnabled);
            oFieldEnablementModel.setProperty("/wbsEnabled", bWbsEnabled); // New property
        
            // Clear non-editable fields to prevent stale data
            if (!bFieldsEnabled) {
                oPortalModel.setProperty("/tds", "");
                oPortalModel.setProperty("/gst", "");
                oPortalModel.setProperty("/paymentTerms", "");
                oPortalModel.setProperty("/totalAmount", "");
            }
        
            if (!bWbsEnabled) {
                oPortalModel.setProperty("/wbs", "");
            }
        
            if (!bPoEnabled) {
                oPortalModel.setProperty("/po", "");
            }
        },

        // Load form data
        _loadFormData: function (sRefNo) {
            this._callService(`/formData/${sRefNo}`, "GET")
                .then(function (oResponse) {
                    var oData = oResponse.data || {};

                    this.getView().getModel("portalModel").setData({
                        refNo: sRefNo,
                        reqNo: oData.reqNo || this._generateNewRequestNumber(),
                        paymentOption: oData.paymentOption || "",
                        paymentType: oData.paymentType || "",
                        poNonPo: oData.poNonPo || "",
                        paymentDate: oData.paymentDate || null,
                        accountingDocNumber: oData.accountingDocNumber || "",
                        po: oData.po || "",
                        vendorCode: oData.vendorCode || "",
                        costCenter: oData.costCenter || "",
                        wbs: oData.wbs || "",
                        totalAmount: oData.totalAmount || "",
                        vendorName: oData.vendorName || "",
                        invoiceNumber: oData.invoiceNumber || "",
                        baseAmount: oData.baseAmount || "",
                        gst: oData.gst || "",
                        tds: oData.tds || "",
                        buyerRequester: oData.buyerRequester || "",
                        buyerHod: oData.buyerHod || "",
                        buyerRequesterKey: oData.buyerRequesterKey || "",
                        buyerHodKey: oData.buyerHodKey || "",
                        paymentTerms: oData.paymentTerms || "",
                        remarks: oData.remarks || "",
                    });

                    this.getView().getModel("Requestservicemodel").setData({
                        refNo: sRefNo,
                        ssfdDtl: {
                            background: oData.background || "",
                            justification: oData.justification || "",
                            deliverables: oData.deliverables || ""
                        }
                    });

                    this.getView().getModel("budgetModel").setData({
                        items: oData.budgetItems || [
                            { nature: "Item 1", amount: 0, contingency: 0, total: 0 },
                            { nature: "Item 2", amount: 0, contingency: 0, total: 0 },
                            { nature: "Total", amount: 0, contingency: 0, total: 0 }
                        ]
                    });

                    this.getView().getModel("UploadDocSrvTabData").setData({
                        attachments: oData.attachments || []
                    });

                    this.getView().getModel("fieldEnablement").setData({
                        submitFieldsEnabled: oData.status !== "SUBMITTED" && oData.status !== "APPROVED",
                        fieldsEnabled: !(oData.paymentOption === "Advance Payment" || oData.paymentOption === "Regular Payment"),
                        poEnabled: !(oData.paymentOption === "Advance Payment" || oData.paymentOption === "Regular Payment")
                    });

                    this.getView().getModel("viewenableddatacheck").setProperty("/enableRowActions", 
                        oData.status !== "SUBMITTED" && oData.status !== "APPROVED");

                    MessageToast.show("Form data loaded successfully!");
                }.bind(this))
                .catch(function (oError) {
                    MessageBox.error("Error loading form data: " + (oError.message || "Unknown error"));
                });
        },

        // Navigation to dashboard
        onDashboardui: function () {
            var oHistory = History.getInstance();
            var sPreviousHash = oHistory.getPreviousHash();

            if (sPreviousHash !== undefined) {
                window.history.go(-1);
            } else {
                this._oRouter.navTo("dashboard");
            }
        },

        // Generate unique request number
        _generateNewRequestNumber: function () {
            var now = new Date();
            var year = now.getFullYear().toString().substr(-2); // Last two digits of the year
            var dayOfYear = Math.floor((now - new Date(now.getFullYear(), 0, 0)) / (1000 * 60 * 60 * 24)); // Day of the year (0-365)
            return "REQ" + year + dayOfYear.toString().padStart(3, '0'); // e.g., "REQ250174" for June 23, 2025
        },

        // Save form as draft with confirmation popup
        onSaveCapexravexform: function () {
            if (!this._validateForm()) {
                return;
            }
        
            MessageBox.confirm("Are you sure you want to save this form as a draft?", {
                title: "Confirm Save",
                actions: [MessageBox.Action.YES, MessageBox.Action.NO],
                onClose: function (sAction) {
                    if (sAction === MessageBox.Action.YES) {
                        var oPayload = this._createPayload("DRAFT");
        
                        this._callService("/saveDraft", "POST", oPayload)
                            .then(function () {
                                MessageBox.success("Capex and Revex Request " + oPayload.reqNo + " is saved successfully", {
                                    title: "Save Successful",
                                    onClose: function () {
                                        // Optional: Add any action after closing the popup
                                    }
                                });
                            }.bind(this))
                            .catch(function (oError) {
                                MessageBox.error("Error saving draft: " + (oError.message || "Unknown error"));
                            });
                    }
                }.bind(this)
            });
        },

        // Submit form with enhanced validation
        onSubmitCapexravexform: function() {
            var isValid = true;
            var missingFields = [];
            var oView = this.getView();
            
            // First reset all field states
            this._resetFieldStates();

            // Get payment option and PO/Non-PO selection
            var sPaymentOption = oView.byId("cbPaymentOptieon").getSelectedKey();
            var sPoNonPo = oView.byId("cbPoNonePo").getSelectedKey();
            var bFieldsEnabled = oView.getModel("fieldEnablement").getProperty("/fieldsEnabled");

            // Required fields - these will always be mandatory
            var aMandatoryFields = [
                { id: "cbPaymentOptieon", field: "Payment Option" },
                { id: "cbPaymentTyepe", field: "Payment Type" },
                { id: "cbPoNonePo", field: "PO/Non PO" },
                { id: "dpPaymentDaete", field: "Payment Date" },
                { id: "inpAccDocNumberer", field: "Accounting Document Number" },
                { id: "inpCostCenterer", field: "Cost Center" },
                { id: "inpWBSes", field: "WBS" },
                { id: "inpVendorCodeee", field: "Vendor Code" },
                { id: "inpVendorNameee", field: "Vendor Name" },
                { id: "inpBaseAmouneta", field: "Base Amount" },
                { id: "inpInvoiceee", field: sPaymentOption === "Advance Payment" ? "Proforma Number" : "Invoice Number" }
                
            ];

            // Validate mandatory fields
            aMandatoryFields.forEach(function(item) {
                var oControl = oView.byId(item.id);
                if (!oControl) return;

                var sValue = oControl.getValue ? oControl.getValue().trim() : oControl.getSelectedKey ? oControl.getSelectedKey().trim() : "";
                
                if (item.id === "dpPaymentDaete" && !sValue) {
                    oControl.setValueState("Error");
                    oControl.setValueStateText("This field is mandatory");
                    isValid = false;
                    missingFields.push(item.field);
                } else if (!sValue) {
                    oControl.setValueState("Error");
                    oControl.setValueStateText("This field is mandatory");
                    isValid = false;
                    missingFields.push(item.field);
                } else if (item.id === "inpBaseAmouneta" && sValue && isNaN(parseFloat(sValue))) {
                    oControl.setValueState("Error");
                    oControl.setValueStateText("Must be a valid number");
                    isValid = false;
                    missingFields.push(item.field + " (must be a valid number)");
                }
            });

            // Validate PO if PO is selected
            if (sPoNonPo === "po") {
                var oPoControl = oView.byId("po");
                if (oPoControl) {
                    var sPoValue = oPoControl.getValue ? oPoControl.getValue().trim() : "";
                    if (!sPoValue) {
                        oPoControl.setValueState("Error");
                        oPoControl.setValueStateText("PO Number is required for PO-based payments");
                        isValid = false;
                        missingFields.push("PO Number");
                    }
                }
            }

            // Conditionally required fields (only when fields are enabled)
            if (bFieldsEnabled) {
                var aConditionalFields = [
                    { id: "gst", field: "GST" },
                    { id: "tds", field: "TDS" },
                    { id: "paymentTerms", field: "Payment Terms" },
                    { id: "totalAmount", field: "Total Amount" }
                ];

                aConditionalFields.forEach(function(item) {
                    var oControl = oView.byId(item.id);
                    if (!oControl) return;

                    var sValue = oControl.getValue ? oControl.getValue().trim() : "";

                    if (!sValue) {
                        oControl.setValueState("Error");
                        oControl.setValueStateText("This field is mandatory for Regular Payment");
                        isValid = false;
                        missingFields.push(item.field);
                    } else if (["gst", "tds", "totalAmount"].includes(item.id) && sValue && isNaN(parseFloat(sValue))) {
                        oControl.setValueState("Error");
                        oControl.setValueStateText("Must be a valid number");
                        isValid = false;
                        missingFields.push(item.field + " (must be a valid number)");
                    }
                });
            }

            // Final validation result
            if (!isValid) {
                var errorMessage = "Please fill all required fields:\n" +
                    missingFields.map(field => "• " + field).join("\n");

                // MessageBox.error(errorMessage, {
                //     title: "Missing Required Fields",
                //     // details: "All fields marked with (*) are mandatory.",
                //     actions: [MessageBox.Action.OK]
                // });
                return;
            }

            // Additional validation from _validateForm
            if (!this._validateForm()) {
                return;
            }

            // Open Remarks Dialog
            if (!this._oRemarksDialog) {
                Fragment.load({
                    id: oView.getId(),
                    name: "com/mmapprovalhub/approvalhub/Fragments/RemarksDialog",
                    controller: this
                }).then(function(oDialog) {
                    this._oRemarksDialog = oDialog;
                    oView.addDependent(this._oRemarksDialog);
                    oView.getModel("viewenableddatacheck").setProperty("/remarkModel", "");
                    this._oRemarksDialog.open();
                }.bind(this));
            } else {
                oView.getModel("viewenableddatacheck").setProperty("/remarkModel", "");
                this._oRemarksDialog.open();
            }
        },

        // Helper function to reset all field states
        _resetFieldStates: function() {
            var oView = this.getView();
            var aControlIds = [
                "cbPaymentOptieon", "cbPaymentTyepe", "cbPoNonePo", "dpPaymentDaete",
                "inpAccDocNumberer", "inpCostCenterer", "inpWBSes", "inpVendorCodeee",
                "inpVendorNameee", "inpBaseAmouneta", "inpInvoiceee", "po", "gst",
                "tds", "paymentTerms", "totalAmount"
            ];

            aControlIds.forEach(function(sId) {
                var oControl = oView.byId(sId);
                if (oControl) {
                    oControl.setValueState("None");
                    oControl.setValueStateText("");
                }
            });
        },

        // Helper function to get control value
        _getControlValue: function(sControlId) {
            var oControl = this.getView().byId(sControlId);
            if (!oControl) return "";
            
            if (oControl.getValue) {
                return oControl.getValue();
            } else if (oControl.getSelectedKey) {
                return oControl.getSelectedKey();
            } else if (oControl.getDate) {
                return oControl.getDate();
            }
            return "";
        },

        // Handle live validation for input fields
        _handleLiveValidation: function(oEvent) {
            var oControl = oEvent.getSource();
            var sValue = oControl.getValue ? oControl.getValue().trim() : oControl.getSelectedKey ? oControl.getSelectedKey().trim() : "";
            var sId = oControl.getId();

            // Clear error if field is filled with valid data
            if (sId === "dpPaymentDaete" && sValue) {
                oControl.setValueState("None");
                oControl.setValueStateText("");
            } else if (sValue && ["cbPaymentOptieon", "cbPaymentTyepe", "cbPoNonePo", "inpAccDocNumberer", "inpCostCenterer", 
                                 "inpWBSes", "inpVendorCodeee", "inpVendorNameee", "inpInvoiceee", "po"].includes(sId)) {
                oControl.setValueState("None");
                oControl.setValueStateText("");
            } else if (sId === "inpBaseAmouneta" && sValue && !isNaN(parseFloat(sValue))) {
                oControl.setValueState("None");
                oControl.setValueStateText("");
            } else if (["gst", "tds", "totalAmount"].includes(sId) && sValue && !isNaN(parseFloat(sValue))) {
                oControl.setValueState("None");
                oControl.setValueStateText("");
            }
            // Show error for empty mandatory fields or invalid data
            else if (sId === "dpPaymentDaete" && !sValue) {
                oControl.setValueState("Error");
                oControl.setValueStateText("This field is mandatory");
            } else if (!sValue && ["cbPaymentOptieon", "cbPaymentTyepe", "cbPoNonePo", "inpAccDocNumberer", "inpCostCenterer", 
                                  "inpWBSes", "inpVendorCodeee", "inpVendorNameee", "inpInvoiceee"].includes(sId)) {
                oControl.setValueState("Error");
                oControl.setValueStateText("This field is mandatory");
            } else if (sId === "inpBaseAmouneta" && sValue && isNaN(parseFloat(sValue))) {
                oControl.setValueState("Error");
                oControl.setValueStateText("Must be a valid number");
            } else if (["gst", "tds", "totalAmount"].includes(sId) && sValue && isNaN(parseFloat(sValue))) {
                oControl.setValueState("Error");
                oControl.setValueStateText("Must be a valid number");
            }
        },

        // Submit remarks and form
        onSubmitReamrksData: function () {
            var sRemarks = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            if (!sRemarks) {
                MessageToast.show("Please enter remarks before submitting.");
                return;
            }

            var oPayload = this._createPayload("SUBMITTED", sRemarks);

            this._callService("/submitForm", "POST", oPayload)
                .then(function () {
                    // Prepare timeline data to pass to Approver screen
                    var oTimelineData = {
                        results: oPayload.approvalHistory || []
                    };

                    MessageToast.show("Form submitted successfully. Request Number: " + oPayload.reqNo);
                    this.getView().getModel("fieldEnablement").setProperty("/submitFieldsEnabled", false);
                    this.getView().getModel("fieldEnablement").setProperty("/fieldsEnabled", false);
                    this.getView().getModel("viewenableddatacheck").setProperty("/enableRowActions", false);
                    this._oRemarksDialog.close();

                    // Navigate to Approval screen with form data and timeline
                    this._oRouter.navTo("approval", {
                        reqNo: oPayload.reqNo,
                        formData: encodeURIComponent(JSON.stringify(oPayload)),
                        timelineData: encodeURIComponent(JSON.stringify(oTimelineData))
                    });
                }.bind(this))
                .catch(function (oError) {
                    MessageBox.error("Error submitting form: " + (oError.message || "Unknown error"));
                });
        },

        // Approve action
        onApprovedData: function () {
            var sRemarks = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            if (!sRemarks) {
                MessageToast.show("Please enter remarks before approving.");
                return;
            }

            var oPortalModel = this.getView().getModel("portalModel").getData();
            var oTimelineModel = this.getView().getModel("timelinesslogdata");

            var oTimelineEntry = {
                role: "Approver",
                userName: "John Doe",
                userEmail: "john.doe@example.com",
                remarks: `Form approved. Remarks: ${sRemarks}`,
                createdAt: new Date().toISOString(),
                userPicture: ""
            };

            var oPayload = {
                refNo: oPortalModel.refNo || oPortalModel.reqNo,
                reqNo: oPortalModel.reqNo,
                status: "APPROVED",
                remarks: sRemarks,
                approvalHistory: [oTimelineEntry]
            };

            this._callService("/approveForm", "POST", oPayload)
                .then(function () {
                    var aTimelineData = oTimelineModel.getProperty("/results");
                    aTimelineData.push(oTimelineEntry);
                    oTimelineModel.refresh(true);

                    MessageToast.show("Form approved successfully.");
                    this._oRemarksDialog.close();
                }.bind(this))
                .catch(function (oError) {
                    MessageBox.error("Error approving form: " + (oError.message || "Unknown error"));
                });
        },

        // Reject action
        onRejectData: function () {
            var sRemarks = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            if (!sRemarks) {
                MessageToast.show("Please enter remarks before rejecting.");
                return;
            }

            var oPortalModel = this.getView().getModel("portalModel").getData();
            var oTimelineModel = this.getView().getModel("timelinesslogdata");

            var oTimelineEntry = {
                role: "Approver",
                userName: "John Doe",
                userEmail: "john.doe@example.com",
                remarks: `Form rejected. Remarks: ${sRemarks}`,
                createdAt: new Date().toISOString(),
                userPicture: ""
            };

            var oPayload = {
                refNo: oPortalModel.refNo || oPortalModel.reqNo,
                reqNo: oPortalModel.reqNo,
                status: "REJECTED",
                remarks: sRemarks,
                approvalHistory: [oTimelineEntry]
            };

            this._callService("/rejectForm", "POST", oPayload)
                .then(function () {
                    var aTimelineData = oTimelineModel.getProperty("/results");
                    aTimelineData.push(oTimelineEntry);
                    oTimelineModel.refresh(true);

                    MessageToast.show("Form rejected successfully.");
                    this._oRemarksDialog.close();
                }.bind(this))
                .catch(function (oError) {
                    MessageBox.error("Error rejecting form: " + (oError.message || "Unknown error"));
                });
        },

        // Send back action
        onSendbackData: function () {
            var sRemarks = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
            if (!sRemarks) {
                MessageToast.show("Please enter remarks before sending back.");
                return;
            }

            var oPortalModel = this.getView().getModel("portalModel").getData();
            var oTimelineModel = this.getView().getModel("timelinesslogdata");

            var oTimelineEntry = {
                role: "Approver",
                userName: "John Doe",
                userEmail: "john.doe@example.com",
                remarks: `Form sent back. Remarks: ${sRemarks}`,
                createdAt: new Date().toISOString(),
                userPicture: ""
            };

            var oPayload = {
                refNo: oPortalModel.refNo || oPortalModel.reqNo,
                reqNo: oPortalModel.reqNo,
                status: "SENT_BACK",
                remarks: sRemarks,
                approvalHistory: [oTimelineEntry]
            };

            this._callService("/sendBackForm", "POST", oPayload)
                .then(function () {
                    var aTimelineData = oTimelineModel.getProperty("/results");
                    aTimelineData.push(oTimelineEntry);
                    oTimelineModel.refresh(true);

                    MessageToast.show("Form sent back successfully.");
                    this._oRemarksDialog.close();
                }.bind(this))
                .catch(function (oError) {
                    MessageBox.error("Error sending back form: " + (oError.message || "Unknown error"));
                });
        },

        // Close remarks dialog
        onCloseReamrksFrag: function () {
            this.getView().getModel("viewenableddatacheck").setProperty("/remarkModel", "");
            this._oRemarksDialog.close();
        },

        // Create payload for save and submit
        _createPayload: function (sStatus, sRemarks) {
            var oPortalModel = this.getView().getModel("portalModel").getData();
            var oRequestServiceModel = this.getView().getModel("Requestservicemodel").getData();
            var oBudgetModel = this.getView().getModel("budgetModel").getData();
            var oTimelineModel = this.getView().getModel("timelinesslogdata") || new JSONModel({ results: [] }).getData();

            var oTimelineEntry = sRemarks ? [{
                role: "Submitter",
                userName: "Alice Smith",
                userEmail: "alice.smith@example.com",
                remarks: `Form ${sStatus.toLowerCase()} with Request Number: ${oPortalModel.reqNo}. Remarks: ${sRemarks}`,
                createdAt: new Date().toISOString(),
                userPicture: ""
            }] : [];

            return {
                refNo: oRequestServiceModel.refNo,
                reqNo: oPortalModel.reqNo,
                paymentOption: oPortalModel.paymentOption,
                paymentType: oPortalModel.paymentType,
                poNonPo: oPortalModel.poNonPo,
                paymentDate: oPortalModel.paymentDate,
                accountingDocNumber: oPortalModel.accountingDocNumber,
                po: oPortalModel.po,
                vendorCode: oPortalModel.vendorCode,
                costCenter: oPortalModel.costCenter,
                wbs: oPortalModel.wbs,
                totalAmount: oPortalModel.totalAmount,
                vendorName: oPortalModel.vendorName,
                invoiceNumber: oPortalModel.invoiceNumber,
                baseAmount: oPortalModel.baseAmount,
                gst: oPortalModel.gst,
                tds: oPortalModel.tds,
                buyerRequester: oPortalModel.buyerRequester,
                buyerHod: oPortalModel.buyerHod,
                buyerRequesterKey: oPortalModel.buyerRequesterKey,
                buyerHodKey: oPortalModel.buyerHodKey,
                paymentTerms: oPortalModel.paymentTerms,
                remarks: sRemarks || oPortalModel.remarks,
                background: oRequestServiceModel.ssfdDtl.background,
                justification: oRequestServiceModel.ssfdDtl.justification,
                deliverables: oRequestServiceModel.ssfdDtl.deliverables,
                budgetItems: oBudgetModel.items,
                status: sStatus,
                approvalHistory: sStatus === "SUBMITTED" ? [...oTimelineModel.results, ...oTimelineEntry] : oTimelineModel.results
            };
        },

        // Validate form
        _validateForm: function () {
            var oPortalModel = this.getView().getModel("portalModel").getData();
            var oRequestServiceModel = this.getView().getModel("Requestservicemodel").getData();
            var oFieldEnablementModel = this.getView().getModel("fieldEnablement");
            var bFieldsEnabled = oFieldEnablementModel.getProperty("/fieldsEnabled");
            var bValid = true;

            var aRequiredFields = [
                { field: "paymentOption", value: oPortalModel.paymentOption, label: "Payment Option" },
                { field: "paymentType", value: oPortalModel.paymentType, label: "Payment Type" },
                { field: "poNonPo", value: oPortalModel.poNonPo, label: "PO/Non PO" },
                { field: "paymentDate", value: oPortalModel.paymentDate, label: "Payment Date" },
                { field: "vendorName", value: oPortalModel.vendorName, label: "Vendor Name" },
                { field: "invoiceNumber", value: oPortalModel.invoiceNumber, label: "Invoice Number" },
                { field: "costCenter", value: oPortalModel.costCenter, label: "Cost Center" },
                { field: "baseAmount", value: oPortalModel.baseAmount, label: "Base Amount" },
                { field: "buyerRequester", value: oPortalModel.buyerRequester, label: "Buyer Requestor" },
            ];

            if (bFieldsEnabled) {
                aRequiredFields.push({ field: "gst", value: oPortalModel.gst, label: "GST" });
                aRequiredFields.push({ field: "tds", value: oPortalModel.tds, label: "TDS" });
                aRequiredFields.push({ field: "paymentTerms", value: oPortalModel.paymentTerms, label: "Payment Terms" });
                aRequiredFields.push({ field: "totalAmount", value: oPortalModel.totalAmount, label: "Total Amount" });
            }

            aRequiredFields.forEach(function (oField) {
                if (!oField.value || oField.value === "") {
                    MessageToast.show(`${oField.label} is a required field.`);
                    bValid = false;
                } else if (["baseAmount", "gst", "tds", "totalAmount"].includes(oField.field) && isNaN(parseFloat(oField.value))) {
                    MessageToast.show(`${oField.label} must be a valid number.`);
                    bValid = false;
                }
            });

            return bValid;
        },

        // Reset form
        _resetForm: function () {
            this.getView().getModel("portalModel").setData({
                reqNo: this._generateNewRequestNumber(),
                paymentOption: "",
                paymentType: "",
                poNonPo: "",
                paymentDate: null,
                accountingDocNumber: "",
                po: "",
                vendorCode: "",
                costCenter: "",
                wbs: "",
                totalAmount: "",
                vendorName: "",
                invoiceNumber: "",
                baseAmount: "",
                gst: "",
                tds: "",
                buyerRequester: "",
                buyerHod: "",
                buyerRequesterKey: "",
                buyerHodKey: "",
                paymentTerms: "",
                remarks: "",
            });

            this.getView().getModel("Requestservicemodel").setData({
                refNo: "REF" + Date.now(),
                ssfdDtl: {
                    background: "",
                    justification: "",
                    deliverables: ""
                }
            });

            this.getView().getModel("budgetModel").setData({
                items: [
                    { nature: "Item 1", amount: 0, contingency: 0, total: 0 },
                    { nature: "Item 2", amount: 0, contingency: 0, total: 0 },
                    { nature: "Total", amount: 0, contingency: 0, total: 0 }
                ]
            });

            this.getView().getModel("UploadDocSrvTabData").setData({
                attachments: []
            });

            this.getView().getModel("fieldEnablement").setData({
                submitFieldsEnabled: true,
                fieldsEnabled: true,
                poEnabled: true
            });

            this.getView().getModel("viewenableddatacheck").setData({
                enableRowActions: true,
                remarkModel: "",
                approveButtonVisibility: false,
                sendBackButtonVisibility: false
            });
        },

        // Handle buyer requester selection
        onSuggestionItemSelectedBuyerRequester: function (oEvent) {
            var oSelectedItem = oEvent.getParameter("selectedItem");
            if (oSelectedItem) {
                this.getView().getModel("portalModel").setProperty("/buyerRequester", oSelectedItem.getText());
                this.getView().getModel("portalModel").setProperty("/buyerRequesterKey", oSelectedItem.getKey());
            }
        },

        // Handle buyer HOD selection
        onSuggestionItemSelectedBuyerHod: function (oEvent) {
            var oSelectedItem = oEvent.getParameter("selectedItem");
            if (oSelectedItem) {
                this.getView().getModel("portalModel").setProperty("/buyerHod", oSelectedItem.getText());
                this.getView().getModel("portalModel").setProperty("/buyerHodKey", oSelectedItem.getKey());
            }
        },

        // Handle live change in text areas
        handleLiveChange: function (oEvent) {
            var oTextArea = oEvent.getSource();
            var sValue = oEvent.getParameter("value");
            if (sValue.length > 4000) {
                oTextArea.setValueState("Error");
                oTextArea.setValueStateText("Maximum 4000 characters allowed.");
            } else {
                oTextArea.setValueState("None");
                oTextArea.setValueStateText("");
            }
        },

        // Handle budget amount change
        onBudgetAmountChange: function (oEvent) {
            var oInput = oEvent.getSource();
            var fAmount = parseFloat(oInput.getValue()) || 0;
            var oItem = oInput.getBindingContext("budgetModel").getObject();
            oItem.contingency = fAmount * 0.05;
            oItem.total = fAmount + oItem.contingency;

            var oBudgetModel = this.getView().getModel("budgetModel");
            var aItems = oBudgetModel.getProperty("/items");
            var oTotalItem = aItems.find(function (item) { return item.nature === "Total"; });
            var fTotalAmount = aItems.reduce(function (sum, item) {
                return item.nature !== "Total" ? sum + (parseFloat(item.amount) || 0) : sum;
            }, 0);
            oTotalItem.amount = fTotalAmount;
            oTotalItem.contingency = fTotalAmount * 0.05;
            oTotalItem.total = fTotalAmount + oTotalItem.contingency;

            oBudgetModel.refresh(true);
        },

        // Handle file upload
        onUploadTabAttchmment: function (oEvent) {
            var oFileUploader = oEvent.getSource();
            var aFiles = oEvent.getParameter("files");
            var oUploadModel = this.getView().getModel("UploadDocSrvTabData");

            for (var i = 0; i < aFiles.length; i++) {
                var oFile = aFiles[i];
                var oFormData = new FormData();
                oFormData.append("file", oFile);
                oFormData.append("parentType", "Request");

                this._uploadFile("/uploadAttachment", oFormData)
                    .then(function (oResponse) {
                        var aAttachments = oUploadModel.getProperty("/attachments");
                        aAttachments.push({
                            fileName: oFile.name,
                            uploadedOn: new Date().toISOString(),
                            uploadedBy: "Current User",
                            ID: oResponse.ID || Date.now().toString()
                        });
                        oUploadModel.refresh(true);
                        MessageToast.show("File uploaded successfully!");
                    }.bind(this))
                    .catch(function (oError) {
                        MessageBox.error("Error uploading file: " + (oError.message || "Unknown error"));
                    });
            }
        },

        // Handle file download
        onDownloadTabAttachemnt: function (oEvent) {
            var oButton = oEvent.getSource();
            var sFileName = oButton.getCustomData().find(function (oCustomData) {
                return oCustomData.getKey() === "fileName";
            }).getValue();
            var sID = oButton.getCustomData().find(function (oCustomData) {
                return oCustomData.getKey() === "ID";
            }).getValue();

            this._callService(`/downloadAttachment/${sID}`, "GET")
                .then(function (oResponse) {
                    var blob = new Blob([oResponse.data], { type: oResponse.contentType });
                    var url = URL.createObjectURL(blob);
                    var a = document.createElement("a");
                    a.href = url;
                    a.download = sFileName;
                    a.click();
                    URL.revokeObjectURL(url);
                }.bind(this))
                .catch(function (oError) {
                    MessageBox.error("Error downloading file: " + (oError.message || "Unknown error"));
                });
        },

        // Handle file deletion
        onDeleteTabAttchment: function (oEvent) {
            var oButton = oEvent.getSource();
            var sFileName = oButton.getCustomData().find(function (oCustomData) {
                return oCustomData.getKey() === "fileName";
            }).getValue();
            var sID = oButton.getCustomData().find(function (oCustomData) {
                return oCustomData.getKey() === "ID";
            }).getValue();
            var oUploadModel = this.getView().getModel("UploadDocSrvTabData");

            MessageBox.confirm(`Are you sure you want to delete ${sFileName}?`, {
                title: "Confirm Deletion",
                actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                onClose: function (sAction) {
                    if (sAction === MessageBox.Action.OK) {
                        this._callService(`/deleteAttachment/${sID}`, "DELETE")
                            .then(function () {
                                var aAttachments = oUploadModel.getProperty("/attachments");
                                var iIndex = aAttachments.findIndex(function (item) { return item.ID === sID; });
                                if (iIndex !== -1) {
                                    aAttachments.splice(iIndex, 1);
                                    oUploadModel.refresh(true);
                                    MessageToast.show("File deleted successfully!");
                                }
                            }.bind(this))
                            .catch(function (oError) {
                                MessageBox.error("Error deleting file: " + (oError.message || "Unknown error"));
                            });
                    }
                }.bind(this)
            });
        },

        // Mock service call
        _callService: function (sUrl, sMethod, oData) {
            return new Promise(function (resolve, reject) {
                setTimeout(function () {
                    resolve({
                        status: "Success",
                        data: {
                            refNo: oData?.refNo || "REF123456",
                            reqNo: oData?.reqNo || this._generateNewRequestNumber(),
                            paymentOption: oData?.paymentOption || "",
                            paymentType: oData?.paymentType || "",
                            poNonPo: oData?.poNonPo || "",
                            paymentDate: oData?.paymentDate || null,
                            accountingDocNumber: oData?.accountingDocNumber || "",
                            po: oData?.po || "",
                            vendorCode: oData?.vendorCode || "",
                            costCenter: oData?.costCenter || "",
                            wbs: oData?.wbs || "",
                            totalAmount: oData?.totalAmount || "",
                            vendorName: oData?.vendorName || "",
                            invoiceNumber: oData?.invoiceNumber || "",
                            baseAmount: oData?.baseAmount || "",
                            gst: oData?.gst || "",
                            tds: oData?.tds || "",
                            buyerRequester: oData?.buyerRequester || "",
                            buyerHod: oData?.buyerHod || "",
                            buyerRequesterKey: oData?.buyerRequesterKey || "",
                            buyerHodKey: oData?.buyerHodKey || "",
                            paymentTerms: oData?.paymentTerms || "",
                            remarks: oData?.remarks || "",
                            background: oData?.background || "",
                            justification: oData?.justification || "",
                            deliverables: oData?.deliverables || "",
                            budgetItems: oData?.budgetItems || [
                                { nature: "Item 1", amount: 0, contingency: 0, total: 0 },
                                { nature: "Item 2", amount: 0, contingency: 0, total: 0 },
                                { nature: "Total", amount: 0, contingency: 0, total: 0 }
                            ],
                            attachments: oData?.attachments || [],
                            approvalHistory: oData?.approvalHistory || [],
                            status: oData?.status || "DRAFT",
                        }
                    });
                }.bind(this), 500);
            }.bind(this));
        },

        // Mock file upload
        _uploadFile: function (sUrl, oFormData) {
            return new Promise(function (resolve, reject) {
                setTimeout(function () {
                    resolve({ ID: Date.now().toString() });
                }, 500);
            });
        }
    });
});