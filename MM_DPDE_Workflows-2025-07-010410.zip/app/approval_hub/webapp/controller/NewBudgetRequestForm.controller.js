sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageToast",
  "sap/m/MessageBox",
], (Controller, JSONModel, MessageToast, MessageBox) => {
  "use strict";

  return Controller.extend("com.mmapprovalhub.approvalhub.controller.NewBudgetRequestForm", {
    onInit() {

      var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
      oRouter.getRoute("NewBudgetRequestForm").attachPatternMatched(this._onRouteBudReqController, this); //proceed
      oRouter.getRoute("NewBudgetRequestFormRef").attachPatternMatched(this._onRouteNewBudgetRequestFormRef, this); //Tab Nav
      oRouter.getRoute("NewBudgetRequestFormRefApproved").attachPatternMatched(this._onRouteNewBudgetRequestFormRefApproved, this); //Approver

      // this.remarksDialog = sap.ui.xmlfragment("com.mmapprovalhub.approvalhub.Fragments.remarks", this);
      // this.getView().addDependent(this.remarksDialog);
      this.remarksDialog = sap.ui.xmlfragment(this.getView().getId(), "com.mmapprovalhub.approvalhub.Fragments.remarks", this);
      this.getView().addDependent(this.remarksDialog);

      this.onNBRFDivisionData();
      this.onNBRFLocationData();
      this.onNBRFContingencyData();
      this.onNewBudgetApproverR1();
      this.onNewBudgetApproverR2();
      this.onNewBudgetApproverR3();

      this.onAdditionalApprovalforBudget();
      this.onDocumentCategory();
      this.onAssignApprover();
      this.onRecommendedBy1();
      this.onRecommendedBy2();
      this.onRecommendedBy3();
      this.onRecommendedBy4();
      this.onRecommendedBy5();
      this.onRecommendedBy6();
      this.onApprovedBy();
      this.onCorporateTeamApprover();


      var oAttachmentData = { attachments: [] };
      var oAttachmentModel = new JSONModel(oAttachmentData);
      this.getView().setModel(oAttachmentModel, "UploadDocSrvTabData");

      var oModelDate = new sap.ui.model.json.JSONModel();
      var oDate = new Date();
      var sFormattedDate = oDate.toISOString().split("T")[0];
      oModelDate.setData({ CreationDate: sFormattedDate });
      this.getView().setModel(oModelDate);

      this.getView().byId("RevenueBudgetInput").attachBrowserEvent("keydown", function (oEvent) {
        var key = oEvent.charCode || oEvent.keyCode || 0;
        var isCtrlPressed = oEvent.ctrlKey || oEvent.metaKey;
        return (
          key == 8 || key == 9 || key == 13 || key == 46 || key == 110 || key == 190 ||
          (key >= 35 && key <= 40) ||
          (key >= 48 && key <= 57) ||
          (key >= 96 && key <= 105) ||
          (isCtrlPressed && (key == 67 || key == 86))
        );
      });

      var oViewModel = new sap.ui.model.json.JSONModel({

        enableRowActions: true,
        approvebuttonvisiblity: false,
        approvebuttonvisiblityData: false,
        approvebuttonfragment: false,
        rejetedbuttonfragmnet: false,
        enableIRR: false,
        sendbackbuttonvisiblity: false,

        newBudgetReq: true,
        additionalBudgetReq: true,

        enableFormFields: true,
        disableFormFields: false,

        remarkModel: "",

        BudgetTransferRoweditable: false,
        BudgetContingencyRoweditable: false,
        BudgetSavingsRoweditable: false,
        BudgetCostOverrunRoweditable: false,
        BudgetAdvancementRoweditable: false

      });
      this.getView().setModel(oViewModel, "viewenableddatacheck");

      var oTimelineData = {
        timelineItems: [
          {
            dateTime: "7/22/2016 at 3:00 PM",
            title: "Ankit Pathak Created a Request",
            text: "Data Save",
            userName: "Ankit Pathak",
            userPicture: "https://ui-avatars.com/api/?name=Ankit+Rath"
          },
          {
            dateTime: "7/22/2016 at 6:00 PM",
            title: "Yugal Created a Request",
            text: "Data Submit",
            userName: "Yugal",
            userPicture: "https://ui-avatars.com/api/?name=Yugal"
          },
          {
            dateTime: "7/22/2016 at 3:00 PM",
            title: "Ayushi Mam added a note [Approved]",
            text: "Submitted.",
            userName: "Ayushi Mam",
            userPicture: "https://ui-avatars.com/api/?name=Ayushi"
          },
          {
            dateTime: "7/22/2016 at 3:00 PM",
            title: "Aakib Mohd added a note [Approved]",
            text: "Done.",
            userName: "Aakib Mohd",
            userPicture: "https://ui-avatars.com/api/?name=Aakib+Mohd"
          }
        ]
      };
      var oTimelineModel = new JSONModel(oTimelineData);
      this.getView().setModel(oTimelineModel, "timelineModel");
    },


    onGetCurrentUser: function () {
      var oModel = this.getOwnerComponent().getModel("approvalservicev2");
      var that = this;
    
      oModel.read("/getCurrentUser", {
        urlParameters: {
          role: "'Asset Team'"
        },
        success: function (oData) {
          that.sEmail = oData.email; 
          // console.log("User data:", oData);
        },
        error: function (oError) {
          console.error("Error fetching user data:", oError);
        }
      });
    },


    // onGetCurrentUser: function () {
    //   var oModel = this.getView().getModel(); 
    
    //   oModel.bindContext("/getCurrentUser").requestObject()
    //     .then(function (oData) {
    //       console.log("User data:", oData);
    //     })
    //     .catch(function (oError) {
    //       console.error("Error:", oError);
    //     });
    // },

    formatDisplayDate: function (sDate) {
      if (!sDate) {
        return "";
      }

      var oDate = new Date(sDate);

      var iDay = oDate.getDate().toString().padStart(2, '0');
      var iMonth = (oDate.getMonth() + 1).toString().padStart(2, '0');
      var iYear = oDate.getFullYear();

      return iDay + "-" + iMonth + "-" + iYear;
    },

    _onRouteBudReqController: function (oEvent) {
      var oArgs = oEvent.getParameter("arguments");
      var formType = oEvent.getParameter("arguments").formType;
      this.byId("ReferenceNumberID").setVisible(false);

      var oView = this.getView();

      if (formType == "ABRF") {
        this.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");
        this.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
        this.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);

        // const abrFields = [
        //   "chkBudgetTransfer", "chkContingency", "chkSavings", "chkCostOverrun", "chkAdvancement",
        //   "AddCapitalBudgetInput", "ApprovalforBudgetBox", "AddBudgetTransferInput", "AddBudgetTransferFromWBSInput",
        //   "AddBudgetTransferToWBSInput", "AddContingencyRequiredInput", "AddCostOverrunInput",
        //   "AddContingencyAllowedInput", "AddUtilisedInput", "AddAvailableInput",
        //   "OriginalIRRPaybackInput", "RevisedIRRPaybackInput", "AddParkedSavingsInput",
        //   "AddParkedSavingsFromWBSInput", "AddParkedSavingsToWBSInput", "AddAdvancementofCAPEXInput",
        //   "AddAdvancementofContingencyInput", "AddApprovedProjectCAPEXInputLakh", "AddTotalProjectCAPEXInput"
        // ];
        // abrFields.forEach(id => oView.byId(id)?.setEditable(true));
        // var oLabel = this.byId("DepartmentLabel");
        // oLabel.setRequired(false);

      } else {
        this.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
        this.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
        this.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);

        const crFields = [
          "CapitalBudgetInput", "ContingencyBox", "SeekApprovalInput", "RevenueBudgetInput"
        ];
        crFields.forEach(id => oView.byId(id)?.setEditable(true));
      }

      const commonFields = [
        "DivisionBox", "LocationBox", "DepartmentInput", "ProjectItemDesInput", "ProjectNameInput", "ItemDescInput",
        "ImplementationDateInput", "IRRPaybackInput", "ContactPersonInput", "ContactNumberInput",
        "ObjectiveInp", "BackgroundInp", "proposalInp", "DeliverablesInp",
        "R1Box", "R2Box", "R3Box"
      ];

      commonFields.forEach(id => oView.byId(id)?.setEditable(true));

      oView.byId("SaveBtnNBRF").setEnabled(true);
      oView.byId("SubmitNewBudgetReqForm").setEnabled(true);


      var basedNameUI = oArgs.basedNameUINBRF;
      this._BudReqNameUI = basedNameUI;

      this._reqIDData = oArgs.reqIDData;
      this.byId("ReferenceNumberID").setText("Reference Number : ")
      var oRequestServiceModel = this.getOwnerComponent().getModel("Requestservicemodel");
      if (!oRequestServiceModel) {
        oRequestServiceModel = new sap.ui.model.json.JSONModel();
        this.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
      }
      this.getView().byId("CapitalBudgetInput").setValue("");
      var oEmptyData = {
        reqID: "",
        refNo: "",
        captlBudget: "",
        remarks: "",
        newdtl: []
      };
      oRequestServiceModel.setData(oEmptyData);

    },





    onCancelButton: function () {
      var oRouter = this.getOwnerComponent().getRouter();
      oRouter.navTo("AdditionalBudgetRequest");
    },

    onNBRFDivisionData: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      var that = this;
      oModelV2.read("/ControlValues", {
        urlParameters: {
          "$filter": "category eq '" + "NABDiv" + "'"
        },
        success: function (oData) {
          if (oData && oData.results) {
            var uniqueMap = {};
            var uniqueResults = oData.results.filter(function (item) {
              if (!uniqueMap[item.description]) {
                uniqueMap[item.description] = true;
                return true;
              }
              return false;
            });
            var oJSONModel = new sap.ui.model.json.JSONModel({ results: uniqueResults });
            oView.setModel(oJSONModel, "NBRFDivisionModel");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.", oError);
        }
      });
    },

    // onAdditionalApprovalforBudget: function () {
    //   var oView = this.getView();
    //   var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
    //   var that = this;

    //   oModelV2.read("/ControlValues", {
    //     urlParameters: {
    //       "$filter": "category eq '" + "NABDiv" + "'"
    //     },
    //     success: function (oData) {
    //       if (oData && oData.results) {

    //         var oJSONModel = new sap.ui.model.json.JSONModel(oData);
    //         oView.setModel(oJSONModel, "AdditionalApprovalforBudgetModel");
    //       }
    //     },
    //     error: function (oError) {
    //       sap.m.MessageToast.show("Failed to load data.", oError);
    //     }
    //   });
    // },


    onAdditionalApprovalforBudget: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      var that = this;

      oModelV2.read("/ControlValues", {
        urlParameters: {
          "$filter": "category eq 'approvalType'"
        },
        success: function (oData) {
          if (oData && oData.results) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "AdditionalApprovalforBudgetModel");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.");
          console.error("Read error: ", oError);
        }
      });
    },

    onDocumentCategory: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      var that = this;

      oModelV2.read("/ControlValues", {
        urlParameters: {
          "$filter": "category eq 'doc_Category'"
        },
        success: function (oData) {
          if (oData && oData.results) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "DocumentCategoryModel");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.");
          console.error("Read error: ", oError);
        }
      });
    },

    onNBRFContingencyData: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      oModelV2.read("/ControlValues", {
        urlParameters: {
          "$filter": "category eq '" + "NABcontValue" + "'"
        },
        success: function (oData) {
          if (oData) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "NBRFContingencyDataModel");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.", oError);
        }
      });
    },

    onNBRFLocationData: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      oModelV2.read("/ControlValues", {
        urlParameters: {
          "$filter": "category eq '" + "NABDiv" + "'"
        },
        success: function (oData) {
          if (oData) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "NBRFLocationDataModel");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.", oError);
        }
      });
    },

    onAssignApprover: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      oModelV2.read("/Approvers", {
        urlParameters: {
          "$filter": "role eq '" + "Asset Team" + "'"
        },
        success: function (oData) {
          if (oData) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "onNewBudgetAssetTeamModel");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.", oError);
        }
      });
    },

    onCorporateTeamApprover: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      oModelV2.read("/Approvers", {
        urlParameters: {
          "$filter": "role eq '" + "Corporate Team" + "'"
        },
        success: function (oData) {
          if (oData) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "onNewBudgetCorporateTeamModel");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.", oError);
        }
      });
    },

    onRecommendedBy1: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      oModelV2.read("/Approvers", {
        urlParameters: {
          "$filter": "role eq '" + "Recommended1" + "'"
        },
        success: function (oData) {
          if (oData) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "onNewBudgetRecommended1Model");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.", oError);
        }
      });
    },

    onRecommendedBy2: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      oModelV2.read("/Approvers", {
        urlParameters: {
          "$filter": "role eq '" + "Recommended2" + "'"
        },
        success: function (oData) {
          if (oData) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "onNewBudgetRecommended2Model");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.", oError);
        }
      });
    },

    onRecommendedBy3: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      oModelV2.read("/Approvers", {
        urlParameters: {
          "$filter": "role eq '" + "Recommended3" + "'"
        },
        success: function (oData) {
          if (oData) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "onNewBudgetRecommended3Model");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.", oError);
        }
      });
    },

    onRecommendedBy4: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      oModelV2.read("/Approvers", {
        urlParameters: {
          "$filter": "role eq '" + "Recommended4" + "'"
        },
        success: function (oData) {
          if (oData) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "onNewBudgetRecommended4Model");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.", oError);
        }
      });
    },

    onRecommendedBy5: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      oModelV2.read("/Approvers", {
        urlParameters: {
          "$filter": "role eq '" + "Recommended5" + "'"
        },
        success: function (oData) {
          if (oData) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "onNewBudgetRecommended5Model");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.", oError);
        }
      });
    },

    onRecommendedBy6: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      oModelV2.read("/Approvers", {
        urlParameters: {
          "$filter": "role eq '" + "Recommended6" + "'"
        },
        success: function (oData) {
          if (oData) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "onNewBudgetRecommended6Model");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.", oError);
        }
      });
    },

    onApprovedBy: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      oModelV2.read("/Approvers", {
        urlParameters: {
          "$filter": "role eq '" + "ApprovedBy" + "'"
        },
        success: function (oData) {
          if (oData) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "onNewBudgetApprovedByModel");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.", oError);
        }
      });
    },

    onNewBudgetApproverR1: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      oModelV2.read("/Approvers", {
        urlParameters: {
          "$filter": "role eq '" + "R1" + "'"
        },
        success: function (oData) {
          if (oData) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "onNewBudgetApproverR1Model");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.", oError);
        }
      });
    },

    onNewBudgetApproverR2: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      oModelV2.read("/Approvers", {
        urlParameters: {
          "$filter": "role eq '" + "R2" + "'"
        },
        success: function (oData) {
          if (oData) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "onNewBudgetApproverR2Model");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.", oError);
        }
      });
    },

    onNewBudgetApproverR3: function () {
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      oModelV2.read("/Approvers", {
        urlParameters: {
          "$filter": "role eq '" + "R3" + "'"
        },
        success: function (oData) {
          if (oData) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "onNewBudgetApproverR3Model");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load data.", oError);
        }
      });
    },


    onSaveNewBudgetReqForm: function () {
      var oView = this.getView();
      var reqid = this._reqIDData;

      var DivisionBox = oView.byId("DivisionBox");
      var sDivisionValue = DivisionBox ? DivisionBox.getValue().trim() : "";

      if (!sDivisionValue) {
        MessageBox.error("Please select mandatory division field");
        return;
      }

      let oBudgetTransfer = oView.byId("chkBudgetTransfer").getSelected();
      let oContingency = oView.byId("chkContingency").getSelected();
      let oSavings = oView.byId("chkSavings").getSelected();
      let oOverrun = oView.byId("chkCostOverrun").getSelected();
      let oAdvance = oView.byId("chkAdvancement").getSelected();

      var formTitle = this.byId("NewBudgetReqFormPage").getTitle();
      var ftype = "";

      if (formTitle === "New Budget Request") {
        ftype = "CR";
      } else {
        ftype = "ABR";
      }

      var onewdtl = {
        creationDate: oView.byId("CreationDateInput").getValue(),
        NABDiv: oView.byId("DivisionBox").getSelectedKey(),
        NABLoc: oView.byId("LocationBox").getSelectedKey(),
        dept: oView.byId("DepartmentInput").getValue(),
        projectDesc: oView.byId("ProjectItemDesInput").getValue(),
        itemDesc: oView.byId("ItemDescInput").getValue(),
        implDate: oView.byId("ImplementationDateInput").getDateValue(),

        irrPaybacks: oView.byId("IRRPaybackInput").getValue(),
        contactPerson: oView.byId("ContactPersonInput").getValue(),
        contactNo: oView.byId("ContactNumberInput").getValue(),

        objective: oView.byId("ObjectiveInp").getValue(),
        background: oView.byId("BackgroundInp").getValue(),
        proposal: oView.byId("proposalInp").getValue(),
        deliverables: oView.byId("DeliverablesInp").getValue(),

        // Fix duplicate captlBudget definition (remove the second one)
        captlBudget: oView.byId("CapitalBudgetInput").getValue(),
        NABcontValue: oView.byId("ContingencyBox").getValue(),
        LakhsInput: oView.byId("LakhsInput").getValue(),
        revBudget: oView.byId("RevenueBudgetInput").getValue(),
        totalProjCost: oView.byId("TotalProjectCostInput").getValue(),
        seekApproval: oView.byId("SeekApprovalInput").getValue(),

        approverR1: oView.byId("R1Box").getSelectedKey(),
        approverR2: oView.byId("R2Box").getSelectedKey(),
        approverR3: oView.byId("R3Box").getSelectedKey(),

        //checkbox
        fdBudgetTrans: oBudgetTransfer,
        fdContingency: oContingency,
        fdSavings: oSavings,
        fdOverrun: oOverrun,
        fdAdvance: oAdvance,

        // Budget form fields
        addlBudget: oView.byId("AddCapitalBudgetInput").getValue(),
        budgetTrans: oView.byId("AddBudgetTransferInput").getValue(),
        bTfromWbs: oView.byId("AddBudgetTransferFromWBSInput").getValue(),
        bTtoWbs: oView.byId("AddBudgetTransferToWBSInput").getValue(),

        origIrr: oView.byId("OriginalIRRPaybackInput").getValue(),
        revIrr: oView.byId("RevisedIRRPaybackInput").getValue(),

        contReq: oView.byId("AddContingencyRequiredInput").getValue(),
        costOverrun: oView.byId("AddCostOverrunInput").getValue(),
        contAllowed: oView.byId("AddContingencyAllowedInput").getValue(),
        utilised: oView.byId("AddUtilisedInput").getValue(),
        available: oView.byId("AddAvailableInput").getValue(),
        savings: oView.byId("AddParkedSavingsInput").getValue(),
        savingsFromWbs: oView.byId("AddParkedSavingsFromWBSInput").getValue(),
        savingsToWbs: oView.byId("AddParkedSavingsToWBSInput").getValue(),

        approvalType: oView.byId("ApprovalforBudgetBox").getSelectedKey(),
        capexAdvance: oView.byId("AddAdvancementofCAPEXInput").getValue(),
        contingencyAdv: oView.byId("AddAdvancementofContingencyInput").getValue(),
        capexApproved: oView.byId("AddApprovedProjectCAPEXInputLakh").getValue(),
        capexTotal: oView.byId("AddTotalProjectCAPEXInput").getValue(),
        wbsNo: oView.byId("WBSNumberInput").getValue(),
        subType: ftype
      };

      // List of decimal fields
      var decimalFields = [
        "addlBudget", "budgetTrans", "contReq", "costOverrun", "contAllowed",
        "utilised", "available", "savings", "capexAdvance", "contingencyAdv",
        "capexApproved", "capexTotal",
        "captlBudget", "NABcontValue", "LakhsInput", "revBudget", "totalProjCost", "seekApproval"
      ];


      // Sanitize decimal fields before sending
      decimalFields.forEach(function (field) {
        if (onewdtl[field] === "") {
          onewdtl[field] = null;
        } else {
          onewdtl[field] = parseFloat(onewdtl[field]);
          if (isNaN(onewdtl[field])) {
            onewdtl[field] = null;
          }
        }
      });

      // Prepare the payload for the OData service (newdtl as an array)
      // this.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
      // this.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request"); 



      var oSavePayload = {
        stage: "Initiator",
        status: "Draft",
        type: 'NAB',
        remarks: "",
        newdtl: onewdtl
      };

      // var oCreatePayload = JSON.parse(JSON.stringify(oSavePayload));

      console.log(oSavePayload);

      var that = this;
      var oModel = this.getOwnerComponent().getModel("approvalservicev2");

      if (!this._reqIDData) {
        // Create new request
        oModel.create("/Requests", oSavePayload, {
          success: function (oData) {
            that._reqIDData = oData.reqID;


            that.attachmentuploadFilesData(that._reqIDData);
            that.byId("ReferenceNumberID").setVisible(true);
            that.byId("ReferenceNumberID").setText(" Request ID : " + oData.refNo);

            that.refNoData = oData.refNo;

            if (oData) {
              var oComponent = that.getOwnerComponent();
              var oRequestServiceModel = oComponent.getModel("Requestservicemodel");
              if (!oRequestServiceModel) {
                oRequestServiceModel = new sap.ui.model.json.JSONModel();
                oComponent.setModel(oRequestServiceModel, "Requestservicemodel");
              }
              oRequestServiceModel.setData(oData);
            }
            var reqid = oData.reqID;
            var refNo = oData.refNo;
            sap.m.MessageBox.success("Request " + refNo + " has been saved successfully!");
            sap.ui.core.BusyIndicator.hide();
          },
          error: function (oError) {
            sap.m.MessageToast.show("Error saving request: " + oError.message);
            sap.ui.core.BusyIndicator.hide();
          }
        });
      } else {
        // Update existing request
        oModel.update("/Requests('" + reqid + "')", oSavePayload, {
          success: function (oData) {
            that.refNoData = oData.refNo;
            var refNo = oData.refNo;

            that.attachmentuploadFilesData(that._reqIDData);

            sap.m.MessageBox.success("Request " + refNo + " has been saved successfully!");
            sap.ui.core.BusyIndicator.hide();
          },
          error: function (oError) {
            sap.m.MessageToast.show("Error saving request: " + oError.message);
            sap.ui.core.BusyIndicator.hide();
          }
        });
      }
    },

    onDashboardui: function () {
      var Name = this._BudReqNameUI;
      if (Name === "BudReq") {
        var oRouter = this.getOwnerComponent().getRouter();
        oRouter.navTo("DashboardUI", {
          Name: "BudReq"
        });
      }
    },

    onDashboarduiNBRF: function (Name) {
      var Approvalcheck = this._ApprovedCheck;
      if (Approvalcheck === "Approved") {
        var oRouter = this.getOwnerComponent().getRouter();
        oRouter.navTo("approverdashboard", {
        });

      } else {
        this._BudReqNameUI = "NBRF";
        var Name = this._BudReqNameUI;
        if (Name === "NBRF") {
          var oRouter = this.getOwnerComponent().getRouter();
          oRouter.navTo("DashboardUI", {
            Name: "NBRF"
          });
        }

      }

    },

    onCloseReamrksFrag: function () {
      this.remarksDialog.close();
    },

    onSubmitNewBudgetReqForm: function () {
      // this._validateFormFields();
      this.getView().byId("RemarkInput").setValue("");
      var isFormValid = this._validateFormFields();
      if (isFormValid) {
        this.remarksDialog.open();
      }
      this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
    },

    onApprovedNewBudgetReqForm: function () {
      var isFormValid = this._validateFormFields();
      this.getView().byId("RemarkInput").setValue("");
      this.getView().byId("approverremark").setVisible(true);
      this.getView().byId("Rejectremark").setVisible(false);
      if (isFormValid) {
        this.remarksDialog.open();
      }

      this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
    },

    onRejectNewBudgetReqForm: function () {
      // var isFormValid = this._validateFormFields();
      this.getView().byId("RemarkInput").setValue("");
      this.getView().byId("approverremark").setVisible(false);
      this.getView().byId("Rejectremark").setVisible(true);
      // if (isFormValid) {
      //   this.remarksDialog.open();
      // }
      this.remarksDialog.open();
      this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
    },


    _validateFormFields: function () {
      var isValid = true;
      // ComboBox
      var Division = this.getView().byId("DivisionBox");
      var Location = this.getView().byId("LocationBox");
      var Contingency = this.getView().byId("ContingencyBox");
      var R1Box = this.getView().byId("R1Box");
      var R2Box = this.getView().byId("R2Box");
      var R3Box = this.getView().byId("R3Box");
      var ApprovalforBudgetBox = this.getView().byId("ApprovalforBudgetBox");

      // Input fields
      var DepartmentInput = this.getView().byId("DepartmentInput");
      var ProjectItemDesInput = this.getView().byId("ProjectItemDesInput");
      var ImplementationDateInput = this.getView().byId("ImplementationDateInput");
      var IRRPaybackInput = this.getView().byId("IRRPaybackInput");
      var ContactPersonInput = this.getView().byId("ContactPersonInput");
      var ContactNumberInput = this.getView().byId("ContactNumberInput");
      var AddCapitalBudgetInput = this.getView().byId("AddCapitalBudgetInput");

      var oProjectNameInput = this.getView().byId("ProjectNameInput");
      var oItemDescInput = this.getView().byId("ItemDescInput");

      // Input fields- Budget
      var CapitalBudgetInput = this.getView().byId("CapitalBudgetInput");
      var RevenueBudgetInput = this.getView().byId("RevenueBudgetInput");
      var TotalProjectCostInput = this.getView().byId("TotalProjectCostInput");
      var SeekApprovalInput = this.getView().byId("SeekApprovalInput");

      // TextArea fields
      var ObjectiveInp = this.getView().byId("ObjectiveInp");
      var BackgroundInp = this.getView().byId("BackgroundInp");
      var ProposalInp = this.getView().byId("proposalInp");
      var DeliverablesInp = this.getView().byId("DeliverablesInp");

      // Reset value states
      [
        Division, Location, Contingency, R1Box, R2Box, R3Box, oProjectNameInput, oItemDescInput, DepartmentInput, ProjectItemDesInput, ImplementationDateInput,
        IRRPaybackInput, ContactPersonInput, ContactNumberInput, ObjectiveInp, BackgroundInp, ProposalInp, DeliverablesInp,
        CapitalBudgetInput, RevenueBudgetInput, TotalProjectCostInput, SeekApprovalInput, ApprovalforBudgetBox, AddCapitalBudgetInput
      ].forEach(function (control) {
        if (control) control.setValueState("None");
      });



      if (!Division.getValue()) {
        Division.setValueState("Error");
        isValid = false;
      }
      if (!Location.getValue()) {
        Location.setValueState("Error");
        isValid = false;
      }

      if (oProjectNameInput.getVisible() && !oProjectNameInput.getValue()) {
        oProjectNameInput.setValueState("Error");
        isValid = false;
      } else {
        oProjectNameInput.setValueState("None");
      }

      if (oItemDescInput.getVisible() && !oItemDescInput.getValue()) {
        oItemDescInput.setValueState("Error");
        isValid = false;
      } else {
        oItemDescInput.setValueState("None");
      }

      if (ApprovalforBudgetBox.getVisible() && !ApprovalforBudgetBox.getValue()) {
        ApprovalforBudgetBox.setValueState("Error");
        isValid = false;
      } else {
        ApprovalforBudgetBox.setValueState("None");
      }

      if (AddCapitalBudgetInput.getVisible() && !AddCapitalBudgetInput.getValue()) {
        AddCapitalBudgetInput.setValueState("Error");
        isValid = false;
      } else {
        AddCapitalBudgetInput.setValueState("None");
      }



      if (Contingency.getVisible() && !Contingency.getValue()) {
        Contingency.setValueState("Error");
        isValid = false;
      } else {
        Contingency.setValueState("None");
      }

      var oStage = this.stagesData;


      if (oStage === "R1" || oStage === "R2" || oStage === "R3") {

      } else {
        if (!R1Box.getValue()) {
          R1Box.setValueState("Error");
          isValid = false;
        }

        if (!R2Box.getValue()) {
          R2Box.setValueState("Error");
          isValid = false;
        }

        if (!R3Box.getValue()) {
          R3Box.setValueState("Error");
          isValid = false;
        }

      }

      if (!DepartmentInput.getValue()) {
        DepartmentInput.setValueState("Error");
        isValid = false;
      }
      if (!ProjectItemDesInput.getValue()) {
        ProjectItemDesInput.setValueState("Error");
        isValid = false;
      }

      if (ImplementationDateInput.getVisible() && !ImplementationDateInput.getDateValue()) {
        ImplementationDateInput.setValueState("Error");
        isValid = false;
      } else {
        ImplementationDateInput.setValueState("None");
      }


      if (IRRPaybackInput.getVisible()) {
        if (!IRRPaybackInput.getValue()) {
          IRRPaybackInput.setValueState("Error");
          isValid = false;
        } else {
          IRRPaybackInput.setValueState("None");
        }
      }

      if (!ContactPersonInput.getValue()) {
        ContactPersonInput.setValueState("Error");
        isValid = false;
      }
      if (!ContactNumberInput.getValue()) {
        ContactNumberInput.setValueState("Error");
        isValid = false;
      }

      if (CapitalBudgetInput.getVisible() && !CapitalBudgetInput.getValue()) {
        CapitalBudgetInput.setValueState("Error");
        isValid = false;
      } else {
        CapitalBudgetInput.setValueState("None");
      }

      if (RevenueBudgetInput.getVisible() && !RevenueBudgetInput.getValue()) {
        RevenueBudgetInput.setValueState("Error");
        isValid = false;
      } else {
        RevenueBudgetInput.setValueState("None");
      }

      if (TotalProjectCostInput.getVisible() && !TotalProjectCostInput.getValue()) {
        TotalProjectCostInput.setValueState("Error");
        isValid = false;
      } else {
        TotalProjectCostInput.setValueState("None");
      }

      if (SeekApprovalInput.getVisible() && !SeekApprovalInput.getValue()) {
        SeekApprovalInput.setValueState("Error");
        isValid = false;
      } else {
        SeekApprovalInput.setValueState("None");
      }

      var formTitle = this.getView().byId("NewBudgetReqFormPage").getTitle();
      var ftype = "";
      if (formTitle === "New Budget Request") {
        ftype = "CR";
      } else {
        ftype = "ABR";
      }

      if (ftype === "ABR") {
        var aFundingCheckboxes = [
          this.getView().byId("chkBudgetTransfer"),
          this.getView().byId("chkContingency"),
          this.getView().byId("chkSavings"),
          this.getView().byId("chkCostOverrun"),
          this.getView().byId("chkAdvancement")
        ];

        var aVisibleFunding = aFundingCheckboxes.filter(function (oCB) {
          return oCB && oCB.getVisible();
        });

        if (aVisibleFunding.length > 0) {
          var bAnyChecked = aVisibleFunding.some(function (oCB) {
            return oCB.getSelected();
          });

          if (!bAnyChecked) {
            aVisibleFunding.forEach(function (oCB) {
              oCB.setValueState("Error");
            });
            sap.m.MessageBox.error("Please select at least one Funding option.");
            isValid = false;
            return;
          } else {
            aVisibleFunding.forEach(function (oCB) {
              oCB.setValueState("None");
            });
          }
        }
      } else {

      }


      if (!isValid) {
        sap.m.MessageBox.error("Please fill all required fields.");
      }
      return isValid;
    },

    onDivisionChange: function () {
      this._clearValueState("DivisionBox");
    },
    onLocationChange: function () {
      this._clearValueState("LocationBox");
    },
    onContingencyChange: function () {
      this._clearValueState("ContingencyBox");
    },
    onR1BoxChange: function () {
      this._clearValueState("R1Box");
    },
    onR2BoxChange: function () {
      this._clearValueState("R2Box");
    },
    onR3BoxChange: function () {
      this._clearValueState("R3Box");
    },

    onDepartmentInputChange: function () {
      this._clearValueState("DepartmentInput");
    },

    onProjectItemDesInputChange: function () {
      this._clearValueState("ProjectItemDesInput");
    },

    onProjectNameChange: function () {
      this._clearValueState("ProjectNameInput");
    },

    onAdditionalBudgetRequired: function () {
      this._clearValueState("AddCapitalBudgetInput");
    },

    onItemDescriptionChange: function () {
      this._clearValueState("ItemDescInput");
    },


    OnImpleDateInputChange: function () {
      this._clearValueState("ImplementationDateInput");
    },
    onIRRPaybackInputChange: function () {
      this._clearValueState("IRRPaybackInput");
    },
    onContactPersonInputChange: function () {
      this._clearValueState("ContactPersonInput");
    },
    // onApprovalforBudgetBoxChange: function() {
    //   this._clearValueState("ApprovalforBudgetBox");
    // },

    onContactNumberInputChange: function (oEvent) {
      this._clearValueState("ContactNumberInput");
      var oInput = oEvent.getSource();
      var sValue = oInput.getValue().trim();
      var isValid = /^\d{0,20}$/.test(sValue);
      if (!isValid && sValue !== "") {
        oInput.setValueState(sap.ui.core.ValueState.Error);
        oInput.setValueStateText("Please enter only numeric values (maximum 20 digits).");
      } else {
        oInput.setValueState(sap.ui.core.ValueState.None);
      }
    },

    onCapitalBudgetChange: function (oEvent) {
      this._clearValueState("CapitalBudgetInput");
      this.calculateTotalProjectCost();
      const value = oEvent.getParameter("value");
      const input = oEvent.getSource();
      if (!isNaN(value) && value !== "") {
        const formattedValue = parseFloat(value).toFixed(2);
        input.setValue(formattedValue);
      }
    },
    // onObjectiveChange: function() {
    // this._clearValueState("ObjectiveInp");
    // },
    // onBackgroundChange: function() {
    // this._clearValueState("BackgroundInp");
    // },
    // onProposalChange: function() {
    // this._clearValueState("proposalInp");
    // },
    // onDeliverablesChange: function() {
    // this._clearValueState("DeliverablesInp");
    // },
    onRevenueBudgetChange: function () {
      this._clearValueState("RevenueBudgetInput");
      this.calculateTotalProjectCost();
    },
    onTotalProjectCostChange: function () {
      this._clearValueState("TotalProjectCostInput");
    },
    onSeekApprovalChange: function () {
      this._clearValueState("SeekApprovalInput");
    },

    _clearValueState: function (sId) {
      var oControl = this.getView().byId(sId);
      if (oControl) {
        oControl.setValueState("None");
      }
    },
    // ==============Upload File Attachments start====================
    // onUploadTabAttchmmentNBRF: function (oEvent) {
    //   var oFileUploader = oEvent.getSource();
    //   var aFiles = oEvent.getParameter("files");
    //   if (!aFiles || aFiles.length === 0) {
    //     MessageToast.show("No files selected.");
    //     return;
    //   }
    //   var oModel = this.getView().getModel("UploadDocSrvTabData");
    //   var aAttachments = oModel.getProperty("/attachments") || [];
    //   var sUploadedOn = new Date().toISOString().split("T")[0];
    //   var that = this;
    //   for (var i = 0; i < aFiles.length; i++) {
    //     (function (file, index) {
    //       var oReader = new FileReader();
    //       oReader.onload = function (e) {
    //         var sBase64Data = e.target.result;
    //         aAttachments.push({
    //           ID: new Date().getTime().toString() + index,
    //           fileName: file.name,
    //           mimeType: file.type,
    //           content: sBase64Data
    //         });
    //         if (index === aFiles.length - 1) {
    //           oModel.setProperty("/attachments", aAttachments);
    //           oModel.refresh(true);
    //           MessageToast.show("Files uploaded: " + aFiles.length);
    //           oFileUploader.setValue("");
    //         }
    //       };
    //       oReader.onerror = function () {
    //         MessageToast.show("Error reading file: " + file.name);
    //       };
    //       oReader.readAsDataURL(file); // Read file as base64
    //     })(aFiles[i], i);
    //   }
    // },

    // onUploadPress: function (oEvent) {
    //   var oFileUploader = this.byId("fileUploaderTabAttchmentNBRF");
    //   // var aFiles = oFileUploader.getDomRef().files;

    //   // var oFileUploader = oEvent.getSource();
    //   var aFiles = oEvent.getParameter("files");

    //   if (!aFiles || aFiles.length === 0) {
    //     MessageToast.show("Please select at least one file first.");
    //     return;
    //   }

    //   var oModel = this.getView().getModel("UploadDocSrvTabData");
    //   var aAttachments = oModel.getProperty("/attachments") || [];
    //   var sUploadedOn = new Date().toISOString().split("T")[0];
    //   var that = this;

    //   // Clear previous temporary selections
    //   aAttachments = aAttachments.filter(function (item) {
    //     return !item.temp;
    //   });

    //   for (var i = 0; i < aFiles.length; i++) {
    //     (function (file, index) {
    //       var oReader = new FileReader();
    //       oReader.onload = function (e) {
    //         var sBase64Data = e.target.result;
    //         aAttachments.push({
    //           ID: new Date().getTime().toString() + index,
    //           fileName: file.name,
    //           uploadedBy: "Current User",
    //           uploadedOn: sUploadedOn,
    //           deleteTabVisible: true,
    //           content: sBase64Data
    //         });

    //         if (index === aFiles.length - 1) {
    //           oModel.setProperty("/attachments", aAttachments);
    //           oModel.refresh(true); // Force refresh to update bindings
    //           MessageToast.show("Uploaded " + aFiles.length + " file(s) successfully!");
    //           oFileUploader.setValue("");
    //         }
    //       };
    //       oReader.onerror = function () {
    //         MessageToast.show("Error reading file: " + file.name);
    //       };
    //       oReader.readAsDataURL(file);
    //     })(aFiles[i], i);
    //   }
    // },

    onUploadTabAttchmment: function (oEvent) {
      var oFileUploader = oEvent.getSource();
      var aFiles = oEvent.getParameter("files");
      if (!aFiles || aFiles.length === 0) {
        MessageToast.show("No files selected.", { position: "bottom center" });
        return;
      }

      var oModel = this.getView().getModel("UploadDocSrvTabData");
      var aAttachments = oModel.getProperty("/attachments") || [];
      var sUploadedOn = new Date().toISOString().split("T")[0];

      for (var i = 0; i < aFiles.length; i++) {
        (function (file, index) {
          var oReader = new FileReader();
          oReader.onload = function (e) {
            var sBase64Data = e.target.result;
            aAttachments.push({
              ID: new Date().getTime().toString() + index,
              fileName: file.name,
              mimeType: file.type,
              content: sBase64Data,
              uploadedBy: "Current User",
              uploadedOn: sUploadedOn,
              deleteTabVisible: true
            });

            if (index === aFiles.length - 1) {
              oModel.setProperty("/attachments", aAttachments);
              oModel.refresh(true);
              MessageToast.show("Files uploaded: " + aFiles.length, { position: "bottom center" });
              oFileUploader.setValue("");
            }
          };
          oReader.onerror = function () {
            MessageToast.show("Error reading file: " + file.name, { position: "bottom center" });
          };
          oReader.readAsDataURL(file);
        })(aFiles[i], i);
      }
    },

    // onDownloadTabAttachemntNBRF: function (oEvent) {
    //   var oButton = oEvent.getSource();
    //   var sID = oButton.getCustomData().find(function (oData) {
    //     return oData.getKey() === "ID";
    //   });
    //   var sFileName = oButton.getCustomData().find(function (oData) {
    //     return oData.getKey() === "fileName";
    //   });

    //   // Defensive checks
    //   if (!sID || !sFileName) {
    //     sap.m.MessageToast.show("Missing attachment ID or file name.");
    //     return;
    //   }

    //   var sID = sID.getValue();
    //   var sFileName = sFileName.getValue();

    //   var oModel = this.getView().getModel("UploadDocSrvTabData");
    //   var aAttachments = oModel.getProperty("/attachments") || [];
    //   var oAttachment = aAttachments.find(function (oItem) {
    //     return oItem.ID === sID;
    //   });

    //   var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
    //   var sPath = "/ReqAttachments(guid'" + sID + "')";

    //   var that = this;

    //   // Step 1: Read metadata from backend to get media_src
    //   oModelV2.read(sPath, {
    //     success: function (oData) {
    //       if (oData && oData.__metadata && oData.__metadata.media_src) {
    //         // Use <a download> for direct media stream download
    //         var oLink = document.createElement("a");
    //         oLink.href = oData.__metadata.media_src;
    //         oLink.download = sFileName;
    //         document.body.appendChild(oLink);
    //         oLink.click();
    //         document.body.removeChild(oLink);
    //         sap.m.MessageToast.show("Downloading file from server: " + sFileName);
    //       } else {
    //         // Fallback to local
    //         that._downloadLocalAttachmentNBRF(oAttachment, sFileName);
    //       }
    //     },
    //     error: function () {
    //       // Fallback to local
    //       that._downloadLocalAttachmentNBRF(oAttachment, sFileName);
    //     }
    //   });
    // },
    // _downloadBase64File: function (sBase64Content, sFileName) {
    //   try {
    //     var sBase64Data = sBase64Content.split(',')[1];
    //     var sMimeType = sBase64Content.split(';')[0].split(':')[1];
    //     var byteCharacters = atob(sBase64Data);
    //     var byteNumbers = new Array(byteCharacters.length);
    //     for (var i = 0; i < byteCharacters.length; i++) {
    //       byteNumbers[i] = byteCharacters.charCodeAt(i);
    //     }
    //     var byteArray = new Uint8Array(byteNumbers);
    //     var oBlob = new Blob([byteArray], { type: sMimeType });
    //     var sUrl = URL.createObjectURL(oBlob);

    //     var oLink = document.createElement("a");
    //     oLink.href = sUrl;
    //     oLink.download = sFileName;
    //     document.body.appendChild(oLink);
    //     oLink.click();
    //     document.body.removeChild(oLink);
    //     URL.revokeObjectURL(sUrl);
    //     sap.m.MessageToast.show("Downloading file: " + sFileName);
    //   } catch (e) {
    //     sap.m.MessageToast.show("Error downloading file: " + sFileName);
    //   }
    // },
    // _downloadLocalAttachmentNBRF: function (oAttachment, sFileName) {
    //   if (!oAttachment || !oAttachment.content) {
    //     sap.m.MessageToast.show("Local file content not found for: " + sFileName);
    //     return;
    //   }
    //   this._downloadBase64File(oAttachment.content, sFileName);
    // },

    // onDeleteTabAttchmentNBRF: function (oEvent) {
    //   var oButton = oEvent.getSource();
    //   var oModel = this.getView().getModel("UploadDocSrvTabData");
    //   var aAttachments = oModel.getProperty("/attachments");
    //   var sID = oButton.getCustomData().find(function (oData) {
    //     return oData.getKey() === "ID";
    //   }).getValue();
    //   var iIndex = aAttachments.findIndex(function (oItem) {
    //     return oItem.ID === sID;
    //   });
    //   if (iIndex === -1) return;
    //   var sFileName = aAttachments[iIndex].fileName;
    //   var oAttachment = aAttachments[iIndex];
    //   var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
    //   var sPath = "/ReqAttachments(guid'" + sID + "')";
    //   var that = this;
    //   oModelV2.remove(sPath, {
    //     success: function () {
    //       that._removeAttachmentFromLocalModelNBRF(oModel, aAttachments, iIndex, sFileName);
    //       sap.m.MessageToast.show("Deleted " + sFileName);
    //     },
    //     error: function () {
    //       that._removeAttachmentFromLocalModelNBRF(oModel, aAttachments, iIndex, sFileName);
    //       sap.m.MessageToast.show("Deleted  " + sFileName);
    //     }
    //   });
    // },

    // _removeAttachmentFromLocalModelNBRF: function (oModel, aAttachments, iIndex, sFileName) {
    //   aAttachments.splice(iIndex, 1);
    //   oModel.setProperty("/attachments", aAttachments);
    //   oModel.refresh(true);
    // },

    onDownloadTabAttachemntNBRF: function (oEvent) {
      var oButton = oEvent.getSource();
      var sID = oButton.getCustomData().find(function (oData) {
        return oData.getKey() === "ID";
      }).getValue();
      var sFileName = oButton.getCustomData().find(function (oData) {
        return oData.getKey() === "fileName";
      }).getValue();

      var oModel = this.getView().getModel("UploadDocSrvTabData");
      var aAttachments = oModel.getProperty("/attachments") || [];
      var oAttachment = aAttachments.find(function (oItem) {
        return oItem.ID === sID;
      });

      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      var sPath = "/ReqAttachments(guid'" + sID + "')";
      var that = this;

      oModelV2.read(sPath, {
        success: function (oData) {
          if (oData && oData.__metadata && oData.__metadata.media_src) {
            var oLink = document.createElement("a");
            oLink.href = oData.__metadata.media_src;
            oLink.download = sFileName;
            document.body.appendChild(oLink);
            oLink.click();
            document.body.removeChild(oLink);
            MessageToast.show("Downloading file from server: " + sFileName, { position: "bottom center" });
          } else {
            that._downloadLocalAttachment(oAttachment, sFileName);
          }
        },
        error: function () {
          that._downloadLocalAttachment(oAttachment, sFileName);
        }
      });
    },

    _downloadBase64File: function (sBase64Content, sFileName) {
      try {
        var sBase64Data = sBase64Content.split(',')[1];
        var sMimeType = sBase64Content.split(';')[0].split(':')[1];
        var byteCharacters = atob(sBase64Data);
        var byteNumbers = new Array(byteCharacters.length);
        for (var i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        var byteArray = new Uint8Array(byteNumbers);
        var oBlob = new Blob([byteArray], { type: sMimeType });
        var sUrl = URL.createObjectURL(oBlob);

        var oLink = document.createElement("a");
        oLink.href = sUrl;
        oLink.download = sFileName;
        document.body.appendChild(oLink);
        oLink.click();
        document.body.removeChild(oLink);
        URL.revokeObjectURL(sUrl);
        MessageToast.show("Downloading file: " + sFileName, { position: "bottom center" });
      } catch (e) {
        MessageToast.show("Error downloading file: " + sFileName, { position: "bottom center" });
        console.error("Error downloading file:", e);
      }
    },

    _downloadLocalAttachmentNBRF: function (oAttachment, sFileName) {
      if (!oAttachment || !oAttachment.content) {
        MessageToast.show("Local file content not found for: " + sFileName, { position: "bottom center" });
        return;
      }
      this._downloadBase64File(oAttachment.content, sFileName);
    },



    onDeleteTabAttchmentNBRF: function (oEvent) {
      var oButton = oEvent.getSource();
      var oModel = this.getView().getModel("UploadDocSrvTabData");
      var aAttachments = oModel.getProperty("/attachments");
      var sID = oButton.getCustomData().find(function (oData) {
        return oData.getKey() === "ID";
      }).getValue();
      var iIndex = aAttachments.findIndex(function (oItem) {
        return oItem.ID === sID;
      });
      if (iIndex === -1) return;

      var sFileName = aAttachments[iIndex].fileName;
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      var sPath = "/ReqAttachments(guid'" + sID + "')";
      var that = this;

      oModelV2.remove(sPath, {
        success: function () {
          that._removeAttachmentFromLocalModel(oModel, aAttachments, iIndex, sFileName);
          MessageToast.show("Deleted " + sFileName, { position: "bottom center" });
        },
        error: function (oError) {
          that._removeAttachmentFromLocalModel(oModel, aAttachments, iIndex, sFileName);
          MessageToast.show("Deleted " + sFileName, { position: "bottom center" });
          console.error("Error deleting attachment:", oError);
        }
      });
    },

    _removeAttachmentFromLocalModelNBRF: function (oModel, aAttachments, iIndex, sFileName) {
      aAttachments.splice(iIndex, 1);
      oModel.setProperty("/attachments", aAttachments);
      oModel.refresh(true);
    },


    onAttchmentDataFetch: function () {
      var reqid = this._reqIDData;
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

      oModelV2.read("/ReqAttachments", {
        filters: [
          new sap.ui.model.Filter("reqID", sap.ui.model.FilterOperator.EQ, reqid)
        ],
        success: function (oData) {
          if (oData && oData.results) {
            var oJSONModel = new JSONModel({
              attachments: oData.results
            });
            oView.setModel(oJSONModel, "UploadDocSrvTabData");
          }
        },
        error: function (oError) {
          MessageToast.show("Failed to load attachment data.", { position: "bottom center" });
          console.error("Error fetching attachment data:", oError);
        }
      });
    },

    // ==============Upload File Attachments end====================

    onSubmitReamrksData: function () {
      var oView = this.getView();
      var reqid = this._reqIDData;
      var statusData = this.statusData;
      var subtypedata = this._onSubType;
      var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
      if (!remarkInput) {
        MessageBox.information("Please provide a remark before submitting.");
        return;
      }


      var formTitle = this.getView().byId("NewBudgetReqFormPage").getTitle();
      var ftype = "";
      if (formTitle === "New Budget Request") {
        ftype = "CR";
      } else {
        ftype = "ABR";
      }

      var onewdtl = {
        creationDate: oView.byId("CreationDateInput").getValue(),
        NABDiv: oView.byId("DivisionBox").getSelectedKey(),
        NABLoc: oView.byId("LocationBox").getSelectedKey(),
        dept: oView.byId("DepartmentInput").getValue(),
        projectDesc: oView.byId("ProjectItemDesInput").getValue(),
        itemDesc: oView.byId("ItemDescInput").getValue(),
        implDate: oView.byId("ImplementationDateInput").getDateValue(),

        irrPaybacks: oView.byId("IRRPaybackInput").getValue(),
        contactPerson: oView.byId("ContactPersonInput").getValue(),
        contactNo: oView.byId("ContactNumberInput").getValue(),

        objective: oView.byId("ObjectiveInp").getValue(),
        background: oView.byId("BackgroundInp").getValue(),
        proposal: oView.byId("proposalInp").getValue(),
        deliverables: oView.byId("DeliverablesInp").getValue(),

        // Fix duplicate captlBudget definition (remove the second one)
        captlBudget: oView.byId("CapitalBudgetInput").getValue(),
        NABcontValue: oView.byId("ContingencyBox").getValue(),
        LakhsInput: oView.byId("LakhsInput").getValue(),
        revBudget: oView.byId("RevenueBudgetInput").getValue(),
        totalProjCost: oView.byId("TotalProjectCostInput").getValue(),
        seekApproval: oView.byId("SeekApprovalInput").getValue(),

        approverR1: oView.byId("R1Box").getSelectedKey(),
        approverR2: oView.byId("R2Box").getSelectedKey(),
        approverR3: oView.byId("R3Box").getSelectedKey(),

        // Budget form fields
        addlBudget: oView.byId("AddCapitalBudgetInput").getValue(),
        budgetTrans: oView.byId("AddBudgetTransferInput").getValue(),
        bTfromWbs: oView.byId("AddBudgetTransferFromWBSInput").getValue(),
        bTtoWbs: oView.byId("AddBudgetTransferToWBSInput").getValue(),

        origIrr: oView.byId("OriginalIRRPaybackInput").getValue(),
        revIrr: oView.byId("RevisedIRRPaybackInput").getValue(),

        contReq: oView.byId("AddContingencyRequiredInput").getValue(),
        costOverrun: oView.byId("AddCostOverrunInput").getValue(),
        contAllowed: oView.byId("AddContingencyAllowedInput").getValue(),
        utilised: oView.byId("AddUtilisedInput").getValue(),
        available: oView.byId("AddAvailableInput").getValue(),
        savings: oView.byId("AddParkedSavingsInput").getValue(),
        savingsFromWbs: oView.byId("AddParkedSavingsFromWBSInput").getValue(),
        savingsToWbs: oView.byId("AddParkedSavingsToWBSInput").getValue(),

        approvalType: oView.byId("ApprovalforBudgetBox").getSelectedKey(),
        capexAdvance: oView.byId("AddAdvancementofCAPEXInput").getValue(),
        contingencyAdv: oView.byId("AddAdvancementofContingencyInput").getValue(),
        capexApproved: oView.byId("AddApprovedProjectCAPEXInputLakh").getValue(),
        capexTotal: oView.byId("AddTotalProjectCAPEXInput").getValue(),
        subType: ftype
      };

      // List of decimal fields
      var decimalFields = [
        "addlBudget", "budgetTrans", "contReq", "costOverrun", "contAllowed",
        "utilised", "available", "savings", "capexAdvance", "contingencyAdv",
        "capexApproved", "capexTotal",
        "captlBudget", "NABcontValue", "LakhsInput", "revBudget", "totalProjCost", "seekApproval"
      ];


      // Sanitize decimal fields before sending
      decimalFields.forEach(function (field) {
        if (onewdtl[field] === "") {
          onewdtl[field] = null;
        } else {
          onewdtl[field] = parseFloat(onewdtl[field]);
          if (isNaN(onewdtl[field])) {
            onewdtl[field] = null;
          }
        }
      });

      var that = this;
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

      oModelV2.read("/Approvers", {
        urlParameters: {
          "$filter": "role eq 'R1'"
        },
        success: function (oData) {
          if (oData && oData.results && oData.results.length > 0) {

            var oComboBox = that.byId("R1Box");
            var oSelectedItem = oComboBox.getSelectedItem();

            if (!oSelectedItem) {
              sap.m.MessageToast.show("Please select an approver from the list.");
              return;
            }

            var oSelectedContext = oSelectedItem.getBindingContext("onNewBudgetApproverR1Model");
            var oSelectedData = oSelectedContext.getObject();
            var approverName = oSelectedData.name;

            var oSubtype = that.subType;
            var oStage = that.stagesData;

            var statusData = that.statusData;

            if(statusData === "Pending"){
              var oSubmitPayload = {
                pendingWith: approverName,
                stage: "Initiator",
                status: "Pending",
                type: 'NAB',
                remarks: remarkInput,
                newdtl: onewdtl,
              };
              }else{
                var oSubmitPayload = {
                  pendingWith: approverName,
                  stage: "",
                  status: "Pending",
                  type: 'NAB',
                  remarks: remarkInput,
                  newdtl: onewdtl,
                };
              }

            // var oSubmitPayload = {
            //   pendingWith: approverName,
            //   stage: "",
            //   status: "Pending",
            //   type: 'NAB',
            //   remarks: remarkInput,
            //   newdtl: onewdtl,
            // };

            var oModel = that.getOwnerComponent().getModel("approvalservicev2");

            if (!that._reqIDData) {
              // Create new request
              oModel.create("/Requests", oSubmitPayload, {
                success: function (oData) {
                  that._reqIDData = oData.reqID;
                  var reqid = oData.reqID;

                  var oRequestServiceModel = that.getOwnerComponent().getModel("Requestservicemodel");
                  if (!oRequestServiceModel) {
                    oRequestServiceModel = new sap.ui.model.json.JSONModel();
                    that.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
                  }
                  oRequestServiceModel.setData(oData);
                  that.refNoData = oData.refNo;
                  var reqID = oData.reqID;
                  var refNo = oData.refNo;


                  // var oModelAction = that.getOwnerComponent().getModel("approvalservicev2");
                  // var oPayload = {
                  //   reqID: reqID,
                  //   action: "SUBMIT",
                  //   remarks: "test"
                  // };

                  // oModelAction.create("/NBApproval", oPayload, {
                  //   success: function (oData, response) {
                  //     MessageToast.show("Action executed successfully");
                  //     console.log("Success:", oData);
                  //   },
                  //   error: function (oError) {
                  //     MessageBox.error("Error executing action");
                  //     console.log("Error:", oError);
                  //   }
                  // });

                  that.Approversendtonext(reqID);

                  sap.m.MessageBox.success("Request " + refNo + " has been submit successfully ", {
                    title: "Success",
                    actions: [sap.m.MessageBox.Action.OK],
                    onClose: function (oAction) {
                      if (oAction === sap.m.MessageBox.Action.OK) {
                        var oRouter = that.getOwnerComponent().getRouter();
                        oRouter.navTo("DashboardUI", { Name: "NBRF" });
                      }
                    }
                  });
                },
                error: function (oError) {
                  sap.m.MessageToast.show("Error submitting request: " + oError.message);
                }
              });
            } else {
              var reqid = that._reqIDData;
              // oModel.update("/Requests('" + reqid + "')", oSubmitPayload, {
              // oModel.update("/Requests(reqID='" + reqid + "')", oSubmitPayload, {
              //  oModel.update("/Requests(reqID='" + reqid + "')", oSubmitPayload, {

              // oModel.update("/Requests(reqID='" + reqid + "')", oSubmitPayload, {
              //   method: "PATCH",
              oModel.update("/Requests(reqID='" + reqid + "')", oSubmitPayload, {
                success: function (oData) {

                  that.refNoData = oData.refNo;
                  var refNo = oData.refNo;

                  var reqID = oData.reqID;

                  that.Approversendtonext(reqID);

                  // var oModelAction = that.getOwnerComponent().getModel("approvalservicev2");
                  // var oPayload = {
                  //   reqID: reqID,
                  //   action: "SUBMIT"
                  // };

                  // oModelAction.callFunction("/NBApproval", {
                  //   method: "POST",
                  //   urlParameters: oPayload,
                  //   success: function (oData, response) {
                  //     MessageToast.show("Action executed successfully");
                  //     console.log("Success:", oData);
                  //   },
                  //   error: function (oError) {
                  //     MessageBox.error("Error executing action");
                  //     console.log("Error:", oError);
                  //   }
                  // });


                  sap.m.MessageBox.success("Request " + refNo + " has been submit successfully ", {
                    title: "Success",
                    actions: [sap.m.MessageBox.Action.OK],
                    onClose: function (oAction) {
                      if (oAction === sap.m.MessageBox.Action.OK) {
                        var oRouter = that.getOwnerComponent().getRouter();
                        oRouter.navTo("DashboardUI", { Name: "NBRF" });
                      }
                    }
                  });
                },
                error: function (oError) {
                  sap.m.MessageToast.show("Error updating request: " + oError.message);
                }
              });
            }
          } else {
          }
        },
        error: function (oError) {
          // sap.m.MessageToast.show("Error fetching approver: " + oError.message);
        }
      });

    },

    // onApprovedData: function () {
    //   var oView = this.getView();
    //   var reqid = this._reqIDData;
    //   var statusData = this.statusData;
    //   var subtypedata = this._onSubType;
    //   var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
    //   if (!remarkInput) {
    //     MessageBox.information("Please provide a remark before submitting.");
    //     return;
    //   }

  
    //   var formTitle = this.getView().byId("NewBudgetReqFormPage").getTitle();
    //   var ftype = "";
    //   if (formTitle === "New Budget Request") {
    //     ftype = "CR";
    //   } else {
    //     ftype = "ABR";
    //   }

    //   var onewdtl = {
    //     creationDate: oView.byId("CreationDateInput").getValue(),
    //     NABDiv: oView.byId("DivisionBox").getSelectedKey(),
    //     NABLoc: oView.byId("LocationBox").getSelectedKey(),
    //     dept: oView.byId("DepartmentInput").getValue(),
    //     projectDesc: oView.byId("ProjectItemDesInput").getValue(),
    //     implDate: oView.byId("ImplementationDateInput").getDateValue(),

    //     irrPayback: oView.byId("IRRPaybackInput").getValue(),
    //     contactPerson: oView.byId("ContactPersonInput").getValue(),
    //     contactNo: oView.byId("ContactNumberInput").getValue(),

    //     objective: oView.byId("ObjectiveInp").getValue(),
    //     background: oView.byId("BackgroundInp").getValue(),
    //     proposal: oView.byId("proposalInp").getValue(),
    //     deliverables: oView.byId("DeliverablesInp").getValue(),

    //     // Fix duplicate captlBudget definition (remove the second one)
    //     captlBudget: oView.byId("CapitalBudgetInput").getValue(),
    //     NABcontValue: oView.byId("ContingencyBox").getValue(),
    //     LakhsInput: oView.byId("LakhsInput").getValue(),
    //     revBudget: oView.byId("RevenueBudgetInput").getValue(),
    //     totalProjCost: oView.byId("TotalProjectCostInput").getValue(),
    //     seekApproval: oView.byId("SeekApprovalInput").getValue(),


    //     recommAuth: oView.byId("SelectRecommendingInput").getValue(),
    //     recomApprover1: oView.byId("Recommended1CB").getSelectedKey(),
    //     recomApprover2: oView.byId("Recommended2CB").getSelectedKey(),
    //     recomApprover3: oView.byId("Recommended3CB").getSelectedKey(),
    //     recomApprover4: oView.byId("Recommended4CB").getSelectedKey(),
    //     recomApprover5: oView.byId("Recommended5CB").getSelectedKey(),
    //     recomApprover6: oView.byId("Recommended6CB").getSelectedKey(),
    //     approvedBy: oView.byId("ApprovebyCB").getSelectedKey(),
    //     NABprojCode: oView.byId("ProjectCodeCB").getSelectedKey(),
       

    //     // Budget form fields
    //     addlBudget: oView.byId("AddCapitalBudgetInput").getValue(),
    //     budgetTrans: oView.byId("AddBudgetTransferInput").getValue(),
    //     bTfromWbs: oView.byId("AddBudgetTransferFromWBSInput").getValue(),
    //     bTtoWbs: oView.byId("AddBudgetTransferToWBSInput").getValue(),

    //     origIrr: oView.byId("OriginalIRRPaybackInput").getValue(),
    //     revIrr: oView.byId("RevisedIRRPaybackInput").getValue(),

    //     contReq: oView.byId("AddContingencyRequiredInput").getValue(),
    //     costOverrun: oView.byId("AddCostOverrunInput").getValue(),
    //     contAllowed: oView.byId("AddContingencyAllowedInput").getValue(),
    //     utilised: oView.byId("AddUtilisedInput").getValue(),
    //     available: oView.byId("AddAvailableInput").getValue(),
    //     savings: oView.byId("AddParkedSavingsInput").getValue(),
    //     savingsFromWbs: oView.byId("AddParkedSavingsFromWBSInput").getValue(),
    //     savingsToWbs: oView.byId("AddParkedSavingsToWBSInput").getValue(),

    //     approvalType: oView.byId("ApprovalforBudgetBox").getSelectedKey(),
    //     capexAdvance: oView.byId("AddAdvancementofCAPEXInput").getValue(),
    //     contingencyAdv: oView.byId("AddAdvancementofContingencyInput").getValue(),
    //     capexApproved: oView.byId("AddApprovedProjectCAPEXInputLakh").getValue(),
    //     capexTotal: oView.byId("AddTotalProjectCAPEXInput").getValue(),
    //     subType: ftype
    //   };

    //   // List of decimal fields
    //   var decimalFields = [
    //     "addlBudget", "budgetTrans", "contReq", "costOverrun", "contAllowed",
    //     "utilised", "available", "savings", "capexAdvance", "contingencyAdv",
    //     "capexApproved", "capexTotal",
    //     "captlBudget", "NABcontValue", "LakhsInput", "revBudget", "totalProjCost", "seekApproval"
    //   ];


    //   // Sanitize decimal fields before sending
    //   decimalFields.forEach(function (field) {
    //     if (onewdtl[field] === "") {
    //       onewdtl[field] = null;
    //     } else {
    //       onewdtl[field] = parseFloat(onewdtl[field]);
    //       if (isNaN(onewdtl[field])) {
    //         onewdtl[field] = null;
    //       }
    //     }
    //   });

    //   var oSubmitPayload = {
    //     type: 'NAB',
    //     remarks: remarkInput,
    //     newdtl: onewdtl,
    //   };

    //   var that = this;

    //   var oModel = that.getOwnerComponent().getModel("approvalservicev2");

    //   if (!that._reqIDData) {
    //     oModel.create("/Requests", oSubmitPayload, {
    //       success: function (oData) {
    //         that._reqIDData = oData.reqID;
    //         var reqid = oData.reqID;

    //         var oRequestServiceModel = that.getOwnerComponent().getModel("Requestservicemodel");
    //         if (!oRequestServiceModel) {
    //           oRequestServiceModel = new sap.ui.model.json.JSONModel();
    //           that.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
    //         }
    //         oRequestServiceModel.setData(oData);
    //         that.refNoData = oData.refNo;
    //         var reqID = oData.reqID;
    //         var refNo = oData.refNo;

    //         that.approverdatacheckApproved(reqID);

    //         // sap.m.MessageBox.success("Request " + refNo + " has been submit successfully ", {
    //         //   title: "Success",
    //         //   actions: [sap.m.MessageBox.Action.OK],
    //         //   onClose: function (oAction) {
    //         //     if (oAction === sap.m.MessageBox.Action.OK) {
    //         //       var oRouter = that.getOwnerComponent().getRouter();
    //         //       oRouter.navTo("DashboardUI", { Name: "NBRF" });
    //         //     }
    //         //   }
    //         // });
    //       },
    //       error: function (oError) {
    //         sap.m.MessageToast.show("Error submitting request: " + oError.message);
    //       }
    //     });
    //   } else {
    //     var reqid = that._reqIDData;
    //     oModel.update("/Requests(reqID='" + reqid + "')", oSubmitPayload, {
    //       success: function (oData) {

    //         that.refNoData = oData.refNo;
    //         var refNo = oData.refNo;

    //         var reqID = oData.reqID;

    //         that.approverdatacheckApproved(reqID);

    //         // sap.m.MessageBox.success("Request " + refNo + " has been submit successfully ", {
    //         //   title: "Success",
    //         //   actions: [sap.m.MessageBox.Action.OK],
    //         //   onClose: function (oAction) {
    //         //     if (oAction === sap.m.MessageBox.Action.OK) {
    //         //       var oRouter = that.getOwnerComponent().getRouter();
    //         //       oRouter.navTo("DashboardUI", { Name: "NBRF" });
    //         //     }
    //         //   }
    //         // });
    //       },
    //       error: function (oError) {
    //         sap.m.MessageToast.show("Error updating request: " + oError.message);
    //       }
    //     });
    //   }

    // },

    onRejectData: function () {
      var oView = this.getView();
      var reqid = this._reqIDData;
      var statusData = this.statusData;
      var subtypedata = this._onSubType;
      var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
      if (!remarkInput) {
        MessageBox.information("Please provide a remark before submitting.");
        return;
      }


      var formTitle = this.getView().byId("NewBudgetReqFormPage").getTitle();
      var ftype = "";
      if (formTitle === "New Budget Request") {
        ftype = "CR";
      } else {
        ftype = "ABR";
      }

      var onewdtl = {
        creationDate: oView.byId("CreationDateInput").getValue(),
        NABDiv: oView.byId("DivisionBox").getSelectedKey(),
        NABLoc: oView.byId("LocationBox").getSelectedKey(),
        dept: oView.byId("DepartmentInput").getValue(),
        projectDesc: oView.byId("ProjectItemDesInput").getValue(),
        implDate: oView.byId("ImplementationDateInput").getDateValue(),

        irrPaybacks: oView.byId("IRRPaybackInput").getValue(),
        contactPerson: oView.byId("ContactPersonInput").getValue(),
        contactNo: oView.byId("ContactNumberInput").getValue(),

        objective: oView.byId("ObjectiveInp").getValue(),
        background: oView.byId("BackgroundInp").getValue(),
        proposal: oView.byId("proposalInp").getValue(),
        deliverables: oView.byId("DeliverablesInp").getValue(),

        // Fix duplicate captlBudget definition (remove the second one)
        captlBudget: oView.byId("CapitalBudgetInput").getValue(),
        NABcontValue: oView.byId("ContingencyBox").getValue(),
        LakhsInput: oView.byId("LakhsInput").getValue(),
        revBudget: oView.byId("RevenueBudgetInput").getValue(),
        totalProjCost: oView.byId("TotalProjectCostInput").getValue(),
        seekApproval: oView.byId("SeekApprovalInput").getValue(),

        // approverR1: approverR1,
        // approverR2: approverR2,
        // approverR3: approverR3,

        // Budget form fields
        addlBudget: oView.byId("AddCapitalBudgetInput").getValue(),
        budgetTrans: oView.byId("AddBudgetTransferInput").getValue(),
        bTfromWbs: oView.byId("AddBudgetTransferFromWBSInput").getValue(),
        bTtoWbs: oView.byId("AddBudgetTransferToWBSInput").getValue(),

        origIrr: oView.byId("OriginalIRRPaybackInput").getValue(),
        revIrr: oView.byId("RevisedIRRPaybackInput").getValue(),

        contReq: oView.byId("AddContingencyRequiredInput").getValue(),
        costOverrun: oView.byId("AddCostOverrunInput").getValue(),
        contAllowed: oView.byId("AddContingencyAllowedInput").getValue(),
        utilised: oView.byId("AddUtilisedInput").getValue(),
        available: oView.byId("AddAvailableInput").getValue(),
        savings: oView.byId("AddParkedSavingsInput").getValue(),
        savingsFromWbs: oView.byId("AddParkedSavingsFromWBSInput").getValue(),
        savingsToWbs: oView.byId("AddParkedSavingsToWBSInput").getValue(),

        approvalType: oView.byId("ApprovalforBudgetBox").getSelectedKey(),
        capexAdvance: oView.byId("AddAdvancementofCAPEXInput").getValue(),
        contingencyAdv: oView.byId("AddAdvancementofContingencyInput").getValue(),
        capexApproved: oView.byId("AddApprovedProjectCAPEXInputLakh").getValue(),
        capexTotal: oView.byId("AddTotalProjectCAPEXInput").getValue(),
        subType: ftype
      };

      // List of decimal fields
      var decimalFields = [
        "addlBudget", "budgetTrans", "contReq", "costOverrun", "contAllowed",
        "utilised", "available", "savings", "capexAdvance", "contingencyAdv",
        "capexApproved", "capexTotal",
        "captlBudget", "NABcontValue", "LakhsInput", "revBudget", "totalProjCost", "seekApproval"
      ];


      // Sanitize decimal fields before sending
      decimalFields.forEach(function (field) {
        if (onewdtl[field] === "") {
          onewdtl[field] = null;
        } else {
          onewdtl[field] = parseFloat(onewdtl[field]);
          if (isNaN(onewdtl[field])) {
            onewdtl[field] = null;
          }
        }
      });

      var oSubmitPayload = {
        stage: "Rejected",
        status: "Rejected",
        type: 'NAB',
        remarks: remarkInput,
        newdtl: onewdtl,
      };

      var that = this;

      var oModel = that.getOwnerComponent().getModel("approvalservicev2");

      if (!that._reqIDData) {
        oModel.create("/Requests", oSubmitPayload, {
          success: function (oData) {
            that._reqIDData = oData.reqID;
            var reqid = oData.reqID;

            var oRequestServiceModel = that.getOwnerComponent().getModel("Requestservicemodel");
            if (!oRequestServiceModel) {
              oRequestServiceModel = new sap.ui.model.json.JSONModel();
              that.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
            }
            oRequestServiceModel.setData(oData);
            that.refNoData = oData.refNo;
            var reqID = oData.reqID;
            var refNo = oData.refNo;

            that.RejectdatacheckApproved(reqID);

          },
          error: function (oError) {
            sap.m.MessageToast.show("Error submitting request: " + oError.message);
          }
        });
      } else {
        var reqid = that._reqIDData;
        oModel.update("/Requests(reqID='" + reqid + "')", oSubmitPayload, {
          success: function (oData) {

            that.refNoData = oData.refNo;
            var refNo = oData.refNo;

            var reqID = oData.reqID;

            that.RejectdatacheckApproved(reqID);

          },
          error: function (oError) {
            sap.m.MessageToast.show("Error updating request: " + oError.message);
          }
        });
      }

    },

 

    // onAssignNewBudgetReqForm: function () {
    //   var reqid = this._reqIDData;

    //   var Assignapprovename = this.getView().byId("R1Boxfrag").getSelectedKey();

    //   var onewdtl = {
    //     assignedTo: Assignapprovename
    //   };

    //   var oSubmitPayload = {
    //     stage: "",
    //     status: "pending",
    //     type: 'NAB',
    //     newdtl: onewdtl,
    //   };

    //   var that = this;

    //   var oModel = that.getOwnerComponent().getModel("approvalservicev2");

    //   var reqid = that._reqIDData;
    //   oModel.update("/Requests(reqID='" + reqid + "')", oSubmitPayload, {
    //     success: function (oData) {

    //       that.refNoData = oData.refNo;
    //       var refNo = oData.refNo;

    //       var reqID = oData.reqID;

    //       that.AssigndatacheckApproved(reqID);

    //     },
    //     error: function (oError) {
    //       sap.m.MessageToast.show("Error updating request: " + oError.message);
    //     }
    //   });


    // },

    // AssigndatacheckApproved: function (reqid) {
    //   var oModel = this.getOwnerComponent().getModel("approvalservicev2");
    //   var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");

    //   var reqid = this._reqIDData;

    //   var Assignapprovename = this.getView().byId("R1Boxfrag").getSelectedKey();

    //   var Data = {
    //     assignedTo: Assignapprovename
    //   };

    //   var oApprovedPayload = {
    //     reqID: reqid,
    //     action: "ASSIGN",
    //     remarks: remarkInput,
    //     data :Data
    //   };
    //   var that = this;
    //   sap.ui.core.BusyIndicator.show(0);

    //   oModel.create("/NBApproval", oApprovedPayload, {
    //     success: function () {
    //       sap.ui.core.BusyIndicator.hide();
    //       MessageBox.success("Request Assigned successfully!");
    //     },
    //     error: function (oError) {
    //       console.error("Error assigning request:", oError);
    //     }
    //   });
    // },

    onAssignNewBudgetReqForm: function (reqid) {
      var oModel = this.getOwnerComponent().getModel("approvalservicev2");
      var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");

      var reqid = this._reqIDData;
      var sStage = this.stagesData;

      if(sStage=== "Asset Team"){
        var Assignapprovename = this.getView().byId("R1Boxfrag").getSelectedKey();
      }else  if(sStage=== "Corporate Team"){
        var Assignapprovename = this.getView().byId("CTBoxfrag").getSelectedKey();
      } 

      var Data = {
        assignedTo: Assignapprovename 
      };

      var oApprovedPayload = {
        reqID: reqid,
        action: "ASSIGN",
        remarks: remarkInput,
        data :Data
      };

      var that = this;
      sap.ui.core.BusyIndicator.show(0);

      oModel.create("/NBApproval", oApprovedPayload, {
        success: function () {
          sap.ui.core.BusyIndicator.hide();
          // MessageBox.success("Request Assigned successfully!");
          sap.m.MessageBox.success("Request Assigned successfully!", {
            title: "Success",
            actions: [sap.m.MessageBox.Action.OK],
            onClose: function (oAction) {
              if (oAction === sap.m.MessageBox.Action.OK) {
                var oRouter = that.getOwnerComponent().getRouter();
                oRouter.navTo("approverdashboard");
              }
            }
          });
        },
        error: function (oError) {
          console.error("Error assigning request:", oError);
        }
      });
    },

    onForwardNewBudgetReqForm: function (reqid) {
      var oModel = this.getOwnerComponent().getModel("approvalservicev2");
      var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");

      var reqid = this._reqIDData;

      var Assignapprovename = this.getView().byId("R1Boxfrag").getSelectedKey();

      var Data = {
        assignedTo: Assignapprovename
      };

      var oApprovedPayload = {
        reqID: reqid,
        action: "FORWARD",
        remarks: remarkInput
      };
      var that = this;
      sap.ui.core.BusyIndicator.show(0);

      oModel.create("/NBApproval", oApprovedPayload, {
        success: function () {
          sap.ui.core.BusyIndicator.hide();
          MessageBox.success("Request Forward successfully!");
        },
        error: function (oError) {
          console.error("Error forwarding request:", oError);
        }
      });
    },

    RejectdatacheckApproved: function (reqid) {
      var oModel = this.getOwnerComponent().getModel("approvalservicev2");
      var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
      var oApprovedPayload = {
        reqID: reqid,
        action: "REJECT",
        remarks: remarkInput
      };
      var that = this;
      sap.ui.core.BusyIndicator.show(0);

      oModel.create("/NBApproval", oApprovedPayload, {
        success: function () {
          MessageBox.success("Request rejected successfully!", {
            onClose: function () {
              if (that._ApprovedCheck === "Approved") {
                sap.ui.core.BusyIndicator.hide();
                that.getOwnerComponent().getRouter().navTo("approverdashboard");
              }
            }
          });
        },
        error: function (oError) {
          console.error("Error rejecting request:", oError);
        }
      });
    },

    onCloseAssignFrag: function () {
      this.AssignpopupDialog.close();
      this.getOwnerComponent().getRouter().navTo("approverdashboard");
    },

    onApprovedData: function (reqid) {

      var oView = this.getView();
      var reqid = this._reqIDData;
      var statusData = this.statusData;
      var subtypedata = this._onSubType;
      var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");
      if (!remarkInput) {
        MessageBox.information("Please provide a remark before submitting.");
        return;
      }

  
      var formTitle = this.getView().byId("NewBudgetReqFormPage").getTitle();
      var ftype = "";
      if (formTitle === "New Budget Request") {
        ftype = "CR";
      } else {
        ftype = "ABR";
      }

      var onewdtl = {
        creationDate: oView.byId("CreationDateInput").getValue(),
        NABDiv: oView.byId("DivisionBox").getSelectedKey(),
        NABLoc: oView.byId("LocationBox").getSelectedKey(),
        dept: oView.byId("DepartmentInput").getValue(),
        projectDesc: oView.byId("ProjectItemDesInput").getValue(),
        implDate: oView.byId("ImplementationDateInput").getDateValue(),

        irrPaybacks: oView.byId("IRRPaybackInput").getValue(),
        contactPerson: oView.byId("ContactPersonInput").getValue(),
        contactNo: oView.byId("ContactNumberInput").getValue(),

        objective: oView.byId("ObjectiveInp").getValue(),
        background: oView.byId("BackgroundInp").getValue(),
        proposal: oView.byId("proposalInp").getValue(),
        deliverables: oView.byId("DeliverablesInp").getValue(),

        // Fix duplicate captlBudget definition (remove the second one)
        captlBudget: oView.byId("CapitalBudgetInput").getValue(),
        NABcontValue: oView.byId("ContingencyBox").getValue(),
        LakhsInput: oView.byId("LakhsInput").getValue(),
        revBudget: oView.byId("RevenueBudgetInput").getValue(),
        totalProjCost: oView.byId("TotalProjectCostInput").getValue(),
        seekApproval: oView.byId("SeekApprovalInput").getValue(),


        recommAuth: oView.byId("SelectRecommendingInput").getValue(),
        recomApprover1: oView.byId("Recommended1CB").getSelectedKey(),
        recomApprover2: oView.byId("Recommended2CB").getSelectedKey(),
        recomApprover3: oView.byId("Recommended3CB").getSelectedKey(),
        recomApprover4: oView.byId("Recommended4CB").getSelectedKey(),
        recomApprover5: oView.byId("Recommended5CB").getSelectedKey(),
        recomApprover6: oView.byId("Recommended6CB").getSelectedKey(),
        approvedBy: oView.byId("ApprovebyCB").getSelectedKey(),
        NABprojCode: oView.byId("ProjectCodeCB").getSelectedKey(),

        wbsNo: oView.byId("WBSNumberInput").getValue(),
        wbsNo: oView.byId("AmountInput").getValue(),
        wbsNo: oView.byId("CorpteamCB").getSelectedKey(),
       

        // Budget form fields
        addlBudget: oView.byId("AddCapitalBudgetInput").getValue(),
        budgetTrans: oView.byId("AddBudgetTransferInput").getValue(),
        bTfromWbs: oView.byId("AddBudgetTransferFromWBSInput").getValue(),
        bTtoWbs: oView.byId("AddBudgetTransferToWBSInput").getValue(),

        origIrr: oView.byId("OriginalIRRPaybackInput").getValue(),
        revIrr: oView.byId("RevisedIRRPaybackInput").getValue(),

        contReq: oView.byId("AddContingencyRequiredInput").getValue(),
        costOverrun: oView.byId("AddCostOverrunInput").getValue(),
        contAllowed: oView.byId("AddContingencyAllowedInput").getValue(),
        utilised: oView.byId("AddUtilisedInput").getValue(),
        available: oView.byId("AddAvailableInput").getValue(),
        savings: oView.byId("AddParkedSavingsInput").getValue(),
        savingsFromWbs: oView.byId("AddParkedSavingsFromWBSInput").getValue(),
        savingsToWbs: oView.byId("AddParkedSavingsToWBSInput").getValue(),

        approvalType: oView.byId("ApprovalforBudgetBox").getSelectedKey(),
        capexAdvance: oView.byId("AddAdvancementofCAPEXInput").getValue(),
        contingencyAdv: oView.byId("AddAdvancementofContingencyInput").getValue(),
        capexApproved: oView.byId("AddApprovedProjectCAPEXInputLakh").getValue(),
        capexTotal: oView.byId("AddTotalProjectCAPEXInput").getValue(),
        wbsNo: this.getView().byId("WBSNumberInput").getValue(),
        subType: ftype
      };

      // List of decimal fields
      var decimalFields = [
        "addlBudget", "budgetTrans", "contReq", "costOverrun", "contAllowed",
        "utilised", "available", "savings", "capexAdvance", "contingencyAdv",
        "capexApproved", "capexTotal",
        "captlBudget", "NABcontValue", "LakhsInput", "revBudget", "totalProjCost", "seekApproval"
      ];


      // Sanitize decimal fields before sending
      decimalFields.forEach(function (field) {
        if (onewdtl[field] === "") {
          onewdtl[field] = null;
        } else {
          onewdtl[field] = parseFloat(onewdtl[field]);
          if (isNaN(onewdtl[field])) {
            onewdtl[field] = null;
          }
        }
      });


      var oModel = this.getOwnerComponent().getModel("approvalservicev2");
      // var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");

      // var oCorpTeamCB = this.byId("CorpteamCB");
      // var sSelectedKey = oCorpTeamCB.getSelectedKey();

      // var oCorpTeamMem = that.corpTeamMem ;

      // var Data = {
      //   assignedTo: sSelectedKey,
      //   corpTeamMem: sSelectedKey
      // };


      // if (!sSelectedKey && !oCorpTeamMem) {
      //   var oApprovedPayload = {
      //     reqID: reqid,
      //     action: "APPROVE",
      //     remarks: remarkInput,
      //     data : onewdtl
      //   };
      // } else {
      //   var oApprovedPayload = {
      //     reqID: reqid,
      //     action: "ASSIGN",
      //     remarks: remarkInput,
      //     data : Data
      //   };
      // }

      var oCorpTeamCB = this.byId("CorpteamCB");
      var sSelectedKey = oCorpTeamCB.getSelectedKey();

      var oCorpTeamMem = this.corpTeamMem;

      var Data = {
        assignedTo: sSelectedKey,
        corpTeamMem: sSelectedKey
      };

      var hasSelectedKey = !!sSelectedKey;
      var hasCorpTeamMem = !!oCorpTeamMem;

      var oApprovedPayload;

      if (hasSelectedKey && !hasCorpTeamMem) {
        // Only this specific case: assign
        oApprovedPayload = {
          reqID: reqid,
          action: "ASSIGN",
          remarks: remarkInput,
          data: Data
        };
      } else {
        // All other cases: approve
        oApprovedPayload = {
          reqID: reqid,
          action: "APPROVE",
          remarks: remarkInput,
          data: onewdtl
        };
      }


      var that = this;
      sap.ui.core.BusyIndicator.show(0);

      oModel.create("/NBApproval", oApprovedPayload, {
        success: function () {
          MessageBox.success("Request approved successfully!", {
            onClose: function () {
              if (that._ApprovedCheck === "Approved") {
                sap.ui.core.BusyIndicator.hide();
                that.getOwnerComponent().getRouter().navTo("approverdashboard");
              }
            }
          });
        },
        error: function (oError) {
          console.error("Error approving request:", oError);
        }
      });
    },

    Approversendtonext: function (reqID) {
      var oModel = this.getOwnerComponent().getModel("approvalservicev2");
      var remarkInput = this.getView().getModel("viewenableddatacheck").getProperty("/remarkModel");

      var statusData = this.statusData;

      var sdata = {
        wbsNo: this.getView().byId("WBSNumberInput").getValue(),
      }

    if(statusData === "Pending"){
        var oApprovedPayload = {
          reqID: reqID,
          action: "APPROVE",
          remarks: remarkInput,
          data : sdata
        };
      }else{
        var oApprovedPayload = {
          reqID: reqID,
          action: "SUBMIT",
          remarks: remarkInput
        };
      }

     
      var that = this;
      sap.ui.core.BusyIndicator.show(0);

      oModel.create("/NBApproval", oApprovedPayload, {
        success: function () {
          // MessageBox.success("Mail sent successfully!");
          sap.ui.core.BusyIndicator.hide();
        },
        error: function (oError) {
          sap.ui.core.BusyIndicator.hide();
          MessageToast.show("Error approving request.", { position: "bottom center" });
          console.error("Error approving request:", oError);
        }
      });
    },


    _onRouteNewBudgetRequestFormRef: function (oEvent) {
      var oArgs = oEvent.getParameter("arguments");
      this._NBRFNameUI = oArgs.basedNameUINBRF;
      var reqID = oArgs.reqID;

      this._reqIDData = reqID;

      // this._ApprovedCheck=""
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      var that = this;
      oModelV2.read("/Requests", {
        urlParameters: {
          "$filter": "reqID eq '" + reqID + "'",
          "$expand": "newdtl"
        },
        success: function (oData) {
          that.byId("ReferenceNumberID").setText("Reference Number : " + oData.results[0].refNo);

          if (oData && oData.results.length > 0) {

            let oRequestServiceModel = that.getOwnerComponent().getModel("Requestservicemodel");
            if (!oRequestServiceModel) {
              oRequestServiceModel = new sap.ui.model.json.JSONModel();
              that.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
            }
            oRequestServiceModel.setData(oData.results[0]);
          } else {
            sap.m.MessageToast.show("No data found for Req ID: " + reqID);
          }
          that.onFetchTimelinessDataNBRF();

          //  var cbBudgetTrans = oData.results.newdtl.fdBudgetTrans;
          var cbBudgetTrans = oData.results[0].newdtl.fdBudgetTrans;
          var cbContingency = oData.results[0].newdtl.fdContingency;
          var cbSaving = oData.results[0].newdtl.fdSavings;
          var cbOverrun = oData.results[0].newdtl.fdOverrun;
          var cbAdvance = oData.results[0].newdtl.fdAdvance;

          var oSubType = oData.results[0].newdtl.subType;
          var oStatus = oData.results[0].status;
          that.statusData = oData.results[0].status;
          var oStagesData = oData.results[0].stage;

          //  AddBudgetTransferInput
          //  AddBudgetTransferFromWBSInput
          //  AddBudgetTransferToWBSInput

          if (cbBudgetTrans === true) {
            that.getView().byId("AddBudgetTransferInput").setEditable(true);
            that.getView().byId("AddBudgetTransferFromWBSInput").setEditable(true);
            that.getView().byId("AddBudgetTransferToWBSInput").setEditable(true);
          } else {
            that.getView().byId("AddBudgetTransferInput").setEditable(false);
            that.getView().byId("AddBudgetTransferFromWBSInput").setEditable(false);
            that.getView().byId("AddBudgetTransferToWBSInput").setEditable(false);
          }

          if (cbContingency === true) {
            that.getView().byId("AddContingencyRequiredInput").setEditable(true);
            that.getView().byId("AddContingencyAllowedInput").setEditable(true);
            that.getView().byId("AddUtilisedInput").setEditable(true);
            that.getView().byId("AddApprovedProjectCAPEXInputLakh").setEditable(true);
          } else {
            that.getView().byId("AddContingencyRequiredInput").setEditable(false);
            that.getView().byId("AddContingencyAllowedInput").setEditable(false);
            that.getView().byId("AddUtilisedInput").setEditable(false);
            that.getView().byId("AddApprovedProjectCAPEXInputLakh").setEditable(false);
          }

          if (cbSaving === true) {
            that.getView().byId("AddParkedSavingsInput").setEditable(true);
            that.getView().byId("AddParkedSavingsFromWBSInput").setEditable(true);
            that.getView().byId("AddParkedSavingsToWBSInput").setEditable(true);
          } else {
            that.getView().byId("AddParkedSavingsInput").setEditable(false);
            that.getView().byId("AddParkedSavingsFromWBSInput").setEditable(false);
            that.getView().byId("AddParkedSavingsToWBSInput").setEditable(false);
          }

          if (cbOverrun === true) {
            that.getView().byId("AddCostOverrunInput").setEditable(true);
            that.getView().byId("AddAvailableInput").setEditable(true);
            that.getView().byId("OriginalIRRPaybackInput").setEditable(true);
            that.getView().byId("RevisedIRRPaybackInput").setEditable(true);
          } else {
            that.getView().byId("AddCostOverrunInput").setEditable(false);
            that.getView().byId("AddAvailableInput").setEditable(false);
            that.getView().byId("OriginalIRRPaybackInput").setEditable(false);
            that.getView().byId("RevisedIRRPaybackInput").setEditable(false);
          }

          if (cbAdvance === true) {
            that.getView().byId("AddAdvancementofCAPEXInput").setEditable(true);
            that.getView().byId("AddAdvancementofContingencyInput").setEditable(true);
            that.getView().byId("AddTotalProjectCAPEXInput").setEditable(true);
          } else {
            that.getView().byId("AddAdvancementofCAPEXInput").setEditable(false);
            that.getView().byId("AddAdvancementofContingencyInput").setEditable(false);
            that.getView().byId("AddTotalProjectCAPEXInput").setEditable(false);
          }

          var reqType = reqID.split("-")[2];

          if (oStatus==="Draft" && oStagesData === "Initiator" && oSubType === "ABR") {
            that.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");
            that.getView().byId("ReferenceNumberID").setVisible(true);
            that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
            that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);
            const oView = that.getView();

            const commonFields = [
              "DivisionBox", "LocationBox", "DepartmentInput", "ProjectItemDesInput", "ProjectNameInput", "ItemDescInput",
              "ImplementationDateInput", "IRRPaybackInput", "ContactPersonInput", "ContactNumberInput",
              "ObjectiveInp", "BackgroundInp", "proposalInp", "DeliverablesInp",
              "R1Box", "R2Box", "R3Box"
            ];

            commonFields.forEach(id => oView.byId(id)?.setEditable(true));

            // ABR-specific fields
            if (oSubType === "ABR") {
              const abrFields = [
                "chkBudgetTransfer", "chkContingency", "chkSavings", "chkCostOverrun", "chkAdvancement",
                "AddCapitalBudgetInput", "ApprovalforBudgetBox", "AddBudgetTransferInput", "AddBudgetTransferFromWBSInput",
                "AddBudgetTransferToWBSInput", "AddContingencyRequiredInput", "AddCostOverrunInput",
                "AddContingencyAllowedInput", "AddUtilisedInput", "AddAvailableInput",
                "OriginalIRRPaybackInput", "RevisedIRRPaybackInput", "AddParkedSavingsInput",
                "AddParkedSavingsFromWBSInput", "AddParkedSavingsToWBSInput", "AddAdvancementofCAPEXInput",
                "AddAdvancementofContingencyInput", "AddApprovedProjectCAPEXInputLakh", "AddTotalProjectCAPEXInput"
              ];
              abrFields.forEach(id => oView.byId(id)?.setEditable(true));
            }

            oView.byId("SaveBtnNBRF").setEnabled(true);
            oView.byId("SubmitNewBudgetReqForm").setEnabled(true);



          } else if (oStatus==="Draft" && oStagesData === "Initiator" && oSubType === "CR") {
            that.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
            that.getView().byId("ReferenceNumberID").setVisible(true);
            that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
            that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);

            const oView = that.getView();

            const commonFields = [
              "DivisionBox", "LocationBox", "DepartmentInput", "ProjectItemDesInput", "ProjectNameInput", "ItemDescInput",
              "ImplementationDateInput", "IRRPaybackInput", "ContactPersonInput", "ContactNumberInput",
              "ObjectiveInp", "BackgroundInp", "proposalInp", "DeliverablesInp",
              "R1Box", "R2Box", "R3Box"
            ];

            commonFields.forEach(id => oView.byId(id)?.setEditable(true));

            // CR-specific fields
            if (oSubType === "CR") {
              const crFields = [
                "CapitalBudgetInput", "ContingencyBox", "SeekApprovalInput", "RevenueBudgetInput"
              ];
              crFields.forEach(id => oView.byId(id)?.setEditable(true));
            }

            oView.byId("SaveBtnNBRF").setEnabled(true);
            oView.byId("SubmitNewBudgetReqForm").setEnabled(true);

          } else if (["R1", "R2", "R3"].includes(oStagesData) && (oSubType === "ABR" || oSubType === "CR")) {

            // Set form title and enable/disable flags
            const oView = that.getView();

            if (oSubType === "ABR") {
              that.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");
              that.getView().byId("ReferenceNumberID").setVisible(true);
              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);
            } else if (oSubType === "CR") {
              that.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
              that.getView().byId("ReferenceNumberID").setVisible(true);
              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);
            }

            // Fields to disable in both ABR and CR
            const commonFields = [
              "DivisionBox", "LocationBox", "DepartmentInput", "ProjectItemDesInput", "ProjectNameInput", "ItemDescInput",
              "ImplementationDateInput", "IRRPaybackInput", "ContactPersonInput", "ContactNumberInput",
              "ObjectiveInp", "BackgroundInp", "proposalInp", "DeliverablesInp",
              "R1Box", "R2Box", "R3Box"
            ];

            commonFields.forEach(id => oView.byId(id)?.setEditable(false));

            // ABR-specific fields
            if (oSubType === "ABR") {
              const abrFields = [
                "chkBudgetTransfer", "chkContingency", "chkSavings", "chkCostOverrun", "chkAdvancement",
                "AddCapitalBudgetInput", "ApprovalforBudgetBox", "AddBudgetTransferInput", "AddBudgetTransferFromWBSInput",
                "AddBudgetTransferToWBSInput", "AddContingencyRequiredInput", "AddCostOverrunInput",
                "AddContingencyAllowedInput", "AddUtilisedInput", "AddAvailableInput",
                "OriginalIRRPaybackInput", "RevisedIRRPaybackInput", "AddParkedSavingsInput",
                "AddParkedSavingsFromWBSInput", "AddParkedSavingsToWBSInput", "AddAdvancementofCAPEXInput",
                "AddAdvancementofContingencyInput", "AddApprovedProjectCAPEXInputLakh", "AddTotalProjectCAPEXInput"
              ];
              abrFields.forEach(id => oView.byId(id)?.setEditable(false));
            }

            // CR-specific fields
            if (oSubType === "CR") {
              const crFields = [
                "CapitalBudgetInput", "ContingencyBox", "SeekApprovalInput", "RevenueBudgetInput"
              ];
              crFields.forEach(id => oView.byId(id)?.setEditable(false));
            }

            oView.byId("SaveBtnNBRF").setEnabled(false);
            oView.byId("SubmitNewBudgetReqForm").setEnabled(false);
          } else if (["Asset Team","Recommended By 1","Recommended By 2","Recommended By 3","Recommended By 4","Recommended By 5","Recommended By 6","Approved By"].includes(oStagesData) && (oSubType === "ABR" || oSubType === "CR")) {
            // Set form title and enable/disable flags
            const oView = that.getView();

            if (oSubType === "ABR") {
              that.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");
              that.getView().byId("ReferenceNumberID").setVisible(true);
              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);
            } else if (oSubType === "CR") {
              that.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
              that.getView().byId("ReferenceNumberID").setVisible(true);
              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);
            }

            oView.byId("Recommendedsection").setVisible(true);

            // Fields to disable in both ABR and CR
            const commonFields = [
              "DivisionBox", "LocationBox", "DepartmentInput", "ProjectItemDesInput", "ProjectNameInput", "ItemDescInput",
              "ImplementationDateInput", "IRRPaybackInput", "ContactPersonInput", "ContactNumberInput",
              "ObjectiveInp", "BackgroundInp", "proposalInp", "DeliverablesInp",
              "R1Box", "R2Box", "R3Box", "SelectRecommendingInput", "Recommended1CB", "Recommended2CB", "Recommended3CB", "Recommended4CB", "Recommended5CB",  "Recommended6CB", "ApprovebyCB", "ProjectCodeCB"
            ];

            commonFields.forEach(id => oView.byId(id)?.setEditable(false));

            // ABR-specific fields
            if (oSubType === "ABR") {
              const abrFields = [
                "chkBudgetTransfer", "chkContingency", "chkSavings", "chkCostOverrun", "chkAdvancement",
                "AddCapitalBudgetInput", "ApprovalforBudgetBox", "AddBudgetTransferInput", "AddBudgetTransferFromWBSInput",
                "AddBudgetTransferToWBSInput", "AddContingencyRequiredInput", "AddCostOverrunInput",
                "AddContingencyAllowedInput", "AddUtilisedInput", "AddAvailableInput",
                "OriginalIRRPaybackInput", "RevisedIRRPaybackInput", "AddParkedSavingsInput",
                "AddParkedSavingsFromWBSInput", "AddParkedSavingsToWBSInput", "AddAdvancementofCAPEXInput",
                "AddAdvancementofContingencyInput", "AddApprovedProjectCAPEXInputLakh", "AddTotalProjectCAPEXInput"
              ];
              abrFields.forEach(id => oView.byId(id)?.setEditable(false));
            }

            // CR-specific fields
            if (oSubType === "CR") {
              const crFields = [
                "CapitalBudgetInput", "ContingencyBox", "SeekApprovalInput", "RevenueBudgetInput"
              ];
              crFields.forEach(id => oView.byId(id)?.setEditable(false));
            }

            oView.byId("SaveBtnNBRF").setEnabled(false);
            oView.byId("SubmitNewBudgetReqForm").setEnabled(false);
          }else if (oStatus==="Pending" && oStagesData === "Initiator"  && (oSubType === "ABR" || oSubType === "CR")) {
            // Set form title and enable/disable flags
            const oView = that.getView();

            if (oSubType === "ABR") {
              that.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");
              that.getView().byId("ReferenceNumberID").setVisible(true);
              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);
            } else if (oSubType === "CR") {
              that.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
              that.getView().byId("ReferenceNumberID").setVisible(true);
              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);
            }

            oView.byId("Recommendedsection").setVisible(true);
            oView.byId("WBSNumberID").setVisible(true);
            oView.byId("WBSNumberInput").setVisible(true);

            // Fields to disable in both ABR and CR
            const commonFields = [
              "DivisionBox", "LocationBox", "DepartmentInput", "ProjectItemDesInput", "ProjectNameInput", "ItemDescInput",
              "ImplementationDateInput", "IRRPaybackInput", "ContactPersonInput", "ContactNumberInput",
              "ObjectiveInp", "BackgroundInp", "proposalInp", "DeliverablesInp",
              "R1Box", "R2Box", "R3Box", "SelectRecommendingInput", "Recommended1CB", "Recommended2CB", "Recommended3CB", "Recommended4CB", "Recommended5CB",  "Recommended6CB", "ApprovebyCB", "ProjectCodeCB"
            ];

            commonFields.forEach(id => oView.byId(id)?.setEditable(false));

            // ABR-specific fields
            if (oSubType === "ABR") {
              const abrFields = [
                "chkBudgetTransfer", "chkContingency", "chkSavings", "chkCostOverrun", "chkAdvancement",
                "AddCapitalBudgetInput", "ApprovalforBudgetBox", "AddBudgetTransferInput", "AddBudgetTransferFromWBSInput",
                "AddBudgetTransferToWBSInput", "AddContingencyRequiredInput", "AddCostOverrunInput",
                "AddContingencyAllowedInput", "AddUtilisedInput", "AddAvailableInput",
                "OriginalIRRPaybackInput", "RevisedIRRPaybackInput", "AddParkedSavingsInput",
                "AddParkedSavingsFromWBSInput", "AddParkedSavingsToWBSInput", "AddAdvancementofCAPEXInput",
                "AddAdvancementofContingencyInput", "AddApprovedProjectCAPEXInputLakh", "AddTotalProjectCAPEXInput"
              ];
              abrFields.forEach(id => oView.byId(id)?.setEditable(false));
            }

            // CR-specific fields
            if (oSubType === "CR") {
              const crFields = [
                "CapitalBudgetInput", "ContingencyBox", "SeekApprovalInput", "RevenueBudgetInput"
              ];
              crFields.forEach(id => oView.byId(id)?.setEditable(false));
            }

            oView.byId("SaveBtnNBRF").setEnabled(true);
            oView.byId("SubmitNewBudgetReqForm").setEnabled(true);
          } else if (oStatus==="Pending" && oStagesData === "Asset Team Member"  && (oSubType === "ABR" || oSubType === "CR")) {

            const oView = that.getView();

            if (oSubType === "ABR") {
              that.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");
              that.getView().byId("ReferenceNumberID").setVisible(true);
              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);
            } else if (oSubType === "CR") {
              that.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
              that.getView().byId("ReferenceNumberID").setVisible(true);
              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);
            }

            oView.byId("Recommendedsection").setVisible(true);
            oView.byId("WBSNumberID").setVisible(true);
            oView.byId("WBSNumberInput").setVisible(true);
            oView.byId("WBSNumberInput").setEditable(false);

            // Fields to disable in both ABR and CR
            const commonFields = [
              "DivisionBox", "LocationBox", "DepartmentInput", "ProjectItemDesInput", "ProjectNameInput", "ItemDescInput",
              "ImplementationDateInput", "IRRPaybackInput", "ContactPersonInput", "ContactNumberInput",
              "ObjectiveInp", "BackgroundInp", "proposalInp", "DeliverablesInp",
              "R1Box", "R2Box", "R3Box", "SelectRecommendingInput", "Recommended1CB", "Recommended2CB", "Recommended3CB", "Recommended4CB", "Recommended5CB",  "Recommended6CB", "ApprovebyCB", "ProjectCodeCB"
            ];

            commonFields.forEach(id => oView.byId(id)?.setEditable(false));

            // ABR-specific fields
            if (oSubType === "ABR") {
              const abrFields = [
                "chkBudgetTransfer", "chkContingency", "chkSavings", "chkCostOverrun", "chkAdvancement",
                "AddCapitalBudgetInput", "ApprovalforBudgetBox", "AddBudgetTransferInput", "AddBudgetTransferFromWBSInput",
                "AddBudgetTransferToWBSInput", "AddContingencyRequiredInput", "AddCostOverrunInput",
                "AddContingencyAllowedInput", "AddUtilisedInput", "AddAvailableInput",
                "OriginalIRRPaybackInput", "RevisedIRRPaybackInput", "AddParkedSavingsInput",
                "AddParkedSavingsFromWBSInput", "AddParkedSavingsToWBSInput", "AddAdvancementofCAPEXInput",
                "AddAdvancementofContingencyInput", "AddApprovedProjectCAPEXInputLakh", "AddTotalProjectCAPEXInput"
              ];
              abrFields.forEach(id => oView.byId(id)?.setEditable(false));
            }

            // CR-specific fields
            if (oSubType === "CR") {
              const crFields = [
                "CapitalBudgetInput", "ContingencyBox", "SeekApprovalInput", "RevenueBudgetInput"
              ];
              crFields.forEach(id => oView.byId(id)?.setEditable(false));
            }

            oView.byId("SaveBtnNBRF").setEnabled(false);
            oView.byId("SubmitNewBudgetReqForm").setEnabled(false);

          }else if (oStatus==="Pending" && oStagesData === "Corporate Team"  && (oSubType === "ABR" || oSubType === "CR")) {

            const oView = that.getView();

            if (oSubType === "ABR") {
              that.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");
              that.getView().byId("ReferenceNumberID").setVisible(true);
              that.getView().byId("AmountID").setVisible(true);
              that.getView().byId("AmountInput").setVisible(true);
              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);
            } else if (oSubType === "CR") {
              that.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
              that.getView().byId("ReferenceNumberID").setVisible(true);
              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);
            }

            oView.byId("Recommendedsection").setVisible(true);
            oView.byId("WBSNumberID").setVisible(true);
            oView.byId("WBSNumberInput").setVisible(true);
            oView.byId("WBSNumberInput").setEditable(false);

            oView.byId("CorpteamID").setVisible(true);
            oView.byId("CorpteamCB").setVisible(true);
            oView.byId("CorpteamCB").setEditable(false);

            // Fields to disable in both ABR and CR
            const commonFields = [
              "DivisionBox", "LocationBox", "DepartmentInput", "ProjectItemDesInput", "ProjectNameInput", "ItemDescInput",
              "ImplementationDateInput", "IRRPaybackInput", "ContactPersonInput", "ContactNumberInput",
              "ObjectiveInp", "BackgroundInp", "proposalInp", "DeliverablesInp",
              "R1Box", "R2Box", "R3Box", "SelectRecommendingInput", "Recommended1CB", "Recommended2CB", "Recommended3CB", "Recommended4CB", "Recommended5CB",  "Recommended6CB", "ApprovebyCB", "ProjectCodeCB"
            ];

            commonFields.forEach(id => oView.byId(id)?.setEditable(false));

            // ABR-specific fields
            if (oSubType === "ABR") {
              const abrFields = [
                "chkBudgetTransfer", "chkContingency", "chkSavings", "chkCostOverrun", "chkAdvancement",
                "AddCapitalBudgetInput", "ApprovalforBudgetBox", "AddBudgetTransferInput", "AddBudgetTransferFromWBSInput",
                "AddBudgetTransferToWBSInput", "AddContingencyRequiredInput", "AddCostOverrunInput",
                "AddContingencyAllowedInput", "AddUtilisedInput", "AddAvailableInput",
                "OriginalIRRPaybackInput", "RevisedIRRPaybackInput", "AddParkedSavingsInput",
                "AddParkedSavingsFromWBSInput", "AddParkedSavingsToWBSInput", "AddAdvancementofCAPEXInput",
                "AddAdvancementofContingencyInput", "AddApprovedProjectCAPEXInputLakh", "AddTotalProjectCAPEXInput"
              ];
              abrFields.forEach(id => oView.byId(id)?.setEditable(false));
            }

            // CR-specific fields
            if (oSubType === "CR") {
              const crFields = [
                "CapitalBudgetInput", "ContingencyBox", "SeekApprovalInput", "RevenueBudgetInput"
              ];
              crFields.forEach(id => oView.byId(id)?.setEditable(false));
            }

            oView.byId("SaveBtnNBRF").setEnabled(false);
            oView.byId("SubmitNewBudgetReqForm").setEnabled(false);

          }
            


          that.onAttchmentDataFetch();

        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load HOD data.");
        }
      });
    },

    onFetchTimelinessDataNBRF: function () {
      var reqid = this._reqIDData;
      var oView = this.getView();
      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");

      oModelV2.read("/ProcessLogs", {
        filters: [
          new sap.ui.model.Filter("reqID", sap.ui.model.FilterOperator.EQ, reqid)
        ],
        success: function (oData) {
          if (oData && oData.results) {
            var oJSONModel = new sap.ui.model.json.JSONModel(oData);
            oView.setModel(oJSONModel, "timelinesslogdata");
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load attachment data.");
          console.error(oError);
        }
      });
    },

    // onCapitalBudgetliveChange: function(oEvent) {
    //   const value = oEvent.getParameter("value");
    //   const input = oEvent.getSource();
    //   if (isNaN(value) || parseFloat(value) < 0) {
    //       input.setValueState("Error");
    //       input.setValueStateText("Please enter a valid positive number");
    //   } else {
    //       input.setValueState("None");
    //   }
    //   const formattedValue = parseFloat(value).toFixed(2);
    // if (!isNaN(formattedValue)) {
    //     this.byId("CapitalBudgetInput").setValue(formattedValue);
    // }
    // },
    onCapitalBudgetliveChange: function (oEvent) {
      const value = oEvent.getParameter("value");
      const input = oEvent.getSource();

      if (isNaN(value) || parseFloat(value) < 0) {
        input.setValueState("Error");
        input.setValueStateText("Please enter a valid positive number");
      } else {
        input.setValueState("None");
      }
    },


    onRevenueBudgetChange: function (oEvent) {
      const value = oEvent.getParameter("value");
      const input = oEvent.getSource();
      if (isNaN(value) || parseFloat(value) < 0 || value.length > 15) {
        input.setValueState("Error");
        input.setValueStateText("Please enter a valid numeric value (max 15 characters)");
      } else {
        input.setValueState("None");
      }
      if (!isNaN(value) && value !== "") {
        const formattedValue = parseFloat(value).toFixed(2);
        input.setValue(formattedValue);
      }
    },

    onProjectItemDesInputChange: function (oEvent) {
      var sValue = oEvent.getParameter("value");
      var oInput = oEvent.getSource();

      // Allow only alphanumeric characters
      if (!/^[a-zA-Z0-9\s]*$/.test(sValue)) {
        oInput.setValueState("Error");
        oInput.setValueStateText("Only alphanumeric characters are allowed.");
      } else {
        oInput.setValueState("None");
      }
    },

    onObjectiveChange: function (oEvent) {
      this.validateTextArea(oEvent, "Objective", 250);
    },
    onBackgroundChange: function (oEvent) {
      this.validateTextArea(oEvent, "Background", 1000);
    },
    onProposalChange: function (oEvent) {
      this.validateTextArea(oEvent, "Proposal", 1000);
    },
    onDeliverablesChange: function (oEvent) {
      this.validateTextArea(oEvent, "Deliverables", 375);
    },
    onContactPersonInputChange: function (oEvent) {
      this.validateTextArea(oEvent, "ContactPerson", 50);
    },
    onRemarksChangeNBRF: function (oEvent) {
      this.validateTextArea(oEvent, "RemarksNBRF", 1000);
    },
    validateTextArea: function (oEvent, sFieldName, iMaxLength) {
      var oTextArea = oEvent.getSource();
      var sValue = oTextArea.getValue().trim();

      if (!sValue) {
        oTextArea.setValueState("Error");
        oTextArea.setValueStateText(sFieldName + " is required");
      } else if (sValue.length > iMaxLength) {
        oTextArea.setValueState("Error");
        oTextArea.setValueStateText(sFieldName + " cannot exceed " + iMaxLength + " characters");
      } else {
        oTextArea.setValueState("None");
      }
    },
    onDivisionChangeValidate: function (oEvent) {
      this.validateComboBoxValue(oEvent.getSource(), "Division");
    },
    onLocationChangeValidate: function (oEvent) {
      this.validateComboBoxValue(oEvent.getSource(), "Location");
    },
    onContingencyChangeValidate: function (oEvent) {
      this.validateComboBoxValue(oEvent.getSource(), "Contingency");
      this.calculateTotalProjectCost();
    },
    onR1ChangeValidate: function (oEvent) {
      this.validateComboBoxValue(oEvent.getSource(), "R1");
      // this._validateApprovers();
      if (!this._suppressValidation) {
        this._validateApprovers();
      }
    },
    onR2ChangeValidate: function (oEvent) {
      this.validateComboBoxValue(oEvent.getSource(), "R2");
      // this._validateApprovers();
      if (!this._suppressValidation) {
        this._validateApprovers();
      }
    },
    onR3ChangeValidate: function (oEvent) {
      this.validateComboBoxValue(oEvent.getSource(), "R3");
      // this._validateApprovers();
      if (!this._suppressValidation) {
        this._validateApprovers();
      }
    },
    onApprovalforBudgetBoxChange: function (oEvent) {
      this.validateComboBoxValue(oEvent.getSource(), "ApprovalforBudget");
    },
    validateComboBoxValue: function (oComboBox, sFieldLabel) {
      var sEnteredValue = oComboBox.getValue();
      var aItems = oComboBox.getItems();
      var bIsValid = aItems.some(function (item) {
        return item.getText() === sEnteredValue || item.getKey() === sEnteredValue;
      });

      if (!bIsValid && sEnteredValue !== "") {
        oComboBox.setValueState(sap.ui.core.ValueState.Error);
        oComboBox.setValueStateText("Please select a valid " + sFieldLabel + " from the list.");
      } else {
        oComboBox.setValueState(sap.ui.core.ValueState.None);
      }
    },

    _validateApprovers: function () {

      if (this._validateApproversTimeout) {
        clearTimeout(this._validateApproversTimeout);
      }

      this._validateApproversTimeout = setTimeout(() => {
        const r1Box = this.byId("R1Box");
        const r2Box = this.byId("R2Box");
        const r3Box = this.byId("R3Box");

        const r1 = r1Box.getSelectedKey();
        const r2 = r2Box.getSelectedKey();
        const r3 = r3Box.getSelectedKey();

        const duplicates = [];

        // Reset visual error states
        r1Box.setValueState("None");
        r2Box.setValueState("None");
        r3Box.setValueState("None");

        this._suppressValidation = true;

        if (r1 && r2 && r1 === r2) {
          r2Box.setSelectedKey("");
          duplicates.push("R1 & R2");
        }
        if (r1 && r3 && r1 === r3) {
          r3Box.setSelectedKey("");
          duplicates.push("R1 & R3");
        }
        if (r2 && r3 && r2 === r3) {
          r3Box.setSelectedKey("");
          duplicates.push("R2 & R3");
        }

        this._suppressValidation = false;

        // Show error only once
        if (duplicates.length > 0 && !this._messageBoxOpen) {
          this._messageBoxOpen = true;
          MessageBox.error(`Approvers ${duplicates.join(", ")} must be different.`, {
            onClose: () => {
              this._messageBoxOpen = false;
            }
          });
        }
      }, 200);
    },

    onSeekApprovalChange: function () {
      var oView = this.getView();
      var oSeekInput = oView.byId("SeekApprovalInput");
      var oTotalInput = oView.byId("TotalProjectCostInput");
      var seekApprovalValue = parseFloat(oSeekInput.getValue());
      var totalProjectCostValue = parseFloat(oTotalInput.getValue());
      if (!isNaN(seekApprovalValue) && !isNaN(totalProjectCostValue)) {
        if (seekApprovalValue > totalProjectCostValue) {
          sap.m.MessageBox.error(
            "Seek Approval value should be less than or equal to Total Project Cost",
            {
              title: "Error"
            }
          );
          oSeekInput.setValueState("Error");
          oSeekInput.setValueStateText("Value exceeds total project cost");
          // Optionally: clear the invalid input
          // oSeekInput.setValue("");
        } else {
          oSeekInput.setValueState("None");
        }
      }
    },
    _ContingencyValidation: function (oEvent) {
      var oView = this.getView();
      var oModel = oView.getModel("Requestservicemodel");
      var oData = oModel.getProperty("/newdtl");
      var fCapitalBudget = parseFloat(oData.capitalBudget);
      var sSelectedKey = oEvent.getSource().getSelectedKey();
      var fContingencyPercent = parseFloat(sSelectedKey);
      if (!isNaN(fCapitalBudget) && !isNaN(fContingencyPercent)) {
        var fCalculatedLakhs = (fCapitalBudget * fContingencyPercent) / 100;
        oModel.setProperty("/newdtl/revBudget", fCalculatedLakhs.toFixed(2));
      } else {
        oModel.setProperty("/newdtl/revBudget", "0.00");
      }
    },



    calculateTotalProjectCost: function () {
      var oView = this.getView();
      var capitalBudget = parseFloat(oView.byId("CapitalBudgetInput").getValue()) || 0;
      var contingencyPercent = parseFloat(oView.byId("ContingencyBox").getSelectedKey().replace("%", "")) || 0;
      var lakhs = (capitalBudget * contingencyPercent) / 100;

      oView.byId("LakhsInput").setValue(lakhs.toFixed(2));
      var revenueBudget = parseFloat(oView.byId("RevenueBudgetInput").getValue()) || 0;
      var totalProjectCost = capitalBudget + lakhs;
      if (revenueBudget > 0) {
        totalProjectCost += revenueBudget;
      }
      oView.byId("TotalProjectCostInput").setValue(totalProjectCost.toFixed(2));
    },








    // onLocationChange: function (oEvent) {
    //   var oComboBox = oEvent.getSource();
    //   var sValue = oComboBox.getValue(); 
    //   var bMatch = false;
    //   oComboBox.getItems().forEach(function (oItem) {
    //       if (oItem.getText() === sValue) {
    //           bMatch = true;
    //       }
    //   });
    //   if (!bMatch) {
    //       oComboBox.setValueState(sap.ui.core.ValueState.Error);
    //       oComboBox.setValueStateText("This option is not available in the list");
    //   } else {
    //       oComboBox.setValueState(sap.ui.core.ValueState.None);
    //   }
    // },

    onCancelNewBudgetReqForm: function () {
      var oRouter = this.getOwnerComponent().getRouter();
      if (this._ApprovedCheck === "Approved") {
        //  oRouter.navTo("approverdashboard", {});
      } else {
        oRouter.navTo("DashboardUI", {
          Name: "NBRF"
        });
      }
    },

    _onRouteNewBudgetRequestFormRefApproved: function (oEvent) {
      this._ApprovedCheck = "";
      var oArgs = oEvent.getParameter("arguments");
      this._NBRFNameUI = oArgs.basedNameUINBRF;

      var reqID = oArgs.reqID;
      this._reqIDData = reqID;

      this._ApprovedCheck = oArgs.approved;

      var oModelV2 = this.getOwnerComponent().getModel("approvalservicev2");
      var that = this;
      oModelV2.read("/Requests", {
        urlParameters: {
          "$filter": "reqID eq '" + reqID + "'",
          "$expand": "newdtl"
        },

        success: function (oData) {
          that.getView().byId("ReferenceNumberID").setText("Reference Number : " + oData.results[0].refNo);
          if (oData && oData.results.length > 0) {

            // this.getView().byId("").setValue( oData.results[0].refNo);
            let oRequestServiceModel = that.getOwnerComponent().getModel("Requestservicemodel");
            if (!oRequestServiceModel) {
              oRequestServiceModel = new sap.ui.model.json.JSONModel();
              that.getOwnerComponent().setModel(oRequestServiceModel, "Requestservicemodel");
            }
            oRequestServiceModel.setData(oData.results[0]);

            that.reqID = oData.results[0].status;

            that.onGetCurrentUser();

            that.onFetchTimelinessDataNBRF();

            that.onAttchmentDataFetch();

            var pendingWithemail = that.sEmail;

            that.status = oData.results[0].status;
            that.subType = oData.results[0].newdtl.subType;
            that.stagesData = oData.results[0].stage;
            that.oPendingwith = oData.results[0].pendingWith;


            that.approverR1 = oData.results[0].newdtl.approverR1;
            that.approverR2 = oData.results[0].newdtl.approverR2;
            that.approverR3 = oData.results[0].newdtl.approverR3;
            that.corpTeamMem = oData.results[0].newdtl.corpTeamMem;

            // enableFormFields: true,
            // disableFormFields: false,

            if (that.status === "Pending" && that.stagesData === "R1" && that.subType === "ABR") {
              that.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");

              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);
              that.getView().byId("DivisionBox").setEditable(false);

              that.getView().byId("R1Box").setEditable(false);
              that.getView().byId("R2Box").setEditable(false);
              that.getView().byId("R3Box").setEditable(false);

              that.getView().byId("SaveBtnNBRF").setVisible(false);
              that.getView().byId("SubmitNewBudgetReqForm").setVisible(false);
              that.getView().byId("ApprovedNewBudgetReqForm").setVisible(true);
              that.getView().byId("RejectNewBudgetReqForm").setVisible(true);


            } else if (that.status === "Pending" && that.stagesData === "R1" && that.subType === "CR") {
              that.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);
              that.getView().byId("DivisionBox").setEditable(false);
              that.getView().byId("ImplementationDateInput").setEditable(true);

              that.getView().byId("R1Box").setEditable(false);
              that.getView().byId("R2Box").setEditable(false);
              that.getView().byId("R3Box").setEditable(false);

              that.getView().byId("SaveBtnNBRF").setVisible(false);
              that.getView().byId("SubmitNewBudgetReqForm").setVisible(false);
              that.getView().byId("AssignNewBudgetReqForm").setVisible(false);
              that.getView().byId("ForwardNewBudgetReqForm").setVisible(false);
              that.getView().byId("ApprovedNewBudgetReqForm").setVisible(true);
              that.getView().byId("RejectNewBudgetReqForm").setVisible(true);

              that.getView().byId("Recommendedsection").setVisible(false);
            } else if (that.status === "Pending" && that.stagesData === "R2" && that.subType === "ABR") {
              that.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");

              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);
              that.getView().byId("DivisionBox").setEditable(false);

              that.getView().byId("R1Box").setEditable(false);
              that.getView().byId("R2Box").setEditable(false);
              that.getView().byId("R3Box").setEditable(false);
              that.getView().byId("SaveBtnNBRF").setVisible(false);
              that.getView().byId("SubmitNewBudgetReqForm").setVisible(false);
              that.getView().byId("AssignNewBudgetReqForm").setVisible(false);
              that.getView().byId("ForwardNewBudgetReqForm").setVisible(false);
              that.getView().byId("ApprovedNewBudgetReqForm").setVisible(true);
              that.getView().byId("RejectNewBudgetReqForm").setVisible(true);

              that.getView().byId("Recommendedsection").setVisible(false);


            } else if (that.status === "Pending" && that.stagesData === "R2" && that.subType === "CR") {
              that.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);
              that.getView().byId("DivisionBox").setEditable(false);
              that.getView().byId("ImplementationDateInput").setEditable(true);

              that.getView().byId("R1Box").setEditable(false);
              that.getView().byId("R2Box").setEditable(false);
              that.getView().byId("R3Box").setEditable(false);

              that.getView().byId("SaveBtnNBRF").setVisible(false);
              that.getView().byId("SubmitNewBudgetReqForm").setVisible(false);
              that.getView().byId("AssignNewBudgetReqForm").setVisible(false);
              that.getView().byId("ForwardNewBudgetReqForm").setVisible(false);
              that.getView().byId("ApprovedNewBudgetReqForm").setVisible(true);
              that.getView().byId("RejectNewBudgetReqForm").setVisible(true);
              that.getView().byId("Recommendedsection").setVisible(false);
            } else if (that.status === "Pending" && that.stagesData === "R3" && that.subType === "ABR") {
              that.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");

              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);
              that.getView().byId("DivisionBox").setEditable(false);

              that.getView().byId("R1Box").setEditable(false);
              that.getView().byId("R2Box").setEditable(false);
              that.getView().byId("R3Box").setEditable(false);

              that.getView().byId("SaveBtnNBRF").setVisible(false);
              that.getView().byId("SubmitNewBudgetReqForm").setVisible(false);
              that.getView().byId("AssignNewBudgetReqForm").setVisible(false);
              that.getView().byId("ForwardNewBudgetReqForm").setVisible(false);
              that.getView().byId("ApprovedNewBudgetReqForm").setVisible(true);
              that.getView().byId("RejectNewBudgetReqForm").setVisible(true);
              that.getView().byId("Recommendedsection").setVisible(false);


            } else if (that.status === "Pending" && that.stagesData === "R3" && that.subType === "CR") {
              that.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
              that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
              that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);
              that.getView().byId("DivisionBox").setEditable(false);
              that.getView().byId("ImplementationDateInput").setEditable(true);

              that.getView().byId("R1Box").setEditable(false);
              that.getView().byId("R2Box").setEditable(false);
              that.getView().byId("R3Box").setEditable(false);

              that.getView().byId("SaveBtnNBRF").setVisible(false);
              that.getView().byId("SubmitNewBudgetReqForm").setVisible(false);
              that.getView().byId("AssignNewBudgetReqForm").setVisible(false);
              that.getView().byId("ForwardNewBudgetReqForm").setVisible(false);
              that.getView().byId("ApprovedNewBudgetReqForm").setVisible(true);
              that.getView().byId("RejectNewBudgetReqForm").setVisible(true);
              that.getView().byId("Recommendedsection").setVisible(false);

            } else if (that.status === "Pending" && that.stagesData === "Asset Team" && that.oPendingwith === "") {
              const oView = that.getView();
            
              if (!that.AssignpopupDialog) {
                that.AssignpopupDialog = sap.ui.xmlfragment(
                  oView.getId(),
                  "com.mmapprovalhub.approvalhub.Fragments.Assignpopup",
                  that
                );
                oView.addDependent(that.AssignpopupDialog);
              }

              that.getView().byId("CTLabelFrag").setVisible(false);
              that.getView().byId("CTBoxfrag").setVisible(false);
            
              that.getView().byId("R1Boxfrag").setSelectedKey("");
              that.getView().byId("CTBoxfrag").setSelectedKey("");
 
              that.AssignpopupDialog.open();

            } else if (that.status === "Pending" && that.stagesData === "Asset Team" && that.oPendingwith === pendingWithemail) {
              const oView = that.getView();
              if (that.subType === "ABR") {
                that.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");
                that.getView().byId("ReferenceNumberID").setVisible(true);
                that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
                that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);
              } else if (that.subType === "CR") {
                that.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
                that.getView().byId("ReferenceNumberID").setVisible(true);
                that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
                that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);
              }

              oView.byId("DivisionBox").setEditable(false);

              that.getView().byId("R1Box").setEditable(false);
              that.getView().byId("R2Box").setEditable(false);
              that.getView().byId("R3Box").setEditable(false);

              oView.byId("SaveBtnNBRF").setVisible(false);
              oView.byId("SubmitNewBudgetReqForm").setVisible(false);
              oView.byId("CancelNewBudgetReqForm").setVisible(false);
              oView.byId("ApprovedNewBudgetReqForm").setVisible(true);
              oView.byId("RejectNewBudgetReqForm").setVisible(true);
              oView.byId("ApprovedNewBudgetReqForm").setEnabled(true);
              oView.byId("Recommendedsection").setVisible(true);
              oView.byId("SelectRecommendingInput").setEditable(true);
              oView.byId("RejectNewBudgetReqForm").setEnabled(true);
              oView.byId("ForwardNewBudgetReqForm").setVisible(true);

            } else if (that.status === "Pending" && that.stagesData === "Asset Team" && that.oPendingwith !== pendingWithemail) {
              const oView = that.getView();
              if (that.subType === "ABR") {
                that.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");
                that.getView().byId("ReferenceNumberID").setVisible(true);
                that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
                that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);
              } else if (that.subType === "CR") {
                that.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
                that.getView().byId("ReferenceNumberID").setVisible(true);
                that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
                that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);
              }

              oView.byId("DivisionBox").setEditable(false);

              oView.byId("SaveBtnNBRF").setVisible(false);
              oView.byId("SubmitNewBudgetReqForm").setVisible(false);
              oView.byId("CancelNewBudgetReqForm").setVisible(false);
              oView.byId("ApprovedNewBudgetReqForm").setEnabled(false);
              oView.byId("RejectNewBudgetReqForm").setEnabled(false);
              oView.byId("ApprovedNewBudgetReqForm").setVisible(true);
              oView.byId("RejectNewBudgetReqForm").setVisible(true);
              oView.byId("ForwardNewBudgetReqForm").setVisible(true);

              oView.byId("Recommendedsection").setVisible(true);
              

              // // Fields to disable in both ABR and CR
              // const commonFields = [
              //   "DivisionBox", "LocationBox", "DepartmentInput", "ProjectItemDesInput", "ProjectNameInput", "ItemDescInput",
              //   "ImplementationDateInput", "IRRPaybackInput", "ContactPersonInput", "ContactNumberInput",
              //   "ObjectiveInp", "BackgroundInp", "proposalInp", "DeliverablesInp",
              //   "R1Box", "R2Box", "R3Box",   "SelectRecommendingInput", "Recommended1CB", "Recommended2CB", "Recommended3CB", "Recommended4CB", "Recommended5CB",  "Recommended6CB", "ApprovebyCB", "ProjectCodeCB",
              // ];

              // commonFields.forEach(id => oView.byId(id)?.setEditable(false));

              // // ABR-specific fields
              // if (that.subType === "ABR") {
              //   const abrFields = [
              //     "chkBudgetTransfer", "chkContingency", "chkSavings", "chkCostOverrun", "chkAdvancement",
              //     "AddCapitalBudgetInput", "ApprovalforBudgetBox", "AddBudgetTransferInput", "AddBudgetTransferFromWBSInput",
              //     "AddBudgetTransferToWBSInput", "AddContingencyRequiredInput", "AddCostOverrunInput",
              //     "AddContingencyAllowedInput", "AddUtilisedInput", "AddAvailableInput",
              //     "OriginalIRRPaybackInput", "RevisedIRRPaybackInput", "AddParkedSavingsInput",
              //     "AddParkedSavingsFromWBSInput", "AddParkedSavingsToWBSInput", "AddAdvancementofCAPEXInput",
              //     "AddAdvancementofContingencyInput", "AddApprovedProjectCAPEXInputLakh", "AddTotalProjectCAPEXInput"
              //   ];
              //   abrFields.forEach(id => oView.byId(id)?.setEditable(false));
              // }

              // // CR-specific fields
              // if (that.subType === "CR") {
              //   const crFields = [
              //     "CapitalBudgetInput", "ContingencyBox", "SeekApprovalInput", "RevenueBudgetInput"
              //   ];
              //   crFields.forEach(id => oView.byId(id)?.setEditable(false));
              // }

            } else if ((that.status === "Pending" && that.stagesData === "Recommended By 1") || (that.status === "Pending" && that.stagesData === "Recommended By 2") || (that.status === "Pending" && that.stagesData === "Recommended By 3") || (that.status === "Pending" && that.stagesData === "Recommended By 4") || (that.status === "Pending" && that.stagesData === "Recommended By 5") || (that.status === "Pending" && that.stagesData === "Recommended By 6") || (that.status === "Pending" && that.stagesData === "Approved By")) {

              var oView = that.getView();
              if (that.subType === "ABR") {
                that.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");
                that.getView().byId("ReferenceNumberID").setVisible(true);
                that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
                that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);
              } else if (that.subType === "CR") {
                that.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
                that.getView().byId("ReferenceNumberID").setVisible(true);
                that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
                that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);
              }

              oView.byId("DivisionBox").setEditable(false);

              oView.byId("SaveBtnNBRF").setVisible(false);
              oView.byId("SubmitNewBudgetReqForm").setVisible(false);
              oView.byId("CancelNewBudgetReqForm").setVisible(false);
              oView.byId("ApprovedNewBudgetReqForm").setVisible(true);
              oView.byId("RejectNewBudgetReqForm").setVisible(true);
              oView.byId("ForwardNewBudgetReqForm").setVisible(false);

              oView.byId("Recommendedsection").setVisible(true);
              

              // // Fields to disable in both ABR and CR
              // const commonFields = [
              //   "DivisionBox", "LocationBox", "DepartmentInput", "ProjectItemDesInput", "ProjectNameInput", "ItemDescInput",
              //   "ImplementationDateInput", "IRRPaybackInput", "ContactPersonInput", "ContactNumberInput",
              //   "ObjectiveInp", "BackgroundInp", "proposalInp", "DeliverablesInp",
              //   "R1Box", "R2Box", "R3Box",  "SelectRecommendingInput", "Recommended1CB", "Recommended2CB", "Recommended3CB", "Recommended4CB", "Recommended5CB",  "Recommended6CB", "ApprovebyCB", "ProjectCodeCB",
              // ];

              // commonFields.forEach(id => oView.byId(id)?.setEditable(false));

              // // ABR-specific fields
              // if (that.subType === "ABR") {
              //   const abrFields = [
              //     "chkBudgetTransfer", "chkContingency", "chkSavings", "chkCostOverrun", "chkAdvancement",
              //     "AddCapitalBudgetInput", "ApprovalforBudgetBox", "AddBudgetTransferInput", "AddBudgetTransferFromWBSInput",
              //     "AddBudgetTransferToWBSInput", "AddContingencyRequiredInput", "AddCostOverrunInput",
              //     "AddContingencyAllowedInput", "AddUtilisedInput", "AddAvailableInput",
              //     "OriginalIRRPaybackInput", "RevisedIRRPaybackInput", "AddParkedSavingsInput",
              //     "AddParkedSavingsFromWBSInput", "AddParkedSavingsToWBSInput", "AddAdvancementofCAPEXInput",
              //     "AddAdvancementofContingencyInput", "AddApprovedProjectCAPEXInputLakh", "AddTotalProjectCAPEXInput"
              //   ];
              //   abrFields.forEach(id => oView.byId(id)?.setEditable(false));
              // }

              // // CR-specific fields
              // if (that.subType === "CR") {
              //   const crFields = [
              //     "CapitalBudgetInput", "ContingencyBox", "SeekApprovalInput", "RevenueBudgetInput"
              //   ];
              //   crFields.forEach(id => oView.byId(id)?.setEditable(false));
              // }

            }else if (that.status === "Pending" && that.stagesData === "Initiator"){

              var oView = that.getView();
              if (that.subType === "ABR") {
                that.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");
                that.getView().byId("ReferenceNumberID").setVisible(true);
                that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
                that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);
              } else if (that.subType === "CR") {
                that.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
                that.getView().byId("ReferenceNumberID").setVisible(true);
                that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
                that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);
              }

              oView.byId("DivisionBox").setEditable(false);

              oView.byId("SaveBtnNBRF").setVisible(false);
              oView.byId("SubmitNewBudgetReqForm").setVisible(false);
              oView.byId("CancelNewBudgetReqForm").setVisible(false);
              oView.byId("ApprovedNewBudgetReqForm").setVisible(true);
              oView.byId("RejectNewBudgetReqForm").setVisible(true);
              oView.byId("ForwardNewBudgetReqForm").setVisible(false);

              oView.byId("Recommendedsection").setVisible(true);
              oView.byId("WBSNumberID").setVisible(true);
              oView.byId("WBSNumberInput").setVisible(true);
              oView.byId("WBSNumberInput").setEditable(false);
              

              // Fields to disable in both ABR and CR
              const commonFields = [
                "DivisionBox", "LocationBox", "DepartmentInput", "ProjectItemDesInput", "ProjectNameInput", "ItemDescInput",
                "ImplementationDateInput", "IRRPaybackInput", "ContactPersonInput", "ContactNumberInput",
                "ObjectiveInp", "BackgroundInp", "proposalInp", "DeliverablesInp",
                "R1Box", "R2Box", "R3Box",  "SelectRecommendingInput", "Recommended1CB", "Recommended2CB", "Recommended3CB", "Recommended4CB", "Recommended5CB",  "Recommended6CB", "ApprovebyCB", "ProjectCodeCB",
              ];

              commonFields.forEach(id => oView.byId(id)?.setEditable(false));

              // ABR-specific fields
              if (that.subType === "ABR") {
                const abrFields = [
                  "chkBudgetTransfer", "chkContingency", "chkSavings", "chkCostOverrun", "chkAdvancement",
                  "AddCapitalBudgetInput", "ApprovalforBudgetBox", "AddBudgetTransferInput", "AddBudgetTransferFromWBSInput",
                  "AddBudgetTransferToWBSInput", "AddContingencyRequiredInput", "AddCostOverrunInput",
                  "AddContingencyAllowedInput", "AddUtilisedInput", "AddAvailableInput",
                  "OriginalIRRPaybackInput", "RevisedIRRPaybackInput", "AddParkedSavingsInput",
                  "AddParkedSavingsFromWBSInput", "AddParkedSavingsToWBSInput", "AddAdvancementofCAPEXInput",
                  "AddAdvancementofContingencyInput", "AddApprovedProjectCAPEXInputLakh", "AddTotalProjectCAPEXInput"
                ];
                abrFields.forEach(id => oView.byId(id)?.setEditable(false));
              }

              // CR-specific fields
              if (that.subType === "CR") {
                const crFields = [
                  "CapitalBudgetInput", "ContingencyBox", "SeekApprovalInput", "RevenueBudgetInput"
                ];
                crFields.forEach(id => oView.byId(id)?.setEditable(false));
              } 


            }else if (that.status === "Pending" && that.stagesData === "Asset Team Member"){

              var oView = that.getView();
              if (that.subType === "ABR") {
                that.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");
                that.getView().byId("ReferenceNumberID").setVisible(true);
                that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
                that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);
              } else if (that.subType === "CR") {
                that.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
                that.getView().byId("ReferenceNumberID").setVisible(true);
                that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
                that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);
              }

              oView.byId("DivisionBox").setEditable(false);

              oView.byId("SaveBtnNBRF").setVisible(false);
              oView.byId("SubmitNewBudgetReqForm").setVisible(false);
              oView.byId("CancelNewBudgetReqForm").setVisible(false);
              oView.byId("ApprovedNewBudgetReqForm").setVisible(true);
              oView.byId("RejectNewBudgetReqForm").setVisible(true);
              oView.byId("ForwardNewBudgetReqForm").setVisible(false);

              oView.byId("Recommendedsection").setVisible(true);
              oView.byId("WBSNumberID").setVisible(true);
              oView.byId("WBSNumberInput").setVisible(true);
              oView.byId("WBSNumberInput").setEditable(true);
              

              // Fields to disable in both ABR and CR
              const commonFields = [
                "DivisionBox", "LocationBox", "DepartmentInput", "ProjectItemDesInput", "ProjectNameInput", "ItemDescInput",
                "ImplementationDateInput", "IRRPaybackInput", "ContactPersonInput", "ContactNumberInput",
                "ObjectiveInp", "BackgroundInp", "proposalInp", "DeliverablesInp",
                "R1Box", "R2Box", "R3Box",  "SelectRecommendingInput", "Recommended1CB", "Recommended2CB", "Recommended3CB", "Recommended4CB", "Recommended5CB",  "Recommended6CB", "ApprovebyCB", "ProjectCodeCB",
              ];

              commonFields.forEach(id => oView.byId(id)?.setEditable(false));

              // ABR-specific fields
              if (that.subType === "ABR") {
                const abrFields = [
                  "chkBudgetTransfer", "chkContingency", "chkSavings", "chkCostOverrun", "chkAdvancement",
                  "AddCapitalBudgetInput", "ApprovalforBudgetBox", "AddBudgetTransferInput", "AddBudgetTransferFromWBSInput",
                  "AddBudgetTransferToWBSInput", "AddContingencyRequiredInput", "AddCostOverrunInput",
                  "AddContingencyAllowedInput", "AddUtilisedInput", "AddAvailableInput",
                  "OriginalIRRPaybackInput", "RevisedIRRPaybackInput", "AddParkedSavingsInput",
                  "AddParkedSavingsFromWBSInput", "AddParkedSavingsToWBSInput", "AddAdvancementofCAPEXInput",
                  "AddAdvancementofContingencyInput", "AddApprovedProjectCAPEXInputLakh", "AddTotalProjectCAPEXInput"
                ];
                abrFields.forEach(id => oView.byId(id)?.setEditable(false));
              }

              // CR-specific fields
              if (that.subType === "CR") {
                const crFields = [
                  "CapitalBudgetInput", "ContingencyBox", "SeekApprovalInput", "RevenueBudgetInput"
                ];
                crFields.forEach(id => oView.byId(id)?.setEditable(false));
              } 


            }else if (that.status === "Pending" && that.stagesData === "Corporate Team" && that.oPendingwith === ""){

              const oView = that.getView();
            
              if (!that.AssignpopupDialog) {
                that.AssignpopupDialog = sap.ui.xmlfragment(
                  oView.getId(),
                  "com.mmapprovalhub.approvalhub.Fragments.Assignpopup",
                  that
                );
                oView.addDependent(that.AssignpopupDialog);
              }

              that.getView().byId("R1LabelFrag").setVisible(false);
              that.getView().byId("R1Boxfrag").setVisible(false);
            
              that.getView().byId("R1Boxfrag").setSelectedKey("");
              that.getView().byId("CTBoxfrag").setSelectedKey("");
              that.AssignpopupDialog.open();

            } else if (that.status === "Pending" && that.stagesData === "Corporate Team"){

              var oView = that.getView();
              if (that.subType === "ABR") {
                that.byId("NewBudgetReqFormPage").setTitle("Additional Budget Request");
                that.getView().byId("ReferenceNumberID").setVisible(true);
                that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", true);
                that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", false);
                that.getView().byId("AmountID").setVisible(true);
                that.getView().byId("AmountInput").setVisible(true);
              } else if (that.subType === "CR") {
                that.byId("NewBudgetReqFormPage").setTitle("New Budget Request");
                that.getView().byId("ReferenceNumberID").setVisible(true);
                that.getView().getModel("viewenableddatacheck").setProperty("/disableFormFields", false);
                that.getView().getModel("viewenableddatacheck").setProperty("/enableFormFields", true);
              }

              oView.byId("DivisionBox").setEditable(false);

              oView.byId("SaveBtnNBRF").setVisible(false);
              oView.byId("SubmitNewBudgetReqForm").setVisible(false);
              oView.byId("CancelNewBudgetReqForm").setVisible(false);
              oView.byId("ApprovedNewBudgetReqForm").setVisible(true);
              oView.byId("RejectNewBudgetReqForm").setVisible(true);
              oView.byId("ForwardNewBudgetReqForm").setVisible(false);

              oView.byId("Recommendedsection").setVisible(true);
              oView.byId("WBSNumberID").setVisible(true);
              oView.byId("WBSNumberInput").setVisible(true);
              oView.byId("WBSNumberInput").setEditable(false);

              oView.byId("CorpteamID").setVisible(true);
              oView.byId("CorpteamCB").setVisible(true);
              

              // Fields to disable in both ABR and CR
              const commonFields = [
                "DivisionBox", "LocationBox", "DepartmentInput", "ProjectItemDesInput", "ProjectNameInput", "ItemDescInput",
                "ImplementationDateInput", "IRRPaybackInput", "ContactPersonInput", "ContactNumberInput",
                "ObjectiveInp", "BackgroundInp", "proposalInp", "DeliverablesInp",
                "R1Box", "R2Box", "R3Box",  "SelectRecommendingInput", "Recommended1CB", "Recommended2CB", "Recommended3CB", "Recommended4CB", "Recommended5CB",  "Recommended6CB", "ApprovebyCB", "ProjectCodeCB",
              ];

              commonFields.forEach(id => oView.byId(id)?.setEditable(false));

              // ABR-specific fields
              if (that.subType === "ABR") {
                const abrFields = [
                  "chkBudgetTransfer", "chkContingency", "chkSavings", "chkCostOverrun", "chkAdvancement",
                  "AddCapitalBudgetInput", "ApprovalforBudgetBox", "AddBudgetTransferInput", "AddBudgetTransferFromWBSInput",
                  "AddBudgetTransferToWBSInput", "AddContingencyRequiredInput", "AddCostOverrunInput",
                  "AddContingencyAllowedInput", "AddUtilisedInput", "AddAvailableInput",
                  "OriginalIRRPaybackInput", "RevisedIRRPaybackInput", "AddParkedSavingsInput",
                  "AddParkedSavingsFromWBSInput", "AddParkedSavingsToWBSInput", "AddAdvancementofCAPEXInput",
                  "AddAdvancementofContingencyInput", "AddApprovedProjectCAPEXInputLakh", "AddTotalProjectCAPEXInput"
                ];
                abrFields.forEach(id => oView.byId(id)?.setEditable(false));
              }

              // CR-specific fields
              if (that.subType === "CR") {
                const crFields = [
                  "CapitalBudgetInput", "ContingencyBox", "SeekApprovalInput", "RevenueBudgetInput"
                ];
                crFields.forEach(id => oView.byId(id)?.setEditable(false));
              } 


            }



          } else {
            sap.m.MessageToast.show("No data found for Req ID: " + reqID);
          }
        },
        error: function (oError) {
          sap.m.MessageToast.show("Failed to load HOD data.");
        }
      });
    },

    // onBudgetTransferSelectNBRF: function(oEvent) {
    //   var bSelected = oEvent.getParameter("selected"); 
    //   var oViewModel = this.getView().getModel("viewenableddatacheck");
    //   oViewModel.setProperty("/BudgetTransferRoweditable", bSelected);
    // },
    // onContingencySelectNBRF: function(oEvent) {
    //   var bSelected = oEvent.getParameter("selected"); 
    //   var oViewModel = this.getView().getModel("viewenableddatacheck");
    //   oViewModel.setProperty("/BudgetContingencyRoweditable", bSelected);
    // },
    // onSavingsSelectNBRF: function(oEvent) {
    //   var bSelected = oEvent.getParameter("selected"); 
    //   var oViewModel = this.getView().getModel("viewenableddatacheck");
    //   oViewModel.setProperty("/BudgetSavingsRoweditable", bSelected);
    // },
    // onCostOverrunSelectNBRF: function(oEvent) {
    //   var bSelected = oEvent.getParameter("selected"); 
    //   var oViewModel = this.getView().getModel("viewenableddatacheck");
    //   oViewModel.setProperty("/BudgetCostOverrunRoweditable", bSelected);
    // },
    // onAdvancementSelectNBRF: function(oEvent) {
    //   var bSelected = oEvent.getParameter("selected"); 
    //   var oViewModel = this.getView().getModel("viewenableddatacheck");
    //   oViewModel.setProperty("/BudgetAdvancementRoweditable", bSelected);
    // },

    onBudgetTransferSelectNBRF: function (oEvent) {
      var bSelected = oEvent.getParameter("selected");
      // var oViewModel = this.getView().getModel("viewenableddatacheck");
      // oViewModel.setProperty("/BudgetTransferRoweditable", bSelected);

      if (!bSelected) {
        this.byId("AddBudgetTransferInput").setValue("");
        this.byId("AddBudgetTransferFromWBSInput").setValue("");
        this.byId("AddBudgetTransferToWBSInput").setValue("");
        this.byId("AddBudgetTransferInput").setEditable(false);
        this.byId("AddBudgetTransferFromWBSInput").setEditable(false);
        this.byId("AddBudgetTransferToWBSInput").setEditable(false);
      } else {
        this.byId("AddBudgetTransferInput").setEditable(true);
        this.byId("AddBudgetTransferFromWBSInput").setEditable(true);
        this.byId("AddBudgetTransferToWBSInput").setEditable(true);

      }

      this._updateCalculations();
    },

    onContingencySelectNBRF: function (oEvent) {
      var bSelected = oEvent.getParameter("selected");
      // var oViewModel = this.getView().getModel("viewenableddatacheck");
      // oViewModel.setProperty("/BudgetContingencyRoweditable", bSelected);

      if (!bSelected) {
        this.byId("AddContingencyRequiredInput").setValue("");
        this.byId("AddContingencyAllowedInput").setValue("");
        this.byId("AddUtilisedInput").setValue("");
        this.byId("AddApprovedProjectCAPEXInputLakh").setValue("");
        this.byId("AddContingencyRequiredInput").setEditable(false);
        this.byId("AddContingencyAllowedInput").setEditable(false);
        this.byId("AddUtilisedInput").setEditable(false);
        this.byId("AddApprovedProjectCAPEXInputLakh").setEditable(false);
      } else {
        this.byId("AddContingencyRequiredInput").setEditable(true);
        this.byId("AddContingencyAllowedInput").setEditable(true);
        this.byId("AddUtilisedInput").setEditable(true);
        this.byId("AddApprovedProjectCAPEXInputLakh").setEditable(true);
      }

      this._updateCalculations();
    },

    onSavingsSelectNBRF: function (oEvent) {
      var bSelected = oEvent.getParameter("selected");
      // var oViewModel = this.getView().getModel("viewenableddatacheck");
      // oViewModel.setProperty("/BudgetSavingsRoweditable", bSelected);

      if (!bSelected) {
        this.byId("AddParkedSavingsInput").setValue("");
        this.byId("AddParkedSavingsFromWBSInput").setValue("");
        this.byId("AddParkedSavingsToWBSInput").setValue("");
        this.byId("AddContingencyAllowedInput").setValue("");
        this.byId("AddApprovedProjectCAPEXInputLakh").setValue("");

        this.byId("AddParkedSavingsInput").setEditable(false);
        this.byId("AddParkedSavingsFromWBSInput").setEditable(false);
        this.byId("AddParkedSavingsToWBSInput").setEditable(false);
        this.byId("AddContingencyAllowedInput").setEditable(false);
        this.byId("AddApprovedProjectCAPEXInputLakh").setEditable(false);
      } else {
        this.byId("AddParkedSavingsInput").setEditable(true);
        this.byId("AddParkedSavingsFromWBSInput").setEditable(true);
        this.byId("AddParkedSavingsToWBSInput").setEditable(true);
        this.byId("AddContingencyAllowedInput").setEditable(true);
        this.byId("AddApprovedProjectCAPEXInputLakh").setEditable(true);
      }

      this._updateCalculations();
    },

    onCostOverrunSelectNBRF: function (oEvent) {
      var bSelected = oEvent.getParameter("selected");
      // var oViewModel = this.getView().getModel("viewenableddatacheck");
      // oViewModel.setProperty("/BudgetCostOverrunRoweditable", bSelected);

      if (!bSelected) {
        this.byId("OriginalIRRPaybackInput").setValue("");
        this.byId("RevisedIRRPaybackInput").setValue("");
        this.byId("AddCostOverrunInput").setValue("");
        this.byId("AddAvailableInput").setValue("");
        this.byId("AddContingencyAllowedInput").setValue("");
        this.byId("AddApprovedProjectCAPEXInputLakh").setValue("");

        this.byId("OriginalIRRPaybackInput").setEditable(false);
        this.byId("RevisedIRRPaybackInput").setEditable(false);
        // this.byId("AddCostOverrunInput").setEditable(false);
        // this.byId("AddAvailableInput").setEditable(false);
        this.byId("AddContingencyAllowedInput").setEditable(false);
        this.byId("AddApprovedProjectCAPEXInputLakh").setEditable(false);
      } else {
        this.byId("OriginalIRRPaybackInput").setEditable(true);
        this.byId("RevisedIRRPaybackInput").setEditable(true);
        // this.byId("AddCostOverrunInput").setEditable(true);
        // this.byId("AddAvailableInput").setEditable(true);
        this.byId("AddContingencyAllowedInput").setEditable(true);
        this.byId("AddApprovedProjectCAPEXInputLakh").setEditable(true);
      }

      this._updateCalculations();
    },

    onAdvancementSelectNBRF: function (oEvent) {
      var bSelected = oEvent.getParameter("selected");
      // var oViewModel = this.getView().getModel("viewenableddatacheck");
      // oViewModel.setProperty("/BudgetAdvancementRoweditable", bSelected);

      if (!bSelected) {
        this.byId("AddAdvancementofCAPEXInput").setValue("");
        this.byId("AddAdvancementofContingencyInput").setValue("");
        this.byId("AddApprovedProjectCAPEXInputLakh").setValue("");
        this.byId("AddTotalProjectCAPEXInput").setValue("");

        this.byId("AddAdvancementofCAPEXInput").setEditable(false);
        this.byId("AddAdvancementofContingencyInput").setEditable(false);
        this.byId("AddApprovedProjectCAPEXInputLakh").setEditable(false);
        this.byId("AddTotalProjectCAPEXInput").setEditable(false);
      } else {
        this.byId("AddAdvancementofCAPEXInput").setEditable(true);
        this.byId("AddAdvancementofContingencyInput").setEditable(true);
        this.byId("AddApprovedProjectCAPEXInputLakh").setEditable(true);
        this.byId("AddTotalProjectCAPEXInput").setEditable(true);
      }

      this._updateCalculations();
    },

    onAddCapitalBudgetInputChange: function (oEvent) {
      this._clearValueState("AddCapitalBudgetInput");
      this._updateCalculations();
    },

    onLakhsChange: function (oEvent) {
      this._updateCalculations();
    },

    onAddContingencyRequiredInputChange: function (oEvent) {
      this._validateContingencyRequired();
      this._updateCalculations();
    },

    onAddContingencyAllowedInputChange: function (oEvent) {
      this._updateCalculations();
    },

    onAddUtilisedInputChange: function (oEvent) {
      this._updateCalculations();
    },

    onAddParkedSavingsInputChange: function (oEvent) {
      this._updateCalculations();
    },

    onAddApprovedProjectCAPEXInputLakhChange: function (oEvent) {
      this._updateCalculations();
    },

    _validateContingencyRequired: function () {
      var oView = this.getView();
      var fContingencyRequired = parseFloat(oView.byId("AddContingencyRequiredInput").getValue()) || 0;
      var fContingencyAllowed = parseFloat(oView.byId("AddContingencyAllowedInput").getValue()) || 0;
      var fUtilised = parseFloat(oView.byId("AddUtilisedInput").getValue()) || 0;
      var fAvailable = fContingencyAllowed - fUtilised;

      if (fContingencyRequired > fAvailable && fAvailable >= 0) {
        oView.byId("AddContingencyRequiredInput").setValueState("Error");
        oView.byId("AddContingencyRequiredInput").setValueStateText("Contingency Required should be less than or equal to " + fAvailable.toFixed(2));
      } else {
        oView.byId("AddContingencyRequiredInput").setValueState("None");
      }
    },

    // _updateCalculations: function () {
    //   var oView = this.getView();
    //   var oViewModel = this.getView().getModel("viewenableddatacheck");

    //   // Get values from inputs
    //   var fAdditionalBudget = parseFloat(oView.byId("AddCapitalBudgetInput").getValue()) || 0;
    //   var fBudgetTransfer = parseFloat(oView.byId("AddBudgetTransferInput").getValue()) || 0;
    //   var fContingencyRequired = parseFloat(oView.byId("AddContingencyRequiredInput").getValue()) || 0;
    //   var fContingencyAllowed = parseFloat(oView.byId("AddContingencyAllowedInput").getValue()) || 0;
    //   var fUtilised = parseFloat(oView.byId("AddUtilisedInput").getValue()) || 0;
    //   var fParkedSavings = parseFloat(oView.byId("AddParkedSavingsInput").getValue()) || 0;
    //   var fApprovedProjectCAPEX = parseFloat(oView.byId("AddApprovedProjectCAPEXInputLakh").getValue()) || 0;

    //   // Determine which funding options are selected
    //   var bContingencySelected = oView.byId("chkContingency").getSelected();
    //   var bSavingsSelected = oView.byId("chkSavings").getSelected();
    //   var bCostOverrunSelected = oView.byId("chkCostOverrun").getSelected();

    //   // Contingency Funding: Available = Contingency Allowed - Utilised
    //   var fAvailable = fContingencyAllowed - fUtilised;
    //   oView.byId("AddAvailableInput").setValue(fAvailable.toFixed(2));

    //   // Savings/Cost Over-run Funding: Contingency Allowed = Utilised (auto)
    //   if (bSavingsSelected || bCostOverrunSelected) {
    //     oView.byId("AddContingencyAllowedInput").setValue(fUtilised.toFixed(2));
    //     fContingencyAllowed = fUtilised;
    //     fAvailable = 0;
    //     oView.byId("AddAvailableInput").setValue("0.00");
    //     // Auto-adjust Contingency Required if it exceeds Available
    //     if (fContingencyRequired > fAvailable) {
    //       fContingencyRequired = fAvailable;
    //       oView.byId("AddContingencyRequiredInput").setValue(fContingencyRequired.toFixed(2));
    //     }
    //   }
    //   // Cost Over-run Calculation
    //   if (bCostOverrunSelected) {
    //     var fFormula1 = fAdditionalBudget - fBudgetTransfer - fContingencyRequired - fParkedSavings;
    //     var fFormula2 = (0.1 * fApprovedProjectCAPEX) + fContingencyAllowed;
    //     var fCostOverrun = Math.min(fFormula1, fFormula2);
    //     oView.byId("AddCostOverrunInput").setValue(fCostOverrun.toFixed(2));
    //   }

    //   // Total should equal Additional Budget Required
    //   var fTotal = fAdditionalBudget;
    //   oView.byId("AddTotalInput").setValue(fTotal.toFixed(2));

    //   // Re-validate Contingency Required after updates
    //   this._validateContingencyRequired();
    // },
    onAddCapitalBudgetInputdecimalchange: function (oEvent) {
      this._onaddDecimalPoint(oEvent);
    },
    onAddBudgetTransferInputdecimalchange: function (oEvent) {
      this._onaddDecimalPoint(oEvent);
    },
    onAddContingencyRequiredInputdecimalchange: function (oEvent) {
      this._onaddDecimalPoint(oEvent);
    },

    _onaddDecimalPoint: function (oEvent) {
      const value = oEvent.getParameter("value");
      const input = oEvent.getSource();

      if (!isNaN(value) && value !== "") {
        const formattedValue = parseFloat(value).toFixed(2);
        input.setValue(formattedValue);
      }
    },

    onInputChanged: function () {
      this._calculateTotal();
    },

  //   onRecommenderCountChange: function (oEvent) {
  //     var iCount = parseInt(oEvent.getSource().getValue(), 10);
  
  //     if (isNaN(iCount) || iCount < 1 || iCount > 6) {
  //         sap.m.MessageToast.show("Please enter a number between 1 and 6.");
  //         return;
  //     }
  
  //     // Loop through 6 ComboBoxes
  //     for (var i = 1; i <= 6; i++) {
  //         var oComboBox = this.byId("Recommended" + i + "CB");
  //         if (oComboBox) {
  //             oComboBox.setEditable(i <= iCount); // Enable only up to iCount
  //         }
  //     }
  // },

  onRecommenderCountChange: function (oEvent) {
    var sValue = oEvent.getSource().getValue();
    var iCount = parseInt(sValue, 10);

    // If input is empty or invalid, make all ComboBoxes non-editable
    if (!sValue || isNaN(iCount) || iCount < 1 || iCount > 6) {
        for (var j = 1; j <= 6; j++) {
            var oComboBoxClear = this.byId("Recommended" + j + "CB");
            if (oComboBoxClear) {
                oComboBoxClear.setEditable(false);
                oComboBoxClear.setSelectedKey(""); // optional: clear selection
            }
        }

        if (sValue) {
            sap.m.MessageToast.show("Please enter a number between 1 and 6.");
        }
        return;
    }

    // Loop through 6 ComboBoxes and toggle editability
    for (var i = 1; i <= 6; i++) {
        var oComboBox = this.byId("Recommended" + i + "CB");
        if (oComboBox) {
            oComboBox.setEditable(i <= iCount);
            if (i > iCount) {
                oComboBox.setSelectedKey(""); // optional: clear values beyond iCount
            }
        }
    }
},

    _calculateTotal: function () {
      var that = this;
      var oView = that.getView();
      // Parse all inputs
      var budgetTransfer = parseNumber("AddBudgetTransferInput");
      var contingencyRequired = parseNumber("AddContingencyRequiredInput");
      var parkedSavings = parseNumber("AddParkedSavingsInput");
      var costOverrun = parseNumber("AddCostOverrunInput");
      var advCapex = parseNumber("AddAdvancementofCAPEXInput");
      var advContingency = parseNumber("AddAdvancementofContingencyInput");

      var contingencyAllowed = parseNumber("AddContingencyAllowedInput");
      var utilised = parseNumber("AddUtilisedInput");
      var additionalBudgetRequired = parseNumber("AddCapitalBudgetInput");
      var approvedCapex = parseNumber("AddApprovedProjectCAPEXInputLakh");

      function parseNumber(id) {
        var value = that.getView().byId(id)?.getValue() || "0";
        return parseFloat(value) || 0;
      }

      var isContingencyChecked = that.getView().byId("chkContingency").getSelected();
      if (isContingencyChecked === true) {

        var available = contingencyAllowed - utilised;
        oView.byId("AddAvailableInput").setValue(available.toFixed(2));

        if (contingencyRequired > available) {
          MessageBox.error("Contingency Required  value should be less than or equal to difference of Contingency Allowed and Utilised value.");
        }
      }

      var isSavingsChecked = that.getView().byId("chkSavings").getSelected();
      if (isSavingsChecked === true) {

        let utilizedFromSavings = 0;
        if (parkedSavings >= contingencyAllowed) {
          utilizedFromSavings = contingencyAllowed;
        } else {
          utilizedFromSavings = parkedSavings;
        }

        oView.byId("AddUtilisedInput")?.setValue(utilizedFromSavings.toFixed(2));

        const available = contingencyAllowed - utilizedFromSavings;
        oView.byId("AddAvailableInput")?.setValue(available.toFixed(2));
      } else {
        oView.byId("AddUtilisedInput")?.setValue(0.00);
        oView.byId("AddAvailableInput")?.setValue(0.00);
      }


      var isAdvancementChecked = that.getView().byId("chkAdvancement").getSelected();
      if (isAdvancementChecked === true) {
        var capexInput = that.getView().byId("AddAdvancementofCAPEXInput").getValue();
        var contingencyInput = that.getView().byId("AddAdvancementofContingencyInput").getValue();
        var additionalBudgetRequired = parseFloat(that.getView().byId("AddCapitalBudgetInput").getValue());

        if (capexInput !== "" && contingencyInput !== "") {
          var advCapex = parseFloat(capexInput);
          var advContingency = parseFloat(contingencyInput);
          var totalAdvancement = advCapex + advContingency;

          if (totalAdvancement !== additionalBudgetRequired) {
            MessageBox.error(
              "The total advancement (CAPEX + Contingency) must be equal to the Additional Budget Required (" +
              additionalBudgetRequired + ")."
            );
          }
        }
      }

      var isCostOverrunChecked = that.getView().byId("chkCostOverrun").getSelected();
      if (isCostOverrunChecked) {

        var tenPercentTotal = (approvedCapex + contingencyAllowed) * 0.10;

        var calculatedValue = additionalBudgetRequired - budgetTransfer - contingencyRequired - parkedSavings;

        var costOverrun = Math.min(tenPercentTotal, calculatedValue);

        var oUtilised = contingencyAllowed;

        costOverrun = Math.max(costOverrun, 0);

        oView.byId("AddCostOverrunInput").setValue(costOverrun.toFixed(2));

      } else {
        oView.byId("AddCostOverrunInput").setValue(0.00);
      }

      if (isCostOverrunChecked && !isContingencyChecked) {
        oView.byId("AddUtilisedInput").setValue(oUtilised.toFixed(2));
      }

  
      // Reset total before calculating
      var total = 0;

      // Define sources
      var budgetSources = [
        {
          checkboxId: "chkBudgetTransfer",
          label: "Budget Transfer",
          amount: parseNumber("AddBudgetTransferInput")
        },
        {
          checkboxId: "chkContingency",
          label: "Contingency",
          amount: parseNumber("AddContingencyRequiredInput")
        },
        {
          checkboxId: "chkSavings",
          label: "Parked Savings",
          amount: parseNumber("AddParkedSavingsInput")
        },
        {
          checkboxId: "chkCostOverrun",
          label: "Cost Overrun",
          amount: parseNumber("AddCostOverrunInput")
        },
        {
          checkboxId: "chkAdvancement",
          label: "Advancement",
          amount: parseNumber("AddAdvancementofCAPEXInput") + parseNumber("AddAdvancementofContingencyInput")
        }
      ];

      // For logging selected sources
      var selectedSources = [];

      // Calculate total based on currently selected checkboxes
      budgetSources.forEach(function (source) {
        var isChecked = that.getView().byId(source.checkboxId).getSelected();
        if (isChecked) {
          total += source.amount;
          selectedSources.push(source.label + ": " + source.amount);
        }
      });

      // Update Total input
      oView.byId("AddTotalInput").setValue(total.toFixed(2));


      // Final validation
      if (selectedSources.length > 0) {
        if (total !== additionalBudgetRequired) {
          MessageBox.error("Total Value should be equal to Additional Budget Required Value.\n\nBreakdown:\n" + selectedSources.join("\n"));
        } else {
          MessageToast.show("Total allocation is valid.\nBreakdown:\n" + selectedSources.join("\n"));
        }
      }

    },

    attachmentuploadFilesData: function (reqid) {
      var oModelTabdata = this.getView().getModel("UploadDocSrvTabData");
      var aFilesData = oModelTabdata.getProperty("/attachments") || [];
      var oModel = this.getOwnerComponent().getModel("approvalservicev2");
      sap.ui.core.BusyIndicator.show(0);

      aFilesData.forEach(function (file) {
        if (!file.fileName || file.uploaded) return;

        if (file.content && typeof file.content === "string" && file.content.includes(',')) {
          var base64Content = file.content.split(',')[1];
          var payload = {
            fileName: file.fileName,
            content: base64Content,
            mediaType: file.mimeType || "text/plain",
            reqID: reqid
          };

          oModel.create("/ReqAttachments", payload, {
            success: function () {
              file.uploaded = true;
              oModelTabdata.refresh(true);
              sap.ui.core.BusyIndicator.hide();
            },
            error: function (oError) {
              MessageToast.show("Error uploading attachment: " + file.fileName, { position: "bottom center" });
              console.error("Error uploading attachment:", oError);
              sap.ui.core.BusyIndicator.hide();
            }
          });
        }
      });
    },


  });
});
