sap.ui.define([], function() {
    "use strict";
  
    return {
      isFuelRequestAndInitiateFRS: function(approvalType, initiationKey) {
        return approvalType === "Fuel Request" && initiationKey === "Initiate FRS";
      },
      isConsumableRequestAndInitiateCRS: function(approvalType, initiationKey) {
        return approvalType === "Consumable Request" && initiationKey === "Initiate CRS";
      },
      isStationaryRequestAndInitiateSRS: function(approvalType, initiationKey) {
        return approvalType === "Stationary Request" && initiationKey === "Initiate SRS";
      },
      isWasteDisposalRequestAndInitiateWDRS: function(approvalType, initiationKey) {
        return approvalType === "Waste Disposal Request" && initiationKey === "Initiate WDRS";
      },
  
  
  
    };
  });
  